<?php
include 'accessFRG.php';

function base64UrlEncode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}
$Id              = $_POST['id'];
$message         = $_POST['message'];
$recipientName   = "Lakshan Singh "; 
$recipientEmail  = "sonukashya6398@gmail.com"; 
$subject         = "New Contact Creation in Zoho Crm"; 
$messageBody     = "Hello, MR. $recipientName new $message in your zoho Crm \n and ID is $Id "; 


$rawEmail = "From: \"Lakshan\" <laksansingh235@gmail.com>\r\n" .
            "To: \"$recipientName\" <$recipientEmail>\r\n" .
            "Subject: $subject\r\n" .
            "MIME-Version: 1.0\r\n" .
            "Content-Type: text/plain; charset=UTF-8\r\n\r\n" .
            "$messageBody\r\n";


$encodedEmail = base64UrlEncode($rawEmail);


 "Encoded Email:\n$encodedEmail\n";

$accessToken = $data1['access_token']; 

$url = 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send';

$data = [
    'raw' => $encodedEmail 
];


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $accessToken, 
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));


$response = curl_exec($ch);


if(curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
} else {
    
    echo "API Response:\n$response\n";
}


curl_close($ch);

?>
