<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<style>
* {
  box-sizing: border-box;
}

body {
  background-color: #f1f1f1;
}

#regForm {
  background-color: #ffffff;
  margin: 100px auto;
  font-family: Raleway;
  padding: 40px;
  width: 70%;
  min-width: 300px;
}

h1 {
  text-align: center;
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that get an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

button {
  background-color: #04AA6D;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #04AA6D;
}

.error {
  color: red;
}
</style>
<body>

<form id="regForm"  method="POST">
  <h1>Register:</h1>
  
  <div class="tab">
  <p>Name:-</p>
    <p><input placeholder="First name..." oninput="checkfname()" name="fname" id="fname"> <span class="error" id="fnameerr"></span></p>
    <p><input placeholder="Last name..." oninput="checklname()" name="lname" id="lname"><span class="error" id="lnameerr"></span></p>
    <p><input placeholder="E-mail..." oninput="checkemail()" name="email" id="email"><span class="error" id="emailerr"></span></p>
    <p><input placeholder="Phone..." oninput="checkphone()" name="phone" id="phone" maxlength="10"><span class="error" id="phoneerr"></span></p>
  </div>

  <div class="tab">
    <label for="contact-info">Lead Info:</label>
    <p><input placeholder="Lead Source" oninput="checklead()" name="lead_source" id="source"><span class="error" id="leaderr"></span></p>
    <p><input placeholder="Designation" oninput="checkdesignation()" name="designation" id="designation"><span class="error" id="designationerr"></span></p>
    <p><input placeholder="Account Name" oninput="checkaccount()" name="account_name" id="account"><span class="error" id="accounterr"></span></p>
  </div>

  <div class="tab">
    <label for="address">Address info:</label>
    <p><input placeholder="Mailing Address" oninput="checkmailadd()" name="mail_address" id="mail_add"><span class="error" id="mail_adderr"></span></p>
    <p><input placeholder="Mailing City" oninput="checkcity()" name="mail_city" id="city"><span class="error" id="cityerr"></span></p>
    <p><input placeholder="Mailing State" oninput="checkcity()" name="mail_state" id="state"><span class="error" id="stateerr"></span></p>
    <p><input placeholder="Mailing Zip" oninput="checkzip()" name="mail_zip" id="zip"><span class="error" id="ziperr"></span></p>
    <p><input placeholder="Mailing Country" oninput="checkcountry()" name="mail_country" id="country"><span class="error" id="countryerr"></span></p>
  </div>

  <!-- Navigation buttons -->
  <div style="overflow:auto;">
    <div style="float:right;" id="buttons">
      <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
      <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
    </div>
  </div>

  <div style="text-align:center;margin-top:40px;">
    <span class="step"></span>
    <span class="step"></span>
    <span class="step"></span>
  </div>
</form>

<script>
function validateForm() {
  // Function to run all validation checks
  checkfname();
  checklname();
  checkemail();
  checkphone();
  checklead();
  checkdesignation();
  checkaccount();
  checkmailadd();
  checkcity();
  checkstate();
  checkzip();
  checkcountry();
  return (
    checkfname() &&
    checklname() &&
    checkemail() &&
    checkphone() &&
    checklead() &&
    checkdesignation() &&
    checkaccount() &&
    checkmailadd() &&
    checkcity() &&
    checkstate() &&
    checkzip() &&
    checkcountry()
  );
}


let currentTab = 0;
showTab(currentTab);

function showTab(n) {
  let tabs = document.getElementsByClassName("tab");
  tabs[n].style.display = "block";
  document.getElementById("prevBtn").style.display = n == 0 ? "none" : "inline";
  document.getElementById("nextBtn").innerHTML = n == (tabs.length-1) ? "Submit" : "Next";
  fixStepIndicator(n);
  
  if (tabs.length==n) {
    $(document).on('click','#nextBtn',function () {
      
 
  // if (!validateForm()) {
  //   alert("please check the erros or requierd feilds");
  //   return false;
  // } else {
    
    let formData=$('#regForm').serialize();
    $.ajax({
      url:"sample.php",
      method:"POST",
      data:formData,
      
      success:function(mydata){
        alert(mydata);
        alert("submitted successfully");
        
      }
    })
  // }
 })
}

}

function nextPrev(n) {
  let tabs = document.getElementsByClassName("tab");
  if (n == 1 && !validateForm()) return false;
  tabs[currentTab].style.display = "none";
  currentTab += n;
  if (currentTab >= tabs.length) {
    document.getElementById("regForm").submit();
    return false;
  }
  showTab(currentTab);
}

function validateForm() {
  let valid = true;
  if (currentTab == 0) {
    valid = checkfname() && checklname() && checkemail() && checkphone();
  }
  if (currentTab == 1) {
    valid = checklead() && checkdesignation() && checkaccount();
  }
  if (currentTab == 2) {
    valid = checkmailadd() && checkcity() && checkstate() && checkzip() && checkcountry();
  }
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid;
}

function fixStepIndicator(n) {
  let steps = document.getElementsByClassName("step");
  for (let i = 0; i < steps.length; i++) {
    steps[i].className = steps[i].className.replace(" active", "");
  }
  steps[n].className += " active";
}

// Validation functions

function checkfname() {
  let pattern = /^[a-zA-Z]+$/;
  let fname = $('#fname').val();
  let validfname = pattern.test(fname);
  
  if (fname == '') {
      $("#fnameerr").text("Please enter your first name");
      return false;
  } 
  if (!validfname) {
      $("#fnameerr").text("Please enter a valid first name");
      return false;
  }
  $("#fnameerr").text("");
  return true;
}

function checklname() {
  let pattern = /^[a-zA-Z]+$/;
  let lname = $('#lname').val();
  let validlname = pattern.test(lname);
  
  if (lname == '') {
      $("#lnameerr").text("Please enter your last name");
      return false;
  } 
  if (!validlname) {
      $("#lnameerr").text("Please enter a valid last name");
      return false;
  }
  $("#lnameerr").text("");
  return true;
}

function checkemail() {
  let pattern = /^[\w.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  let email = $('#email').val();
  let validemail = pattern.test(email);

  if (email == '') {
      $("#emailerr").text("Please enter your email");
      return false;
  } 
  if (!validemail) {
      $("#emailerr").text("Please enter a valid email address");
      return false;
  }
  $("#emailerr").text("");
  return true;
}

function checkphone() {
  let pattern = /^[0-9]{10}$/; // Example: Validates 10 digit phone numbers
  let phone = $('#phone').val();
  let validphone = pattern.test(phone);

  if (phone == "") {
      $("#phoneerr").text("Please enter a mobile number");
      return false;
  }
  if (!validphone) {
      $('#phoneerr').text("Please enter a valid mobile number");
      return false;
  }
  $("#phoneerr").text("");
  return true;
}

function checklead() {
  let pattern = /^[a-zA-Z\s]+$/;  // Allows spaces between words
  let lead = $('#source').val();
  let validlead = pattern.test(lead);

  if (lead == "") {
      $("#leaderr").text("Please enter a lead source");
      return false;
  }
  if (!validlead) {
      $('#leaderr').text("Please enter a valid lead source");
      return false;
  }
  $("#leaderr").text("");
  return true;
}

function checkdesignation() {
  let pattern = /^[a-zA-Z\s]+$/;
  let designation = $('#designation').val();
  let validdesignation = pattern.test(designation);

  if (designation == "") {
      $("#designationerr").text("Please enter a designation");
      return false;
  }
  if (!validdesignation) {
      $('#designationerr').text("Please enter a valid designation");
      return false;
  }
  $('#designationerr').text("");
  return true;
}

function checkaccount() {
  let pattern = /^[a-zA-Z\s]+$/;
  let account = $('#account').val();
  let validaccount = pattern.test(account);

  if (account == "") {
      $("#accounterr").text("Please enter an account name");
      return false;
  }
  if (!validaccount) {
      $("#accounterr").text("Please enter a valid account name");
      return false;
  }
  $("#accounterr").text("");
  return true;
}

function checkmailadd() {
  let pattern = /^[a-zA-Z\s]+$/;
  let mail_add = $('#mail_add').val();
  let validmail_add = pattern.test(mail_add);

  if (mail_add == "") {
      $("#mail_adderr").text("Please enter a mailing address");
      return false;
  }
  if (!validmail_add) {
      $("#mail_adderr").text("Please enter a valid mailing address");
      return false;
  }
  $("#mail_adderr").text("");
  return true;
}

function checkcity() {
  let pattern = /^[a-zA-Z\s]+$/;
  let city = $('#city').val();
  let validcity = pattern.test(city);

  if (city == "") {
      $("#cityerr").text("Please enter a city");
      return false;
  }
  if (!validcity) {
      $("#cityerr").text("Please enter a valid city name");
      return false;
  }
  $("#cityerr").text("");
  return true;
}

function checkstate() {
  let pattern = /^[a-zA-Z\s]+$/;
  let state = $('#state').val();
  let validstate = pattern.test(state);

  if (state == "") {
      $("#stateerr").text("Please enter a state");
      return false;
  }
  if (!validstate) {
      $("#stateerr").text("Please enter a valid state name");
      return false;
  }
  $("#stateerr").text("");
  return true;
}

function checkzip() {
  let pattern = /^[0-9]+$/; 
  let zip = $('#zip').val();
  let validzip = pattern.test(zip);

  if (zip == "") {
      $("#ziperr").text("Please enter a ZIP code");
      return false;
  }
  if (!validzip) {
      $("#ziperr").text("Please enter a valid ZIP code");
      return false;
  }
  $("#ziperr").text("");
  return true;
}

function checkcountry() {
  let pattern = /^[a-zA-Z\s]+$/;
  let country = $('#country').val();
  let validcountry = pattern.test(country);

  if (country == "") {
      $("#countryerr").text("Please enter a country");
      return false;
  }
  if (!validcountry) {
      $("#countryerr").text("Please enter a valid country name");
      return false;
  }
  $("#countryerr").text("");
  return true;
}


</script>

</body>
</html>
