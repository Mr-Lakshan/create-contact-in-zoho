
<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
  * {
      box-sizing: border-box;
    }

    body {
      background-color: #121212; /* Dark background */
      color: white; /* White text */
      font-family: Raleway, sans-serif;
    }

    #editForm{
      background-color: #1c1c1c; /* Dark background for form */
      margin: 100px auto;
      padding: 40px;
      width: 70%;
      min-width: 300px;
      border-radius: 8px; /* Rounded corners */
      border: 2px solid #f1c40f; /* Golden border */
    }

    h1 {
      text-align: center;
      color: #f1c40f; /* Golden text for header */
    }

    input {
      padding: 12px;
      width: 100%;
      font-size: 17px;
      font-family: Raleway;
      border: 1px solid #333; /* Dark border */
      background-color: #2d2d2d; /* Dark input fields */
      color: white;
    }

    input.invalid {
      background-color: #e74c3c; /* Red background on error */
    }

    .tab {
      display: none;
    }

    button {
      background-color: #f1c40f; /* Golden button */
      color: #121212; /* Black text on golden background */
      border: none;
      padding: 10px 20px;
      font-size: 17px;
      cursor: pointer;
      border-radius: 4px;
    }

    button:hover {
      opacity: 0.8;
    }

    #prevBtn {
      background-color: #7f8c8d; /* Dark gray for previous button */
    }

    .step {
      height: 15px;
      width: 15px;
      margin: 0 2px;
      background-color: #f39c12; /* Golden circles */
      border: none;
      border-radius: 50%;
      display: inline-block;
      opacity: 0.5;
    }

    .step.active {
      opacity: 1;
    }

    .step.finish {
      background-color: #f1c40f; /* Golden circles for finished steps */
    }

    .error {
      color: #e74c3c; /* Red text for error messages */
    }

    .success {
      background-color: #27ae60; /* Green background for success */
      margin-left: 30%;
      margin-right: 25%;
      margin-top: 10%;
      height: 50px;
      width: 300pt;
      padding-left: 10%;
      color: white;
      text-align: center;
      line-height: 50px;
      border-radius: 5px;
    }

    .errors {
      background-color: #e74c3c; /* Red background for errors */
      margin-left: 30%;
      margin-right: 25%;
      margin-top: 10%;
      height: 50px;
      width: 300pt;
      padding-left: 10%;
      color: white;
      text-align: center;
      line-height: 50px;
      border-radius: 5px;
    }

    #massage {
      display: none;
    }
</style>
<body>
<div id="massage"></div>
<form id="editForm" action="">
  <h1>Update-Details:</h1>
  <!-- One "tab" for each step in the form: -->
  <div class="tab">Name:
    <input type="hidden" name="edit_id" id="id" value="">
    <p><input placeholder="First name..." oninput="this.className = ''" name="fname" id="fname" value = ""><span class="error" id="fnameerr"></span></p>
    <p><input placeholder="Last name..." oninput="this.className = ''" name="lname" id="lname" value=""><span class="error" id="lnameerr"></span></p>
    <p><input placeholder="E-mail..." oninput="this.className = ''" name="email" id="email" value=""><span class="error" id="emailerr"></span></p>
    <p><input placeholder="Phone..." oninput="this.className = ''" name="phone" id="phone" value=""><span class="error" id="phoneerr"></span></p></p>
  </div>
  <div class="tab"> Lead Details:
    <p><input placeholder="Lead Source" oninput="this.className = ''" name="lead_source" id="source" value=""><span class="error" id="leaderr"></span></p>
    <p><input placeholder="Designation" oninput="this.className = ''" name="designation" id="designation" value=""><span class="error" id="designationerr"></span></p>
    <p><input placeholder="Account Name" oninput="this.className = ''" name="account_name" id="account" value=""><span class="error" id="accounterr"></span></p>
  </div>
  <div class="tab">Address Details:
    <p><input placeholder="Mailing Address" oninput="this.className = ''" name="mail_address" id="mail_add" value=""><span class="error" id="mail_adderr"></span></p>
    <p><input placeholder="Mailing City" oninput="this.className = ''" name="mail_city" id="city" value=""><span class="error" id="cityerr"></span></p>
    <p><input placeholder="Mailing State" oninput="this.className = ''" name="mail_state" id="state" value=""><span class="error" id="stateerr"></span></p>
    <p><input placeholder="Mailing Zip" oninput="this.className = ''" name="mail_zip" id="zip" value=""><span class="error" id="ziperr"></span></p>
    <p><input placeholder="Mailing Country" oninput="this.className = ''" name="mail_country" id="country" value=""><span class="error" id="countryerr"></span></p>
  </div>

  <div style="overflow:auto;">
    <div style="float:right;">
      <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
      <button type="button" class="nxtbtn" id="nextBtn" onclick="nextPrev(1)">Next</button>
    </div>
  </div>
  <!-- Circles which indicates the steps of the form: -->
  <div style="text-align:center;margin-top:40px;">
    <span class="step"></span>
    <span class="step"></span>
    <span class="step"></span>
  </div>
</form>

<script>
  $(document).ready(function () {
    let Id = sessionStorage.getItem("Id");
    $.ajax({
        url:     'getsinglecontact.php',
        method:  'GET',
        data:    {Id},
        success: function (response) {

        let data = JSON.parse(response);
       console.log(response);
    
        let fullname = data.data[0].Full_Name;
        let name     = fullname.split(" ");
        let Id = sessionStorage.getItem("Id");
        $('#id').val(Id);
        $('#fname').val(name[0]);
        $('#lname').val(name[1]);
        $('#email').val(data.data[0].Email);
        $('#phone').val(data.data[0].Phone);
        $('#source').val(data.data[0].Lead_Source); 
        $('#designation').val(data.data.Designation);
        $('#account').val(data.data[0].Account_Name.name);
        $('#mail_add').val(data.data[0].Mailing_Street);
        $('#zip').val(data.data[0].Mailing_Zip);
        $('#city').val(data.data[0].Mailing_City);
        $('#state').val(data.data[0].Mailing_State);
        $('#country').val(data.data[0].Mailing_Country);
        }
    })
   
  checksteps();
    $('#fname').on('input', function() { checkfname(); saveToLocalStorage(); });
    $('#lname').on('input', function() { checklname(); saveToLocalStorage(); });
    $('#email').on('input', function() { checkemail(); saveToLocalStorage(); });
    $('#phone').on('input', function() { checkphone(); saveToLocalStorage(); });
    $('#source').on('input', function() { checklead(); saveToLocalStorage(); });
    $('#designation').on('input', function() { checkdesignation(); saveToLocalStorage(); });
    $('#account').on('input', function() { checkaccount(); saveToLocalStorage(); });
    $('#mail_add').on('input', function() { checkmailadd(); saveToLocalStorage(); });
    $('#city').on('input', function() { checkcity(); saveToLocalStorage(); });
    $('#state').on('input', function() { checkstate(); saveToLocalStorage(); });
    $('#zip').on('input', function() { checkzip(); saveToLocalStorage(); });
    $('#country').on('input', function() { checkcountry(); saveToLocalStorage(); });

    
    loadFromLocalStorage();
   
  });
 

  function saveToLocalStorage() {
    localStorage.setItem('fname', $('#fname').val());
    localStorage.setItem('lname', $('#lname').val());
    localStorage.setItem('email', $('#email').val());
    localStorage.setItem('phone', $('#phone').val());
    localStorage.setItem('lead_source', $('#source').val());
    localStorage.setItem('designation', $('#designation').val());
    localStorage.setItem('account_name', $('#account').val());
    localStorage.setItem('mail_address', $('#mail_add').val());
    localStorage.setItem('mail_city', $('#city').val());
    localStorage.setItem('mail_state', $('#state').val());
    localStorage.setItem('mail_zip', $('#zip').val());
    localStorage.setItem('mail_country', $('#country').val());
  }

  // Load form data from localStorage
  function loadFromLocalStorage() {
    if (localStorage.getItem('fname')) $('#fname').val(localStorage.getItem('fname'));
    if (localStorage.getItem('lname')) $('#lname').val(localStorage.getItem('lname'));
    if (localStorage.getItem('email')) $('#email').val(localStorage.getItem('email'));
    if (localStorage.getItem('phone')) $('#phone').val(localStorage.getItem('phone'));
    if (localStorage.getItem('lead_source')) $('#source').val(localStorage.getItem('lead_source'));
    if (localStorage.getItem('designation')) $('#designation').val(localStorage.getItem('designation'));
    if (localStorage.getItem('account_name')) $('#account').val(localStorage.getItem('account_name'));
    if (localStorage.getItem('mail_address')) $('#mail_add').val(localStorage.getItem('mail_address'));
    if (localStorage.getItem('mail_city')) $('#city').val(localStorage.getItem('mail_city'));
    if (localStorage.getItem('mail_state')) $('#state').val(localStorage.getItem('mail_state'));
    if (localStorage.getItem('mail_zip')) $('#zip').val(localStorage.getItem('mail_zip'));
    if (localStorage.getItem('mail_country')) $('#country').val(localStorage.getItem('mail_country'));
  }

  var currentTab = 0; 
showTab(currentTab); 

function nextPrev(n) {
  var x = document.getElementsByClassName("tab");

  if (n == 1 && !validateForm()) return false;


  x[currentTab].style.display = "none";

  
  currentTab = currentTab + n;
  checksteps();



  if (currentTab >= x.length) {
    Swal.fire({
  title: 'Are you want to update the data?',
  text: 'You are updating the details',
  icon: 'warning',
  showCancelButton: true,  
  confirmButtonText: 'Yes, Update it!',  
  cancelButtonText: 'No, keep it'  
}).then((result) => {
  if (result.isConfirmed) {
    let id = sessionStorage.getItem("Id");
   
    let formData = $('#editForm').serialize();
    $("#editForm").hide();
    $('#massage').show();
    $.ajax({
      url: "editcontact.php",
      method: "POST",
      data: formData,
      success: function (response) {
        
        if (typeof response === 'string') {
            response = JSON.parse(response);
        }
        var message = response.data[0].message;
        var status  = response.data[0].status;
        if (status == 'error'){
          $('#massage').text(message).addClass('errors');
        }
        else {
          $('#massage').text(message).addClass('success');
        }
        localStorage.clear();
        sessionStorage.clear()
        setTimeout(function() {
          $('#massage').fadeOut();
          
        //   $('body').load('test.php');
        }, 4000,window.location.href = 'Showcontacts.php');
        
  
        
      }
    });
    
  } else if (result.isDismissed) {
    currentTab = x.length - 1;
      showTab(currentTab);
      return false;
    
  }
});
      

    
    
    return; 
  }


  showTab(currentTab);
  
}


function showTab(n) {
  var x = document.getElementsByClassName("tab");

  if (n < 0 || n >= x.length) {
    console.error("Invalid tab index:", n);
    return;
  }


  for (var i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }

 
  x[n].style.display = "block";

  
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }

  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }


  fixStepIndicator(n);
}

function fixStepIndicator(n) {
  // Ensure all steps are reset before updating the active step
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }

  
  if (x[n]) {
    x[n].className += " active";
  } else {
    console.error("Step element not found for index", n);
  }
}



function validateForm() {
  let valid = true;
  if (currentTab == 0) {
    valid = checkfname() && checklname() && checkemail() && checkphone();
  }
  if (currentTab == 1) {
    valid = checklead() && checkdesignation() && checkaccount();
  }
  if (currentTab == 2) {
    valid = checkmailadd() && checkcity() && checkstate() && checkzip() && checkcountry();
  }
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid;
}
function checksteps() {
  $('.nxtbtn').off('click');
  if (currentTab==0) {
  $('.nxtbtn').click(function () {
    checkfname() || checklname() || checkemail() || checkphone();
  })
  }
  if (currentTab==1) {
   
  $('.nxtbtn').click(function () {
    checklead() || checkdesignation() || checkaccount();
  })
  }
  if (currentTab == 2) {
  
    $('.nxtbtn').click(function () {
      
      
      checkmailadd() || checkcity() || checkstate() || checkzip() || checkcountry();
      
    })
    }
 
}

  function checkfname() {
    let pattern = /^[a-zA-Z]+$/;
    let fname = $('#fname').val();
    let validfname = pattern.test(fname);

    if (fname == '') {
      $("#fnameerr").text("Please enter your first name");
      return false;
    }
    if (!validfname) {
      $("#fnameerr").text("Please enter a valid first name");
      return false;
    }
    $("#fnameerr").text("");
    return true;
  }

  function checklname() {
    let pattern = /^[a-zA-Z]+$/;
    let lname = $('#lname').val();
    let validlname = pattern.test(lname);

    if (lname == '') {
      $("#lnameerr").text("Please enter your last name");
      return false;
    }
    if (!validlname) {
      $("#lnameerr").text("Please enter a valid last name");
      return false;
    }
    $("#lnameerr").text("");
    return true;
  }

  function checkemail() {
    let pattern = /^[\w.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    let email = $('#email').val();
    let validemail = pattern.test(email);

    if (email == '') {
      $("#emailerr").text("Please enter your email");
      return false;
    }
    if (!validemail) {
      $("#emailerr").text("Please enter a valid email address");
      return false;
    }
    $("#emailerr").text("");
    return true;
  }

  function checkphone() {
    let pattern = /^[0-9]{10}$/;
    let phone = $('#phone').val();
    let validphone = pattern.test(phone);

    if (phone == "") {
      $("#phoneerr").text("Please enter a mobile number");
      return false;
    }
    if (!validphone) {
      $('#phoneerr').text("Please enter a valid mobile number");
      return false;
    }
    $("#phoneerr").text("");
    return true;
  }

  function checklead() {
    let pattern = /^[a-zA-Z\s]+$/;
    let lead = $('#source').val();
    let validlead = pattern.test(lead);

    if (lead == "") {
      $("#leaderr").text("Please enter a lead source");
      return false;
    }
    if (!validlead) {
      $('#leaderr').text("Please enter a valid lead source");
      return false;
    }
    $("#leaderr").text("");
    return true;
  }

  function checkdesignation() {
    let pattern = /^[a-zA-Z\s]+$/;
    let designation = $('#designation').val();
    let validdesignation = pattern.test(designation);

    if (designation == "") {
      $("#designationerr").text("Please enter a designation");
      return false;
    }
    if (!validdesignation) {
      $('#designationerr').text("Please enter a valid designation");
      return false;
    }
    $('#designationerr').text("");
    return true;
  }

  function checkaccount() {
    let pattern = /^[a-zA-Z\s]+$/;
    let account = $('#account').val();
    let validaccount = pattern.test(account);

    if (account == "") {
      $("#accounterr").text("Please enter an account name");
      return false;
    }
    if (!validaccount) {
      $("#accounterr").text("Please enter a valid account name");
      return false;
    }
    $("#accounterr").text("");
    return true;
  }

  function checkmailadd() {
    let pattern = /^[a-zA-Z0-9\s,.\-\/#&()]+(\r?\n[a-zA-Z0-9\s,.\-\/#&()]+)*$/;
    let mail_add = $('#mail_add').val();
    let validmail_add = pattern.test(mail_add);

    if (mail_add == "") {
      $("#mail_adderr").text("Please enter a mailing address");
      return false;
    }
    if (!validmail_add) {
      $("#mail_adderr").text("Please enter a valid mailing address");
      return false;
    }
    $("#mail_adderr").text("");
    return true;
  }

  function checkcity() {
    let pattern = /^[a-zA-Z\s]+$/;
    let city = $('#city').val();
    let validcity = pattern.test(city);

    if (city == "") {
      $("#cityerr").text("Please enter a city");
      return false;
    }
    if (!validcity) {
      $("#cityerr").text("Please enter a valid city name");
      return false;
    }
    $("#cityerr").text("");
    return true;
  }

  function checkzip() {
    let pattern = /^[0-9]{6}$/;
    let zip = $('#zip').val();
    let validzip = pattern.test(zip);

    if (zip == "") {
      $("#ziperr").text("Please enter a ZIP code");
      return false;
    }
    if (!validzip) {
      $("#ziperr").text("Please enter a valid ZIP code");
      return false;
    }
    $("#ziperr").text("");
    return true;
  }

  function checkcountry() {
    let pattern = /^[a-zA-Z\s]+$/;
    let country = $('#country').val();
    let validcountry = pattern.test(country);

    if (country == "") {
      $("#countryerr").text("Please enter a country");
      return false;
    }
    if (!validcountry) {
      $("#countryerr").text("Please enter a valid country name");
      return false;
    }
    $("#countryerr").text("");
    return true;
  }
  function checkstate() {
  let pattern = /^[a-zA-Z\s]+$/;
  let state = $('#state').val();
  let validstate = pattern.test(state);

  if (state == "") {
      $("#stateerr").text("Please enter a state");
      return false;
  }
  if (!validstate) {
      $("#stateerr").text("Please enter a valid state name");
      return false;
  }
  $("#stateerr").text("");
  return true;
}


</script>

</body>
</html>
