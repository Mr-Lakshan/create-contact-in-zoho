<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://accounts.google.com/o/oauth2/v2/auth?client_id=441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com&redirect_uri=https%3A%2F%2Foauth.pstmn.io%2Fv1%2Fcallback&response_type=code&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fgmail.readonly%20https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fgmail.send&access_type=offline',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json',
    'Cookie: __Host-GAPS=1:-nl0nr_MdeESKkNVCfmqvbOb1XaTug:yWjac8IZOM-G2FlG'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
?>
<!doctype html><html lang="en-US" dir="ltr"><head><base href="https://accounts.google.com/v3/signin/"><link rel="preconnect" href="//www.gstatic.com"><meta name="referrer" content="origin"><style data-href="https://www.gstatic.com/_/mss/boq-identity/_/ss/k=boq-identity.AccountsSignInUi.XBZxDW3GzkE.L.X.O/am=iDGYyTCNQKD8ARGgAgAgAKABAAAAAAAAAAAwAAAACgE/d=1/ed=1/rs=AOaEmlFBD75SY6tOzwXCqJhxwHOUY0RcRg/m=identifierview,_b,_tp" nonce="_yooe-PG2SHuH8k7sVbxxw">@-webkit-keyframes quantumWizBoxInkSpread{
    0%{-webkit-transform:translate(-50%,
        -50%) scale(0.2);-webkit-transform:translate(-50%,
        -50%) scale(0.2);-ms-transform:translate(-50%,
        -50%) scale(0.2);-o-transform:translate(-50%,
        -50%) scale(0.2);transform:translate(-50%,
        -50%) scale(0.2)
    }to{-webkit-transform:translate(-50%,
        -50%) scale(2.2);-webkit-transform:translate(-50%,
        -50%) scale(2.2);-ms-transform:translate(-50%,
        -50%) scale(2.2);-o-transform:translate(-50%,
        -50%) scale(2.2);transform:translate(-50%,
        -50%) scale(2.2)
    }
}@keyframes quantumWizBoxInkSpread{
    0%{-webkit-transform:translate(-50%,
        -50%) scale(0.2);-webkit-transform:translate(-50%,
        -50%) scale(0.2);-ms-transform:translate(-50%,
        -50%) scale(0.2);-o-transform:translate(-50%,
        -50%) scale(0.2);transform:translate(-50%,
        -50%) scale(0.2)
    }to{-webkit-transform:translate(-50%,
        -50%) scale(2.2);-webkit-transform:translate(-50%,
        -50%) scale(2.2);-ms-transform:translate(-50%,
        -50%) scale(2.2);-o-transform:translate(-50%,
        -50%) scale(2.2);transform:translate(-50%,
        -50%) scale(2.2)
    }
}@-webkit-keyframes quantumWizIconFocusPulse{
    0%{-webkit-transform:translate(-50%,
        -50%) scale(1.5);-webkit-transform:translate(-50%,
        -50%) scale(1.5);-ms-transform:translate(-50%,
        -50%) scale(1.5);-o-transform:translate(-50%,
        -50%) scale(1.5);transform:translate(-50%,
        -50%) scale(1.5);opacity: 0
    }to{-webkit-transform:translate(-50%,
        -50%) scale(2);-webkit-transform:translate(-50%,
        -50%) scale(2);-ms-transform:translate(-50%,
        -50%) scale(2);-o-transform:translate(-50%,
        -50%) scale(2);transform:translate(-50%,
        -50%) scale(2);opacity: 1
    }
}@keyframes quantumWizIconFocusPulse{
    0%{-webkit-transform:translate(-50%,
        -50%) scale(1.5);-webkit-transform:translate(-50%,
        -50%) scale(1.5);-ms-transform:translate(-50%,
        -50%) scale(1.5);-o-transform:translate(-50%,
        -50%) scale(1.5);transform:translate(-50%,
        -50%) scale(1.5);opacity: 0
    }to{-webkit-transform:translate(-50%,
        -50%) scale(2);-webkit-transform:translate(-50%,
        -50%) scale(2);-ms-transform:translate(-50%,
        -50%) scale(2);-o-transform:translate(-50%,
        -50%) scale(2);transform:translate(-50%,
        -50%) scale(2);opacity: 1
    }
}@-webkit-keyframes quantumWizRadialInkSpread{
    0%{-webkit-transform:scale(1.5);-webkit-transform:scale(1.5);-ms-transform:scale(1.5);-o-transform:scale(1.5);transform:scale(1.5);opacity: 0
    }to{-webkit-transform:scale(2.5);-webkit-transform:scale(2.5);-ms-transform:scale(2.5);-o-transform:scale(2.5);transform:scale(2.5);opacity: 1
    }
}@keyframes quantumWizRadialInkSpread{
    0%{-webkit-transform:scale(1.5);-webkit-transform:scale(1.5);-ms-transform:scale(1.5);-o-transform:scale(1.5);transform:scale(1.5);opacity: 0
    }to{-webkit-transform:scale(2.5);-webkit-transform:scale(2.5);-ms-transform:scale(2.5);-o-transform:scale(2.5);transform:scale(2.5);opacity: 1
    }
}@-webkit-keyframes quantumWizRadialInkFocusPulse{
    0%{-webkit-transform:scale(2);-webkit-transform:scale(2);-ms-transform:scale(2);-o-transform:scale(2);transform:scale(2);opacity: 0
    }to{-webkit-transform:scale(2.5);-webkit-transform:scale(2.5);-ms-transform:scale(2.5);-o-transform:scale(2.5);transform:scale(2.5);opacity: 1
    }
}@keyframes quantumWizRadialInkFocusPulse{
    0%{-webkit-transform:scale(2);-webkit-transform:scale(2);-ms-transform:scale(2);-o-transform:scale(2);transform:scale(2);opacity: 0
    }to{-webkit-transform:scale(2.5);-webkit-transform:scale(2.5);-ms-transform:scale(2.5);-o-transform:scale(2.5);transform:scale(2.5);opacity: 1
    }
}:root{--wf-tfs:calc(var(--c-tfs,
    32)/16*1rem);--wf-tfs-bp2:calc(var(--c-tfs,
    36)/16*1rem);--wf-tfs-bp3:calc(var(--c-tfs,
    36)/16*1rem);--wf-tfs-bp5:calc(var(--c-tfs,
    44)/16*1rem);--wf-stfs:calc(var(--c-stfs,
    16)/16*1rem);--wf-stfs-bp5:calc(var(--c-stfs,
    16)/16*1rem)
}.Dzz9Db,.GpMPBe{display:block;height: 25vh;position:relative
}@media (min-width: 600px){.Dzz9Db,.GpMPBe{height: 150px
    }
}.Dzz9Db.Irjbwb{height:auto
}.GpMPBe{margin: 0;overflow:hidden
}.UFQPDd,.JNOvdd{display:block;height: 100%;margin: 0 auto;-o-object-fit:contain;object-fit:contain;width: 100%
}.f4ZpM{display:block;height: 100%;max-width: 100%;min-height: 110px;position:relative;-webkit-transform:translate(-43%,
    -3%);-ms-transform:translate(-43%,
    -3%);transform:translate(-43%,
    -3%);width:auto;z-index: 3
}.wsArZ[data-ss-mode="1"
] .Dzz9Db,.wsArZ[data-ss-mode="1"
] .f4ZpM{height:auto;width: 100%
}.wsArZ[data-ss-mode="1"
] .f4ZpM{max-width: 400px
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .Dzz9Db,.NQ5OL .f4ZpM{height:auto;width: 100%
    }.NQ5OL .f4ZpM{max-width: 400px
    }
}.Dzz9Db.utFBGf,.Dzz9Db.utFBGf .f4ZpM{height:auto
}.Dzz9Db.utFBGf .f4ZpM{height:auto;max-width: 312px;width: 100%
}.Dzz9Db.utFBGf.zpCp3 .f4ZpM{max-width:unset
}.Dzz9Db.IiQozc .f4ZpM{margin: 0 auto;-webkit-transform:none;-ms-transform:none;transform:none
}.Dzz9Db.Irjbwb .f4ZpM{height:auto;width: 100%
}.Dzz9Db.EEeaqf .f4ZpM{max-height: 144px;max-width: 144px
}.nPt1pc{background-image:-webkit-gradient(linear,left top,left bottom,from(rgba(233,
    233,
    233,
    0)),color-stop(62.22%,rgba(233,
    233,
    233,
    0)),color-stop(40.22%,rgb(233,
    233,
    233)),to(rgba(233,
    233,
    233,
    0)));background-image:-webkit-linear-gradient(top,rgba(233,
    233,
    233,
    0) 0,rgba(233,
    233,
    233,
    0) 62.22%,rgb(233,
    233,
    233) 40.22%,rgba(233,
    233,
    233,
    0) 100%);background-image:linear-gradient(to bottom,rgba(233,
    233,
    233,
    0) 0,rgba(233,
    233,
    233,
    0) 62.22%,rgb(233,
    233,
    233) 40.22%,rgba(233,
    233,
    233,
    0) 100%);height: 100%;left: 0;overflow:hidden;position:absolute;right: 0;top: 0;z-index: 2
}.nPt1pc: :after,.nPt1pc: :before{content: "";display:block;height: 100%;min-width: 110px;position:absolute;right: -10%;-webkit-transform:rotate(-104deg);-ms-transform:rotate(-104deg);transform:rotate(-104deg);width: 25vh;z-index: 2
}@media (min-width: 600px){.nPt1pc: :after,.nPt1pc: :before{width: 150px
    }
}.nPt1pc: :before{background-image:-webkit-gradient(linear,left top,left bottom,from(rgba(243,
    243,
    243,
    0)),to(rgba(243,
    243,
    243,.9)));background-image:-webkit-linear-gradient(top,rgba(243,
    243,
    243,
    0) 0,rgba(243,
    243,
    243,.9) 100%);background-image:linear-gradient(to bottom,rgba(243,
    243,
    243,
    0) 0,rgba(243,
    243,
    243,.9) 100%);bottom: -10%
}.nPt1pc: :after{background-image:-webkit-gradient(linear,left top,left bottom,from(rgba(255,
    255,
    255,
    0)),to(rgba(255,
    255,
    255,.9)));background-image:-webkit-linear-gradient(top,rgba(255,
    255,
    255,
    0) 0,rgba(255,
    255,
    255,.9) 100%);background-image:linear-gradient(to bottom,rgba(255,
    255,
    255,
    0) 0,rgba(255,
    255,
    255,.9) 100%);bottom: -80%
}.wsArZ[data-ss-mode="1"
] .nPt1pc~.f4ZpM{width:auto
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .nPt1pc~.f4ZpM{width:auto
    }
}.ZS7CGc .f4ZpM{height:auto
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .ZS7CGc .f4ZpM{width: 115px
    }
}.qiRZ5e .f4ZpM{-webkit-transform:translate(-9%,
    -3%);-ms-transform:translate(-9%,
    -3%);transform:translate(-9%,
    -3%)
}.vIv7Gf .f4ZpM{margin:auto;max-height: 230px;right: 0;top: -3%;-webkit-transform:none;-ms-transform:none;transform:none
}.nvYXVd .f4ZpM{-webkit-transform:translate(9%,
    -3%);-ms-transform:translate(9%,
    -3%);transform:translate(9%,
    -3%)
}.uOhnzd .f4ZpM{-webkit-transform:translate(24px,
    0);-ms-transform:translate(24px,
    0);transform:translate(24px,
    0)
}.MsYMaf .f4ZpM{-webkit-transform:translate(0,
    0);-ms-transform:translate(0,
    0);transform:translate(0,
    0)
}.wsArZ[data-ss-mode="1"
] .YIi9qf .f4ZpM{max-width: 115px
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .YIi9qf .f4ZpM{max-width: 115px
    }
}.QG3Xbe .f4ZpM{max-width: 300px
}.F6gtje .f4ZpM{-webkit-transform:none;-ms-transform:none;transform:none
}@-webkit-keyframes mdc-ripple-fg-radius-in{
    0%{-webkit-animation-timing-function:cubic-bezier(0.4,
        0,
        0.2,
        1);-webkit-animation-timing-function:cubic-bezier(0.4,
        0,
        0.2,
        1);-o-animation-timing-function:cubic-bezier(0.4,
        0,
        0.2,
        1);animation-timing-function:cubic-bezier(0.4,
        0,
        0.2,
        1);-webkit-transform:translate(var(--mdc-ripple-fg-translate-start,
        0)) scale(1);-webkit-transform:translate(var(--mdc-ripple-fg-translate-start,
        0)) scale(1);-ms-transform:translate(var(--mdc-ripple-fg-translate-start,
        0)) scale(1);-o-transform:translate(var(--mdc-ripple-fg-translate-start,
        0)) scale(1);transform:translate(var(--mdc-ripple-fg-translate-start,
        0)) scale(1)
    }to{-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
        0)) scale(var(--mdc-ripple-fg-scale,
        1));-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
        0)) scale(var(--mdc-ripple-fg-scale,
        1));-ms-transform:translate(var(--mdc-ripple-fg-translate-end,
        0)) scale(var(--mdc-ripple-fg-scale,
        1));-o-transform:translate(var(--mdc-ripple-fg-translate-end,
        0)) scale(var(--mdc-ripple-fg-scale,
        1));transform:translate(var(--mdc-ripple-fg-translate-end,
        0)) scale(var(--mdc-ripple-fg-scale,
        1))
    }
}@keyframes mdc-ripple-fg-radius-in{
    0%{-webkit-animation-timing-function:cubic-bezier(0.4,
        0,
        0.2,
        1);-webkit-animation-timing-function:cubic-bezier(0.4,
        0,
        0.2,
        1);-o-animation-timing-function:cubic-bezier(0.4,
        0,
        0.2,
        1);animation-timing-function:cubic-bezier(0.4,
        0,
        0.2,
        1);-webkit-transform:translate(var(--mdc-ripple-fg-translate-start,
        0)) scale(1);-webkit-transform:translate(var(--mdc-ripple-fg-translate-start,
        0)) scale(1);-ms-transform:translate(var(--mdc-ripple-fg-translate-start,
        0)) scale(1);-o-transform:translate(var(--mdc-ripple-fg-translate-start,
        0)) scale(1);transform:translate(var(--mdc-ripple-fg-translate-start,
        0)) scale(1)
    }to{-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
        0)) scale(var(--mdc-ripple-fg-scale,
        1));-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
        0)) scale(var(--mdc-ripple-fg-scale,
        1));-ms-transform:translate(var(--mdc-ripple-fg-translate-end,
        0)) scale(var(--mdc-ripple-fg-scale,
        1));-o-transform:translate(var(--mdc-ripple-fg-translate-end,
        0)) scale(var(--mdc-ripple-fg-scale,
        1));transform:translate(var(--mdc-ripple-fg-translate-end,
        0)) scale(var(--mdc-ripple-fg-scale,
        1))
    }
}@-webkit-keyframes mdc-ripple-fg-opacity-in{
    0%{-webkit-animation-timing-function:linear;-webkit-animation-timing-function:linear;-o-animation-timing-function:linear;animation-timing-function:linear;opacity: 0
    }to{opacity:var(--mdc-ripple-fg-opacity,
        0)
    }
}@keyframes mdc-ripple-fg-opacity-in{
    0%{-webkit-animation-timing-function:linear;-webkit-animation-timing-function:linear;-o-animation-timing-function:linear;animation-timing-function:linear;opacity: 0
    }to{opacity:var(--mdc-ripple-fg-opacity,
        0)
    }
}@-webkit-keyframes mdc-ripple-fg-opacity-out{
    0%{-webkit-animation-timing-function:linear;-webkit-animation-timing-function:linear;-o-animation-timing-function:linear;animation-timing-function:linear;opacity:var(--mdc-ripple-fg-opacity,
        0)
    }to{opacity: 0
    }
}@keyframes mdc-ripple-fg-opacity-out{
    0%{-webkit-animation-timing-function:linear;-webkit-animation-timing-function:linear;-o-animation-timing-function:linear;animation-timing-function:linear;opacity:var(--mdc-ripple-fg-opacity,
        0)
    }to{opacity: 0
    }
}.VfPpkd-ksKsZd-XxIAqe{--mdc-ripple-fg-size: 0;--mdc-ripple-left: 0;--mdc-ripple-top: 0;--mdc-ripple-fg-scale: 1;--mdc-ripple-fg-translate-end: 0;--mdc-ripple-fg-translate-start: 0;-webkit-tap-highlight-color:rgba(0,
    0,
    0,
    0);will-change:transform,opacity;position:relative;outline:none;overflow:hidden
}.VfPpkd-ksKsZd-XxIAqe: :before,.VfPpkd-ksKsZd-XxIAqe: :after{position:absolute;-webkit-border-radius: 50%;-moz-border-radius: 50%;border-radius: 50%;opacity: 0;pointer-events:none;content: ""
}.VfPpkd-ksKsZd-XxIAqe: :before{-webkit-transition:opacity 15ms linear,background-color 15ms linear;-webkit-transition:opacity 15ms linear,background-color 15ms linear;-o-transition:opacity 15ms linear,background-color 15ms linear;transition:opacity 15ms linear,background-color 15ms linear;z-index: 1;z-index:var(--mdc-ripple-z-index,
    1)
}.VfPpkd-ksKsZd-XxIAqe: :after{z-index: 0;z-index:var(--mdc-ripple-z-index,
    0)
}.VfPpkd-ksKsZd-XxIAqe.VfPpkd-ksKsZd-mWPk3d: :before{-webkit-transform:scale(var(--mdc-ripple-fg-scale,
    1));-webkit-transform:scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:scale(var(--mdc-ripple-fg-scale,
    1));-o-transform:scale(var(--mdc-ripple-fg-scale,
    1));transform:scale(var(--mdc-ripple-fg-scale,
    1))
}.VfPpkd-ksKsZd-XxIAqe.VfPpkd-ksKsZd-mWPk3d: :after{top: 0;left: 0;-webkit-transform:scale(0);-webkit-transform:scale(0);-ms-transform:scale(0);-o-transform:scale(0);transform:scale(0);-webkit-transform-origin:center center;-webkit-transform-origin:center center;-ms-transform-origin:center center;-o-transform-origin:center center;transform-origin:center center
}.VfPpkd-ksKsZd-XxIAqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd: :after{top:var(--mdc-ripple-top,
    0);left:var(--mdc-ripple-left,
    0)
}.VfPpkd-ksKsZd-XxIAqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-lJfZMc: :after{-webkit-animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards;-webkit-animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards;-o-animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards;animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards
}.VfPpkd-ksKsZd-XxIAqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-OmS1vf: :after{-webkit-animation:mdc-ripple-fg-opacity-out 150ms;-webkit-animation:mdc-ripple-fg-opacity-out 150ms;-o-animation:mdc-ripple-fg-opacity-out 150ms;animation:mdc-ripple-fg-opacity-out 150ms;-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));-o-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1))
}.VfPpkd-ksKsZd-XxIAqe: :before,.VfPpkd-ksKsZd-XxIAqe: :after{top:-webkit-calc(50% - 100%);top:-moz-calc(50% - 100%);top:calc(50% - 100%);left:-webkit-calc(50% - 100%);left:-moz-calc(50% - 100%);left:calc(50% - 100%);width: 200%;height: 200%
}.VfPpkd-ksKsZd-XxIAqe.VfPpkd-ksKsZd-mWPk3d: :after{width:var(--mdc-ripple-fg-size,
    100%);height:var(--mdc-ripple-fg-size,
    100%)
}.VfPpkd-ksKsZd-XxIAqe[data-mdc-ripple-is-unbounded
],.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd{overflow:visible
}.VfPpkd-ksKsZd-XxIAqe[data-mdc-ripple-is-unbounded
]: :before,.VfPpkd-ksKsZd-XxIAqe[data-mdc-ripple-is-unbounded
]: :after,.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd: :before,.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd: :after{top:-webkit-calc(50% - 50%);top:-moz-calc(50% - 50%);top:calc(50% - 50%);left:-webkit-calc(50% - 50%);left:-moz-calc(50% - 50%);left:calc(50% - 50%);width: 100%;height: 100%
}.VfPpkd-ksKsZd-XxIAqe[data-mdc-ripple-is-unbounded
].VfPpkd-ksKsZd-mWPk3d: :before,.VfPpkd-ksKsZd-XxIAqe[data-mdc-ripple-is-unbounded
].VfPpkd-ksKsZd-mWPk3d: :after,.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd.VfPpkd-ksKsZd-mWPk3d: :before,.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd.VfPpkd-ksKsZd-mWPk3d: :after{top:var(--mdc-ripple-top,calc(50% - 50%));left:var(--mdc-ripple-left,calc(50% - 50%));width:var(--mdc-ripple-fg-size,
    100%);height:var(--mdc-ripple-fg-size,
    100%)
}.VfPpkd-ksKsZd-XxIAqe[data-mdc-ripple-is-unbounded
].VfPpkd-ksKsZd-mWPk3d: :after,.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd.VfPpkd-ksKsZd-mWPk3d: :after{width:var(--mdc-ripple-fg-size,
    100%);height:var(--mdc-ripple-fg-size,
    100%)
}.VfPpkd-ksKsZd-XxIAqe: :before,.VfPpkd-ksKsZd-XxIAqe: :after{background-color:#000;background-color:var(--mdc-ripple-color,#000)
}.VfPpkd-ksKsZd-XxIAqe:hover: :before,.VfPpkd-ksKsZd-XxIAqe.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,
    0.04)
}.VfPpkd-ksKsZd-XxIAqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe: :before,.VfPpkd-ksKsZd-XxIAqe:not(.VfPpkd-ksKsZd-mWPk3d):focus: :before{-webkit-transition-duration: 75ms;-webkit-transition-duration: 75ms;-o-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,
    0.12)
}.VfPpkd-ksKsZd-XxIAqe:not(.VfPpkd-ksKsZd-mWPk3d): :after{-webkit-transition:opacity 150ms linear;-webkit-transition:opacity 150ms linear;-o-transition:opacity 150ms linear;transition:opacity 150ms linear
}.VfPpkd-ksKsZd-XxIAqe:not(.VfPpkd-ksKsZd-mWPk3d):active: :after{-webkit-transition-duration: 75ms;-webkit-transition-duration: 75ms;-o-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,
    0.12)
}.VfPpkd-ksKsZd-XxIAqe.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.12)
}.VfPpkd-Bz112c-LgbsSe{font-size: 24px;width: 48px;height: 48px;padding: 12px
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-Bz112c-LgbsSe-OWXEXe-e5LLRc-SxQuSe .VfPpkd-Bz112c-Jh9lGc{width: 40px;height: 40px;margin-top: 4px;margin-bottom: 4px;margin-right: 4px;margin-left: 4px
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-Bz112c-LgbsSe-OWXEXe-e5LLRc-SxQuSe .VfPpkd-Bz112c-J1Ukfc-LhBDec{max-height: 40px;max-width: 40px
}.VfPpkd-Bz112c-LgbsSe:disabled{color:rgba(0,
    0,
    0,.38);color:var(--mdc-theme-text-disabled-on-light,rgba(0,
    0,
    0,.38))
}.VfPpkd-Bz112c-LgbsSe svg,.VfPpkd-Bz112c-LgbsSe img{width: 24px;height: 24px
}.VfPpkd-Bz112c-LgbsSe{display:inline-block;position:relative;-webkit-box-sizing:border-box;box-sizing:border-box;border:none;outline:none;background-color:transparent;fill:currentColor;color:inherit;text-decoration:none;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;z-index: 0;overflow:visible
}.VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-RLmnJb{position:absolute;top: 50%;height: 48px;left: 50%;width: 48px;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%)
}@media screen and (forced-colors:active){.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-J1Ukfc-LhBDec,.VfPpkd-Bz112c-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-J1Ukfc-LhBDec{display:block
    }
}.VfPpkd-Bz112c-LgbsSe:disabled{cursor:default;pointer-events:none
}.VfPpkd-Bz112c-LgbsSe[hidden
]{display:none
}.VfPpkd-Bz112c-LgbsSe-OWXEXe-KVuj8d-Q3DXx{-webkit-box-align:center;-webkit-align-items:center;align-items:center;display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center
}.VfPpkd-Bz112c-J1Ukfc-LhBDec{pointer-events:none;border: 2px solid transparent;border-radius: 6px;-webkit-box-sizing:content-box;box-sizing:content-box;position:absolute;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%);height: 100%;width: 100%;display:none
}@media screen and (forced-colors:active){.VfPpkd-Bz112c-J1Ukfc-LhBDec{border-color:CanvasText
    }
}.VfPpkd-Bz112c-J1Ukfc-LhBDec: :after{content: "";border: 2px solid transparent;border-radius: 8px;display:block;position:absolute;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%);height:calc(100% + 4px);width:calc(100% + 4px)
}@media screen and (forced-colors:active){.VfPpkd-Bz112c-J1Ukfc-LhBDec: :after{border-color:CanvasText
    }
}.VfPpkd-Bz112c-kBDsod{display:inline-block
}.VfPpkd-Bz112c-kBDsod.VfPpkd-Bz112c-kBDsod-OWXEXe-IT5dJd,.VfPpkd-Bz112c-LgbsSe-OWXEXe-IT5dJd .VfPpkd-Bz112c-kBDsod{display:none
}.VfPpkd-Bz112c-LgbsSe-OWXEXe-IT5dJd .VfPpkd-Bz112c-kBDsod.VfPpkd-Bz112c-kBDsod-OWXEXe-IT5dJd{display:inline-block
}.VfPpkd-Bz112c-mRLv6{height: 100%;left: 0;outline:none;position:absolute;top: 0;width: 100%
}.VfPpkd-Bz112c-LgbsSe{--mdc-ripple-fg-size: 0;--mdc-ripple-left: 0;--mdc-ripple-top: 0;--mdc-ripple-fg-scale: 1;--mdc-ripple-fg-translate-end: 0;--mdc-ripple-fg-translate-start: 0;-webkit-tap-highlight-color:rgba(0,
    0,
    0,
    0);will-change:transform,opacity
}.VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :after{position:absolute;border-radius: 50%;opacity: 0;pointer-events:none;content: ""
}.VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition:opacity 15ms linear,background-color 15ms linear;transition:opacity 15ms linear,background-color 15ms linear;z-index: 1;z-index:var(--mdc-ripple-z-index,
    1)
}.VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :after{z-index: 0;z-index:var(--mdc-ripple-z-index,
    0)
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transform:scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:scale(var(--mdc-ripple-fg-scale,
    1));transform:scale(var(--mdc-ripple-fg-scale,
    1))
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Bz112c-Jh9lGc: :after{top: 0;left: 0;-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0);-webkit-transform-origin:center center;-ms-transform-origin:center center;transform-origin:center center
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd .VfPpkd-Bz112c-Jh9lGc: :after{top:var(--mdc-ripple-top,
    0);left:var(--mdc-ripple-left,
    0)
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-lJfZMc .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards;animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-OmS1vf .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-animation:mdc-ripple-fg-opacity-out .15s;animation:mdc-ripple-fg-opacity-out .15s;-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1))
}.VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :after{top: 0;left: 0;width: 100%;height: 100%
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Bz112c-Jh9lGc: :after{top:var(--mdc-ripple-top,
    0);left:var(--mdc-ripple-left,
    0);width:var(--mdc-ripple-fg-size,
    100%);height:var(--mdc-ripple-fg-size,
    100%)
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Bz112c-Jh9lGc: :after{width:var(--mdc-ripple-fg-size,
    100%);height:var(--mdc-ripple-fg-size,
    100%)
}.VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :after{background-color:#000;background-color:var(--mdc-ripple-color,#000)
}.VfPpkd-Bz112c-LgbsSe:hover .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Bz112c-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Bz112c-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.VfPpkd-Bz112c-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.VfPpkd-Bz112c-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
}.VfPpkd-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.12)
}.VfPpkd-Bz112c-LgbsSe:disabled:hover .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Bz112c-LgbsSe:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Bz112c-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
    0)
}.VfPpkd-Bz112c-LgbsSe:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Bz112c-LgbsSe:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
    0)
}.VfPpkd-Bz112c-LgbsSe:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.VfPpkd-Bz112c-LgbsSe:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
    0)
}.VfPpkd-Bz112c-LgbsSe:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0)
}.VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc{height: 100%;left: 0;pointer-events:none;position:absolute;top: 0;width: 100%;z-index: -1
}.VfPpkd-dgl2Hf-ppHlrf-sM5MNb{display:inline
}.VfPpkd-LgbsSe{position:relative;display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-box-sizing:border-box;box-sizing:border-box;min-width: 64px;border:none;outline:none;line-height:inherit;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-appearance:none;overflow:visible;vertical-align:middle;background:transparent
}.VfPpkd-LgbsSe .VfPpkd-BFbNVe-bF1uUb{width: 100%;height: 100%;top: 0;left: 0
}.VfPpkd-LgbsSe: :-moz-focus-inner{padding: 0;border: 0
}.VfPpkd-LgbsSe:active{outline:none
}.VfPpkd-LgbsSe:hover{cursor:pointer
}.VfPpkd-LgbsSe:disabled{cursor:default;pointer-events:none
}.VfPpkd-LgbsSe[hidden
]{display:none
}.VfPpkd-LgbsSe .VfPpkd-kBDsod{margin-left: 0;margin-right: 8px;display:inline-block;position:relative;vertical-align:top
}[dir=rtl
] .VfPpkd-LgbsSe .VfPpkd-kBDsod,.VfPpkd-LgbsSe .VfPpkd-kBDsod[dir=rtl
]{margin-left: 8px;margin-right: 0
}.VfPpkd-LgbsSe .VfPpkd-UdE5de-uDEFge{font-size: 0;position:absolute;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%);top: 50%;left: 50%;line-height:normal
}.VfPpkd-LgbsSe .VfPpkd-vQzf8d{position:relative
}.VfPpkd-LgbsSe .VfPpkd-J1Ukfc-LhBDec{pointer-events:none;border: 2px solid transparent;border-radius: 6px;-webkit-box-sizing:content-box;box-sizing:content-box;position:absolute;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%);height:calc(100% + 4px);width:calc(100% + 4px);display:none
}@media screen and (forced-colors:active){.VfPpkd-LgbsSe .VfPpkd-J1Ukfc-LhBDec{border-color:CanvasText
    }
}.VfPpkd-LgbsSe .VfPpkd-J1Ukfc-LhBDec: :after{content: "";border: 2px solid transparent;border-radius: 8px;display:block;position:absolute;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%);height:calc(100% + 4px);width:calc(100% + 4px)
}@media screen and (forced-colors:active){.VfPpkd-LgbsSe .VfPpkd-J1Ukfc-LhBDec: :after{border-color:CanvasText
    }
}@media screen and (forced-colors:active){.VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-J1Ukfc-LhBDec,.VfPpkd-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-J1Ukfc-LhBDec{display:block
    }
}.VfPpkd-LgbsSe .VfPpkd-RLmnJb{position:absolute;top: 50%;height: 48px;left: 0;right: 0;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%)
}.VfPpkd-vQzf8d+.VfPpkd-kBDsod{margin-left: 8px;margin-right: 0
}[dir=rtl
] .VfPpkd-vQzf8d+.VfPpkd-kBDsod,.VfPpkd-vQzf8d+.VfPpkd-kBDsod[dir=rtl
]{margin-left: 0;margin-right: 8px
}svg.VfPpkd-kBDsod{fill:currentColor
}.VfPpkd-LgbsSe-OWXEXe-dgl2Hf{margin-top: 6px;margin-bottom: 6px
}.VfPpkd-LgbsSe{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;text-decoration:none
}.VfPpkd-LgbsSe{padding: 0 8px 0 8px
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ{-webkit-transition:-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:box-shadow .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);padding: 0 16px 0 16px
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ.VfPpkd-LgbsSe-OWXEXe-Bz112c-UbuQg{padding: 0 12px 0 16px
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ.VfPpkd-LgbsSe-OWXEXe-Bz112c-M1Soyc{padding: 0 16px 0 12px
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb{-webkit-transition:-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:box-shadow .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);padding: 0 16px 0 16px
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb.VfPpkd-LgbsSe-OWXEXe-Bz112c-UbuQg{padding: 0 12px 0 16px
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb.VfPpkd-LgbsSe-OWXEXe-Bz112c-M1Soyc{padding: 0 16px 0 12px
}.VfPpkd-LgbsSe-OWXEXe-INsAgc{border-style:solid;-webkit-transition:border .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1)
}.VfPpkd-LgbsSe-OWXEXe-INsAgc .VfPpkd-Jh9lGc{border-style:solid;border-color:transparent
}.VfPpkd-LgbsSe{--mdc-ripple-fg-size: 0;--mdc-ripple-left: 0;--mdc-ripple-top: 0;--mdc-ripple-fg-scale: 1;--mdc-ripple-fg-translate-end: 0;--mdc-ripple-fg-translate-start: 0;-webkit-tap-highlight-color:rgba(0,
    0,
    0,
    0);will-change:transform,opacity
}.VfPpkd-LgbsSe .VfPpkd-Jh9lGc: :before,.VfPpkd-LgbsSe .VfPpkd-Jh9lGc: :after{position:absolute;border-radius: 50%;opacity: 0;pointer-events:none;content: ""
}.VfPpkd-LgbsSe .VfPpkd-Jh9lGc: :before{-webkit-transition:opacity 15ms linear,background-color 15ms linear;transition:opacity 15ms linear,background-color 15ms linear;z-index: 1
}.VfPpkd-LgbsSe .VfPpkd-Jh9lGc: :after{z-index: 0
}.VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Jh9lGc: :before{-webkit-transform:scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:scale(var(--mdc-ripple-fg-scale,
    1));transform:scale(var(--mdc-ripple-fg-scale,
    1))
}.VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Jh9lGc: :after{top: 0;left: 0;-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0);-webkit-transform-origin:center center;-ms-transform-origin:center center;transform-origin:center center
}.VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd .VfPpkd-Jh9lGc: :after{top:var(--mdc-ripple-top,
    0);left:var(--mdc-ripple-left,
    0)
}.VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-lJfZMc .VfPpkd-Jh9lGc: :after{-webkit-animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards;animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards
}.VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-OmS1vf .VfPpkd-Jh9lGc: :after{-webkit-animation:mdc-ripple-fg-opacity-out .15s;animation:mdc-ripple-fg-opacity-out .15s;-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1))
}.VfPpkd-LgbsSe .VfPpkd-Jh9lGc: :before,.VfPpkd-LgbsSe .VfPpkd-Jh9lGc: :after{top: -50%;left: -50%;width: 200%;height: 200%
}.VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d .VfPpkd-Jh9lGc: :after{width:var(--mdc-ripple-fg-size,
    100%);height:var(--mdc-ripple-fg-size,
    100%)
}.VfPpkd-Jh9lGc{position:absolute;-webkit-box-sizing:content-box;box-sizing:content-box;overflow:hidden;z-index: 0;top: 0;left: 0;bottom: 0;right: 0
}.VfPpkd-LgbsSe{font-family:Roboto,sans-serif;font-size:.875rem;letter-spacing:.0892857143em;font-weight: 500;text-transform:uppercase;height: 36px;border-radius: 4px
}.VfPpkd-LgbsSe:not(:disabled){color:#6200ee
}.VfPpkd-LgbsSe:disabled{color:rgba(0,
    0,
    0,.38)
}.VfPpkd-LgbsSe .VfPpkd-kBDsod{font-size: 1.125rem;width: 1.125rem;height: 1.125rem
}.VfPpkd-LgbsSe .VfPpkd-Jh9lGc: :before{background-color:#6200ee
}.VfPpkd-LgbsSe .VfPpkd-Jh9lGc: :after{background-color:#6200ee
}.VfPpkd-LgbsSe:hover .VfPpkd-Jh9lGc: :before,.VfPpkd-LgbsSe.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04
}.VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.VfPpkd-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12
}.VfPpkd-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.VfPpkd-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12
}.VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-text-button-pressed-state-layer-opacity,
    0.12)
}.VfPpkd-LgbsSe .VfPpkd-Jh9lGc{border-radius: 4px
}.VfPpkd-LgbsSe .VfPpkd-J1Ukfc-LhBDec{border-radius: 2px
}.VfPpkd-LgbsSe .VfPpkd-J1Ukfc-LhBDec: :after{border-radius: 4px
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ{font-family:Roboto,sans-serif;font-size:.875rem;letter-spacing:.0892857143em;font-weight: 500;text-transform:uppercase;height: 36px;border-radius: 4px
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ:not(:disabled){background-color:#6200ee
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ:disabled{background-color:rgba(0,
    0,
    0,.12)
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ:not(:disabled){color:#fff
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ:disabled{color:rgba(0,
    0,
    0,.38)
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ .VfPpkd-kBDsod{font-size: 1.125rem;width: 1.125rem;height: 1.125rem
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ .VfPpkd-Jh9lGc: :before{background-color:#fff
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ .VfPpkd-Jh9lGc: :after{background-color:#fff
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ:hover .VfPpkd-Jh9lGc: :before,.VfPpkd-LgbsSe-OWXEXe-k8QpJ.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.08
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.VfPpkd-LgbsSe-OWXEXe-k8QpJ:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-filled-button-pressed-state-layer-opacity,
    0.24)
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ .VfPpkd-Jh9lGc{border-radius: 4px
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ .VfPpkd-J1Ukfc-LhBDec{border-radius: 2px
}.VfPpkd-LgbsSe-OWXEXe-k8QpJ .VfPpkd-J1Ukfc-LhBDec: :after{border-radius: 4px
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb{font-family:Roboto,sans-serif;font-size:.875rem;letter-spacing:.0892857143em;font-weight: 500;text-transform:uppercase;height: 36px;border-radius: 4px;-webkit-box-shadow: 0 3px 1px -2px rgba(0,
    0,
    0,.2),
    0 2px 2px 0 rgba(0,
    0,
    0,.14),
    0 1px 5px 0 rgba(0,
    0,
    0,.12);box-shadow: 0 3px 1px -2px rgba(0,
    0,
    0,.2),
    0 2px 2px 0 rgba(0,
    0,
    0,.14),
    0 1px 5px 0 rgba(0,
    0,
    0,.12)
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb:not(:disabled){background-color:#6200ee
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb:disabled{background-color:rgba(0,
    0,
    0,.12)
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb:not(:disabled){color:#fff
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb:disabled{color:rgba(0,
    0,
    0,.38)
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb .VfPpkd-kBDsod{font-size: 1.125rem;width: 1.125rem;height: 1.125rem
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb .VfPpkd-Jh9lGc: :before{background-color:#fff
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb .VfPpkd-Jh9lGc: :after{background-color:#fff
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb:hover .VfPpkd-Jh9lGc: :before,.VfPpkd-LgbsSe-OWXEXe-MV7yeb.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.08
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.VfPpkd-LgbsSe-OWXEXe-MV7yeb:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-protected-button-pressed-state-layer-opacity,
    0.24)
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb .VfPpkd-Jh9lGc{border-radius: 4px
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb .VfPpkd-J1Ukfc-LhBDec{border-radius: 2px
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb .VfPpkd-J1Ukfc-LhBDec: :after{border-radius: 4px
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.VfPpkd-LgbsSe-OWXEXe-MV7yeb:not(.VfPpkd-ksKsZd-mWPk3d):focus{-webkit-box-shadow: 0 2px 4px -1px rgba(0,
    0,
    0,.2),
    0 4px 5px 0 rgba(0,
    0,
    0,.14),
    0 1px 10px 0 rgba(0,
    0,
    0,.12);box-shadow: 0 2px 4px -1px rgba(0,
    0,
    0,.2),
    0 4px 5px 0 rgba(0,
    0,
    0,.14),
    0 1px 10px 0 rgba(0,
    0,
    0,.12)
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb:hover{-webkit-box-shadow: 0 2px 4px -1px rgba(0,
    0,
    0,.2),
    0 4px 5px 0 rgba(0,
    0,
    0,.14),
    0 1px 10px 0 rgba(0,
    0,
    0,.12);box-shadow: 0 2px 4px -1px rgba(0,
    0,
    0,.2),
    0 4px 5px 0 rgba(0,
    0,
    0,.14),
    0 1px 10px 0 rgba(0,
    0,
    0,.12)
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb:not(:disabled):active{-webkit-box-shadow: 0 5px 5px -3px rgba(0,
    0,
    0,.2),
    0 8px 10px 1px rgba(0,
    0,
    0,.14),
    0 3px 14px 2px rgba(0,
    0,
    0,.12);box-shadow: 0 5px 5px -3px rgba(0,
    0,
    0,.2),
    0 8px 10px 1px rgba(0,
    0,
    0,.14),
    0 3px 14px 2px rgba(0,
    0,
    0,.12)
}.VfPpkd-LgbsSe-OWXEXe-MV7yeb:disabled{-webkit-box-shadow: 0 0 0 0 rgba(0,
    0,
    0,.2),
    0 0 0 0 rgba(0,
    0,
    0,.14),
    0 0 0 0 rgba(0,
    0,
    0,.12);box-shadow: 0 0 0 0 rgba(0,
    0,
    0,.2),
    0 0 0 0 rgba(0,
    0,
    0,.14),
    0 0 0 0 rgba(0,
    0,
    0,.12)
}.VfPpkd-LgbsSe-OWXEXe-INsAgc{font-family:Roboto,sans-serif;font-size:.875rem;letter-spacing:.0892857143em;font-weight: 500;text-transform:uppercase;height: 36px;border-radius: 4px;padding: 0 15px 0 15px;border-width: 1px
}.VfPpkd-LgbsSe-OWXEXe-INsAgc:not(:disabled){color:#6200ee
}.VfPpkd-LgbsSe-OWXEXe-INsAgc:disabled{color:rgba(0,
    0,
    0,.38)
}.VfPpkd-LgbsSe-OWXEXe-INsAgc .VfPpkd-kBDsod{font-size: 1.125rem;width: 1.125rem;height: 1.125rem
}.VfPpkd-LgbsSe-OWXEXe-INsAgc .VfPpkd-Jh9lGc: :before{background-color:#6200ee
}.VfPpkd-LgbsSe-OWXEXe-INsAgc .VfPpkd-Jh9lGc: :after{background-color:#6200ee
}.VfPpkd-LgbsSe-OWXEXe-INsAgc:hover .VfPpkd-Jh9lGc: :before,.VfPpkd-LgbsSe-OWXEXe-INsAgc.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04
}.VfPpkd-LgbsSe-OWXEXe-INsAgc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.VfPpkd-LgbsSe-OWXEXe-INsAgc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12
}.VfPpkd-LgbsSe-OWXEXe-INsAgc:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.VfPpkd-LgbsSe-OWXEXe-INsAgc:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12
}.VfPpkd-LgbsSe-OWXEXe-INsAgc.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,
    0.12)
}.VfPpkd-LgbsSe-OWXEXe-INsAgc .VfPpkd-Jh9lGc{border-radius: 4px
}.VfPpkd-LgbsSe-OWXEXe-INsAgc .VfPpkd-J1Ukfc-LhBDec{border-radius: 2px
}.VfPpkd-LgbsSe-OWXEXe-INsAgc .VfPpkd-J1Ukfc-LhBDec: :after{border-radius: 4px
}.VfPpkd-LgbsSe-OWXEXe-INsAgc:not(:disabled){border-color:rgba(0,
    0,
    0,.12)
}.VfPpkd-LgbsSe-OWXEXe-INsAgc:disabled{border-color:rgba(0,
    0,
    0,.12)
}.VfPpkd-LgbsSe-OWXEXe-INsAgc.VfPpkd-LgbsSe-OWXEXe-Bz112c-UbuQg{padding: 0 11px 0 15px
}.VfPpkd-LgbsSe-OWXEXe-INsAgc.VfPpkd-LgbsSe-OWXEXe-Bz112c-M1Soyc{padding: 0 15px 0 11px
}.VfPpkd-LgbsSe-OWXEXe-INsAgc .VfPpkd-Jh9lGc{top: -1px;left: -1px;bottom: -1px;right: -1px;border-width: 1px
}.VfPpkd-LgbsSe-OWXEXe-INsAgc .VfPpkd-RLmnJb{left: -1px;width:calc(100% + 2px)
}.nCP5yc{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none;-webkit-transition:border .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),box-shadow .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);-webkit-box-shadow:none;box-shadow:none
}.nCP5yc .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
}.nCP5yc:not(:disabled){background-color:rgb(26,
    115,
    232);background-color:var(--gm-fillbutton-container-color,rgb(26,
    115,
    232))
}.nCP5yc:not(:disabled){color:#fff;color:var(--gm-fillbutton-ink-color,#fff)
}.nCP5yc:disabled{background-color:rgba(60,
    64,
    67,.12);background-color:var(--gm-fillbutton-disabled-container-color,rgba(60,
    64,
    67,.12))
}.nCP5yc:disabled{color:rgba(60,
    64,
    67,.38);color:var(--gm-fillbutton-disabled-ink-color,rgba(60,
    64,
    67,.38))
}.nCP5yc .VfPpkd-Jh9lGc: :before,.nCP5yc .VfPpkd-Jh9lGc: :after{background-color:rgb(32,
    33,
    36);background-color:var(--gm-fillbutton-state-color,rgb(32,
    33,
    36))
}.nCP5yc:hover .VfPpkd-Jh9lGc: :before,.nCP5yc.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.16;opacity:var(--mdc-ripple-hover-opacity,.16)
}.nCP5yc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.nCP5yc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
}.nCP5yc:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.nCP5yc:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-ripple-press-opacity,.2)
}.nCP5yc.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.2)
}.nCP5yc .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.nCP5yc .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.nCP5yc .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:#fff
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.nCP5yc .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.nCP5yc .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.nCP5yc:hover{-webkit-box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 1px 3px 1px rgba(60,
    64,
    67,.15);box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 1px 3px 1px rgba(60,
    64,
    67,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-fillbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 1px 3px 1px var(--gm-fillbutton-ambientshadow-color,rgba(60,
    64,
    67,.15));box-shadow: 0 1px 2px 0 var(--gm-fillbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 1px 3px 1px var(--gm-fillbutton-ambientshadow-color,rgba(60,
    64,
    67,.15))
}.nCP5yc:hover .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.nCP5yc:active{-webkit-box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 2px 6px 2px rgba(60,
    64,
    67,.15);box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 2px 6px 2px rgba(60,
    64,
    67,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-fillbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 2px 6px 2px var(--gm-fillbutton-ambientshadow-color,rgba(60,
    64,
    67,.15));box-shadow: 0 1px 2px 0 var(--gm-fillbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 2px 6px 2px var(--gm-fillbutton-ambientshadow-color,rgba(60,
    64,
    67,.15))
}.nCP5yc:active .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.nCP5yc:disabled{-webkit-box-shadow:none;box-shadow:none
}.nCP5yc:disabled:hover .VfPpkd-Jh9lGc: :before,.nCP5yc:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
    0)
}.nCP5yc:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.nCP5yc:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
    0)
}.nCP5yc:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.nCP5yc:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
    0)
}.nCP5yc:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0)
}.nCP5yc:disabled .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.Rj2Mlf{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none;-webkit-transition:border .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),box-shadow .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);-webkit-box-shadow:none;box-shadow:none
}.Rj2Mlf .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
}.Rj2Mlf:not(:disabled){color:rgb(26,
    115,
    232);color:var(--gm-hairlinebutton-ink-color,rgb(26,
    115,
    232))
}.Rj2Mlf:not(:disabled){border-color:rgb(218,
    220,
    224);border-color:var(--gm-hairlinebutton-outline-color,rgb(218,
    220,
    224))
}.Rj2Mlf:not(:disabled):hover{border-color:rgb(218,
    220,
    224);border-color:var(--gm-hairlinebutton-outline-color,rgb(218,
    220,
    224))
}.Rj2Mlf:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.Rj2Mlf:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{border-color:rgb(23,
    78,
    166);border-color:var(--gm-hairlinebutton-outline-color--stateful,rgb(23,
    78,
    166))
}.Rj2Mlf:not(:disabled):active,.Rj2Mlf:not(:disabled):focus:active{border-color:rgb(218,
    220,
    224);border-color:var(--gm-hairlinebutton-outline-color,rgb(218,
    220,
    224))
}.Rj2Mlf:disabled{color:rgba(60,
    64,
    67,.38);color:var(--gm-hairlinebutton-disabled-ink-color,rgba(60,
    64,
    67,.38))
}.Rj2Mlf:disabled{border-color:rgba(60,
    64,
    67,.12);border-color:var(--gm-hairlinebutton-disabled-outline-color,rgba(60,
    64,
    67,.12))
}.Rj2Mlf:hover:not(:disabled),.Rj2Mlf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.Rj2Mlf:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.Rj2Mlf:active:not(:disabled){color:rgb(23,
    78,
    166);color:var(--gm-hairlinebutton-ink-color--stateful,rgb(23,
    78,
    166))
}.Rj2Mlf .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.Rj2Mlf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.Rj2Mlf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(26,
    115,
    232)
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.Rj2Mlf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.Rj2Mlf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.Rj2Mlf .VfPpkd-Jh9lGc: :before,.Rj2Mlf .VfPpkd-Jh9lGc: :after{background-color:rgb(26,
    115,
    232);background-color:var(--gm-hairlinebutton-state-color,rgb(26,
    115,
    232))
}.Rj2Mlf:hover .VfPpkd-Jh9lGc: :before,.Rj2Mlf.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.Rj2Mlf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.Rj2Mlf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.Rj2Mlf:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.Rj2Mlf:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
}.Rj2Mlf.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.12)
}.Rj2Mlf:disabled:hover .VfPpkd-Jh9lGc: :before,.Rj2Mlf:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
    0)
}.Rj2Mlf:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.Rj2Mlf:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
    0)
}.Rj2Mlf:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.Rj2Mlf:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
    0)
}.Rj2Mlf:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0)
}.b9hyVd{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none;-webkit-transition:border .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),box-shadow .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 1px 3px 1px rgba(60,
    64,
    67,.15);box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 1px 3px 1px rgba(60,
    64,
    67,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 1px 3px 1px var(--gm-protectedbutton-ambientshadow-color,rgba(60,
    64,
    67,.15));box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 1px 3px 1px var(--gm-protectedbutton-ambientshadow-color,rgba(60,
    64,
    67,.15))
}.b9hyVd .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
}.b9hyVd:not(:disabled){background-color:#fff;background-color:var(--gm-protectedbutton-container-color,#fff)
}.b9hyVd:not(:disabled){color:rgb(26,
    115,
    232);color:var(--gm-protectedbutton-ink-color,rgb(26,
    115,
    232))
}.b9hyVd:disabled{background-color:rgba(60,
    64,
    67,.12);background-color:var(--gm-protectedbutton-disabled-container-color,rgba(60,
    64,
    67,.12))
}.b9hyVd:disabled{color:rgba(60,
    64,
    67,.38);color:var(--gm-protectedbutton-disabled-ink-color,rgba(60,
    64,
    67,.38))
}.b9hyVd:hover:not(:disabled),.b9hyVd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.b9hyVd:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.b9hyVd:active:not(:disabled){color:rgb(23,
    78,
    166);color:var(--gm-protectedbutton-ink-color--stateful,rgb(23,
    78,
    166))
}.b9hyVd .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.b9hyVd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.b9hyVd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(26,
    115,
    232)
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.b9hyVd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.b9hyVd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.b9hyVd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.b9hyVd:not(.VfPpkd-ksKsZd-mWPk3d):focus{border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 1px 3px 1px rgba(60,
    64,
    67,.15);box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 1px 3px 1px rgba(60,
    64,
    67,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 1px 3px 1px var(--gm-protectedbutton-ambientshadow-color,rgba(60,
    64,
    67,.15));box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 1px 3px 1px var(--gm-protectedbutton-ambientshadow-color,rgba(60,
    64,
    67,.15))
}.b9hyVd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-BFbNVe-bF1uUb,.b9hyVd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.b9hyVd:hover{border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 2px 6px 2px rgba(60,
    64,
    67,.15);box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 2px 6px 2px rgba(60,
    64,
    67,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 2px 6px 2px var(--gm-protectedbutton-ambientshadow-color,rgba(60,
    64,
    67,.15));box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 2px 6px 2px var(--gm-protectedbutton-ambientshadow-color,rgba(60,
    64,
    67,.15))
}.b9hyVd:hover .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.b9hyVd:not(:disabled):active{border-width: 0;-webkit-box-shadow: 0 1px 3px 0 rgba(60,
    64,
    67,.3),
    0 4px 8px 3px rgba(60,
    64,
    67,.15);box-shadow: 0 1px 3px 0 rgba(60,
    64,
    67,.3),
    0 4px 8px 3px rgba(60,
    64,
    67,.15);-webkit-box-shadow: 0 1px 3px 0 var(--gm-protectedbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 4px 8px 3px var(--gm-protectedbutton-ambientshadow-color,rgba(60,
    64,
    67,.15));box-shadow: 0 1px 3px 0 var(--gm-protectedbutton-keyshadow-color,rgba(60,
    64,
    67,.3)),
    0 4px 8px 3px var(--gm-protectedbutton-ambientshadow-color,rgba(60,
    64,
    67,.15))
}.b9hyVd:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.b9hyVd .VfPpkd-Jh9lGc: :before,.b9hyVd .VfPpkd-Jh9lGc: :after{background-color:rgb(26,
    115,
    232);background-color:var(--gm-protectedbutton-state-color,rgb(26,
    115,
    232))
}.b9hyVd:hover .VfPpkd-Jh9lGc: :before,.b9hyVd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.b9hyVd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.b9hyVd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.b9hyVd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.b9hyVd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
}.b9hyVd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.12)
}.b9hyVd:disabled{-webkit-box-shadow:none;box-shadow:none
}.b9hyVd:disabled .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.b9hyVd:disabled:hover .VfPpkd-Jh9lGc: :before,.b9hyVd:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
    0)
}.b9hyVd:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.b9hyVd:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
    0)
}.b9hyVd:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.b9hyVd:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
    0)
}.b9hyVd:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0)
}.Kjnxrf{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none;-webkit-transition:border .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);transition:border .28s cubic-bezier(.4,
    0,.2,
    1),box-shadow .28s cubic-bezier(.4,
    0,.2,
    1),-webkit-box-shadow .28s cubic-bezier(.4,
    0,.2,
    1);-webkit-box-shadow:none;box-shadow:none
}.Kjnxrf .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
}.Kjnxrf:not(:disabled){background-color:rgb(232,
    240,
    254)
}.Kjnxrf:not(:disabled){color:rgb(25,
    103,
    210)
}.Kjnxrf:disabled{background-color:rgba(60,
    64,
    67,.12)
}.Kjnxrf:disabled{color:rgba(60,
    64,
    67,.38)
}.Kjnxrf:hover:not(:disabled),.Kjnxrf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.Kjnxrf:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.Kjnxrf:active:not(:disabled){color:rgb(23,
    78,
    166)
}.Kjnxrf .VfPpkd-Jh9lGc: :before,.Kjnxrf .VfPpkd-Jh9lGc: :after{background-color:rgb(25,
    103,
    210);background-color:var(--mdc-ripple-color,rgb(25,
    103,
    210))
}.Kjnxrf:hover .VfPpkd-Jh9lGc: :before,.Kjnxrf.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.Kjnxrf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.Kjnxrf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.Kjnxrf:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.Kjnxrf:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
}.Kjnxrf.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.1)
}.Kjnxrf .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.Kjnxrf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.Kjnxrf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(25,
    103,
    210)
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.Kjnxrf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.Kjnxrf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.Kjnxrf:hover{-webkit-box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 1px 3px 1px rgba(60,
    64,
    67,.15);box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 1px 3px 1px rgba(60,
    64,
    67,.15)
}.Kjnxrf:hover .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.Kjnxrf:not(:disabled):active{-webkit-box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 2px 6px 2px rgba(60,
    64,
    67,.15);box-shadow: 0 1px 2px 0 rgba(60,
    64,
    67,.3),
    0 2px 6px 2px rgba(60,
    64,
    67,.15)
}.Kjnxrf:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.Kjnxrf:disabled{-webkit-box-shadow:none;box-shadow:none
}.Kjnxrf:disabled .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.Kjnxrf:disabled:hover .VfPpkd-Jh9lGc: :before,.Kjnxrf:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
    0)
}.Kjnxrf:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.Kjnxrf:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
    0)
}.Kjnxrf:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.Kjnxrf:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
    0)
}.Kjnxrf:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0)
}.ksBjEc{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none
}.ksBjEc .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
}.ksBjEc:not(:disabled){background-color:transparent
}.ksBjEc:not(:disabled){color:rgb(26,
    115,
    232);color:var(--gm-colortextbutton-ink-color,rgb(26,
    115,
    232))
}.ksBjEc:disabled{color:rgba(60,
    64,
    67,.38);color:var(--gm-colortextbutton-disabled-ink-color,rgba(60,
    64,
    67,.38))
}.ksBjEc .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.ksBjEc .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(26,
    115,
    232)
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.ksBjEc .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.ksBjEc .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.ksBjEc:hover:not(:disabled),.ksBjEc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.ksBjEc:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.ksBjEc:active:not(:disabled){color:rgb(23,
    78,
    166);color:var(--gm-colortextbutton-ink-color--stateful,rgb(23,
    78,
    166))
}.ksBjEc .VfPpkd-Jh9lGc: :before,.ksBjEc .VfPpkd-Jh9lGc: :after{background-color:rgb(26,
    115,
    232);background-color:var(--gm-colortextbutton-state-color,rgb(26,
    115,
    232))
}.ksBjEc:hover .VfPpkd-Jh9lGc: :before,.ksBjEc.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.ksBjEc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.ksBjEc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.ksBjEc:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.ksBjEc:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
}.ksBjEc.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.12)
}.ksBjEc:disabled:hover .VfPpkd-Jh9lGc: :before,.ksBjEc:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
    0)
}.ksBjEc:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.ksBjEc:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
    0)
}.ksBjEc:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.ksBjEc:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
    0)
}.ksBjEc:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0)
}.LjDxcd{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none
}.LjDxcd .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
}.LjDxcd:not(:disabled){color:rgb(95,
    99,
    104);color:var(--gm-neutraltextbutton-ink-color,rgb(95,
    99,
    104))
}.LjDxcd:disabled{color:rgba(60,
    64,
    67,.38);color:var(--gm-neutraltextbutton-disabled-ink-color,rgba(60,
    64,
    67,.38))
}.LjDxcd:hover:not(:disabled),.LjDxcd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.LjDxcd:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.LjDxcd:active:not(:disabled){color:rgb(32,
    33,
    36);color:var(--gm-neutraltextbutton-ink-color--stateful,rgb(32,
    33,
    36))
}.LjDxcd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.LjDxcd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(95,
    99,
    104)
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.LjDxcd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.LjDxcd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.LjDxcd .VfPpkd-Jh9lGc: :before,.LjDxcd .VfPpkd-Jh9lGc: :after{background-color:rgb(95,
    99,
    104);background-color:var(--gm-neutraltextbutton-state-color,rgb(95,
    99,
    104))
}.LjDxcd:hover .VfPpkd-Jh9lGc: :before,.LjDxcd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.LjDxcd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.LjDxcd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.LjDxcd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.LjDxcd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
}.LjDxcd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.12)
}.LjDxcd:disabled:hover .VfPpkd-Jh9lGc: :before,.LjDxcd:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
    0)
}.LjDxcd:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.LjDxcd:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
    0)
}.LjDxcd:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.LjDxcd:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
    0)
}.LjDxcd:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0)
}.DuMIQc{padding: 0 24px 0 24px
}.P62QJc{padding: 0 23px 0 23px;border-width: 1px
}.P62QJc.VfPpkd-LgbsSe-OWXEXe-Bz112c-UbuQg{padding: 0 11px 0 23px
}.P62QJc.VfPpkd-LgbsSe-OWXEXe-Bz112c-M1Soyc{padding: 0 23px 0 11px
}.P62QJc .VfPpkd-Jh9lGc{top: -1px;left: -1px;bottom: -1px;right: -1px;border-width: 1px
}.P62QJc .VfPpkd-RLmnJb{left: -1px;width:calc(100% + 2px)
}.yHy1rc{z-index: 0
}.yHy1rc .VfPpkd-Bz112c-Jh9lGc: :before,.yHy1rc .VfPpkd-Bz112c-Jh9lGc: :after{z-index: -1
}.yHy1rc:disabled{color:rgba(60,
    64,
    67,.38);color:var(--gm-iconbutton-disabled-ink-color,rgba(60,
    64,
    67,.38))
}.fzRBVc{z-index: 0
}.fzRBVc .VfPpkd-Bz112c-Jh9lGc: :before,.fzRBVc .VfPpkd-Bz112c-Jh9lGc: :after{z-index: -1
}.fzRBVc:disabled{color:rgba(60,
    64,
    67,.38);color:var(--gm-iconbutton-disabled-ink-color,rgba(60,
    64,
    67,.38))
}.WpHeLc{height: 100%;left: 0;position:absolute;top: 0;width: 100%;outline:none
}[dir=rtl
] .HDnnrf .VfPpkd-kBDsod,.HDnnrf .VfPpkd-kBDsod[dir=rtl
]{-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1)
}[dir=rtl
] .QDwDD,.QDwDD[dir=rtl
]{-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1)
}.PDpWxe{will-change:unset
}.LQeN7 .VfPpkd-J1Ukfc-LhBDec{pointer-events:none;border: 2px solid rgb(24,
    90,
    188);border-radius: 6px;-webkit-box-sizing:content-box;box-sizing:content-box;position:absolute;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%);height:calc(100% + 4px);width:calc(100% + 4px)
}@media screen and (forced-colors:active){.LQeN7 .VfPpkd-J1Ukfc-LhBDec{border-color:CanvasText
    }
}.LQeN7 .VfPpkd-J1Ukfc-LhBDec: :after{content: "";border: 2px solid rgb(232,
    240,
    254);border-radius: 8px;display:block;position:absolute;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%);height:calc(100% + 4px);width:calc(100% + 4px)
}@media screen and (forced-colors:active){.LQeN7 .VfPpkd-J1Ukfc-LhBDec: :after{border-color:CanvasText
    }
}.LQeN7.gmghec .VfPpkd-J1Ukfc-LhBDec{display:inline-block
}@media (-ms-high-contrast:active),(-ms-high-contrast:none){.LQeN7.gmghec .VfPpkd-J1Ukfc-LhBDec{display:none
    }
}.mN1ivc .VfPpkd-Bz112c-J1Ukfc-LhBDec{pointer-events:none;border: 2px solid rgb(24,
    90,
    188);border-radius: 6px;-webkit-box-sizing:content-box;box-sizing:content-box;position:absolute;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%);height: 100%;width: 100%
}@media screen and (forced-colors:active){.mN1ivc .VfPpkd-Bz112c-J1Ukfc-LhBDec{border-color:CanvasText
    }
}.mN1ivc .VfPpkd-Bz112c-J1Ukfc-LhBDec: :after{content: "";border: 2px solid rgb(232,
    240,
    254);border-radius: 8px;display:block;position:absolute;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%);height:calc(100% + 4px);width:calc(100% + 4px)
}@media screen and (forced-colors:active){.mN1ivc .VfPpkd-Bz112c-J1Ukfc-LhBDec: :after{border-color:CanvasText
    }
}.mN1ivc.gmghec .VfPpkd-Bz112c-J1Ukfc-LhBDec{display:inline-block
}@media (-ms-high-contrast:active),(-ms-high-contrast:none){.mN1ivc.gmghec .VfPpkd-Bz112c-J1Ukfc-LhBDec{display:none
    }
}.MyRpB .VfPpkd-kBDsod,.MyRpB .VfPpkd-vQzf8d{opacity: 0
}[data-tooltip-enabled=true
]:disabled,.VfPpkd-Bz112c-LgbsSe[data-tooltip-enabled=true
]:disabled .VfPpkd-Bz112c-Jh9lGc{pointer-events:auto
}.VfPpkd-StrnGf-rymPhb{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-subtitle1-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size: 1rem;font-size:var(--mdc-typography-subtitle1-font-size,
    1rem);line-height: 1.75rem;line-height:var(--mdc-typography-subtitle1-line-height,
    1.75rem);font-weight: 400;font-weight:var(--mdc-typography-subtitle1-font-weight,
    400);letter-spacing:.009375em;letter-spacing:var(--mdc-typography-subtitle1-letter-spacing,.009375em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-subtitle1-text-decoration,inherit);text-decoration:var(--mdc-typography-subtitle1-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-subtitle1-text-transform,inherit);line-height: 1.5rem;margin: 0;padding: 8px 0;list-style-type:none;color:rgba(0,
    0,
    0,.87);color:var(--mdc-theme-text-primary-on-background,rgba(0,
    0,
    0,.87))
}.VfPpkd-StrnGf-rymPhb:focus{outline:none
}.VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgba(0,
    0,
    0,.54);color:var(--mdc-theme-text-secondary-on-background,rgba(0,
    0,
    0,.54))
}.VfPpkd-StrnGf-rymPhb-f7MjDc{background-color:transparent
}.VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgba(0,
    0,
    0,.38);color:var(--mdc-theme-text-icon-on-background,rgba(0,
    0,
    0,.38))
}.VfPpkd-StrnGf-rymPhb-IhFlZd{color:rgba(0,
    0,
    0,.38);color:var(--mdc-theme-text-hint-on-background,rgba(0,
    0,
    0,.38))
}.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity:.38
}.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:#000;color:var(--mdc-theme-on-surface,#000)
}.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b{color:#6200ee;color:var(--mdc-theme-primary,#6200ee)
}.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc{color:#6200ee;color:var(--mdc-theme-primary,#6200ee)
}.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc{padding-top: 4px;padding-bottom: 4px;font-size:.812rem
}.VfPpkd-StrnGf-rymPhb-Tkg0ld{display:block
}.VfPpkd-StrnGf-rymPhb-Zmlebc-LhBDec{position:absolute
}.VfPpkd-StrnGf-rymPhb-ibnC6b{display:-webkit-box;display:-webkit-flex;display:flex;position:relative;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:start;-webkit-justify-content:flex-start;justify-content:flex-start;overflow:hidden;padding: 0;padding-left: 16px;padding-right: 16px;height: 48px
}.VfPpkd-StrnGf-rymPhb-ibnC6b:focus{outline:none
}.VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd):focus: :before,.VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe: :before{position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;width: 100%;height: 100%;top: 0;left: 0;border: 1px solid transparent;border-radius:inherit;content: "";pointer-events:none
}@media screen and (forced-colors:active){.VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd):focus: :before,.VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe: :before{border-color:CanvasText
    }
}.VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd: :before{position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;width: 100%;height: 100%;top: 0;left: 0;border: 3px double transparent;border-radius:inherit;content: "";pointer-events:none
}@media screen and (forced-colors:active){.VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd: :before{border-color:CanvasText
    }
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
]{padding-left: 16px;padding-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 16px;padding-right: 16px;height: 56px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
]{padding-left: 16px;padding-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 16px;padding-right: 16px;height: 56px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
]{padding-left: 16px;padding-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 16px;padding-right: 16px;height: 56px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
]{padding-left: 16px;padding-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 16px;padding-right: 16px;height: 72px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
]{padding-left: 16px;padding-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 0;padding-right: 16px;height: 72px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
]{padding-left: 16px;padding-right: 0
}.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-f7MjDc{margin-left: 0;margin-right: 16px;width: 20px;height: 20px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-f7MjDc,.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
]{margin-left: 16px;margin-right: 0
}.VfPpkd-StrnGf-rymPhb-f7MjDc{-webkit-flex-shrink: 0;flex-shrink: 0;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;fill:currentColor;-o-object-fit:cover;object-fit:cover;margin-left: 0;margin-right: 32px;width: 24px;height: 24px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-f7MjDc,.VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
]{margin-left: 32px;margin-right: 0
}.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{margin-left: 0;margin-right: 32px;width: 24px;height: 24px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc,.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
]{margin-left: 32px;margin-right: 0
}.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{margin-left: 0;margin-right: 16px;width: 40px;height: 40px;border-radius: 50%
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
]{margin-left: 16px;margin-right: 0
}.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{margin-left: 0;margin-right: 16px;width: 40px;height: 40px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc,.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
]{margin-left: 16px;margin-right: 0
}.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{margin-left: 0;margin-right: 16px;width: 56px;height: 56px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc,.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
]{margin-left: 16px;margin-right: 0
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{margin-left: 0;margin-right: 16px;width: 100px;height: 56px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc,.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
]{margin-left: 16px;margin-right: 0
}.VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex
}.VfPpkd-StrnGf-rymPhb-IhFlZd{margin-left:auto;margin-right: 0
}.VfPpkd-StrnGf-rymPhb-IhFlZd:not(.HzV7m-fuEl3d){-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-caption-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size:.75rem;font-size:var(--mdc-typography-caption-font-size,.75rem);line-height: 1.25rem;line-height:var(--mdc-typography-caption-line-height,
    1.25rem);font-weight: 400;font-weight:var(--mdc-typography-caption-font-weight,
    400);letter-spacing:.0333333333em;letter-spacing:var(--mdc-typography-caption-letter-spacing,.0333333333em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-caption-text-decoration,inherit);text-decoration:var(--mdc-typography-caption-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-caption-text-transform,inherit)
}.VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
] .VfPpkd-StrnGf-rymPhb-IhFlZd,
[dir=rtl
] .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-IhFlZd{margin-left: 0;margin-right:auto
}.VfPpkd-StrnGf-rymPhb-b9t22c{text-overflow:ellipsis;white-space:nowrap;overflow:hidden
}.VfPpkd-StrnGf-rymPhb-b9t22c[for
]{pointer-events:none
}.VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS{text-overflow:ellipsis;white-space:nowrap;overflow:hidden;display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :before,.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :before,.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :before,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :before,.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :after,.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :after,.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :after,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :after,.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 24px;content: "";vertical-align: 0
}.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-body2-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size:.875rem;font-size:var(--mdc-typography-body2-font-size,.875rem);line-height: 1.25rem;line-height:var(--mdc-typography-body2-line-height,
    1.25rem);font-weight: 400;font-weight:var(--mdc-typography-body2-font-weight,
    400);letter-spacing:.0178571429em;letter-spacing:var(--mdc-typography-body2-letter-spacing,.0178571429em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-body2-text-decoration,inherit);text-decoration:var(--mdc-typography-body2-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-body2-text-transform,inherit);text-overflow:ellipsis;white-space:nowrap;overflow:hidden;display:block;margin-top: 0;line-height:normal
}.VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS: :before{display:inline-block;width: 0;height: 20px;content: "";vertical-align: 0
}.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{font-size:inherit
}.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-ibnC6b{height: 40px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aSi1db-RWgCYc .VfPpkd-StrnGf-rymPhb-b9t22c{-webkit-align-self:flex-start;align-self:flex-start
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aSi1db-RWgCYc .VfPpkd-StrnGf-rymPhb-ibnC6b{height: 64px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aSi1db-RWgCYc.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-OWXEXe-aSi1db-RWgCYc.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-OWXEXe-aSi1db-RWgCYc.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-OWXEXe-aSi1db-RWgCYc.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-OWXEXe-aSi1db-RWgCYc.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b{height: 72px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aSi1db-RWgCYc.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aSi1db-RWgCYc.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-ibnC6b{height: 60px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-f7MjDc{margin-left: 0;margin-right: 16px;width: 36px;height: 36px
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-f7MjDc,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb.VfPpkd-StrnGf-rymPhb-OWXEXe-EzIYc .VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
]{margin-left: 16px;margin-right: 0
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b{cursor:pointer
}a.VfPpkd-StrnGf-rymPhb-ibnC6b{color:inherit;text-decoration:none
}.VfPpkd-StrnGf-rymPhb-clz4Ic{height: 0;margin: 0;border:none;border-bottom-width: 1px;border-bottom-style:solid
}.VfPpkd-StrnGf-rymPhb-clz4Ic{border-bottom-color:rgba(0,
    0,
    0,.12)
}.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-nNtqDd{margin-left: 16px;margin-right: 0;width:calc(100% - 32px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-nNtqDd,.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-nNtqDd[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe{margin-left: 72px;margin-right: 0;width:calc(100% - 72px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe,.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe[dir=rtl
]{margin-left: 0;margin-right: 72px
}.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-nNtqDd{margin-left: 72px;margin-right: 0;width:calc(100% - 88px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-nNtqDd,.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-nNtqDd[dir=rtl
]{margin-left: 0;margin-right: 72px
}.VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc{margin-left: 16px;margin-right: 0;width:calc(100% - 16px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc,.VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{width:calc(100% - 16px)
}.VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{margin-left: 16px;margin-right: 0;width:calc(100% - 32px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg,.VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 16px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2,.VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 32px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2,.VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc{margin-left: 72px;margin-right: 0;width:calc(100% - 72px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc,.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc[dir=rtl
]{margin-left: 0;margin-right: 72px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{width:calc(100% - 16px)
}.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{margin-left: 72px;margin-right: 0;width:calc(100% - 88px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg,.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg[dir=rtl
]{margin-left: 0;margin-right: 72px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 16px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2,.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 32px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2,.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc{margin-left: 72px;margin-right: 0;width:calc(100% - 72px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc[dir=rtl
]{margin-left: 0;margin-right: 72px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{width:calc(100% - 16px)
}.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{margin-left: 72px;margin-right: 0;width:calc(100% - 88px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg[dir=rtl
]{margin-left: 0;margin-right: 72px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 16px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 32px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2,.VfPpkd-StrnGf-rymPhb-OWXEXe-YLEF4c-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc{margin-left: 72px;margin-right: 0;width:calc(100% - 72px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc,.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc[dir=rtl
]{margin-left: 0;margin-right: 72px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{width:calc(100% - 16px)
}.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{margin-left: 72px;margin-right: 0;width:calc(100% - 88px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg,.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg[dir=rtl
]{margin-left: 0;margin-right: 72px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 16px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2,.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 32px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2,.VfPpkd-StrnGf-rymPhb-OWXEXe-JUCs7e-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc{margin-left: 88px;margin-right: 0;width:calc(100% - 88px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc,.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc[dir=rtl
]{margin-left: 0;margin-right: 88px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{width:calc(100% - 16px)
}.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{margin-left: 88px;margin-right: 0;width:calc(100% - 104px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg,.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg[dir=rtl
]{margin-left: 0;margin-right: 88px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 16px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2,.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 32px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2,.VfPpkd-StrnGf-rymPhb-OWXEXe-HiaYvf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc{margin-left: 116px;margin-right: 0;width:calc(100% - 116px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc,.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc[dir=rtl
]{margin-left: 0;margin-right: 116px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{width:calc(100% - 16px)
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{margin-left: 116px;margin-right: 0;width:calc(100% - 132px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg,.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg[dir=rtl
]{margin-left: 0;margin-right: 116px
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2{margin-left: 0;margin-right: 0;width: 100%
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2,.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 0
}.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2{margin-left: 0;margin-right: 0;width:calc(100% - 16px)
}[dir=rtl
] .VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2,.VfPpkd-StrnGf-rymPhb-OWXEXe-aTv5jf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 0
}.VfPpkd-StrnGf-rymPhb-JNdkSc .VfPpkd-StrnGf-rymPhb{padding: 0
}.VfPpkd-StrnGf-rymPhb-oT7voc{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-subtitle1-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size: 1rem;font-size:var(--mdc-typography-subtitle1-font-size,
    1rem);line-height: 1.75rem;line-height:var(--mdc-typography-subtitle1-line-height,
    1.75rem);font-weight: 400;font-weight:var(--mdc-typography-subtitle1-font-weight,
    400);letter-spacing:.009375em;letter-spacing:var(--mdc-typography-subtitle1-letter-spacing,.009375em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-subtitle1-text-decoration,inherit);text-decoration:var(--mdc-typography-subtitle1-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-subtitle1-text-transform,inherit);margin:.75rem 16px
}.VfPpkd-rymPhb-Gtdoyb,.VfPpkd-rymPhb-fpDzbe-fmcmS{color:rgba(0,
    0,
    0,.87);color:var(--mdc-theme-text-primary-on-background,rgba(0,
    0,
    0,.87))
}.VfPpkd-rymPhb-L8ivfd-fmcmS{color:rgba(0,
    0,
    0,.54);color:var(--mdc-theme-text-secondary-on-background,rgba(0,
    0,
    0,.54))
}.VfPpkd-rymPhb-bC5pod-fmcmS{color:rgba(0,
    0,
    0,.38);color:var(--mdc-theme-text-hint-on-background,rgba(0,
    0,
    0,.38))
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e{background-color:transparent
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e{color:rgba(0,
    0,
    0,.38);color:var(--mdc-theme-text-icon-on-background,rgba(0,
    0,
    0,.38))
}.VfPpkd-rymPhb-JMEf7e{color:rgba(0,
    0,
    0,.38);color:var(--mdc-theme-text-hint-on-background,rgba(0,
    0,
    0,.38))
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-JMEf7e{opacity:.38
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-fpDzbe-fmcmS{color:#000;color:var(--mdc-theme-on-surface,#000)
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-L8ivfd-fmcmS{color:#000;color:var(--mdc-theme-on-surface,#000)
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-bC5pod-fmcmS{color:#000;color:var(--mdc-theme-on-surface,#000)
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb{color:#000;color:var(--mdc-theme-on-surface,#000)
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e{color:#000;color:var(--mdc-theme-on-surface,#000)
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{color:#000;color:var(--mdc-theme-on-surface,#000)
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-Gtdoyb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-fpDzbe-fmcmS,.VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-Gtdoyb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-fpDzbe-fmcmS{color:#6200ee;color:var(--mdc-theme-primary,#6200ee)
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb{color:#6200ee;color:var(--mdc-theme-primary,#6200ee)
}.VfPpkd-StrnGf-rymPhb-oT7voc{color:rgba(0,
    0,
    0,.87);color:var(--mdc-theme-text-primary-on-background,rgba(0,
    0,
    0,.87))
}.VfPpkd-rymPhb-clz4Ic: :after{border-bottom-color:white
}.VfPpkd-rymPhb{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-subtitle1-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size: 1rem;font-size:var(--mdc-typography-subtitle1-font-size,
    1rem);line-height: 1.75rem;line-height:var(--mdc-typography-subtitle1-line-height,
    1.75rem);font-weight: 400;font-weight:var(--mdc-typography-subtitle1-font-weight,
    400);letter-spacing:.009375em;letter-spacing:var(--mdc-typography-subtitle1-letter-spacing,.009375em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-subtitle1-text-decoration,inherit);text-decoration:var(--mdc-typography-subtitle1-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-subtitle1-text-transform,inherit);line-height: 1.5rem
}.VfPpkd-rymPhb-fpDzbe-fmcmS{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-subtitle1-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size: 1rem;font-size:var(--mdc-typography-subtitle1-font-size,
    1rem);line-height: 1.75rem;line-height:var(--mdc-typography-subtitle1-line-height,
    1.75rem);font-weight: 400;font-weight:var(--mdc-typography-subtitle1-font-weight,
    400);letter-spacing:.009375em;letter-spacing:var(--mdc-typography-subtitle1-letter-spacing,.009375em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-subtitle1-text-decoration,inherit);text-decoration:var(--mdc-typography-subtitle1-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-subtitle1-text-transform,inherit)
}.VfPpkd-rymPhb-L8ivfd-fmcmS{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-body2-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size:.875rem;font-size:var(--mdc-typography-body2-font-size,.875rem);line-height: 1.25rem;line-height:var(--mdc-typography-body2-line-height,
    1.25rem);font-weight: 400;font-weight:var(--mdc-typography-body2-font-weight,
    400);letter-spacing:.0178571429em;letter-spacing:var(--mdc-typography-body2-letter-spacing,.0178571429em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-body2-text-decoration,inherit);text-decoration:var(--mdc-typography-body2-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-body2-text-transform,inherit)
}.VfPpkd-rymPhb-bC5pod-fmcmS{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-overline-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size:.75rem;font-size:var(--mdc-typography-overline-font-size,.75rem);line-height: 2rem;line-height:var(--mdc-typography-overline-line-height,
    2rem);font-weight: 500;font-weight:var(--mdc-typography-overline-font-weight,
    500);letter-spacing:.1666666667em;letter-spacing:var(--mdc-typography-overline-letter-spacing,.1666666667em);text-decoration:none;-webkit-text-decoration:var(--mdc-typography-overline-text-decoration,none);text-decoration:var(--mdc-typography-overline-text-decoration,none);text-transform:uppercase;text-transform:var(--mdc-typography-overline-text-transform,uppercase)
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c .VfPpkd-rymPhb-KkROqb{width: 40px;height: 40px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb{width: 24px;height: 24px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e .VfPpkd-rymPhb-KkROqb{width: 40px;height: 40px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf .VfPpkd-rymPhb-KkROqb{width: 56px;height: 56px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf .VfPpkd-rymPhb-KkROqb{width: 100px;height: 56px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b .VfPpkd-rymPhb-KkROqb{width: 40px;height: 40px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc .VfPpkd-rymPhb-KkROqb{width: 36px;height: 20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e{width: 24px;height: 24px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-MPu53c .VfPpkd-rymPhb-JMEf7e,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-GCYh9b .VfPpkd-rymPhb-JMEf7e{width: 40px;height: 40px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-scr2fc .VfPpkd-rymPhb-JMEf7e{width: 36px;height: 20px
}.VfPpkd-rymPhb-oT7voc{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-subtitle1-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size: 1rem;font-size:var(--mdc-typography-subtitle1-font-size,
    1rem);line-height: 1.75rem;line-height:var(--mdc-typography-subtitle1-line-height,
    1.75rem);font-weight: 400;font-weight:var(--mdc-typography-subtitle1-font-weight,
    400);letter-spacing:.009375em;letter-spacing:var(--mdc-typography-subtitle1-letter-spacing,.009375em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-subtitle1-text-decoration,inherit);text-decoration:var(--mdc-typography-subtitle1-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-subtitle1-text-transform,inherit)
}.VfPpkd-rymPhb-clz4Ic{background-color:rgba(0,
    0,
    0,.12)
}.VfPpkd-rymPhb-clz4Ic{height: 1px
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.VfPpkd-rymPhb-clz4Ic: :after{content: "";display:block;border-bottom-width: 1px;border-bottom-style:solid
    }
}.VfPpkd-rymPhb{margin: 0;padding: 8px 0;list-style-type:none
}.VfPpkd-rymPhb:focus{outline:none
}.VfPpkd-rymPhb-Tkg0ld{display:block
}.VfPpkd-rymPhb-ibnC6b{display:-webkit-box;display:-webkit-flex;display:flex;position:relative;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:start;-webkit-justify-content:flex-start;justify-content:flex-start;overflow:hidden;padding: 0;-webkit-box-align:stretch;-webkit-align-items:stretch;align-items:stretch;cursor:pointer
}.VfPpkd-rymPhb-ibnC6b:focus{outline:none
}.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc{height: 48px
}.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb{height: 64px
}.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb{height: 88px
}.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc .VfPpkd-rymPhb-KkROqb{-webkit-align-self:center;align-self:center;margin-top: 0
}.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-KkROqb{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 16px
}.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc .VfPpkd-rymPhb-JMEf7e,.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-JMEf7e{-webkit-align-self:center;align-self:center;margin-top: 0
}.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-JMEf7e{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 16px
}.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me,.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-tPcied-hXIJHe{cursor:auto
}.VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd):focus: :before,.VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe: :before{position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;width: 100%;height: 100%;top: 0;left: 0;border: 1px solid transparent;border-radius:inherit;content: "";pointer-events:none
}@media screen and (forced-colors:active){.VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd):focus: :before,.VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe: :before{border-color:CanvasText
    }
}.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd: :before{position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;width: 100%;height: 100%;top: 0;left: 0;border: 3px double transparent;border-radius:inherit;content: "";pointer-events:none
}@media screen and (forced-colors:active){.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd: :before{border-color:CanvasText
    }
}.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:focus: :before{position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;width: 100%;height: 100%;top: 0;left: 0;border: 3px solid transparent;border-radius:inherit;content: "";pointer-events:none
}@media screen and (forced-colors:active){.VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:focus: :before{border-color:CanvasText
    }
}a.VfPpkd-rymPhb-ibnC6b{color:inherit;text-decoration:none
}.VfPpkd-rymPhb-KkROqb{fill:currentColor;-webkit-flex-shrink: 0;flex-shrink: 0;pointer-events:none
}.VfPpkd-rymPhb-JMEf7e{-webkit-flex-shrink: 0;flex-shrink: 0;pointer-events:none
}.VfPpkd-rymPhb-Gtdoyb{text-overflow:ellipsis;white-space:nowrap;overflow:hidden;-webkit-align-self:center;align-self:center;-webkit-box-flex: 1;-webkit-flex: 1;flex: 1;pointer-events:none
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-Gtdoyb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-Gtdoyb{-webkit-align-self:stretch;align-self:stretch
}.VfPpkd-rymPhb-Gtdoyb[for
]{pointer-events:none
}.VfPpkd-rymPhb-fpDzbe-fmcmS{text-overflow:ellipsis;white-space:nowrap;overflow:hidden
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :after,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-L8ivfd-fmcmS{text-overflow:ellipsis;white-space:nowrap;overflow:hidden;display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-L8ivfd-fmcmS: :before{display:inline-block;width: 0;height: 20px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-L8ivfd-fmcmS{white-space:normal;line-height: 20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-BYmFj .VfPpkd-rymPhb-L8ivfd-fmcmS{white-space:nowrap;line-height:auto
}.VfPpkd-rymPhb-bC5pod-fmcmS{text-overflow:ellipsis;white-space:nowrap;overflow:hidden
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :before{display:inline-block;width: 0;height: 24px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c .VfPpkd-rymPhb-KkROqb{margin-left: 16px;margin-right: 16px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 16px;margin-right: 16px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc{height: 56px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb{height: 72px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-YLEF4c .VfPpkd-rymPhb-KkROqb{border-radius: 50%
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb{margin-left: 16px;margin-right: 32px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 32px;margin-right: 16px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc{height: 56px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb{height: 72px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e .VfPpkd-rymPhb-KkROqb{margin-left: 16px;margin-right: 16px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 16px;margin-right: 16px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc{height: 56px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb{height: 72px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf .VfPpkd-rymPhb-KkROqb{margin-left: 16px;margin-right: 16px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 16px;margin-right: 16px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb{height: 72px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 8px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf .VfPpkd-rymPhb-KkROqb{margin-left: 0;margin-right: 16px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 16px;margin-right: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb{height: 72px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c .VfPpkd-rymPhb-KkROqb{margin-left: 8px;margin-right: 24px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 24px;margin-right: 8px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 8px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc{height: 56px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb{height: 72px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b .VfPpkd-rymPhb-KkROqb{margin-left: 8px;margin-right: 24px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 24px;margin-right: 8px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 8px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc{height: 56px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb{height: 72px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc .VfPpkd-rymPhb-KkROqb{margin-left: 16px;margin-right: 16px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc .VfPpkd-rymPhb-KkROqb,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 16px;margin-right: 16px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 16px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS{display:block;margin-top: 0;line-height:normal;margin-bottom: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-bC5pod-fmcmS: :after{display:inline-block;width: 0;height: 20px;content: "";vertical-align: -20px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e: :before{display:inline-block;width: 0;height: 32px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc{height: 56px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb{height: 72px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c.VfPpkd-rymPhb-ibnC6b{padding-left:auto;padding-right: 0
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 0;padding-right:auto
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e{margin-left: 16px;margin-right: 16px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e[dir=rtl
]{margin-left: 16px;margin-right: 16px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-JMEf7e,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-JMEf7e{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf.VfPpkd-rymPhb-ibnC6b{padding-left:auto;padding-right: 0
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 0;padding-right:auto
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{margin-left: 28px;margin-right: 16px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e[dir=rtl
]{margin-left: 16px;margin-right: 28px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-JMEf7e{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-JMEf7e: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-JMEf7e{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-JMEf7e: :before{display:inline-block;width: 0;height: 28px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-caption-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size:.75rem;font-size:var(--mdc-typography-caption-font-size,.75rem);line-height: 1.25rem;line-height:var(--mdc-typography-caption-line-height,
    1.25rem);font-weight: 400;font-weight:var(--mdc-typography-caption-font-weight,
    400);letter-spacing:.0333333333em;letter-spacing:var(--mdc-typography-caption-letter-spacing,.0333333333em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-caption-text-decoration,inherit);text-decoration:var(--mdc-typography-caption-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-caption-text-transform,inherit)
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-MPu53c.VfPpkd-rymPhb-ibnC6b{padding-left:auto;padding-right: 0
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-MPu53c.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-MPu53c.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 0;padding-right:auto
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-MPu53c .VfPpkd-rymPhb-JMEf7e{margin-left: 24px;margin-right: 8px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-MPu53c .VfPpkd-rymPhb-JMEf7e,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-MPu53c .VfPpkd-rymPhb-JMEf7e[dir=rtl
]{margin-left: 8px;margin-right: 24px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-MPu53c.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-JMEf7e{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 8px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-GCYh9b.VfPpkd-rymPhb-ibnC6b{padding-left:auto;padding-right: 0
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-GCYh9b.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-GCYh9b.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 0;padding-right:auto
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-GCYh9b .VfPpkd-rymPhb-JMEf7e{margin-left: 24px;margin-right: 8px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-GCYh9b .VfPpkd-rymPhb-JMEf7e,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-GCYh9b .VfPpkd-rymPhb-JMEf7e[dir=rtl
]{margin-left: 8px;margin-right: 24px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-GCYh9b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-JMEf7e{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 8px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-scr2fc.VfPpkd-rymPhb-ibnC6b{padding-left:auto;padding-right: 0
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-scr2fc.VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-scr2fc.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 0;padding-right:auto
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-scr2fc .VfPpkd-rymPhb-JMEf7e{margin-left: 16px;margin-right: 16px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-scr2fc .VfPpkd-rymPhb-JMEf7e,.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-scr2fc .VfPpkd-rymPhb-JMEf7e[dir=rtl
]{margin-left: 16px;margin-right: 16px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-scr2fc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-JMEf7e{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 16px
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-BYmFj.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-BYmFj.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 20px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-BYmFj.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS{display:block;margin-top: 0;line-height:normal
}.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-BYmFj.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-vfifzc-MCEKJb .VfPpkd-rymPhb-fpDzbe-fmcmS: :before{display:inline-block;width: 0;height: 20px;content: "";vertical-align: 0
}.VfPpkd-rymPhb-ibnC6b{padding-left: 16px;padding-right: 16px
}[dir=rtl
] .VfPpkd-rymPhb-ibnC6b,.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 16px;padding-right: 16px
}.VfPpkd-rymPhb-JNdkSc .VfPpkd-StrnGf-rymPhb{padding: 0
}.VfPpkd-rymPhb-oT7voc{margin:.75rem 16px
}.VfPpkd-rymPhb-clz4Ic{padding: 0;background-clip:content-box
}.VfPpkd-rymPhb-clz4Ic.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-fmcmS.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe{padding-left: 16px;padding-right:auto
}[dir=rtl
] .VfPpkd-rymPhb-clz4Ic.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-fmcmS.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.VfPpkd-rymPhb-clz4Ic.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-fmcmS.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
]{padding-left:auto;padding-right: 16px
}.VfPpkd-rymPhb-clz4Ic.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-fmcmS.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe{padding-left:auto;padding-right: 16px
}[dir=rtl
] .VfPpkd-rymPhb-clz4Ic.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-fmcmS.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,
[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,.VfPpkd-rymPhb-clz4Ic.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-fmcmS.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-Bz112c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-JUCs7e.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YLEF4c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-MPu53c.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-scr2fc.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe[dir=rtl
],.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-GCYh9b.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe[dir=rtl
]{padding-left: 16px;padding-right:auto
}.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe{padding-left: 0;padding-right:auto
}[dir=rtl
] .VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
]{padding-left:auto;padding-right: 0
}[dir=rtl
] .VfPpkd-rymPhb-clz4Ic,.VfPpkd-rymPhb-clz4Ic[dir=rtl
]{padding: 0
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b{--mdc-ripple-fg-size: 0;--mdc-ripple-left: 0;--mdc-ripple-top: 0;--mdc-ripple-fg-scale: 1;--mdc-ripple-fg-translate-end: 0;--mdc-ripple-fg-translate-start: 0;-webkit-tap-highlight-color:rgba(0,
    0,
    0,
    0);will-change:transform,opacity
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{position:absolute;border-radius: 50%;opacity: 0;pointer-events:none;content: ""
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition:opacity 15ms linear,background-color 15ms linear;transition:opacity 15ms linear,background-color 15ms linear;z-index: 1;z-index:var(--mdc-ripple-z-index,
    1)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{z-index: 0;z-index:var(--mdc-ripple-z-index,
    0)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transform:scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:scale(var(--mdc-ripple-fg-scale,
    1));transform:scale(var(--mdc-ripple-fg-scale,
    1))
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d .VfPpkd-StrnGf-rymPhb-pZXsl: :after{top: 0;left: 0;-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0);-webkit-transform-origin:center center;-ms-transform-origin:center center;transform-origin:center center
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{top:var(--mdc-ripple-top,
    0);left:var(--mdc-ripple-left,
    0)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-lJfZMc .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards;animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-OmS1vf .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-animation:mdc-ripple-fg-opacity-out .15s;animation:mdc-ripple-fg-opacity-out .15s;-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1))
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{position:absolute;border-radius: 50%;opacity: 0;pointer-events:none;content: ""
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition:opacity 15ms linear,background-color 15ms linear;transition:opacity 15ms linear,background-color 15ms linear;z-index: 1;z-index:var(--mdc-ripple-z-index,
    1)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{z-index: 0;z-index:var(--mdc-ripple-z-index,
    0)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d .VfPpkd-rymPhb-pZXsl: :before{-webkit-transform:scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:scale(var(--mdc-ripple-fg-scale,
    1));transform:scale(var(--mdc-ripple-fg-scale,
    1))
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d .VfPpkd-rymPhb-pZXsl: :after{top: 0;left: 0;-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0);-webkit-transform-origin:center center;-ms-transform-origin:center center;transform-origin:center center
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd .VfPpkd-rymPhb-pZXsl: :after{top:var(--mdc-ripple-top,
    0);left:var(--mdc-ripple-left,
    0)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-lJfZMc .VfPpkd-rymPhb-pZXsl: :after{-webkit-animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards;animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-OmS1vf .VfPpkd-rymPhb-pZXsl: :after{-webkit-animation:mdc-ripple-fg-opacity-out .15s;animation:mdc-ripple-fg-opacity-out .15s;-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1))
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{top: -50%;left: -50%;width: 200%;height: 200%
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d .VfPpkd-StrnGf-rymPhb-pZXsl: :after{width:var(--mdc-ripple-fg-size,
    100%);height:var(--mdc-ripple-fg-size,
    100%)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{top: -50%;left: -50%;width: 200%;height: 200%
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d .VfPpkd-rymPhb-pZXsl: :after{width:var(--mdc-ripple-fg-size,
    100%);height:var(--mdc-ripple-fg-size,
    100%)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:#000;background-color:var(--mdc-ripple-color,#000)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{background-color:#000;background-color:var(--mdc-ripple-color,#000)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b:hover .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.12)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.12;opacity:var(--mdc-ripple-activated-opacity,.12)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:#6200ee;background-color:var(--mdc-ripple-color,var(--mdc-theme-primary,#6200ee))
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.16;opacity:var(--mdc-ripple-hover-opacity,.16)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-press-opacity,.24)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-pZXsl: :before{opacity:.12;opacity:var(--mdc-ripple-activated-opacity,.12)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-pZXsl: :after{background-color:#6200ee;background-color:var(--mdc-ripple-color,var(--mdc-theme-primary,#6200ee))
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b:hover .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.16;opacity:var(--mdc-ripple-hover-opacity,.16)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-press-opacity,.24)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.24)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.08;opacity:var(--mdc-ripple-selected-opacity,.08)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:#6200ee;background-color:var(--mdc-ripple-color,var(--mdc-theme-primary,#6200ee))
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.12;opacity:var(--mdc-ripple-hover-opacity,.12)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-ripple-focus-opacity,.2)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-ripple-press-opacity,.2)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before{opacity:.08;opacity:var(--mdc-ripple-selected-opacity,.08)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :after{background-color:#6200ee;background-color:var(--mdc-ripple-color,var(--mdc-theme-primary,#6200ee))
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.12;opacity:var(--mdc-ripple-hover-opacity,.12)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-ripple-focus-opacity,.2)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-ripple-press-opacity,.2)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.2)
}:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl,
:not(.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl{position:absolute;top: 0;left: 0;width: 100%;height: 100%;pointer-events:none
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b{--mdc-ripple-fg-size: 0;--mdc-ripple-left: 0;--mdc-ripple-top: 0;--mdc-ripple-fg-scale: 1;--mdc-ripple-fg-translate-end: 0;--mdc-ripple-fg-translate-start: 0;-webkit-tap-highlight-color:rgba(0,
    0,
    0,
    0);will-change:transform,opacity
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{position:absolute;border-radius: 50%;opacity: 0;pointer-events:none;content: ""
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition:opacity 15ms linear,background-color 15ms linear;transition:opacity 15ms linear,background-color 15ms linear;z-index: 1;z-index:var(--mdc-ripple-z-index,
    1)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{z-index: 0;z-index:var(--mdc-ripple-z-index,
    0)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d .VfPpkd-rymPhb-pZXsl: :before{-webkit-transform:scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:scale(var(--mdc-ripple-fg-scale,
    1));transform:scale(var(--mdc-ripple-fg-scale,
    1))
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d .VfPpkd-rymPhb-pZXsl: :after{top: 0;left: 0;-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0);-webkit-transform-origin:center center;-ms-transform-origin:center center;transform-origin:center center
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-ZNMTqd .VfPpkd-rymPhb-pZXsl: :after{top:var(--mdc-ripple-top,
    0);left:var(--mdc-ripple-left,
    0)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-lJfZMc .VfPpkd-rymPhb-pZXsl: :after{-webkit-animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards;animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-Tv8l5d-OmS1vf .VfPpkd-rymPhb-pZXsl: :after{-webkit-animation:mdc-ripple-fg-opacity-out .15s;animation:mdc-ripple-fg-opacity-out .15s;-webkit-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));-ms-transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1));transform:translate(var(--mdc-ripple-fg-translate-end,
    0)) scale(var(--mdc-ripple-fg-scale,
    1))
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{top: -50%;left: -50%;width: 200%;height: 200%
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d .VfPpkd-rymPhb-pZXsl: :after{width:var(--mdc-ripple-fg-size,
    100%);height:var(--mdc-ripple-fg-size,
    100%)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{background-color:#000;background-color:var(--mdc-ripple-color,#000)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b:hover .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.12)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-pZXsl: :before{opacity:.12;opacity:var(--mdc-ripple-activated-opacity,.12)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-pZXsl: :after{background-color:#6200ee;background-color:var(--mdc-ripple-color,var(--mdc-theme-primary,#6200ee))
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b:hover .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.16;opacity:var(--mdc-ripple-hover-opacity,.16)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-press-opacity,.24)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.24)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before{opacity:.08;opacity:var(--mdc-ripple-selected-opacity,.08)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :after{background-color:#6200ee;background-color:var(--mdc-ripple-color,var(--mdc-theme-primary,#6200ee))
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.12;opacity:var(--mdc-ripple-hover-opacity,.12)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,
:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-ripple-focus-opacity,.2)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-ripple-press-opacity,.2)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.2)
}:not(.VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me).VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl{position:relative;outline:none;overflow:hidden;position:absolute;top: 0;left: 0;width: 100%;height: 100%;pointer-events:none
}.P2Hi5d,.mkMxfe,.OBi8lb,.P9QRxe,.vqjb4e,.y8Rdrf,.DMZ54e{font-family:Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 400;color:#000;color:var(--mdc-theme-on-surface,#000)
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-IhFlZd,.mkMxfe .VfPpkd-StrnGf-rymPhb-IhFlZd,.OBi8lb .VfPpkd-StrnGf-rymPhb-IhFlZd,.P9QRxe .VfPpkd-StrnGf-rymPhb-IhFlZd,.vqjb4e .VfPpkd-StrnGf-rymPhb-IhFlZd,.y8Rdrf .VfPpkd-StrnGf-rymPhb-IhFlZd,.DMZ54e .VfPpkd-StrnGf-rymPhb-IhFlZd{color:rgb(95,
    99,
    104)
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(60,
    64,
    67)
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity:.38
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b{color:#000;color:var(--mdc-theme-on-surface,#000)
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc{color:#000;color:var(--mdc-theme-on-surface,#000)
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity: 0
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgb(232,
    240,
    254)
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(26,
    115,
    232);background-color:var(--mdc-ripple-color,rgb(26,
    115,
    232))
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.1)
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:GrayText
    }.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.OBi8lb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.P9QRxe .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.vqjb4e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.y8Rdrf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.DMZ54e .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity: 1
    }
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 24px;padding-right: 16px
}[dir=rtl
] .P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b,.P2Hi5d .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
]{padding-left: 16px;padding-right: 24px
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc{margin-left: 24px;margin-right: 0;width:calc(100% - 24px)
}[dir=rtl
] .P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc,.P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc[dir=rtl
]{margin-left: 0;margin-right: 24px
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{width:calc(100% - 16px)
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{margin-left: 24px;margin-right: 0;width:calc(100% - 40px)
}[dir=rtl
] .P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg,.P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg[dir=rtl
]{margin-left: 0;margin-right: 24px
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2{margin-left: 24px;margin-right: 0;width:calc(100% - 24px)
}[dir=rtl
] .P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2,.P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 24px
}.P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2{margin-left: 24px;margin-right: 0;width:calc(100% - 40px)
}[dir=rtl
] .P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2,.P2Hi5d .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 24px
}.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-f7MjDc{margin-left: 0;margin-right: 16px
}[dir=rtl
] .mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-f7MjDc,.mkMxfe .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
]{margin-left: 16px;margin-right: 0
}.mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc{margin-left: 56px;margin-right: 0;width:calc(100% - 56px)
}[dir=rtl
] .mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc,.mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc[dir=rtl
]{margin-left: 0;margin-right: 56px
}.mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{width:calc(100% - 16px)
}.mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg{margin-left: 56px;margin-right: 0;width:calc(100% - 72px)
}[dir=rtl
] .mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg,.mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg[dir=rtl
]{margin-left: 0;margin-right: 56px
}.mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 16px)
}[dir=rtl
] .mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2,.mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2{margin-left: 16px;margin-right: 0;width:calc(100% - 32px)
}[dir=rtl
] .mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2,.mkMxfe .VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-M1Soyc.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-UbuQg.VfPpkd-StrnGf-rymPhb-clz4Ic-OWXEXe-YbohUe-QFlW2[dir=rtl
]{margin-left: 0;margin-right: 16px
}.r6B9Fd{font-family:Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 400
}.r6B9Fd .VfPpkd-rymPhb-Gtdoyb,.r6B9Fd .VfPpkd-rymPhb-fpDzbe-fmcmS{color:rgb(60,
    64,
    67)
}.r6B9Fd .VfPpkd-rymPhb-L8ivfd-fmcmS,.r6B9Fd .VfPpkd-rymPhb-bC5pod-fmcmS,.r6B9Fd .VfPpkd-rymPhb-JMEf7e{color:rgb(95,
    99,
    104)
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-fpDzbe-fmcmS,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-L8ivfd-fmcmS,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-bC5pod-fmcmS,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{color:rgb(60,
    64,
    67)
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-KkROqb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-JMEf7e{opacity:.38
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-Gtdoyb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-fpDzbe-fmcmS,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-Gtdoyb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-fpDzbe-fmcmS,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb{color:rgb(60,
    64,
    67)
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before{opacity: 0
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgb(232,
    240,
    254)
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before,.r6B9Fd .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :after{background-color:rgb(26,
    115,
    232);background-color:var(--mdc-ripple-color,rgb(26,
    115,
    232))
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-rymPhb-pZXsl: :before,.r6B9Fd .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,.r6B9Fd .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
}.r6B9Fd .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.1)
}@media screen and (forced-colors:active){.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-fpDzbe-fmcmS,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-L8ivfd-fmcmS,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-bC5pod-fmcmS,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{color:GrayText
    }.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-KkROqb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.r6B9Fd .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-JMEf7e{opacity: 1
    }
}.uTZ9Lb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb,.FvXOfd.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb,.QrsYgb.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb,.gfwIBd.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb{-webkit-align-self:center;align-self:center;margin-top: 0
}.HiC7Nc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc{height: 56px
}.HiC7Nc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-HiaYvf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc,.HiC7Nc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-aTv5jf.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-Woal0c-RWgCYc{height: 72px
}.UbEQCe.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .UbEQCe.VfPpkd-rymPhb-ibnC6b,.UbEQCe.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.UbEQCe .VfPpkd-rymPhb-KkROqb{margin-left: 16px;margin-right: 16px
}[dir=rtl
] .UbEQCe .VfPpkd-rymPhb-KkROqb,.UbEQCe .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 16px;margin-right: 16px
}.rKASPc.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .rKASPc.VfPpkd-rymPhb-ibnC6b,.rKASPc.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.rKASPc .VfPpkd-rymPhb-KkROqb{margin-left: 8px;margin-right: 8px
}[dir=rtl
] .rKASPc .VfPpkd-rymPhb-KkROqb,.rKASPc .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 8px;margin-right: 8px
}.rKASPc.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 8px
}.U5k4Fd.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .U5k4Fd.VfPpkd-rymPhb-ibnC6b,.U5k4Fd.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.U5k4Fd .VfPpkd-rymPhb-KkROqb{margin-left: 8px;margin-right: 8px
}[dir=rtl
] .U5k4Fd .VfPpkd-rymPhb-KkROqb,.U5k4Fd .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 8px;margin-right: 8px
}.U5k4Fd.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 8px
}.ifEyr.VfPpkd-rymPhb-ibnC6b{padding-left: 0;padding-right:auto
}[dir=rtl
] .ifEyr.VfPpkd-rymPhb-ibnC6b,.ifEyr.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left:auto;padding-right: 0
}.ifEyr .VfPpkd-rymPhb-KkROqb{margin-left: 8px;margin-right: 8px
}[dir=rtl
] .ifEyr .VfPpkd-rymPhb-KkROqb,.ifEyr .VfPpkd-rymPhb-KkROqb[dir=rtl
]{margin-left: 8px;margin-right: 8px
}.ifEyr.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-aSi1db-MCEKJb .VfPpkd-rymPhb-KkROqb{-webkit-align-self:flex-start;align-self:flex-start;margin-top: 8px
}.SNowt.VfPpkd-rymPhb-ibnC6b{padding-left:auto;padding-right: 0
}[dir=rtl
] .SNowt.VfPpkd-rymPhb-ibnC6b,.SNowt.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 0;padding-right:auto
}.SNowt .VfPpkd-rymPhb-JMEf7e{margin-left: 8px;margin-right: 16px
}[dir=rtl
] .SNowt .VfPpkd-rymPhb-JMEf7e,.SNowt .VfPpkd-rymPhb-JMEf7e[dir=rtl
]{margin-left: 16px;margin-right: 8px
}.tfmWAf.VfPpkd-rymPhb-ibnC6b{padding-left:auto;padding-right: 0
}[dir=rtl
] .tfmWAf.VfPpkd-rymPhb-ibnC6b,.tfmWAf.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 0;padding-right:auto
}.tfmWAf .VfPpkd-rymPhb-JMEf7e{margin-left: 8px;margin-right: 16px
}[dir=rtl
] .tfmWAf .VfPpkd-rymPhb-JMEf7e,.tfmWAf .VfPpkd-rymPhb-JMEf7e[dir=rtl
]{margin-left: 16px;margin-right: 8px
}.axtYbd.VfPpkd-rymPhb-ibnC6b{padding-left:auto;padding-right: 0
}[dir=rtl
] .axtYbd.VfPpkd-rymPhb-ibnC6b,.axtYbd.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 0;padding-right:auto
}.axtYbd .VfPpkd-rymPhb-JMEf7e{margin-left: 16px;margin-right: 24px
}[dir=rtl
] .axtYbd .VfPpkd-rymPhb-JMEf7e,.axtYbd .VfPpkd-rymPhb-JMEf7e[dir=rtl
]{margin-left: 24px;margin-right: 16px
}.aopLEb.VfPpkd-rymPhb-ibnC6b{padding-left:auto;padding-right: 0
}[dir=rtl
] .aopLEb.VfPpkd-rymPhb-ibnC6b,.aopLEb.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 0;padding-right:auto
}.aopLEb .VfPpkd-rymPhb-JMEf7e{margin-left: 16px;margin-right: 24px
}[dir=rtl
] .aopLEb .VfPpkd-rymPhb-JMEf7e,.aopLEb .VfPpkd-rymPhb-JMEf7e[dir=rtl
]{margin-left: 24px;margin-right: 16px
}.zlqiud.VfPpkd-rymPhb-ibnC6b{padding-left:auto;padding-right: 0
}[dir=rtl
] .zlqiud.VfPpkd-rymPhb-ibnC6b,.zlqiud.VfPpkd-rymPhb-ibnC6b[dir=rtl
]{padding-left: 0;padding-right:auto
}.zlqiud .VfPpkd-rymPhb-JMEf7e{margin-left: 16px;margin-right: 24px
}[dir=rtl
] .zlqiud .VfPpkd-rymPhb-JMEf7e,.zlqiud .VfPpkd-rymPhb-JMEf7e[dir=rtl
]{margin-left: 24px;margin-right: 16px
}.isC8Y.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe{padding-left: 24px;padding-right:auto
}[dir=rtl
] .isC8Y.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe,.isC8Y.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-M1Soyc-YbohUe[dir=rtl
]{padding-left:auto;padding-right: 24px
}.MCs1Pd{padding-left: 24px;padding-right: 24px
}[dir=rtl
] .MCs1Pd,.MCs1Pd[dir=rtl
]{padding-left: 24px;padding-right: 24px
}.e6pQl.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe{padding-left:auto;padding-right: 24px
}[dir=rtl
] .e6pQl.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe,.e6pQl.VfPpkd-rymPhb-clz4Ic-OWXEXe-SfQLQb-UbuQg-YbohUe[dir=rtl
]{padding-left: 24px;padding-right:auto
}[dir=rtl
] .e6pQl,.e6pQl[dir=rtl
]{padding: 0
}.VfPpkd-xl07Ob-XxIAqe{display:none;position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;margin: 0;padding: 0;-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);-webkit-transform-origin:top left;-ms-transform-origin:top left;transform-origin:top left;opacity: 0;overflow:auto;will-change:transform,opacity;-webkit-box-shadow: 0 5px 5px -3px rgba(0,
    0,
    0,.2),
    0 8px 10px 1px rgba(0,
    0,
    0,.14),
    0 3px 14px 2px rgba(0,
    0,
    0,.12);box-shadow: 0 5px 5px -3px rgba(0,
    0,
    0,.2),
    0 8px 10px 1px rgba(0,
    0,
    0,.14),
    0 3px 14px 2px rgba(0,
    0,
    0,.12);transform-origin-left:top left;transform-origin-right:top right
}.VfPpkd-xl07Ob-XxIAqe:focus{outline:none
}.VfPpkd-xl07Ob-XxIAqe-OWXEXe-oT9UPb-FNFY6c{display:inline-block;-webkit-transform:scale(.8);-ms-transform:scale(.8);transform:scale(.8);opacity: 0
}.VfPpkd-xl07Ob-XxIAqe-OWXEXe-FNFY6c{display:inline-block;-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);opacity: 1
}.VfPpkd-xl07Ob-XxIAqe-OWXEXe-oT9UPb-xTMeO{display:inline-block;opacity: 0
}[dir=rtl
] .VfPpkd-xl07Ob-XxIAqe,.VfPpkd-xl07Ob-XxIAqe[dir=rtl
]{transform-origin-left:top right;transform-origin-right:top left
}.VfPpkd-xl07Ob-XxIAqe-OWXEXe-oYxtQd{position:relative;overflow:visible
}.VfPpkd-xl07Ob-XxIAqe-OWXEXe-qbOKL{position:fixed
}.VfPpkd-xl07Ob-XxIAqe-OWXEXe-tsQazb{width: 100%
}.VfPpkd-xl07Ob-XxIAqe{max-width:calc(100vw - 32px);max-width:var(--mdc-menu-max-width,calc(100vw - 32px));max-height:calc(100vh - 32px);max-height:var(--mdc-menu-max-height,calc(100vh - 32px));z-index: 8;-webkit-transition:opacity .03s linear,height .25s cubic-bezier(0,
    0,.2,
    1),-webkit-transform .12s cubic-bezier(0,
    0,.2,
    1);transition:opacity .03s linear,height .25s cubic-bezier(0,
    0,.2,
    1),-webkit-transform .12s cubic-bezier(0,
    0,.2,
    1);transition:opacity .03s linear,transform .12s cubic-bezier(0,
    0,.2,
    1),height .25s cubic-bezier(0,
    0,.2,
    1);transition:opacity .03s linear,transform .12s cubic-bezier(0,
    0,.2,
    1),height .25s cubic-bezier(0,
    0,.2,
    1),-webkit-transform .12s cubic-bezier(0,
    0,.2,
    1);background-color:#fff;background-color:var(--mdc-theme-surface,#fff);color:#000;color:var(--mdc-theme-on-surface,#000);border-radius: 4px;border-radius:var(--mdc-shape-medium,
    4px)
}.VfPpkd-xl07Ob-XxIAqe-OWXEXe-oT9UPb-xTMeO{-webkit-transition:opacity 75ms linear;transition:opacity 75ms linear
}.UQ5E0{-webkit-box-shadow: 0 3px 5px -1px rgba(0,
    0,
    0,.2),
    0 6px 10px 0 rgba(0,
    0,
    0,.14),
    0 1px 18px 0 rgba(0,
    0,
    0,.12);box-shadow: 0 3px 5px -1px rgba(0,
    0,
    0,.2),
    0 6px 10px 0 rgba(0,
    0,
    0,.14),
    0 1px 18px 0 rgba(0,
    0,
    0,.12)
}.VfPpkd-xl07Ob{min-width: 112px;min-width:var(--mdc-menu-min-width,
    112px)
}.VfPpkd-xl07Ob .VfPpkd-StrnGf-rymPhb-IhFlZd,.VfPpkd-xl07Ob .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgba(0,
    0,
    0,.87)
}.VfPpkd-xl07Ob .VfPpkd-xl07Ob-ibnC6b-OWXEXe-eKm5Fc-FNFY6c .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04
}.VfPpkd-xl07Ob .VfPpkd-xl07Ob-ibnC6b-OWXEXe-eKm5Fc-FNFY6c .VfPpkd-rymPhb-pZXsl: :before{opacity:.04
}.VfPpkd-xl07Ob .VfPpkd-StrnGf-rymPhb{color:rgba(0,
    0,
    0,.87)
}.VfPpkd-xl07Ob .VfPpkd-StrnGf-rymPhb,.VfPpkd-xl07Ob .VfPpkd-rymPhb{position:relative;border-radius:inherit
}.VfPpkd-xl07Ob .VfPpkd-StrnGf-rymPhb .VfPpkd-BFbNVe-bF1uUb,.VfPpkd-xl07Ob .VfPpkd-rymPhb .VfPpkd-BFbNVe-bF1uUb{width: 100%;height: 100%;top: 0;left: 0
}.VfPpkd-xl07Ob .VfPpkd-StrnGf-rymPhb: :before,.VfPpkd-xl07Ob .VfPpkd-rymPhb: :before{position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;width: 100%;height: 100%;top: 0;left: 0;border: 1px solid transparent;border-radius:inherit;content: "";pointer-events:none
}@media screen and (forced-colors:active){.VfPpkd-xl07Ob .VfPpkd-StrnGf-rymPhb: :before,.VfPpkd-xl07Ob .VfPpkd-rymPhb: :before{border-color:CanvasText
    }
}.VfPpkd-xl07Ob .VfPpkd-StrnGf-rymPhb-clz4Ic{margin: 8px 0
}.VfPpkd-xl07Ob .VfPpkd-StrnGf-rymPhb-ibnC6b{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none
}.VfPpkd-xl07Ob .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me{cursor:auto
}.VfPpkd-xl07Ob a.VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-b9t22c,.VfPpkd-xl07Ob a.VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-f7MjDc{pointer-events:none
}.VfPpkd-qPzbhe-JNdkSc{padding: 0;fill:currentColor
}.VfPpkd-qPzbhe-JNdkSc .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 56px;padding-right: 16px
}[dir=rtl
] .VfPpkd-qPzbhe-JNdkSc .VfPpkd-StrnGf-rymPhb-ibnC6b,.VfPpkd-qPzbhe-JNdkSc .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
]{padding-left: 16px;padding-right: 56px
}.VfPpkd-qPzbhe-JNdkSc .VfPpkd-qPzbhe-JNdkSc-Bz112c{left: 16px;right:auto;visibility:hidden;position:absolute;top: 50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%);-webkit-transition-property:visibility;transition-property:visibility;-webkit-transition-delay: 75ms;transition-delay: 75ms
}[dir=rtl
] .VfPpkd-qPzbhe-JNdkSc .VfPpkd-qPzbhe-JNdkSc-Bz112c,.VfPpkd-qPzbhe-JNdkSc .VfPpkd-qPzbhe-JNdkSc-Bz112c[dir=rtl
]{left:auto;right: 16px
}.VfPpkd-xl07Ob-ibnC6b-OWXEXe-gk6SMd .VfPpkd-qPzbhe-JNdkSc-Bz112c{display:inline;visibility:visible
}.q6oraf{-webkit-box-shadow: 0 3px 5px -1px rgba(0,
    0,
    0,.2),
    0 6px 10px 0 rgba(0,
    0,
    0,.14),
    0 1px 18px 0 rgba(0,
    0,
    0,.12);box-shadow: 0 3px 5px -1px rgba(0,
    0,
    0,.2),
    0 6px 10px 0 rgba(0,
    0,
    0,.14),
    0 1px 18px 0 rgba(0,
    0,
    0,.12)
}.q6oraf .VfPpkd-StrnGf-rymPhb{font-family:Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 400;color:#000;color:var(--mdc-theme-on-surface,#000)
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-IhFlZd{color:rgb(95,
    99,
    104)
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(60,
    64,
    67)
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity:.38
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b{color:#000;color:var(--mdc-theme-on-surface,#000)
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc{color:#000;color:var(--mdc-theme-on-surface,#000)
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity: 0
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgb(232,
    240,
    254)
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(26,
    115,
    232);background-color:var(--mdc-ripple-color,rgb(26,
    115,
    232))
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
}.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.1)
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:GrayText
    }.q6oraf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity: 1
    }
}.FliLIb{-webkit-box-sizing:border-box;box-sizing:border-box;display:inline-block
}.FliLIb .u3bW4e{-webkit-box-shadow: 0px 6px 10px 0px rgba(0,
    0,
    0,.14),
    0px 1px 18px 0px rgba(0,
    0,
    0,.12),
    0px 3px 5px -1px rgba(0,
    0,
    0,.2);box-shadow: 0px 6px 10px 0px rgba(0,
    0,
    0,.14),
    0px 1px 18px 0px rgba(0,
    0,
    0,.12),
    0px 3px 5px -1px rgba(0,
    0,
    0,.2)
}.FliLIb.eLNT1d{display:none
}.FliLIb .q6oraf .VfPpkd-rymPhb,.FliLIb .ksBjEc{font-size:inherit
}.FliLIb .TrZEUc .WpHeLc{position:absolute
}.FliLIb .qIypjc:not(:disabled){color:#fff
}.xYnMae .VfPpkd-Jh9lGc{-webkit-box-sizing:content-box;box-sizing:content-box
}.uRo0Xe .snByac{font-weight: 500;line-height: 1.4286
}.FliLIb .uRo0Xe{min-width: 0
}.uRo0Xe .snByac{margin: 8px 8px;text-transform:none
}.stUf5b.WS4XDd{border: 0;max-height:1.3333333em;padding: 0 2px;vertical-align:middle;width:auto
}.G5XIyb{border: 0;-o-object-fit:contain;object-fit:contain
}.G5XIyb.WS4XDd{border: 0;max-height:1.3333333em;padding: 0 2px;vertical-align:middle;width:auto
}.YZrg6{-webkit-box-align:center;-webkit-align-items:center;align-items:center;background:#fff;border: 1px solid rgb(218,
    220,
    224);-webkit-box-sizing:border-box;box-sizing:border-box;color:rgb(60,
    64,
    67);cursor:pointer;display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;font-family: "Google Sans",
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 14px;font-weight: 500;letter-spacing:.25px;max-width: 100%;position:relative
}.YZrg6: :after{bottom: -1px;border: 1px solid transparent;content: "";left: -1px;position:absolute;right: -1px;top: -1px
}.YZrg6:focus,.YZrg6.u3bW4e{background:rgba(60,
    64,
    67,
    0.122);outline:none
}.YZrg6:focus-visible: :after{bottom: -5px;border: 2px solid rgb(24,
    90,
    188);border-radius: 20px;-webkit-box-shadow: 0 0 0 2px rgb(232,
    240,
    254);box-shadow: 0 0 0 2px rgb(232,
    240,
    254);content: "";left: -5px;position:absolute;right: -5px;top: -5px
}.YZrg6:hover:not(:focus-visible): :after{background:rgba(60,
    64,
    67,
    0.039)
}.YZrg6:focus:not(:focus-visible): :after,.YZrg6:hover:not(:focus-visible): :after,.YZrg6.u3bW4e{border-color:rgb(218,
    220,
    224)
}.YZrg6.qs41qe{color:rgb(60,
    64,
    67)
}.YZrg6.qs41qe:not(:focus-visible): :after{background:rgba(60,
    64,
    67,
    0.122);border-color:rgb(60,
    64,
    67)
}.SOOv2c{color:rgb(26,
    115,
    232);font-size: 12px
}.HnRr5d{border-radius: 16px;padding: 0 15px 0 15px
}.HnRr5d.SOOv2c{border-radius: 12px;padding: 0 10px 0 10px
}.HnRr5d.iiFyne{padding-right: 7px
}.HnRr5d.cd29Sd{padding-left: 5px
}.HnRr5d.SOOv2c.iiFyne{padding-right: 7px
}.HnRr5d.SOOv2c.cd29Sd{padding-left: 2px
}.HnRr5d: :after{border-radius: 16px
}.HnRr5d.SOOv2c: :after{border-radius: 12px
}.gPHLDe{border-radius: 10px;height: 20px;margin-right: 8px
}.gPHLDe .stUf5b,.gPHLDe .G5XIyb{border-radius: 50%;color:rgb(60,
    64,
    67);display:block;height: 20px;width: 20px
}.KTeGk{direction:ltr;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap
}.HnRr5d .KTeGk{line-height: 30px
}.HnRr5d.SOOv2c .KTeGk{line-height: 22px
}.krLnGe{color:rgb(60,
    64,
    67);-webkit-flex-shrink: 0;flex-shrink: 0;height: 18px;margin-left: 4px;-webkit-transition:-webkit-transform .2s cubic-bezier(.4,
    0,.2,
    1);transition:-webkit-transform .2s cubic-bezier(.4,
    0,.2,
    1);transition:transform .2s cubic-bezier(.4,
    0,.2,
    1);transition:transform .2s cubic-bezier(.4,
    0,.2,
    1),-webkit-transform .2s cubic-bezier(.4,
    0,.2,
    1);width: 18px
}.YZrg6.sMVRZe .krLnGe{-webkit-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg)
}.SOOv2c .krLnGe{height: 16px;width: 16px
}.MSBt4d{display:block;height: 100%;width: 100%
}.aTzEhb{margin: 16px 0;outline:none
}.aTzEhb+.aTzEhb{margin-top: 24px
}.aTzEhb:first-child{margin-top: 0
}.aTzEhb:last-child{margin-bottom: 0
}.AORPd{-webkit-border-radius: 8px;-moz-border-radius: 8px;border-radius: 8px;padding: 16px
}.AORPd>:first-child{margin-top: 0
}.AORPd>:last-child{margin-bottom: 0
}.AORPd .kV95Wc{color:rgb(32,
    33,
    36)
}.AORPd .CxRgyd{color:rgb(32,
    33,
    36)
}.AORPd.YFdWic .CxRgyd{color:rgb(95,
    99,
    104);margin-top: 4px;padding: 0
}.AORPd.YFdWic .IdEPtc,.AORPd.YFdWic .CxRgyd{margin-left: 64px;width:-webkit-calc(100% - 64px);width:-moz-calc(100% - 64px);width:calc(100% - 64px)
}.AORPd.YFdWic:not(.S7S4N) .IdEPtc{margin-left: 0;width: 0
}.AORPd:not(.S7S4N)>.CxRgyd{margin-top: 0
}.AORPd.sj692e{background:rgb(232,
    240,
    254)
}.AORPd.Xq8bDe{background:rgb(252,
    232,
    230)
}.AORPd.rNe0id{background:rgb(254,
    247,
    224)
}.AORPd.YFdWic{border: 1px solid rgb(218,
    220,
    224);-webkit-box-sizing:border-box;box-sizing:border-box;min-height: 80px;position:relative
}.AORPd:not(.S7S4N){display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex
}.aTzEhb.eLNT1d{display:none
}.aTzEhb.RDPZE{opacity:.5;pointer-events:none
}.aTzEhb.RDPZE .aTzEhb.RDPZE{opacity: 1
}.wfep7d{border: 1px solid rgb(218,
    220,
    224);-webkit-border-radius: 8px;-moz-border-radius: 8px;border-radius: 8px;padding: 16px
}.wfep7d .UST9Bf{display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-justify-content:flex-end;justify-content:flex-end;margin-top: 16px
}.wfep7d .UST9Bf .xYnMae{margin-bottom: 0;margin-top: 0
}.vEFDtd{border-bottom: 1px solid rgb(218,
    220,
    224);display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-ms-flex-direction:column;-webkit-flex-direction:column;flex-direction:column
}.vEFDtd .V9RXW .rBUW7e,.vEFDtd .vEFDtd:last-child{border-bottom: 0
}.vEFDtd .vEFDtd:last-child .L9iFZc{padding-bottom: 0
}.vEFDtd.D6kf4b{border-bottom: 0
}.IdEPtc:empty,.yMb59d:empty{display:none
}.IdEPtc>:first-child{margin-top: 0;padding-top: 0
}.IdEPtc>:last-child{margin-bottom: 0;padding-bottom: 0
}.UWVyoc{margin: 0 0 8px
}.vEFDtd[data-expand-type="1"
] .L9iFZc,.aTzEhb[data-expand-type="1"
] .A6OHve{cursor:pointer
}.vEFDtd .L9iFZc{padding-bottom: 16px
}.kV95Wc{-webkit-align-items:center;align-items:center;color:rgb(32,
    33,
    36);display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex;font-family:Google Sans,Noto Sans Myanmar UI,arial,sans-serif;font-size: 16px;font-weight: 500;letter-spacing: 0.1px;line-height: 1.5;margin-top: 0;margin-bottom: 0;padding: 0
}.vEFDtd.u3bW4e .kV95Wc{position:relative
}.vEFDtd[data-expand-type="1"
].u3bW4e .kV95Wc: :after{background:rgba(26,
    115,
    232,
    0.149);-webkit-border-radius: 8px;-moz-border-radius: 8px;border-radius: 8px;bottom: -4px;content: "";left: -8px;position:absolute;right: -8px;top: -4px;z-index: -1
}.A6OHve{background:none;border:none;color:inherit;-webkit-box-flex: 1;box-flex: 1;-ms-flex-positive: 1;-webkit-flex-grow: 1;flex-grow: 1;font:inherit;margin: 0;outline: 0;padding: 0;text-align:inherit
}.A6OHve: :-moz-focus-inner{border: 0
}.A6OHve [jsslot
]{position:relative
}.jhXB3b{margin-left: 16px
}.jhXB3b .Z6O26d{-webkit-align-items:center;align-items:center;display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex;height: 24px;-webkit-justify-content:center;justify-content:center;-webkit-transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);width: 24px
}.vEFDtd .jhXB3b,.vEFDtd .A6OHve,.vEFDtd .yiP64c{pointer-events:none
}.vEFDtd.jVwmLb .Z6O26d{-webkit-transform:rotate(-180deg);-ms-transform:rotate(-180deg);-o-transform:rotate(-180deg);transform:rotate(-180deg)
}.yiP64c{color:rgb(95,
    99,
    104);-ms-flex-negative: 0;-webkit-flex-shrink: 0;flex-shrink: 0;height: 20px;margin-right: 16px;width: 20px
}.yiP64c .d7Plee{height: 100%;width: 100%
}.AORPd .yiP64c{margin-top: 0
}.AORPd.sj692e .yiP64c{color:rgb(25,
    103,
    210)
}.AORPd.Xq8bDe .yiP64c{color:rgb(197,
    34,
    31)
}.AORPd.rNe0id .yiP64c{color:rgb(234,
    134,
    0)
}.AORPd.YFdWic .yiP64c{height: 48px;left: 16px;position:absolute;top: 16px;width: 48px
}.yMb59d{color:rgb(95,
    99,
    104);font-size: 14px;font-weight: 400;line-height: 1.4286;margin-top: 8px
}.CxRgyd{margin:auto -24px;padding-left: 24px;padding-right: 24px;margin-bottom: 16px;margin-top: 10px
}@media (min-width: 450px){.CxRgyd{margin:auto -40px;padding-left: 40px;padding-right: 40px;margin-bottom: 16px;margin-top: 10px
    }
}.wfep7d .CxRgyd{margin-bottom: 0;margin-top: 16px
}.IdEPtc:empty+.CxRgyd{margin-top: 0
}.CxRgyd:only-child{margin-bottom: 0;margin-top: 0
}.vEFDtd .CxRgyd{margin-top: 0;overflow-y:hidden;-webkit-transition: 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-transition: 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition: 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1)
}.vEFDtd.jVwmLb .CxRgyd{margin-bottom: 0;margin-top: 0;max-height: 0;opacity: 0;visibility:hidden
}.CxRgyd>[jsslot
]>:first-child:not(section){margin-top: 0;padding-top: 0
}.CxRgyd>[jsslot
]>:last-child:not(section){margin-bottom: 0;padding-bottom: 0
}.w7wqLd{-webkit-align-self:center;-ms-grid-row-align:center;align-self:center;margin-bottom: 0
}.x3iGMd{border-bottom: 1px solid rgb(218,
    220,
    224);display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-ms-flex-direction:row;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:center;justify-content:center;height: 0;margin-bottom: 24px;margin-top: 12px
}.aQPcpb{background:#fff;display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex;height: 24px;margin-top: -12px
}.D6kf4b:not(.jVwmLb) .x3iGMd{display:none
}.D6kf4b .VBGMK:focus-visible{outline:none;position:relative
}.D6kf4b .VBGMK:focus-visible: :after{border: 2px solid #185abc;border-radius: 6px;bottom: 0;box-shadow: 0 0 0 2px #e8f0fe;content: "";left: 0;position:absolute;right: 0;top: 0
}.VfPpkd-Sx9Kwc .VfPpkd-P5QLlc{background-color:#fff;background-color:var(--mdc-theme-surface,#fff)
}.VfPpkd-Sx9Kwc .VfPpkd-IE5DDf,.VfPpkd-Sx9Kwc .VfPpkd-P5QLlc-GGAcbc{background-color:rgba(0,
    0,
    0,.32)
}.VfPpkd-Sx9Kwc .VfPpkd-k2Wrsb{color:rgba(0,
    0,
    0,.87)
}.VfPpkd-Sx9Kwc .VfPpkd-cnG4Wd{color:rgba(0,
    0,
    0,.6)
}.VfPpkd-Sx9Kwc .VfPpkd-zMU9ub{color:#000;color:var(--mdc-theme-on-surface,#000)
}.VfPpkd-Sx9Kwc .VfPpkd-zMU9ub .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Sx9Kwc .VfPpkd-zMU9ub .VfPpkd-Bz112c-Jh9lGc: :after{background-color:#000;background-color:var(--mdc-ripple-color,var(--mdc-theme-on-surface,#000))
}.VfPpkd-Sx9Kwc .VfPpkd-zMU9ub:hover .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Sx9Kwc .VfPpkd-zMU9ub.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Bz112c-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.VfPpkd-Sx9Kwc .VfPpkd-zMU9ub.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-Jh9lGc: :before,.VfPpkd-Sx9Kwc .VfPpkd-zMU9ub:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.VfPpkd-Sx9Kwc .VfPpkd-zMU9ub:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.VfPpkd-Sx9Kwc .VfPpkd-zMU9ub:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
}.VfPpkd-Sx9Kwc .VfPpkd-zMU9ub.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.12)
}.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd .VfPpkd-k2Wrsb,.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd .VfPpkd-T0kwCb,.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd.VfPpkd-Sx9Kwc-XuHpsb-clz4Ic-yePe5c .VfPpkd-T0kwCb{border-color:rgba(0,
    0,
    0,.12)
}.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd .VfPpkd-k2Wrsb{border-bottom: 1px solid rgba(0,
    0,
    0,.12);margin-bottom: 0
}.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-XuHpsb-clz4Ic-tJHJj.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-oclYLd{-webkit-box-shadow: 0 3px 1px -2px rgba(0,
    0,
    0,.2),
    0 2px 2px 0 rgba(0,
    0,
    0,.14),
    0 1px 5px 0 rgba(0,
    0,
    0,.12);box-shadow: 0 3px 1px -2px rgba(0,
    0,
    0,.2),
    0 2px 2px 0 rgba(0,
    0,
    0,.14),
    0 1px 5px 0 rgba(0,
    0,
    0,.12)
}.VfPpkd-Sx9Kwc .VfPpkd-P5QLlc{border-radius: 4px;border-radius:var(--mdc-shape-medium,
    4px)
}.VfPpkd-P5QLlc{-webkit-box-shadow: 0 11px 15px -7px rgba(0,
    0,
    0,.2),
    0 24px 38px 3px rgba(0,
    0,
    0,.14),
    0 9px 46px 8px rgba(0,
    0,
    0,.12);box-shadow: 0 11px 15px -7px rgba(0,
    0,
    0,.2),
    0 24px 38px 3px rgba(0,
    0,
    0,.14),
    0 9px 46px 8px rgba(0,
    0,
    0,.12)
}.VfPpkd-k2Wrsb{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-headline6-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size: 1.25rem;font-size:var(--mdc-typography-headline6-font-size,
    1.25rem);line-height: 2rem;line-height:var(--mdc-typography-headline6-line-height,
    2rem);font-weight: 500;font-weight:var(--mdc-typography-headline6-font-weight,
    500);letter-spacing:.0125em;letter-spacing:var(--mdc-typography-headline6-letter-spacing,.0125em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-headline6-text-decoration,inherit);text-decoration:var(--mdc-typography-headline6-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-headline6-text-transform,inherit)
}.VfPpkd-cnG4Wd{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-body1-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size: 1rem;font-size:var(--mdc-typography-body1-font-size,
    1rem);line-height: 1.5rem;line-height:var(--mdc-typography-body1-line-height,
    1.5rem);font-weight: 400;font-weight:var(--mdc-typography-body1-font-weight,
    400);letter-spacing:.03125em;letter-spacing:var(--mdc-typography-body1-letter-spacing,.03125em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-body1-text-decoration,inherit);text-decoration:var(--mdc-typography-body1-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-body1-text-transform,inherit)
}.VfPpkd-Sx9Kwc,.VfPpkd-IE5DDf{position:fixed;top: 0;left: 0;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-box-sizing:border-box;box-sizing:border-box;width: 100%;height: 100%
}.VfPpkd-Sx9Kwc{display:none;z-index: 7;z-index:var(--mdc-dialog-z-index,
    7)
}.VfPpkd-Sx9Kwc .VfPpkd-cnG4Wd{padding: 20px 24px 20px 24px
}.VfPpkd-Sx9Kwc .VfPpkd-P5QLlc{min-width: 280px
}@media (max-width: 592px){.VfPpkd-Sx9Kwc .VfPpkd-P5QLlc{max-width:calc(100vw - 32px)
    }
}@media (min-width: 592px){.VfPpkd-Sx9Kwc .VfPpkd-P5QLlc{max-width: 560px
    }
}.VfPpkd-Sx9Kwc .VfPpkd-P5QLlc{max-height:calc(100% - 32px)
}.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc{max-width:none
}@media (max-width: 960px){.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc{max-height: 560px;width: 560px
    }.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc .VfPpkd-zMU9ub-suEOdc-sM5MNb{position:relative;right: -12px
    }
}@media (max-width: 720px) and (max-width: 672px){.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc{width:calc(100vw - 112px)
    }
}@media (max-width: 720px) and (min-width: 672px){.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc{width: 560px
    }
}@media (max-width: 720px) and (max-height: 720px){.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc{max-height:calc(100vh - 160px)
    }
}@media (max-width: 720px) and (min-height: 720px){.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc{max-height: 560px
    }
}@media (max-width: 720px){.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc .VfPpkd-zMU9ub-suEOdc-sM5MNb{position:relative;right: -12px
    }
}@media (max-width: 600px),(max-width: 720px) and (max-height: 400px),(min-width: 720px) and (max-height: 400px){.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc{height: 100%;max-height: 100vh;max-width: 100vw;width: 100vw;border-radius: 0
    }.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc .VfPpkd-zMU9ub-suEOdc-sM5MNb{position:relative;-webkit-box-ordinal-group: 0;-webkit-order: -1;order: -1;left: -12px
    }.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc .VfPpkd-oclYLd{padding: 0 16px 9px;-webkit-box-pack:start;-webkit-justify-content:flex-start;justify-content:flex-start
    }.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc .VfPpkd-k2Wrsb{margin-left: -8px
    }
}@media (min-width: 960px){.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc{width:calc(100vw - 400px)
    }.VfPpkd-Sx9Kwc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-P5QLlc .VfPpkd-zMU9ub-suEOdc-sM5MNb{position:relative;right: -12px
    }
}.VfPpkd-Sx9Kwc.VfPpkd-IE5DDf-OWXEXe-L6cTce .VfPpkd-IE5DDf{opacity: 0
}.VfPpkd-IE5DDf{opacity: 0;z-index: -1
}.VfPpkd-wzTsW{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-webkit-flex-direction:row;flex-direction:row;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-justify-content:space-around;justify-content:space-around;-webkit-box-sizing:border-box;box-sizing:border-box;height: 100%;opacity: 0;pointer-events:none
}.VfPpkd-P5QLlc{position:relative;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;-webkit-box-flex: 0;-webkit-flex-grow: 0;flex-grow: 0;-webkit-flex-shrink: 0;flex-shrink: 0;-webkit-box-sizing:border-box;box-sizing:border-box;max-width: 100%;max-height: 100%;pointer-events:auto;overflow-y:auto;outline: 0;-webkit-transform:scale(.8);-ms-transform:scale(.8);transform:scale(.8)
}.VfPpkd-P5QLlc .VfPpkd-BFbNVe-bF1uUb{width: 100%;height: 100%;top: 0;left: 0
}[dir=rtl
] .VfPpkd-P5QLlc,.VfPpkd-P5QLlc[dir=rtl
]{text-align:right
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.VfPpkd-P5QLlc{outline: 2px solid windowText
    }
}.VfPpkd-P5QLlc: :before{position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;width: 100%;height: 100%;top: 0;left: 0;border: 2px solid transparent;border-radius:inherit;content: "";pointer-events:none
}@media screen and (forced-colors:active){.VfPpkd-P5QLlc: :before{border-color:CanvasText
    }
}@media screen and (-ms-high-contrast:active),screen and (-ms-high-contrast:none){.VfPpkd-P5QLlc: :before{content:none
    }
}.VfPpkd-k2Wrsb{display:block;margin-top: 0;position:relative;-webkit-flex-shrink: 0;flex-shrink: 0;-webkit-box-sizing:border-box;box-sizing:border-box;margin: 0 0 1px;padding: 0 24px 9px
}.VfPpkd-k2Wrsb: :before{display:inline-block;width: 0;height: 40px;content: "";vertical-align: 0
}[dir=rtl
] .VfPpkd-k2Wrsb,.VfPpkd-k2Wrsb[dir=rtl
]{text-align:right
}.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd .VfPpkd-k2Wrsb{margin-bottom: 1px;padding-bottom: 15px
}.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-oclYLd{-webkit-box-align:baseline;-webkit-align-items:baseline;align-items:baseline;border-bottom: 1px solid transparent;display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;padding: 0 24px 9px;z-index: 1
}@media screen and (forced-colors:active){.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-oclYLd{border-bottom-color:CanvasText
    }
}.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-oclYLd .VfPpkd-zMU9ub-suEOdc-sM5MNb{position:relative;right: -12px
}.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-k2Wrsb{margin-bottom: 0;padding: 0;border-bottom: 0
}.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd .VfPpkd-k2Wrsb{border-bottom: 0;margin-bottom: 0
}.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-zMU9ub-suEOdc-sM5MNb{top: 5px
}.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd .VfPpkd-T0kwCb{border-top: 1px solid transparent
}@media screen and (forced-colors:active){.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd .VfPpkd-T0kwCb{border-top-color:CanvasText
    }
}.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb-OWXEXe-diJVc .VfPpkd-zMU9ub-suEOdc-sM5MNb{margin-top: 4px
}.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb-OWXEXe-diJVc.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd .VfPpkd-zMU9ub-suEOdc-sM5MNb{margin-top: 0
}.VfPpkd-cnG4Wd{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;-webkit-box-sizing:border-box;box-sizing:border-box;margin: 0;overflow:auto
}.VfPpkd-cnG4Wd>:first-child{margin-top: 0
}.VfPpkd-cnG4Wd>:last-child{margin-bottom: 0
}.VfPpkd-k2Wrsb+.VfPpkd-cnG4Wd,.VfPpkd-oclYLd+.VfPpkd-cnG4Wd{padding-top: 0
}.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd .VfPpkd-k2Wrsb+.VfPpkd-cnG4Wd{padding-top: 8px;padding-bottom: 8px
}.VfPpkd-cnG4Wd .VfPpkd-StrnGf-rymPhb:first-child:last-child{padding: 6px 0 0
}.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd .VfPpkd-cnG4Wd .VfPpkd-StrnGf-rymPhb:first-child:last-child{padding: 0
}.VfPpkd-T0kwCb{display:-webkit-box;display:-webkit-flex;display:flex;position:relative;-webkit-flex-shrink: 0;flex-shrink: 0;-webkit-flex-wrap:wrap;flex-wrap:wrap;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:end;-webkit-justify-content:flex-end;justify-content:flex-end;-webkit-box-sizing:border-box;box-sizing:border-box;min-height: 52px;margin: 0;padding: 8px;border-top: 1px solid transparent
}@media screen and (forced-colors:active){.VfPpkd-T0kwCb{border-top-color:CanvasText
    }
}.VfPpkd-Sx9Kwc-OWXEXe-eu7FSc .VfPpkd-T0kwCb{-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;-webkit-box-align:end;-webkit-align-items:flex-end;align-items:flex-end
}.VfPpkd-M1klYe{margin-left: 8px;margin-right: 0;max-width: 100%;text-align:right
}[dir=rtl
] .VfPpkd-M1klYe,.VfPpkd-M1klYe[dir=rtl
]{margin-left: 0;margin-right: 8px
}.VfPpkd-M1klYe:first-child{margin-left: 0;margin-right: 0
}[dir=rtl
] .VfPpkd-M1klYe:first-child,.VfPpkd-M1klYe:first-child[dir=rtl
]{margin-left: 0;margin-right: 0
}[dir=rtl
] .VfPpkd-M1klYe,.VfPpkd-M1klYe[dir=rtl
]{text-align:left
}.VfPpkd-Sx9Kwc-OWXEXe-eu7FSc .VfPpkd-M1klYe:not(:first-child){margin-top: 12px
}.VfPpkd-Sx9Kwc-OWXEXe-FNFY6c,.VfPpkd-Sx9Kwc-OWXEXe-uGFO6d,.VfPpkd-Sx9Kwc-OWXEXe-FnSee{display:-webkit-box;display:-webkit-flex;display:flex
}.VfPpkd-Sx9Kwc-OWXEXe-uGFO6d .VfPpkd-IE5DDf{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.VfPpkd-Sx9Kwc-OWXEXe-uGFO6d .VfPpkd-wzTsW{-webkit-transition:opacity 75ms linear,-webkit-transform .15s 0ms cubic-bezier(0,
    0,.2,
    1);transition:opacity 75ms linear,-webkit-transform .15s 0ms cubic-bezier(0,
    0,.2,
    1);transition:opacity 75ms linear,transform .15s 0ms cubic-bezier(0,
    0,.2,
    1);transition:opacity 75ms linear,transform .15s 0ms cubic-bezier(0,
    0,.2,
    1),-webkit-transform .15s 0ms cubic-bezier(0,
    0,.2,
    1)
}.VfPpkd-Sx9Kwc-OWXEXe-FnSee .VfPpkd-IE5DDf,.VfPpkd-Sx9Kwc-OWXEXe-FnSee .VfPpkd-wzTsW{-webkit-transition:opacity 75ms linear;transition:opacity 75ms linear
}.VfPpkd-Sx9Kwc-OWXEXe-FnSee .VfPpkd-wzTsW,.VfPpkd-Sx9Kwc-OWXEXe-FnSee .VfPpkd-P5QLlc{-webkit-transform:none;-ms-transform:none;transform:none
}.VfPpkd-Sx9Kwc-OWXEXe-RTQbk .VfPpkd-IE5DDf{-webkit-transition:none;transition:none;opacity: 1
}.VfPpkd-Sx9Kwc-OWXEXe-FNFY6c .VfPpkd-IE5DDf,.VfPpkd-Sx9Kwc-OWXEXe-FNFY6c .VfPpkd-wzTsW{opacity: 1
}.VfPpkd-Sx9Kwc-OWXEXe-FNFY6c .VfPpkd-P5QLlc{-webkit-transform:none;-ms-transform:none;transform:none
}.VfPpkd-Sx9Kwc-OWXEXe-FNFY6c.VfPpkd-P5QLlc-GGAcbc-OWXEXe-TSZdd .VfPpkd-P5QLlc-GGAcbc{opacity: 1
}.VfPpkd-Sx9Kwc-OWXEXe-FNFY6c.VfPpkd-P5QLlc-GGAcbc-OWXEXe-wJB69c .VfPpkd-P5QLlc-GGAcbc{-webkit-transition:opacity 75ms linear;transition:opacity 75ms linear
}.VfPpkd-Sx9Kwc-OWXEXe-FNFY6c.VfPpkd-P5QLlc-GGAcbc-OWXEXe-eo9XGd .VfPpkd-P5QLlc-GGAcbc{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.VfPpkd-P5QLlc-GGAcbc{display:none;opacity: 0;position:absolute;width: 100%;height: 100%;z-index: 1
}.VfPpkd-P5QLlc-GGAcbc-OWXEXe-TSZdd .VfPpkd-P5QLlc-GGAcbc,.VfPpkd-P5QLlc-GGAcbc-OWXEXe-eo9XGd .VfPpkd-P5QLlc-GGAcbc,.VfPpkd-P5QLlc-GGAcbc-OWXEXe-wJB69c .VfPpkd-P5QLlc-GGAcbc{display:block
}.VfPpkd-Sx9Kwc-XuHpsb-pGuBYc{overflow:hidden
}.VfPpkd-Sx9Kwc-OWXEXe-di8rgd-bN97Pc-QFlW2 .VfPpkd-cnG4Wd{padding: 0
}.VfPpkd-Sx9Kwc-OWXEXe-vOE8Lb .VfPpkd-wzTsW .VfPpkd-zMU9ub-suEOdc-sM5MNb{right: 12px;top: 9px;position:absolute;z-index: 1
}.VfPpkd-IE5DDf-OWXEXe-uIDLbb{pointer-events:none
}.VfPpkd-IE5DDf-OWXEXe-uIDLbb .VfPpkd-IE5DDf,.VfPpkd-IE5DDf-OWXEXe-uIDLbb .VfPpkd-P5QLlc-GGAcbc{display:none
}.cC1eCc{z-index: 2001
}.cC1eCc .VfPpkd-k2Wrsb{color:#3c4043
}.cC1eCc .VfPpkd-cnG4Wd{color:#5f6368
}.cC1eCc .VfPpkd-zMU9ub{color:rgb(95,
    99,
    104)
}.cC1eCc .VfPpkd-zMU9ub .VfPpkd-Bz112c-Jh9lGc: :before,.cC1eCc .VfPpkd-zMU9ub .VfPpkd-Bz112c-Jh9lGc: :after{background-color:rgb(95,
    99,
    104);background-color:var(--mdc-ripple-color,rgb(95,
    99,
    104))
}.cC1eCc .VfPpkd-zMU9ub:hover .VfPpkd-Bz112c-Jh9lGc: :before,.cC1eCc .VfPpkd-zMU9ub.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Bz112c-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
}.cC1eCc .VfPpkd-zMU9ub.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-Jh9lGc: :before,.cC1eCc .VfPpkd-zMU9ub:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
}.cC1eCc .VfPpkd-zMU9ub:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
}.cC1eCc .VfPpkd-zMU9ub:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
}.cC1eCc .VfPpkd-zMU9ub.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
    0.12)
}.cC1eCc .VfPpkd-IE5DDf,.cC1eCc .VfPpkd-P5QLlc-GGAcbc{background-color:rgba(32,
    33,
    36,.6)
}.cC1eCc .VfPpkd-P5QLlc{background-color:#fff
}.cC1eCc .VfPpkd-P5QLlc{border-width: 0;-webkit-box-shadow: 0 1px 3px 0 rgba(60,
    64,
    67,.3),
    0 4px 8px 3px rgba(60,
    64,
    67,.15);box-shadow: 0 1px 3px 0 rgba(60,
    64,
    67,.3),
    0 4px 8px 3px rgba(60,
    64,
    67,.15)
}.cC1eCc .VfPpkd-P5QLlc .VfPpkd-BFbNVe-bF1uUb{opacity: 0
}.cC1eCc .VfPpkd-P5QLlc{border-radius: 8px
}.cC1eCc .VfPpkd-T0kwCb{padding-top: 2px;padding-bottom: 2px
}.cC1eCc .VfPpkd-T0kwCb .VfPpkd-RLmnJb{top: -6px;-webkit-transform:none;-ms-transform:none;transform:none
}.cC1eCc .VfPpkd-k2Wrsb{font-family: "Google Sans",Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 500;padding-bottom: 13px
}.cC1eCc .VfPpkd-cnG4Wd{font-family:Roboto,Arial,sans-serif;line-height: 1.25rem;font-size:.875rem;letter-spacing:.0142857143em;font-weight: 400
}.cC1eCc .VfPpkd-T0kwCb .VfPpkd-LgbsSe+.VfPpkd-LgbsSe{margin-left: 8px
}.cC1eCc.VfPpkd-Sx9Kwc-OWXEXe-n9oEIb .VfPpkd-k2Wrsb{font-family: "Google Sans",Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1.125rem;letter-spacing: 0;font-weight: 400;padding-bottom: 0
}.iGu0Be{text-align:center
}[dir=rtl
] .iGu0Be,.iGu0Be[dir=rtl
]{text-align:center
}.nE3Lu{color:rgb(26,
    115,
    232);height: 24px;width: 24px
}.nE3Lu: :after{content: "";display:block
}.bYmtV .VfPpkd-P5QLlc{background-color:#fff;color:#5f6368;font-family:roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;letter-spacing:.25px
}.bYmtV .VfPpkd-k2Wrsb{color:#202124;font-family:Google Sans,Noto Sans Myanmar UI,arial,sans-serif;font-size: 20px;font-weight: 500;letter-spacing:.25px;line-height: 1.3333
}.bYmtV .VfPpkd-cnG4Wd{font-family:roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 14px;letter-spacing:.25px;line-height: 1.4286;padding-bottom: 0
}.bYmtV .VfPpkd-T0kwCb{padding: 0 24px 8px 24px
}.bYmtV .VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :before,.bYmtV .VfPpkd-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-border-radius: 4px;-moz-border-radius: 4px;border-radius: 4px
}.bYmtV.Zttm2{-webkit-border-radius: 0;-moz-border-radius: 0;border-radius: 0
}.bYmtV.Zttm2 .VfPpkd-P5QLlc{height: 100vh;max-height:none;max-width:none;width: 100vw
}.bYmtV.Zttm2 .AH8Npc{height: 100%;width: 100%
}.bYmtV .CJRWze{color:rgb(95,
    99,
    104);font-family:roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;-webkit-box-flex: 1;box-flex: 1;-ms-flex-positive: 1;-webkit-flex-grow: 1;flex-grow: 1;font-size: 12px;font-weight: 400;padding-left: 16px
}.CwHtnf{border:none;color-scheme:initial;display:block;height: 100%;padding: 0;width: 100%
}.bYmtV .CxRgyd{margin-left: 0;margin-right: 0;padding-left: 0;padding-right: 0
}.B6L7ke{height: 25vh;margin:auto -24px;min-height: 110px;padding-left: 24px;padding-right: 24px;position:relative
}.SCAiR{height: 25vh;margin:auto -24px;min-height: 110px;padding-left: 24px;padding-right: 24px;position:relative;overflow:hidden
}.JtUbMb,.Nny6ue{display:block;height: 100%;margin: 0 auto;object-fit:contain;width: 100%
}@media (min-width: 450px){.B6L7ke{margin:auto -40px;padding-left: 40px;padding-right: 40px
    }
}@media (min-width: 601px){.B6L7ke{height: 150px
    }
}.B6L7ke.Irjbwb{height:auto
}.B6L7ke.IiQozc{text-align:center
}.xh7Wmd{height: 25vh;max-width: 100%;min-height: 110px;position:relative;-webkit-transform:translate(-43%,
    -3%);-ms-transform:translate(-43%,
    -3%);-o-transform:translate(-43%,
    -3%);transform:translate(-43%,
    -3%);z-index: 3
}@media (min-width: 601px){.xh7Wmd{height: 150px
    }
}.B6L7ke.FnDdB{height:auto
}.B6L7ke.FnDdB .xh7Wmd{height:auto;max-width: 312px;width: 100%
}.B6L7ke.FnDdB.zpCp3 .xh7Wmd{max-width:unset
}.B6L7ke.IiQozc .xh7Wmd{-webkit-transform:none;-ms-transform:none;-o-transform:none;transform:none
}.B6L7ke.aJJFde .xh7Wmd{left: -100%;margin:auto;position:absolute;right: -100%;-webkit-transform:translate(0,
    -3%);-ms-transform:translate(0,
    -3%);-o-transform:translate(0,
    -3%);transform:translate(0,
    -3%)
}.B6L7ke.Irjbwb .xh7Wmd{height:auto;width: 100%
}.p17Urb{background-image:-webkit-linear-gradient(to bottom,rgba(233,
    233,
    233,
    0) 0%,rgba(233,
    233,
    233,
    0) 62.22%,rgba(233,
    233,
    233,
    1) 40.22%,rgba(233,
    233,
    233,
    0) 100%);background-image:-moz-linear-gradient(to bottom,rgba(233,
    233,
    233,
    0) 0%,rgba(233,
    233,
    233,
    0) 62.22%,rgba(233,
    233,
    233,
    1) 40.22%,rgba(233,
    233,
    233,
    0) 100%);background-image:-ms-linear-gradient(to bottom,rgba(233,
    233,
    233,
    0) 0%,rgba(233,
    233,
    233,
    0) 62.22%,rgba(233,
    233,
    233,
    1) 40.22%,rgba(233,
    233,
    233,
    0) 100%);background-image:-o-linear-gradient(to bottom,rgba(233,
    233,
    233,
    0) 0%,rgba(233,
    233,
    233,
    0) 62.22%,rgba(233,
    233,
    233,
    1) 40.22%,rgba(233,
    233,
    233,
    0) 100%);background-image:linear-gradient(to bottom,rgba(233,
    233,
    233,
    0) 0%,rgba(233,
    233,
    233,
    0) 62.22%,rgba(233,
    233,
    233,
    1) 40.22%,rgba(233,
    233,
    233,
    0) 100%);height: 100%;left: 0;overflow:hidden;position:absolute;right: 0;top: 0;z-index: 2
}.p17Urb: :after,.p17Urb: :before{content: "";display:block;height: 100%;min-width: 110px;position:absolute;right: -10%;-webkit-transform:rotate(-104deg);-ms-transform:rotate(-104deg);-o-transform:rotate(-104deg);transform:rotate(-104deg);width: 25vh;z-index: 2
}@media (min-width: 601px){.p17Urb: :after,.p17Urb: :before{width: 150px
    }
}.p17Urb: :before{background-image:-webkit-linear-gradient(to bottom,rgba(243,
    243,
    243,
    0) 0%,rgba(243,
    243,
    243,.9) 100%);background-image:-moz-linear-gradient(to bottom,rgba(243,
    243,
    243,
    0) 0%,rgba(243,
    243,
    243,.9) 100%);background-image:-ms-linear-gradient(to bottom,rgba(243,
    243,
    243,
    0) 0%,rgba(243,
    243,
    243,.9) 100%);background-image:-o-linear-gradient(to bottom,rgba(243,
    243,
    243,
    0) 0%,rgba(243,
    243,
    243,.9) 100%);background-image:linear-gradient(to bottom,rgba(243,
    243,
    243,
    0) 0%,rgba(243,
    243,
    243,.9) 100%);bottom: -10%
}.p17Urb: :after{background-image:-webkit-linear-gradient(to bottom,rgba(255,
    255,
    255,
    0) 0%,rgba(255,
    255,
    255,.9) 100%);background-image:-moz-linear-gradient(to bottom,rgba(255,
    255,
    255,
    0) 0%,rgba(255,
    255,
    255,.9) 100%);background-image:-ms-linear-gradient(to bottom,rgba(255,
    255,
    255,
    0) 0%,rgba(255,
    255,
    255,.9) 100%);background-image:-o-linear-gradient(to bottom,rgba(255,
    255,
    255,
    0) 0%,rgba(255,
    255,
    255,.9) 100%);background-image:linear-gradient(to bottom,rgba(255,
    255,
    255,
    0) 0%,rgba(255,
    255,
    255,.9) 100%);bottom: -80%
}.DrceJe{height:auto
}.yb5i2e{-webkit-transform:translate(-9%,
    -3%);-ms-transform:translate(-9%,
    -3%);-o-transform:translate(-9%,
    -3%);transform:translate(-9%,
    -3%)
}.hNLjwb{-webkit-transform:translate(9%,
    -3%);-ms-transform:translate(9%,
    -3%);-o-transform:translate(9%,
    -3%);transform:translate(9%,
    -3%)
}.ulNYne{left: -40%;margin:auto;max-height: 230px;position:absolute;right: 0;top: -3%;-webkit-transform:none;-ms-transform:none;-o-transform:none;transform:none
}.F8EZte{-webkit-transform:translate(24px,
    0);-ms-transform:translate(24px,
    0);-o-transform:translate(24px,
    0);transform:translate(24px,
    0)
}.eMXECe{-webkit-transform:translate(0,
    0);-ms-transform:translate(0,
    0);-o-transform:translate(0,
    0);transform:translate(0,
    0)
}.B6L7ke.i1L7v{height: 15vh;max-height: 137px;min-height: 112px;padding-bottom: 12px
}.B6L7ke.i1L7v .xh7Wmd{max-height: 100%;min-height: 100%
}.B6L7ke.j1zy9{height:auto
}.B6L7ke.j1zy9 .xh7Wmd{height:auto;max-width: 432px
}.PeAiAb{max-width: 300px
}:root{--wf-color-warning-bg:#fff0d1;--wf-color-warning-icon:#f09d00;--wf-color-warning-text:#421f00
}@media screen and (prefers-color-scheme:dark){
    :root{--wf-color-warning-bg:#754200;--wf-color-warning-icon:#ffdf99;--wf-color-warning-text:#fff0d1
    }
}.MWnvBb.WS4XDd{border: 0;max-height: 1rem;padding: 0 2px;vertical-align:middle;width:auto
}.IqauWe{border: 0;-o-object-fit:contain;object-fit:contain
}.IqauWe.WS4XDd{border: 0;max-height: 1rem;padding: 0 2px;vertical-align:middle;width:auto
}.q4Wquf,.nfoC7c{display:block;height: 25vh;position:relative
}@media (min-width: 600px){.q4Wquf,.nfoC7c{height: 150px
    }
}.q4Wquf.Irjbwb{height:auto
}@media screen and (prefers-color-scheme:dark){.q4Wquf:not(.GtvzYd){display:none
    }
}.nfoC7c{margin: 0;overflow:hidden
}.PwpMUe,.lVUmD{display:block;height: 100%;margin: 0 auto;-o-object-fit:contain;object-fit:contain;width: 100%
}.St9mde{display:block;height: 100%;max-width: 100%;min-height: 110px;position:relative;-webkit-transform:translate(-43%,
    -3%);-ms-transform:translate(-43%,
    -3%);transform:translate(-43%,
    -3%);width:auto;z-index: 3
}.wsArZ[data-ss-mode="1"
] .q4Wquf,.wsArZ[data-ss-mode="1"
] .St9mde{height:auto;width: 100%
}.wsArZ[data-ss-mode="1"
] .St9mde{max-width: 400px
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .q4Wquf,.NQ5OL .St9mde{height:auto;width: 100%
    }.NQ5OL .St9mde{max-width: 400px
    }
}.q4Wquf.NWba7e,.q4Wquf.NWba7e .St9mde{height:auto
}.q4Wquf.NWba7e .St9mde{height:auto;max-width: 312px;width: 100%
}.q4Wquf.NWba7e.zpCp3 .St9mde{max-width:unset
}.q4Wquf.IiQozc .St9mde{margin: 0 auto;-webkit-transform:none;-ms-transform:none;transform:none
}.q4Wquf.Irjbwb .St9mde{height:auto;width: 100%
}.q4Wquf.EEeaqf .St9mde{max-height: 144px;max-width: 144px
}.SnAaEd{background-image:-webkit-gradient(linear,left top,left bottom,from(rgba(233,
    233,
    233,
    0)),color-stop(62.22%,rgba(233,
    233,
    233,
    0)),color-stop(40.22%,rgb(233,
    233,
    233)),to(rgba(233,
    233,
    233,
    0)));background-image:-webkit-linear-gradient(top,rgba(233,
    233,
    233,
    0) 0,rgba(233,
    233,
    233,
    0) 62.22%,rgb(233,
    233,
    233) 40.22%,rgba(233,
    233,
    233,
    0) 100%);background-image:linear-gradient(to bottom,rgba(233,
    233,
    233,
    0) 0,rgba(233,
    233,
    233,
    0) 62.22%,rgb(233,
    233,
    233) 40.22%,rgba(233,
    233,
    233,
    0) 100%);height: 100%;left: 0;overflow:hidden;position:absolute;right: 0;top: 0;z-index: 2
}@media screen and (prefers-color-scheme:dark){.SnAaEd{display:none
    }
}.SnAaEd: :after,.SnAaEd: :before{content: "";display:block;height: 100%;min-width: 110px;position:absolute;right: -10%;-webkit-transform:rotate(-104deg);-ms-transform:rotate(-104deg);transform:rotate(-104deg);width: 25vh;z-index: 2
}@media (min-width: 600px){.SnAaEd: :after,.SnAaEd: :before{width: 150px
    }
}.SnAaEd: :before{background-image:-webkit-gradient(linear,left top,left bottom,from(rgba(243,
    243,
    243,
    0)),to(rgba(243,
    243,
    243,.9)));background-image:-webkit-linear-gradient(top,rgba(243,
    243,
    243,
    0) 0,rgba(243,
    243,
    243,.9) 100%);background-image:linear-gradient(to bottom,rgba(243,
    243,
    243,
    0) 0,rgba(243,
    243,
    243,.9) 100%);bottom: -10%
}.SnAaEd: :after{background-image:-webkit-gradient(linear,left top,left bottom,from(rgba(255,
    255,
    255,
    0)),to(rgba(255,
    255,
    255,.9)));background-image:-webkit-linear-gradient(top,rgba(255,
    255,
    255,
    0) 0,rgba(255,
    255,
    255,.9) 100%);background-image:linear-gradient(to bottom,rgba(255,
    255,
    255,
    0) 0,rgba(255,
    255,
    255,.9) 100%);bottom: -80%
}.wsArZ[data-ss-mode="1"
] .SnAaEd~.St9mde{width:auto
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .SnAaEd~.St9mde{width:auto
    }
}.RHNWk .St9mde{height:auto
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .RHNWk .St9mde{width: 115px
    }
}.cf660d .St9mde{-webkit-transform:translate(-9%,
    -3%);-ms-transform:translate(-9%,
    -3%);transform:translate(-9%,
    -3%)
}.tUhwwc .St9mde{margin:auto;max-height: 230px;right: 0;top: -3%;-webkit-transform:none;-ms-transform:none;transform:none
}.Jkvqxd .St9mde{-webkit-transform:translate(9%,
    -3%);-ms-transform:translate(9%,
    -3%);transform:translate(9%,
    -3%)
}.onc8Ic .St9mde{-webkit-transform:translate(var(
    --c-ps-s,
    24px
  ),
    0);-ms-transform:translate(var(
    --c-ps-s,
    24px
  ),
    0);transform:translate(var(
    --c-ps-s,
    24px
  ),
    0)
}.WA89Yb .St9mde{-webkit-transform:translate(0,
    0);-ms-transform:translate(0,
    0);transform:translate(0,
    0)
}.wsArZ[data-ss-mode="1"
] .XEN8Yb .St9mde{max-width: 115px
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .XEN8Yb .St9mde{max-width: 115px
    }
}.IsSr6b .St9mde{max-width: 300px
}.mmskdd .St9mde{-webkit-transform:none;-ms-transform:none;transform:none
}.Qk3oof.WS4XDd{border: 0;max-height:1.4285714286em;padding: 0 2px;vertical-align:middle;width:auto
}.uHLU0{border: 0;-o-object-fit:contain;object-fit:contain
}.uHLU0.WS4XDd{border: 0;max-height:1.4285714286em;padding: 0 2px;vertical-align:middle;width:auto
}.XjS9D{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex
}.XjS9D .VfPpkd-J1Ukfc-LhBDec{border-radius: 22px
}.XjS9D .VfPpkd-J1Ukfc-LhBDec: :after{border-radius: 24px
}.XjS9D.eLNT1d{display:none
}.XjS9D .TrZEUc .WpHeLc{position:absolute
}.XjS9D .q6oraf .DMZ54e,.XjS9D .BqKGqe{font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 0.875rem;font-weight: 500;font-weight:var(
    --c-afwt,
    500
  );letter-spacing: 0rem;line-height: 1.4285714286
}.BqKGqe,.BqKGqe .VfPpkd-Jh9lGc{border-radius: 20px
}.XjS9D .VfPpkd-LgbsSe{height: 40px
}@media (orientation:landscape){.XjS9D .VfPpkd-LgbsSe{height: 40px
    }
}.Jskylb:not(:disabled){background:#0b57d0;color:#fff
}.pIzcPc:not(:disabled),.eR0mzb:not(:disabled){color:#0b57d0;outline:#747775
}.Jskylb.Jskylb.Jskylb:not(:disabled){background-color:var(--gm3-sys-color-primary,#0b57d0)
}.Jskylb.Jskylb.Jskylb:not(:disabled){color:var(--gm3-sys-color-on-primary,#fff)
}.Jskylb.Jskylb.Jskylb:not(:disabled):hover{color:var(--gm3-sys-color-on-primary,#fff)
}.Jskylb.Jskylb.Jskylb:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.Jskylb.Jskylb.Jskylb:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:var(--gm3-sys-color-on-primary,#fff)
}.Jskylb.Jskylb.Jskylb:not(:disabled):not(:disabled):active{color:var(--gm3-sys-color-on-primary,#fff)
}.pIzcPc.pIzcPc.pIzcPc:not(:disabled){color:var(--gm3-sys-color-primary,#0b57d0)
}.pIzcPc.pIzcPc.pIzcPc:not(:disabled):hover{color:var(--gm3-sys-color-primary,#0b57d0)
}.pIzcPc.pIzcPc.pIzcPc:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.pIzcPc.pIzcPc.pIzcPc:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:var(--gm3-sys-color-primary,#0b57d0)
}.pIzcPc.pIzcPc.pIzcPc .VfPpkd-Jh9lGc: :before{background-color:var(--gm3-sys-color-primary,#0b57d0)
}.pIzcPc.pIzcPc.pIzcPc .VfPpkd-Jh9lGc: :after{background-color:var(--gm3-sys-color-primary,#0b57d0)
}.pIzcPc.pIzcPc.pIzcPc:not(:disabled){border-color:var(--gm3-sys-color-outline,#747775)
}.pIzcPc.pIzcPc.pIzcPc:not(:disabled):hover{border-color:var(--gm3-sys-color-outline,#747775)
}.pIzcPc.pIzcPc.pIzcPc:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.pIzcPc.pIzcPc.pIzcPc:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{border-color:var(--gm3-sys-color-outline,#747775)
}.pIzcPc.pIzcPc.pIzcPc:not(:disabled):active,.pIzcPc.pIzcPc.pIzcPc:not(:disabled):focus:active{border-color:var(--gm3-sys-color-outline,#747775)
}.eR0mzb.eR0mzb.eR0mzb:not(:disabled){color:var(--gm3-sys-color-primary,#0b57d0)
}.eR0mzb.eR0mzb.eR0mzb:not(:disabled):hover{color:var(--gm3-sys-color-primary,#0b57d0)
}.eR0mzb.eR0mzb.eR0mzb:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.eR0mzb.eR0mzb.eR0mzb:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:var(--gm3-sys-color-primary,#0b57d0)
}.eR0mzb.eR0mzb.eR0mzb .VfPpkd-Jh9lGc: :before{background-color:var(--gm3-sys-color-primary,#0b57d0)
}.eR0mzb.eR0mzb.eR0mzb .VfPpkd-Jh9lGc: :after{background-color:var(--gm3-sys-color-primary,#0b57d0)
}.AnSR9d:not(:disabled).VfPpkd-LgbsSe{background:#c2e7ff;background:var(--gm3-sys-color-secondary-container,#c2e7ff);color:#001d35;color:var(--gm3-sys-color-on-secondary-container,#001d35)
}.AnSR9d:not(:disabled).VfPpkd-LgbsSe:focus{color:#001d35;color:var(--gm3-sys-color-on-secondary-container,#001d35)
}.eR0mzb.VfPpkd-LgbsSe{min-width: 0
}.eR0mzb.VfPpkd-LgbsSe{padding-left: 16px;padding-right: 16px
}.H76ePc{margin:auto;max-width: 380px;overflow:hidden;position:relative
}.H76ePc .LbOduc{position:relative;text-align:center
}.JQ5tlb{border-radius: 50%;color:var(--gm3-sys-color-on-surface-variant,#444746);overflow:hidden
}.pGzURd{line-height: 1.4285714286
}.lPxAeb{width: 100%
}.lPxAeb .JQ5tlb{-webkit-box-flex: 0;-webkit-flex:none;flex:none;height: 28px;margin-right: 12px;width: 28px
}.lPxAeb .LbOduc,.VUfHYd .LbOduc{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center
}.lPxAeb .LbOduc{-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center
}.H76ePc .JQ5tlb{height: 64px;margin: 0 auto 8px;width: 64px
}.MnFlu{border-radius: 50%;display:block
}.lPxAeb .MnFlu,.lPxAeb .Qk3oof,.lPxAeb .uHLU0{max-height: 100%;max-width: 100%
}.H76ePc .MnFlu,.H76ePc .Qk3oof,.H76ePc .uHLU0{height: 64px;width: 64px
}.VUfHYd{height: 24px
}.VUfHYd .JQ5tlb{display:-webkit-box;display:-webkit-flex;display:flex;height: 24px;margin-right: 8px;min-width: 24px
}.VUfHYd .MnFlu,.VUfHYd .Qk3oof,.VUfHYd .uHLU0{color:var(--gm3-sys-color-on-surface-variant,#444746);height: 24px;width: 24px
}.VUfHYd .DOLDDf{overflow:hidden
}.lPxAeb .DOLDDf{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1
}.lPxAeb .pGzURd{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 1rem;font-weight: 500;letter-spacing: 0rem;line-height: 1.5
}.H76ePc .pGzURd{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-size: 0.875rem
}.yAlK0b,.VhdzSd,.H2oig{direction:ltr;font-size: 0.875rem;line-height: 1.4285714286;text-align:left;word-break:break-all
}.yAlK0b{text-decoration:none
}.lPxAeb .yAlK0b,.lPxAeb .VhdzSd,.lPxAeb .H2oig{font-size: 0.875rem;font-weight: 400;letter-spacing: 0rem;line-height: 1.4285714286
}.H2oig{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746)
}.VUfHYd .yAlK0b{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 0.875rem;font-weight: 500;letter-spacing: 0rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap
}.lPxAeb .VhdzSd{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746)
}.lPxAeb .yAlK0b{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746)
}.lPxAeb .yAlK0b[data-email$="@glimitedaccount.com"
]{display:none
}.H76ePc .yAlK0b{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746)
}.lrLKwc{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);font-size: 0.875rem
}.lPxAeb .lrLKwc{-webkit-align-self:flex-start;align-self:flex-start;-webkit-box-flex: 0;-webkit-flex:none;flex:none;font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 0.75rem;font-weight: 400;letter-spacing: 0.00625rem;line-height: 1.3333333333
}.Ahygpe{-webkit-box-align:center;-webkit-align-items:center;align-items:center;background:#fff;background:var(--gm3-sys-color-surface-container-lowest,#fff);border: 1px solid var(--gm3-sys-color-outline,#747775);color:var(--gm3-sys-color-on-surface,#1f1f1f);cursor:pointer;display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;font-size: 0.875rem;font-weight: 500;letter-spacing:.25px;max-width: 100%;position:relative
}.Ahygpe: :after{border: 1px solid transparent;content: "";position:absolute;inset: -1px
}.Ahygpe:focus-visible: :after{border: 2px solid;border-color:#0b57d0;border-color:var(--gm3-sys-color-primary,#0b57d0);-webkit-box-shadow: 0 0 0 2px #d3e3fd;box-shadow: 0 0 0 2px #d3e3fd;-webkit-box-shadow: 0 0 0 2px var(--gm3-sys-color-primary-container,#d3e3fd);box-shadow: 0 0 0 2px var(--gm3-sys-color-primary-container,#d3e3fd);border-radius: 26px;content: "";position:absolute;pointer-events:none;inset: -5px
}.Zjyti{color:#0b57d0;color:var(--gm3-sys-color-primary,#0b57d0);font-size: 0.75rem
}.m8wwGd{border-radius: 16px;padding: 0 15px 0 15px
}.m8wwGd{position:relative
}.m8wwGd: :before{background:#1f1f1f;background:var(--gm3-sys-color-on-surface,#1f1f1f);content: "";opacity: 0;position:absolute;pointer-events:none
}.m8wwGd:hover: :before{opacity: 0.08
}.m8wwGd:focus: :before,.m8wwGd.u3bW4e: :before{opacity: 0.1
}.m8wwGd:active: :before,.m8wwGd.qs41qe: :before{opacity: 0.1
}.m8wwGd: :before{border-radius: 16px;width: 100%;height: 100%
}.m8wwGd:focus,.m8wwGd.u3bW4e{outline:none;border-color:#747775;border-color:var(--gm3-sys-color-outline,#747775)
}.m8wwGd:active,.m8wwGd.qs41qe{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);border-color:#1f1f1f;border-color:var(--gm3-sys-color-on-surface,#1f1f1f)
}.m8wwGd.Zjyti{border-radius: 12px;padding: 0 10px 0 10px
}.m8wwGd.EPPJc{padding-right: 8px
}.m8wwGd.cd29Sd{padding-left: 3px
}.m8wwGd.Zjyti.EPPJc{padding-right: 8px
}.m8wwGd.Zjyti.cd29Sd{padding-left: 2px
}.m8wwGd: :after{border-radius: 16px
}.m8wwGd.Zjyti: :after{border-radius: 12px
}.HOE91e{border-radius: 12px;height: 24px;margin-right: 8px
}.HOE91e .MnFlu,.HOE91e .Qk3oof,.HOE91e .uHLU0{border-radius: 50%;color:var(--gm3-sys-color-on-surface-variant,#444746);display:block;height: 24px;width: 24px
}.IxcUte{direction:ltr;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap
}.m8wwGd .IxcUte{line-height: 30px
}.m8wwGd.xNLKcb .IxcUte{font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 0.875rem;font-weight: 500;letter-spacing: 0rem;text-decoration:none
}.m8wwGd.Zjyti .IxcUte{line-height: 22px
}.JCl8ie{color:var(--gm3-sys-color-on-surface,#1f1f1f);-webkit-flex-shrink: 0;flex-shrink: 0;height: 20px;margin-left: 5px;width: 20px;-webkit-transition:-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1),-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1)
}.Ahygpe.sMVRZe .JCl8ie{-webkit-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg)
}.Zjyti .JCl8ie{height: 16px;width: 16px
}.u4TTuf{display:block;height: 100%;width: 100%
}.rFrNMe{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;-webkit-tap-highlight-color:transparent;display:inline-block;outline:none;padding-bottom: 8px;width: 200px
}.aCsJod{height: 40px;position:relative;vertical-align:top
}.aXBtI{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex;position:relative;top: 14px
}.Xb9hP{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-flex: 1;-webkit-flex-grow: 1;-moz-box-flex: 1;-ms-flex-positive: 1;-webkit-box-flex: 1;box-flex: 1;-ms-flex-positive: 1;-webkit-flex-grow: 1;flex-grow: 1;-webkit-flex-shrink: 1;-ms-flex-negative: 1;-ms-flex-negative: 1;-webkit-flex-shrink: 1;flex-shrink: 1;min-width: 0%;position:relative
}.A37UZe{-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;height: 24px;line-height: 24px;position:relative
}.qgcB3c:not(:empty){padding-right: 12px
}.sxyYjd:not(:empty){padding-left: 12px
}.whsOnd{-webkit-box-flex: 1;-webkit-flex-grow: 1;-moz-box-flex: 1;-ms-flex-positive: 1;-webkit-box-flex: 1;box-flex: 1;-ms-flex-positive: 1;-webkit-flex-grow: 1;flex-grow: 1;-webkit-flex-shrink: 1;-ms-flex-negative: 1;-ms-flex-negative: 1;-webkit-flex-shrink: 1;flex-shrink: 1;background-color:transparent;border:none;display:block;font: 400 16px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;height: 24px;line-height: 24px;margin: 0;min-width: 0%;outline:none;padding: 0;z-index: 0
}.rFrNMe.dm7YTc .whsOnd{color:#fff
}.whsOnd:invalid,.whsOnd:-moz-submit-invalid,.whsOnd:-moz-ui-invalid{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none
}.I0VJ4d>.whsOnd: :-ms-clear,.I0VJ4d>.whsOnd: :-ms-reveal{display:none
}.i9lrp{background-color:rgba(0,
    0,
    0,.12);bottom: -2px;height: 1px;left: 0;margin: 0;padding: 0;position:absolute;width: 100%
}.i9lrp: :before{content: "";position:absolute;top: 0;bottom: -2px;left: 0;right: 0;border-bottom: 1px solid rgba(0,
    0,
    0,
    0);pointer-events:none
}.rFrNMe.dm7YTc .i9lrp{background-color:rgba(255,
    255,
    255,.7)
}.OabDMe{-webkit-transform:scaleX(0);-webkit-transform:scaleX(0);-ms-transform:scaleX(0);-o-transform:scaleX(0);transform:scaleX(0);background-color:#4285f4;bottom: -2px;height: 2px;left: 0;margin: 0;padding: 0;position:absolute;width: 100%
}.rFrNMe.dm7YTc .OabDMe{background-color:#a1c2fa
}.rFrNMe.k0tWj .i9lrp,.rFrNMe.k0tWj .OabDMe{background-color:#d50000;height: 2px
}.rFrNMe.k0tWj.dm7YTc .i9lrp,.rFrNMe.k0tWj.dm7YTc .OabDMe{background-color:#e06055
}.whsOnd[disabled
]{color:rgba(0,
    0,
    0,.38)
}.rFrNMe.dm7YTc .whsOnd[disabled
]{color:rgba(255,
    255,
    255,.5)
}.whsOnd[disabled
]~.i9lrp{background:none;border-bottom: 1px dotted rgba(0,
    0,
    0,.38)
}.OabDMe.Y2Zypf{-webkit-animation:quantumWizPaperInputRemoveUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-animation:quantumWizPaperInputRemoveUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-animation:quantumWizPaperInputRemoveUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);animation:quantumWizPaperInputRemoveUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1)
}.rFrNMe.u3bW4e .OabDMe{-webkit-animation:quantumWizPaperInputAddUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-animation:quantumWizPaperInputAddUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-animation:quantumWizPaperInputAddUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);animation:quantumWizPaperInputAddUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1)
}.rFrNMe.sdJrJc>.aCsJod{padding-top: 24px
}.AxOyFc{-webkit-transform-origin:bottom left;-webkit-transform-origin:bottom left;-ms-transform-origin:bottom left;-o-transform-origin:bottom left;transform-origin:bottom left;-webkit-transition:all .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-transition:all .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-transition:all .3s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:all .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-transition-property:color,bottom,-webkit-transform;-webkit-transition-property:color,bottom,-webkit-transform;-o-transition-property:color,bottom,-webkit-transform;transition-property:color,bottom,-webkit-transform;-webkit-transition-property:color,bottom,transform;-o-transition-property:color,bottom,transform;transition-property:color,bottom,transform;-webkit-transition-property:color,bottom,transform,-webkit-transform;-o-transition-property:color,bottom,transform,-webkit-transform;transition-property:color,bottom,transform,-webkit-transform;color:rgba(0,
    0,
    0,.38);font: 400 16px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;font-size: 16px;pointer-events:none;position:absolute;bottom: 3px;left: 0;width: 100%
}.whsOnd:not([disabled
]):focus~.AxOyFc,.whsOnd[badinput=true
]~.AxOyFc,.rFrNMe.CDELXb .AxOyFc,.rFrNMe.dLgj8b .AxOyFc{-webkit-transform:scale(0.75) translateY(-39px);-webkit-transform:scale(0.75) translateY(-39px);-ms-transform:scale(0.75) translateY(-39px);-o-transform:scale(0.75) translateY(-39px);transform:scale(0.75) translateY(-39px)
}.whsOnd:not([disabled
]):focus~.AxOyFc{color:#3367d6
}.rFrNMe.dm7YTc .whsOnd:not([disabled
]):focus~.AxOyFc{color:#a1c2fa
}.rFrNMe.k0tWj .whsOnd:not([disabled
]):focus~.AxOyFc{color:#d50000
}.ndJi5d{color:rgba(0,
    0,
    0,.38);font: 400 16px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;max-width: 100%;overflow:hidden;pointer-events:none;position:absolute;text-overflow:ellipsis;top: 2px;left: 0;white-space:nowrap
}.rFrNMe.CDELXb .ndJi5d{display:none
}.K0Y8Se{-webkit-tap-highlight-color:transparent;font: 400 12px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;height: 16px;margin-left:auto;padding-left: 16px;padding-top: 8px;pointer-events:none;opacity:.3;white-space:nowrap
}.rFrNMe.dm7YTc .AxOyFc,.rFrNMe.dm7YTc .K0Y8Se,.rFrNMe.dm7YTc .ndJi5d{color:rgba(255,
    255,
    255,.7)
}.rFrNMe.Tyc9J{padding-bottom: 4px
}.dEOOab,.ovnfwe:not(:empty){-webkit-tap-highlight-color:transparent;-webkit-box-flex: 1;-webkit-flex: 1 1 auto;-moz-box-flex: 1;-ms-flex: 1 1 auto;-webkit-box-flex: 1 1 auto;-moz-box-flex: 1 1 auto;-ms-flex: 1 1 auto;-webkit-flex: 1 1 auto;flex: 1 1 auto;font: 400 12px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;min-height: 16px;padding-top: 8px
}.LXRPh{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex
}.ovnfwe{pointer-events:none
}.dEOOab{color:#d50000
}.rFrNMe.dm7YTc .dEOOab,.rFrNMe.dm7YTc.k0tWj .whsOnd:not([disabled
]):focus~.AxOyFc{color:#e06055
}.ovnfwe{opacity:.3
}.rFrNMe.dm7YTc .ovnfwe{color:rgba(255,
    255,
    255,.7);opacity: 1
}.rFrNMe.k0tWj .ovnfwe,.rFrNMe:not(.k0tWj) .ovnfwe:not(:empty)+.dEOOab{display:none
}@-webkit-keyframes quantumWizPaperInputRemoveUnderline{
    0%{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1);opacity: 1
    }to{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1);opacity: 0
    }
}@keyframes quantumWizPaperInputRemoveUnderline{
    0%{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1);opacity: 1
    }to{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1);opacity: 0
    }
}@-webkit-keyframes quantumWizPaperInputAddUnderline{
    0%{-webkit-transform:scaleX(0);-webkit-transform:scaleX(0);-ms-transform:scaleX(0);-o-transform:scaleX(0);transform:scaleX(0)
    }to{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1)
    }
}@keyframes quantumWizPaperInputAddUnderline{
    0%{-webkit-transform:scaleX(0);-webkit-transform:scaleX(0);-ms-transform:scaleX(0);-o-transform:scaleX(0);transform:scaleX(0)
    }to{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1)
    }
}@media (min-width: 600px){.njnYzb.DbQnIe .YqLCIe{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between
    }
}.njnYzb:first-child .H2p7Gf:first-child .i79UJc{padding-top: 8px
}@media (min-width: 600px){.njnYzb.DbQnIe:first-child .H2p7Gf .i79UJc{padding-top: 8px
    }.njnYzb.DbQnIe .H2p7Gf{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;margin-right: 8px;width: 0
    }.njnYzb.DbQnIe .H2p7Gf:last-child{margin-right: 0
    }
}.i79UJc.i79UJc{-webkit-box-sizing:content-box;box-sizing:content-box
}.i79UJc{padding-bottom: 0;padding-top: 24px;width: 100%
}.i79UJc .oJeWuf.oJeWuf{height: 56px;padding-top: 0
}.i79UJc.OcVpRe .oJeWuf.oJeWuf{height: 36px
}.i79UJc .Wic03c{-webkit-box-align:center;-webkit-align-items:center;align-items:center;position:static
}.i79UJc .snByac{background-color:transparent;bottom: 18px;-webkit-box-sizing:border-box;box-sizing:border-box;color:var(--gm3-sys-color-on-surface-variant,#444746);font-size: 16px;font-weight: 400;left: 8px;max-width:calc(100% - 16px);overflow:hidden;padding: 0 8px;text-overflow:ellipsis;-webkit-transition:opacity .15s cubic-bezier(.4,
    0,.2,
    1),background-color .15s cubic-bezier(.4,
    0,.2,
    1),-webkit-transform .15s cubic-bezier(.4,
    0,.2,
    1);transition:opacity .15s cubic-bezier(.4,
    0,.2,
    1),background-color .15s cubic-bezier(.4,
    0,.2,
    1),-webkit-transform .15s cubic-bezier(.4,
    0,.2,
    1);transition:transform .15s cubic-bezier(.4,
    0,.2,
    1),opacity .15s cubic-bezier(.4,
    0,.2,
    1),background-color .15s cubic-bezier(.4,
    0,.2,
    1);transition:transform .15s cubic-bezier(.4,
    0,.2,
    1),opacity .15s cubic-bezier(.4,
    0,.2,
    1),background-color .15s cubic-bezier(.4,
    0,.2,
    1),-webkit-transform .15s cubic-bezier(.4,
    0,.2,
    1);white-space:nowrap;width:auto;z-index: 1
}.i79UJc.OcVpRe .snByac{bottom: 10px;color:var(--gm3-sys-color-on-surface-variant,#444746);font-size: 14px;left: 4px;line-height: 16px;padding: 0 6px
}.i79UJc.u3bW4e .snByac.snByac,.i79UJc.CDELXb .snByac.snByac{background-color:#fff;background-color:var(--gm3-sys-color-surface-container-lowest,#fff);-webkit-transform:scale(.75) translatey(-41px);-ms-transform:scale(.75) translatey(-41px);transform:scale(.75) translatey(-41px)
}.i79UJc.OcVpRe.u3bW4e .snByac,.i79UJc.OcVpRe.CDELXb .snByac{-webkit-transform:scale(.75) translatey(-165%);-ms-transform:scale(.75) translatey(-165%);transform:scale(.75) translatey(-165%)
}.i79UJc .zHQkBf:not([disabled
]):focus~.snByac{color:#0b57d0;color:var(--gm3-sys-color-primary,#0b57d0)
}.i79UJc.IYewr.u3bW4e .zHQkBf:not([disabled
])~.snByac,.i79UJc.IYewr.CDELXb .zHQkBf:not([disabled
])~.snByac{color:#b3261e;color:var(--gm3-sys-color-error,#b3261e)
}.i79UJc .zHQkBf{border-radius: 4px;color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 16px;height: 28px;margin: 2px;padding: 12px 14px;text-align:left;z-index: 1
}.i79UJc.OcVpRe .zHQkBf{font-size: 14px;height: 20px;padding: 6px 8px
}.i79UJc.YKooDc .zHQkBf,.i79UJc.YKooDc .MQL3Ob{direction:ltr;text-align:left
}.i79UJc .iHd5yb{padding-left: 14px
}.i79UJc.OcVpRe .iHd5yb{padding-left: 8px
}.i79UJc .MQL3Ob{padding-right: 14px;z-index: 1
}.i79UJc.OcVpRe .MQL3Ob{padding-right: 8px
}.i79UJc .mIZh1c,.i79UJc .cXrdqd{border-radius: 4px;bottom: 0;-webkit-box-sizing:border-box;box-sizing:border-box
}.i79UJc .mIZh1c,.i79UJc .cXrdqd,.i79UJc.IYewr .mIZh1c,.i79UJc.IYewr .cXrdqd{background-color:transparent;bottom: 0;height:auto;top: 0
}.i79UJc .mIZh1c{border: 1px solid;border-color:#747775;border-color:var(--gm3-sys-color-outline,#747775);padding: 1px
}.i79UJc .cXrdqd{border: 1px solid;border-color:#0b57d0;border-color:var(--gm3-sys-color-primary,#0b57d0);opacity: 0;-webkit-transform:none;-ms-transform:none;transform:none;-webkit-transition:opacity .15s cubic-bezier(.4,
    0,.2,
    1);transition:opacity .15s cubic-bezier(.4,
    0,.2,
    1)
}.i79UJc.u3bW4e .cXrdqd{border-width: 2px
}.i79UJc.u3bW4e .cXrdqd,.i79UJc.IYewr .cXrdqd{-webkit-animation:none;animation:none;opacity: 1
}.i79UJc.IYewr .cXrdqd{border-color:#b3261e;border-color:var(--gm3-sys-color-error,#b3261e)
}.i79UJc .ndJi5d,.i79UJc .ovnfwe{pointer-events:auto
}.i79UJc .RxsGPe,.i79UJc .Is7Fhb{display:none
}.Ly8vae{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);display:-webkit-box;display:-webkit-flex;display:flex;font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 0.75rem;font-weight: 400;letter-spacing: 0.00625rem;line-height: 1.3333333333
}.Ly8vae:empty,.NdBX9e:empty{display:none
}.njnYzb.Jj6Lae .Ly8vae{color:#b3261e;color:var(--gm3-sys-color-error,#b3261e)
}.jEOsLc{display:none;margin-right: 8px
}.JPqhye{height: 16px;width: 16px
}.njnYzb.Jj6Lae .jEOsLc{display:block
}.njnYzb .Ly8vae{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);margin-top: 4px
}.njnYzb .YQOsOe{margin-left: 16px
}.njnYzb.OcVpRe .YQOsOe{margin-left: 10px
}.Ekjuhf{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);-webkit-box-align:start;-webkit-align-items:flex-start;align-items:flex-start;display:-webkit-box;display:-webkit-flex;display:flex;font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 0.75rem;font-weight: 400;letter-spacing: 0.00625rem;line-height: 1.3333333333;margin-top: 2px
}.Ekjuhf.Jj6Lae{color:#b3261e;color:var(--gm3-sys-color-error,#b3261e)
}.AfGCob{margin-right: 8px;margin-top:calc((1px*var(--boq-accounts-wireframe-themes-materialnext-common-abstractinput-help-line-height-unitless-px) - 16px)/2)
}.xTjuxe{display:block;height: 16px;width: 16px
}.edhGSc{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;-webkit-tap-highlight-color:transparent;display:inline-block;outline:none;padding-bottom: 8px
}.RpC4Ne{min-height:1.5em;position:relative;vertical-align:top
}.Pc9Gce{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex;position:relative;padding-top: 14px
}.KHxj8b{-webkit-box-flex: 1;-webkit-flex-grow: 1;-moz-box-flex: 1;-ms-flex-positive: 1;-webkit-box-flex: 1;box-flex: 1;-ms-flex-positive: 1;-webkit-flex-grow: 1;flex-grow: 1;-webkit-flex-shrink: 1;-ms-flex-negative: 1;-ms-flex-negative: 1;-webkit-flex-shrink: 1;flex-shrink: 1;background-color:transparent;border:none;display:block;font: 400 16px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;height: 24px;min-height: 24px;line-height: 24px;margin: 0;outline:none;padding: 0;resize:none;white-space:pre-wrap;word-wrap:break-word;z-index: 0;overflow-y:visible;overflow-x:hidden
}.KHxj8b.VhWN2c{text-align:center
}.edhGSc.dm7YTc .KHxj8b{color:rgba(255,
    255,
    255,.87)
}.edhGSc.u3bW4e.dm7YTc .KHxj8b{color:#fff
}.z0oSpf{background-color:rgba(0,
    0,
    0,.12);height: 1px;left: 0;margin: 0;padding: 0;position:absolute;width: 100%
}.edhGSc.dm7YTc>.RpC4Ne>.z0oSpf{background-color:rgba(255,
    255,
    255,.12)
}.Bfurwb{-webkit-transform:scaleX(0);-webkit-transform:scaleX(0);-ms-transform:scaleX(0);-o-transform:scaleX(0);transform:scaleX(0);background-color:#4285f4;height: 2px;left: 0;margin: 0;padding: 0;position:absolute;width: 100%
}.edhGSc.k0tWj>.RpC4Ne>.z0oSpf,.edhGSc.k0tWj>.RpC4Ne>.Bfurwb{background-color:#d50000;height: 2px
}.edhGSc.k0tWj.dm7YTc>.RpC4Ne>.z0oSpf,.edhGSc.k0tWj.dm7YTc>.RpC4Ne>.Bfurwb{background-color:#ff6e6e
}.edhGSc.RDPZE .KHxj8b{color:rgba(0,
    0,
    0,.38)
}.edhGSc.RDPZE>.RpC4Ne>.z0oSpf{background:none;border-bottom: 1px dotted rgba(0,
    0,
    0,.38)
}.Bfurwb.Y2Zypf{-webkit-animation:quantumWizPaperInputRemoveUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-animation:quantumWizPaperInputRemoveUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-animation:quantumWizPaperInputRemoveUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);animation:quantumWizPaperInputRemoveUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1)
}.edhGSc.u3bW4e>.RpC4Ne>.Bfurwb{-webkit-animation:quantumWizPaperInputAddUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-animation:quantumWizPaperInputAddUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-animation:quantumWizPaperInputAddUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);animation:quantumWizPaperInputAddUnderline .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1)
}.edhGSc.FPYHkb>.RpC4Ne{padding-top: 24px
}.fqp6hd{-webkit-transform-origin:top left;-webkit-transform-origin:top left;-ms-transform-origin:top left;-o-transform-origin:top left;transform-origin:top left;-webkit-transform:translate(0,
    -22px);-webkit-transform:translate(0,
    -22px);-ms-transform:translate(0,
    -22px);-o-transform:translate(0,
    -22px);transform:translate(0,
    -22px);-webkit-transition:all .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-transition:all .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-transition:all .3s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:all .3s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-transition-property:color,top,-webkit-transform;-webkit-transition-property:color,top,-webkit-transform;-o-transition-property:color,top,-webkit-transform;transition-property:color,top,-webkit-transform;-webkit-transition-property:color,top,transform;-o-transition-property:color,top,transform;transition-property:color,top,transform;-webkit-transition-property:color,top,transform,-webkit-transform;-o-transition-property:color,top,transform,-webkit-transform;transition-property:color,top,transform,-webkit-transform;color:rgba(0,
    0,
    0,.38);font: 400 16px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;font-size: 16px;pointer-events:none;position:absolute;top: 100%;width: 100%
}.edhGSc.u3bW4e>.RpC4Ne>.fqp6hd,.edhGSc.CDELXb>.RpC4Ne>.fqp6hd,.edhGSc.LydCob .fqp6hd{-webkit-transform:scale(0.75);-webkit-transform:scale(0.75);-ms-transform:scale(0.75);-o-transform:scale(0.75);transform:scale(0.75);top: 16px
}.edhGSc.dm7YTc>.RpC4Ne>.fqp6hd{color:rgba(255,
    255,
    255,.38)
}.edhGSc.u3bW4e>.RpC4Ne>.fqp6hd,.edhGSc.u3bW4e.dm7YTc>.RpC4Ne>.fqp6hd{color:#4285f4
}.F1pOBe{color:rgba(0,
    0,
    0,.38);font: 400 16px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;max-width: 100%;overflow:hidden;pointer-events:none;position:absolute;bottom: 3px;text-overflow:ellipsis;white-space:nowrap
}.edhGSc.dm7YTc .F1pOBe{color:rgba(255,
    255,
    255,.38)
}.edhGSc.CDELXb>.RpC4Ne>.F1pOBe{display:none
}.S1BUyf{-webkit-tap-highlight-color:transparent;font: 400 12px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;height: 16px;margin-left:auto;padding-left: 16px;padding-top: 8px;pointer-events:none;text-align:right;color:rgba(0,
    0,
    0,.38);white-space:nowrap
}.edhGSc.dm7YTc>.S1BUyf{color:rgba(255,
    255,
    255,.38)
}.edhGSc.wrxyb{padding-bottom: 4px
}.v6odTb,.YElZX:not(:empty){-webkit-tap-highlight-color:transparent;-webkit-box-flex: 1;-webkit-flex: 1 1 auto;-moz-box-flex: 1;-ms-flex: 1 1 auto;-webkit-box-flex: 1 1 auto;-moz-box-flex: 1 1 auto;-ms-flex: 1 1 auto;-webkit-flex: 1 1 auto;flex: 1 1 auto;font: 400 12px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;min-height: 16px;padding-top: 8px
}.edhGSc.wrxyb .jE8NUc{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:-webkit-box;display:-moz-box;display:-webkit-flex;display:-ms-flexbox;display:flex
}.YElZX{pointer-events:none
}.v6odTb{color:#d50000
}.edhGSc.dm7YTc .v6odTb{color:#ff6e6e
}.YElZX{opacity:.3
}.edhGSc.k0tWj .YElZX,.edhGSc:not(.k0tWj) .YElZX:not(:empty)+.v6odTb{display:none
}@-webkit-keyframes quantumWizPaperInputRemoveUnderline{
    0%{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1);opacity: 1
    }to{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1);opacity: 0
    }
}@keyframes quantumWizPaperInputRemoveUnderline{
    0%{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1);opacity: 1
    }to{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1);opacity: 0
    }
}@-webkit-keyframes quantumWizPaperInputAddUnderline{
    0%{-webkit-transform:scaleX(0);-webkit-transform:scaleX(0);-ms-transform:scaleX(0);-o-transform:scaleX(0);transform:scaleX(0)
    }to{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1)
    }
}@keyframes quantumWizPaperInputAddUnderline{
    0%{-webkit-transform:scaleX(0);-webkit-transform:scaleX(0);-ms-transform:scaleX(0);-o-transform:scaleX(0);transform:scaleX(0)
    }to{-webkit-transform:scaleX(1);-webkit-transform:scaleX(1);-ms-transform:scaleX(1);-o-transform:scaleX(1);transform:scaleX(1)
    }
}.X3mtXb{-webkit-box-sizing:content-box;box-sizing:content-box
}.FAiUob,.X3mtXb{display:block;padding: 16px 0 0;width: 100%
}.AFTWye.OcVpRe .X3mtXb,.AFTWye.OcVpRe .FAiUob{padding: 24px 0 0;padding-bottom: 0
}:first-child>.X3mtXb,
:first-child>.FAiUob,
:first-child.OcVpRe>.X3mtXb,
:first-child.OcVpRe>.FAiUob{padding: 8px 0 0
}.AFTWye .X3mtXb .oJeWuf{height: 56px;padding-top: 0
}.AFTWye.OcVpRe .X3mtXb .oJeWuf{height: 36px
}.X3mtXb .Wic03c{-webkit-box-align:center;-webkit-align-items:center;align-items:center;position:static;top: 0
}.X3mtXb .snByac{background:#fff;background:var(--gm3-sys-color-surface-container-lowest,#fff);color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);bottom: 17px;-webkit-box-sizing:border-box;box-sizing:border-box;font-size: 16px;font-weight: 400;left: 8px;max-width:calc(100% - 16px);overflow:hidden;padding: 0 8px;text-overflow:ellipsis;-webkit-transition:opacity .15s cubic-bezier(.4,
    0,.2,
    1),-webkit-transform .15s cubic-bezier(.4,
    0,.2,
    1);transition:opacity .15s cubic-bezier(.4,
    0,.2,
    1),-webkit-transform .15s cubic-bezier(.4,
    0,.2,
    1);transition:transform .15s cubic-bezier(.4,
    0,.2,
    1),opacity .15s cubic-bezier(.4,
    0,.2,
    1);transition:transform .15s cubic-bezier(.4,
    0,.2,
    1),opacity .15s cubic-bezier(.4,
    0,.2,
    1),-webkit-transform .15s cubic-bezier(.4,
    0,.2,
    1);white-space:nowrap;width:auto;z-index: 1
}.X3mtXb.IYewr.u3bW4e .zHQkBf:not([disabled
])~.snByac{color:#b3261e;color:var(--gm3-sys-color-error,#b3261e)
}.AFTWye.OcVpRe .X3mtXb .snByac{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);bottom: 9px;font-size: 14px;left: 4px;line-height: 16px;padding: 0 6px
}.AFTWye.OcVpRe .u3bW4e .snByac,.AFTWye.OcVpRe .CDELXb .snByac{-webkit-transform:scale(.75) translateY(-155%);-ms-transform:scale(.75) translateY(-155%);transform:scale(.75) translateY(-155%)
}.X3mtXb .ndJi5d{top:inherit
}.X3mtXb .ndJi5d,.X3mtXb .ovnfwe{pointer-events:auto
}.X3mtXb .Is7Fhb,.X3mtXb .RxsGPe{font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 0.75rem;font-weight: 400;letter-spacing: 0.00625rem;line-height: 1.3333333333;opacity: 1;padding-top: 4px
}.AFTWye .Is7Fhb{color:var(--gm3-sys-color-on-surface-variant,#444746);margin-left: 16px
}.AFTWye.OcVpRe .Is7Fhb{margin-left: 10px
}.X3mtXb .RxsGPe{color:#b3261e;color:var(--gm3-sys-color-error,#b3261e)
}.X3mtXb .Is7Fhb:empty,.X3mtXb .RxsGPe:empty{display:none
}.X3mtXb .zHQkBf{border-radius: 4px;color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 16px;height: 28px;margin: 1px 1px 0 1px;padding: 13px 15px;text-align:left;width: 100%;z-index: 1
}.X3mtXb.u3bW4e .zHQkBf,.X3mtXb.IYewr .zHQkBf{margin: 2px 2px 0 2px;padding: 12px 14px
}.AFTWye.OcVpRe .X3mtXb .zHQkBf{font-size: 14px;height: 20px;padding: 7px 9px
}.AFTWye.OcVpRe .u3bW4e .zHQkBf,.AFTWye.OcVpRe .IYewr .zHQkBf{height: 20px;padding: 6px 8px
}.UOsO2 .Wic03c,.UOsO2 .zHQkBf,.UOsO2 .iHd5yb,.UOsO2 .MQL3Ob{direction:ltr;text-align:left
}.UOsO2 .Wic03c .snByac{direction:ltr
}.X3mtXb .iHd5yb{padding-left: 15px
}.X3mtXb.u3bW4e .iHd5yb{padding-left: 14px
}.X3mtXb .MQL3Ob{padding-right: 15px;z-index: 1
}.X3mtXb.u3bW4e .MQL3Ob{padding-right: 15px
}.AFTWye.OcVpRe .X3mtXb .iHd5yb{padding-left: 9px
}.AFTWye.OcVpRe .X3mtXb.u3bW4e .iHd5yb{padding-left: 8px
}.AFTWye.OcVpRe .X3mtXb .MQL3Ob,.AFTWye.OcVpRe .X3mtXb.u3bW4e .MQL3Ob{padding-right: 9px
}.X3mtXb .AxOyFc{font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif
}.X3mtXb .whsOnd:not([disabled
]):focus~.AxOyFc{color:#0b57d0;color:var(--gm3-sys-color-primary,#0b57d0)
}.X3mtXb .mIZh1c{border: 1px solid;border-color:#747775;border-color:var(--gm3-sys-color-outline,#747775);border-radius: 4px;bottom: 0;-webkit-box-sizing:border-box;box-sizing:border-box
}.X3mtXb .cXrdqd{border-radius: 4px;bottom: 0;opacity: 0;-webkit-transform:none;-ms-transform:none;transform:none;-webkit-transition:opacity .15s cubic-bezier(.4,
    0,.2,
    1);transition:opacity .15s cubic-bezier(.4,
    0,.2,
    1);width:calc(100% - 4px)
}.X3mtXb .mIZh1c,.X3mtXb .cXrdqd,.X3mtXb.IYewr .mIZh1c,.X3mtXb.IYewr .cXrdqd{background-color:transparent
}.X3mtXb .mIZh1c,.X3mtXb.k0tWj .mIZh1c{height: 100%
}.X3mtXb.IYewr .cXrdqd{height:calc(100% - 2px);width:calc(100% - 2px)
}.X3mtXb .cXrdqd,.X3mtXb.IYewr.u3bW4e .cXrdqd{height:calc(100% - 4px);width:calc(100% - 4px)
}.X3mtXb.u3bW4e .cXrdqd,.X3mtXb.IYewr .cXrdqd{-webkit-animation:none;animation:none;opacity: 1
}.X3mtXb.u3bW4e .cXrdqd{border: 2px solid;border-color:#0b57d0;border-color:var(--gm3-sys-color-primary,#0b57d0)
}.X3mtXb.IYewr.u3bW4e .cXrdqd{border-width: 2px
}.X3mtXb.IYewr .cXrdqd{border: 1px solid;border-color:#b3261e;border-color:var(--gm3-sys-color-error,#b3261e)
}.X3mtXb.IYewr.CDELXb .snByac{color:#b3261e;color:var(--gm3-sys-color-error,#b3261e)
}.X3mtXb .zHQkBf[disabled
]{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);opacity: 0.38
}.FAiUob .mIZh1c{background-color:var(--gm3-sys-color-outline,#747775)
}.FAiUob .cXrdqd{background-color:#0b57d0;background-color:var(--gm3-sys-color-primary,#0b57d0)
}.FAiUob .snByac{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746)
}.FAiUob.u3bW4e .snByac.snByac{color:#0b57d0;color:var(--gm3-sys-color-primary,#0b57d0)
}.Em2Ord{margin: 16px 0;outline:none
}.Em2Ord+.Em2Ord{margin-top: 24px
}.Em2Ord:first-child{margin-top: 0
}.Em2Ord:last-child{margin-bottom: 0
}.PsAlOe{border-radius: 8px;padding: 16px
}.PsAlOe>:first-child{margin-top: 0
}.PsAlOe>:last-child{margin-bottom: 0
}.PsAlOe .x9zgF{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 1rem;font-weight: 500;letter-spacing: 0rem;line-height: 1.5
}.PsAlOe.sj692e .x9zgF,.PsAlOe.sj692e .yTaH4c{color:#041e49;color:var(--gm3-sys-color-on-primary-container,#041e49)
}.PsAlOe.Xq8bDe .x9zgF,.PsAlOe.Xq8bDe .yTaH4c{color:#410e0b;color:var(--gm3-sys-color-on-error-container,#410e0b)
}.PsAlOe.rNe0id .x9zgF,.PsAlOe.rNe0id .yTaH4c{color:var(--wf-color-warning-text,#421f00)
}.PsAlOe .yTaH4c{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f)
}.PsAlOe.YFdWic .vYeFie,.PsAlOe.YFdWic .yTaH4c{margin-left: 64px;width:calc(100% - 48px - 16px)
}.PsAlOe.YFdWic .yTaH4c{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);margin-top: 4px
}.PsAlOe.YFdWic:not(.S7S4N) .vYeFie{margin-left: 0;width: 0
}.PsAlOe:not(.S7S4N)>.yTaH4c{margin-top: 0
}.PsAlOe.sj692e{background:#d3e3fd;background:var(--gm3-sys-color-primary-container,#d3e3fd)
}.PsAlOe.Xq8bDe{background:#f9dedc;background:var(--gm3-sys-color-error-container,#f9dedc)
}.PsAlOe.rNe0id{background:var(--wf-color-warning-bg,#fff0d1)
}.PsAlOe.YFdWic{background:#1b1b1b;background:var(--gm3-sys-color-surface-container-low,#f8fafd);min-height: 80px;position:relative
}.PsAlOe.YFdWic .x9zgF{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f)
}.PsAlOe.YFdWic .yTaH4c{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746)
}.PsAlOe:not(.S7S4N){display:-webkit-box;display:-webkit-flex;display:flex
}.Em2Ord.eLNT1d{display:none
}.Em2Ord.RDPZE{opacity:.5;pointer-events:none
}.Em2Ord.RDPZE .Em2Ord.RDPZE{opacity: 1
}.se0rCf{background-color:#1b1b1b;background-color:var(--gm3-sys-color-surface-container-low,#f8fafd);border-radius: 28px;padding: 16px
}.se0rCf .x9zgF{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f)
}.se0rCf .yTaH4c{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746)
}.se0rCf .X3mtXb .snByac,.se0rCf.Em2Ord .i79UJc .snByac{background-color:#1b1b1b;background-color:var(--gm3-sys-color-surface-container-low,#f8fafd)
}.se0rCf .SgHwWb{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-pack:end;-webkit-justify-content:flex-end;justify-content:flex-end;margin-top: 16px
}.se0rCf .SgHwWb .BqKGqe{margin-bottom: 0;margin-top: 0
}.nn7x3d{border-bottom: 1px solid #c4c7c5;border-bottom: 1px solid var(--gm3-sys-color-outline-variant,#c4c7c5);display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column
}.nn7x3d .V9RXW .rBUW7e{border-bottom: 0
}.nn7x3d .nn7x3d:last-child{border-bottom: 0
}.dwkQ3b:not(.jVwmLb){border-bottom: 0
}.nn7x3d .nn7x3d:last-child .ozEFYb{padding-bottom: 0
}.nn7x3d.dwkQ3b{border-bottom: 0
}.vYeFie:empty,.osxBFb:empty{display:none
}.vYeFie>:first-child{margin-top: 0;padding-top: 0
}.vYeFie>:last-child{margin-bottom: 0;padding-bottom: 0
}.LwQQGe{margin: 0 0 8px
}.nn7x3d[data-expand-type="1"
] .ozEFYb,.Em2Ord[data-expand-type="1"
] .HKEKLe{cursor:pointer
}.nn7x3d .ozEFYb{padding-bottom: 16px
}.x9zgF{-webkit-box-align:center;-webkit-align-items:center;align-items:center;color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);display:-webkit-box;display:-webkit-flex;display:flex;font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 1.25rem;font-weight: 400;letter-spacing: 0rem;line-height: 1.2;margin-top: 0;margin-bottom: 0;padding: 0
}.Em2Ord.S7S4N .Em2Ord:not(.nn7x3d) .x9zgF{font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 1rem;font-weight: 500;letter-spacing: 0rem;line-height: 1.5
}.nn7x3d.u3bW4e .x9zgF{position:relative
}.nn7x3d[data-expand-type="1"
].u3bW4e .x9zgF: :after{background:#0b57d0;background:var(--gm3-sys-color-primary,#0b57d0);border-radius: 8px;bottom: -4px;content: "";left: -8px;position:absolute;opacity: 0.1;right: -8px;top: -4px;z-index: -1
}.HKEKLe{background:none;border:none;color:inherit;-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;font:inherit;margin: 0;outline: 0;padding: 0;text-align:inherit
}.HKEKLe: :-moz-focus-inner{border: 0
}.HKEKLe [jsslot
]{position:relative
}.MI3XC{margin-left: 16px
}.MI3XC .aHWa4d{-webkit-box-align:center;-webkit-align-items:center;align-items:center;display:-webkit-box;display:-webkit-flex;display:flex;height: 24px;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-transition:-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1),-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);width: 24px
}.nn7x3d .MI3XC,.nn7x3d .HKEKLe,.nn7x3d .CuWxc{pointer-events:none
}.nn7x3d.jVwmLb .aHWa4d{-webkit-transform:rotate(-180deg);-ms-transform:rotate(-180deg);transform:rotate(-180deg)
}.CuWxc{color:var(--gm3-sys-color-on-surface-variant,#444746);-webkit-flex-shrink: 0;flex-shrink: 0;height: 20px;margin-right: 16px;width: 20px
}.CuWxc .C3qbwe{height: 100%;width: 100%
}.PsAlOe .CuWxc{margin-top: 0
}.PsAlOe.sj692e .CuWxc{color:#0b57d0;color:var(--gm3-sys-color-primary,#0b57d0)
}.PsAlOe.Xq8bDe .CuWxc{color:#b3261e;color:var(--gm3-sys-color-error,#b3261e)
}.PsAlOe.rNe0id .CuWxc{color:var(--wf-color-warning-icon,#f09d00)
}.PsAlOe.YFdWic .CuWxc{height: 48px;left: 16px;position:absolute;top: 16px;width: 48px
}.osxBFb{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);font-size: 0.875rem;font-weight: 400;line-height: 1.4285714286;margin-top: 8px
}.vYeFie:empty+.yTaH4c{margin-top: 0
}.yTaH4c{margin-bottom: 16px;margin-top: 10px
}.se0rCf .yTaH4c{margin-bottom: 0;margin-top: 16px
}.yTaH4c:only-child{margin-bottom: 0;margin-top: 0
}.nn7x3d .yTaH4c{margin-top: 0;overflow:hidden;-webkit-transition: 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition: 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1)
}.nn7x3d.jVwmLb .yTaH4c{margin-bottom: 0;margin-top: 0;max-height: 0;opacity: 0;visibility:hidden
}.yTaH4c>[jsslot
]>:first-child:not(.PsAlOe){margin-top: 0;padding-top: 0
}.yTaH4c>[jsslot
]>:last-child:not(.PsAlOe){margin-bottom: 0;padding-bottom: 0
}.kvM7xe{margin-bottom: -12px
}.kvM7xe{-webkit-align-self:center;align-self:center;margin-bottom: 0
}.g0ndYb{border-bottom: 1px solid #c4c7c5;border-bottom: 1px solid var(--gm3-sys-color-outline-variant,#c4c7c5);display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-webkit-flex-direction:row;flex-direction:row;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;height: 0;margin-top: 12px
}.VXMllb{background-color:#fff;background-color:var(--gm3-sys-color-surface-container-lowest,#fff);display:-webkit-box;display:-webkit-flex;display:flex;height: 24px;margin-top: -12px
}.dwkQ3b:not(.jVwmLb) .g0ndYb{display:none
}.dgtjld .VfPpkd-IE5DDf{background-color:#000;background-color:var(--gm3-sys-color-scrim,#000);opacity: 0.32
}.dgtjld .VfPpkd-P5QLlc{background-color:#e9eef6;background-color:var(--gm3-sys-color-surface-container-high,#e9eef6);border-radius: 23px
}.dgtjld .VfPpkd-k2Wrsb{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 1.5rem;font-weight: 400;letter-spacing: 0rem;line-height: 1.3333333333
}.dgtjld .VfPpkd-cnG4Wd{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 0.875rem;font-weight: 400;letter-spacing: 0rem;line-height: 1.4285714286;padding-bottom: 0
}.dgtjld .VfPpkd-T0kwCb{padding: 0 24px 16px 24px
}.dgtjld .yTaH4c{margin-left: 0;margin-right: 0;padding-left: 0;padding-right: 0
}.dgtjld .ksBjEc{color:#0b57d0;color:var(--gm3-sys-color-primary,#0b57d0);font-size: 0.875rem;height: 40px;padding: 0 16px
}.dgtjld .ksBjEc:hover:not(:disabled){color:#0b57d0;color:var(--gm3-sys-color-primary,#0b57d0)
}.dgtjld .ksBjEc .VfPpkd-Jh9lGc: :after,.dgtjld .ksBjEc .VfPpkd-Jh9lGc: :before{background-color:#0b57d0;background-color:var(--gm3-sys-color-primary,#0b57d0)
}.dgtjld .ksBjEc:focus:not(:disabled){color:#0b57d0;color:var(--gm3-sys-color-primary,#0b57d0)
}.dgtjld .ksBjEc .VfPpkd-J1Ukfc-LhBDec{border-color:#0b57d0;border-color:var(--gm3-sys-color-primary,#0b57d0)
}.dgtjld .ksBjEc .VfPpkd-J1Ukfc-LhBDec: :after{border-color:#d3e3fd;border-color:var(--gm3-sys-color-primary-container,#d3e3fd)
}.dgtjld .ksBjEc .VfPpkd-J1Ukfc-LhBDec: :after,.dgtjld .ksBjEc .VfPpkd-J1Ukfc-LhBDec,.dgtjld .ksBjEc .VfPpkd-Jh9lGc{border-radius: 23px
}.dgtjld.Zttm2{border-radius: 0
}.dgtjld.Zttm2 .VfPpkd-P5QLlc{height: 100vh;max-height:none;max-width:none;width: 100vw
}.dgtjld.Zttm2 .yHy1rc{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);display:inline-block;padding: 12px;text-align:center
}.dgtjld.Zttm2 .VfPpkd-zMU9ub .NMm5M{fill:var(--gm3-sys-color-primary,#0b57d0)
}.dgtjld.Zttm2 .VfPpkd-Bz112c-J1Ukfc-LhBDec{border-color:#0b57d0;border-color:var(--gm3-sys-color-primary,#0b57d0);padding: 2px
}.dgtjld.Zttm2 .VfPpkd-Bz112c-J1Ukfc-LhBDec,.dgtjld.Zttm2 .VfPpkd-Bz112c-J1Ukfc-LhBDec: :after{border-radius: 50%
}.dgtjld.Zttm2 .yHy1rc:not(.VfPpkd-Bz112c-J1Ukfc-LhBDec): :before{display:none
}.dgtjld.Zttm2 .yHy1rc:not(.VfPpkd-Bz112c-J1Ukfc-LhBDec): :after{background:none;border:none;-webkit-box-shadow:none;box-shadow:none
}.dgtjld.Zttm2 .yHy1rc .VfPpkd-Bz112c-Jh9lGc: :before,.dgtjld.Zttm2 .yHy1rc .VfPpkd-Bz112c-Jh9lGc: :after{background-color:#0b57d0;background-color:var(--gm3-sys-color-primary,#0b57d0)
}.Zttm2 .rcN2gf{height: 100%;width: 100%
}.Zttm2 .RITe7{border:none;color-scheme:normal;display:block;height: 100%;padding: 0;width: 100%
}.KGgLze{color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;font-size: 0.875rem;font-weight: 400;padding-left: 16px
}.rqy4Nd{-webkit-box-align:center;-webkit-align-items:center;align-items:center;background:var(--gm3-sys-color-surface-container-lowest,#fff);border: 1px solid var(--gm3-sys-color-outline,#747775);border-radius: 16px;color:var(--gm3-sys-color-on-surface,#1f1f1f);cursor:pointer;display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;max-width: 100%;padding: 0 15px 0 15px
}.rqy4Nd:focus-visible{outline:none;position:relative
}.rqy4Nd:focus-visible: :after{border: 2px solid;border-color:var(--gm3-sys-color-primary,#0b57d0);border-radius: 26px;content: "";position:absolute;pointer-events:none;inset: -5px
}.rqy4Nd{position:relative
}.rqy4Nd: :before{background:var(--gm3-sys-color-on-surface,#1f1f1f);content: "";opacity: 0;position:absolute;pointer-events:none
}.rqy4Nd:hover: :before{opacity: 0.08
}.rqy4Nd:focus: :before,.rqy4Nd.u3bW4e: :before{opacity: 0.12
}.rqy4Nd:active: :before,.rqy4Nd.qs41qe: :before{opacity: 0.12
}.rqy4Nd: :before{border-radius: 16px;width: 100%;height: 100%
}.rqy4Nd:focus,.rqy4Nd.u3bW4e{outline:none;border-color:var(--gm3-sys-color-outline,#747775)
}.rqy4Nd:active,.rqy4Nd.qs41qe{color:var(--gm3-sys-color-on-surface,#1f1f1f);border-color:var(--gm3-sys-color-on-surface,#1f1f1f)
}.rqy4Nd: :after{border: 1px solid transparent;border-radius: 16px;content: "";position:absolute;inset: -1px
}.rqy4Nd.EPPJc{padding-right: 8px
}.rqy4Nd:not(.DbQnIe).cd29Sd{padding-left: 3px
}.rqy4Nd.DbQnIe{color:var(--gm3-sys-color-primary,#0b57d0);border-radius: 12px;padding: 0 10px 0 10px
}.rqy4Nd.DbQnIe.cd29Sd{padding-left: 0px
}.rqy4Nd.DbQnIe.EPPJc{padding-right: 8px
}.rqy4Nd.DbQnIe: :after{border-radius: 12px
}.p4lXmb{border-radius: 12px;height: 24px;margin-right: 8px
}.p4lXmb .RucDLe,.p4lXmb .MWnvBb,.p4lXmb .IqauWe{border-radius: 50%;color:var(--gm3-sys-color-on-surface-variant,#444746);display:block;height: 24px;width: 24px
}.BLBDic{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr;text-align:left;font-family:Google Sans Text;font-weight: 400;font-size: 0.875rem;letter-spacing: 0rem;line-height: 1.25rem;line-height: 30px
}.rqy4Nd.DbQnIe .BLBDic{font-family:Google Sans Text;font-weight: 500;font-size: 0.688rem;letter-spacing: 0.006rem;line-height: 1rem;line-height: 22px
}.rqy4Nd:not(.DbQnIe).xNLKcb .BLBDic{font-family:Google Sans Text;font-weight: 500;font-size: 0.875rem;letter-spacing: 0rem;line-height: 1.25rem;line-height: 30px
}.ikhOsf{color:var(--gm3-sys-color-on-surface,#1f1f1f);-webkit-flex-shrink: 0;flex-shrink: 0;height: 20px;margin-left: 5px;width: 20px;-webkit-transition:-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1),-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1)
}.rqy4Nd.sMVRZe .ikhOsf{-webkit-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg)
}.rqy4Nd.DbQnIe .ikhOsf{color:var(--gm3-sys-color-primary,#0b57d0);height: 16px;width: 16px
}.KH7bFe{display:block;height: 100%;width: 100%
}.ySLakb{margin: 16px 0;outline:none
}.ySLakb+.ySLakb{margin-top: 24px
}.ySLakb:first-child{margin-top: 0
}.ySLakb:last-child{margin-bottom: 0
}.i3HiPd{border-radius: 8px;padding: 16px
}.i3HiPd>:first-child{margin-top: 0
}.i3HiPd>:last-child{margin-bottom: 0
}.i3HiPd .xHr6Xe{font-family:Google Sans Text;font-weight: 500;font-size: 1rem;letter-spacing: 0rem;line-height: 1.5rem
}.i3HiPd.sj692e .xHr6Xe,.i3HiPd.sj692e .F4tG3e{color:var(--gm3-sys-color-on-primary-container,#041e49)
}.i3HiPd.Xq8bDe .xHr6Xe,.i3HiPd.Xq8bDe .F4tG3e{color:var(--gm3-sys-color-on-error-container,#410e0b)
}.i3HiPd.rNe0id .xHr6Xe,.i3HiPd.rNe0id .F4tG3e{color:var(
    --wf-color-warning-text,#421f00
  )
}.i3HiPd.YFdWic .Y9aYob,.i3HiPd.YFdWic .F4tG3e{margin-left: 64px;width:calc(100% - 48px - 16px)
}.i3HiPd.YFdWic .F4tG3e{color:var(--gm3-sys-color-on-surface-variant,#444746);margin-top: 4px
}.i3HiPd.YFdWic .xHr6Xe{color:var(--gm3-sys-color-on-surface,#1f1f1f)
}.i3HiPd.YFdWic:not(.S7S4N) .Y9aYob{margin-left: 0;width: 0
}.i3HiPd:not(.S7S4N)>.F4tG3e{margin-top: 0
}.i3HiPd.sj692e{background:var(--gm3-sys-color-primary-container,#d3e3fd)
}.i3HiPd.Xq8bDe{background:var(--gm3-sys-color-error-container,#f9dedc)
}.i3HiPd.rNe0id{background:var(
    --wf-color-warning-bg,#fff0d1
  )
}.i3HiPd.YFdWic{background:var(--gm3-sys-color-surface-container-low,#f8fafd);min-height: 80px;position:relative
}.i3HiPd:not(.S7S4N){display:-webkit-box;display:-webkit-flex;display:flex
}.ySLakb.eLNT1d{display:none
}.ySLakb.RDPZE{opacity:.5;pointer-events:none
}.ySLakb.RDPZE .ySLakb.RDPZE{opacity: 1
}.Ci1RI{background:var(--gm3-sys-color-surface-container-low,#f8fafd);border-radius: 28px;padding: 16px
}.Ci1RI .xHr6Xe{color:var(--gm3-sys-color-on-surface,#1f1f1f)
}.Ci1RI .F4tG3e{color:var(--gm3-sys-color-on-surface-variant,#444746)
}.Ci1RI .Zy76pd .snByac,.Ci1RI.ySLakb .hYWTMe .snByac,.Ci1RI .Zy76pd.u3bW4e .snByac,.Ci1RI.ySLakb .hYWTMe.u3bW4e .snByac{background-color:var(--gm3-sys-color-surface-container-low,#f8fafd)
}.Ci1RI .rcBv3{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-pack:end;-webkit-justify-content:flex-end;justify-content:flex-end;margin-top: 16px
}.Ci1RI .rcBv3 .Mauo7{margin-bottom: 0;margin-top: 0
}.ZfdVuf{bottom: 1px solid var(--gm3-sys-color-outline-variant,#c4c7c5);display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column
}.ZfdVuf .V9RXW .rBUW7e{border-bottom: 0
}.ZfdVuf .ZfdVuf:last-child{border-bottom: 0
}.xe7Heb:not(.jVwmLb){border-bottom: 0
}.ZfdVuf .ZfdVuf:last-child .xwfjVe{padding-bottom: 0
}.ZfdVuf.xe7Heb{border-bottom: 0
}.Y9aYob:empty,.XQ6hEf:empty{display:none
}.Y9aYob>:first-child{margin-top: 0;padding-top: 0
}.Y9aYob>:last-child{margin-bottom: 0;padding-bottom: 0
}.uY2Qad{margin: 0 0 8px
}.ZfdVuf[data-expand-type="1"
] .xwfjVe,.ySLakb[data-expand-type="1"
] .GliO4d{cursor:pointer
}.ZfdVuf .xwfjVe{padding-bottom: 16px
}.xHr6Xe{-webkit-box-align:center;-webkit-align-items:center;align-items:center;color:var(--gm3-sys-color-on-surface,#1f1f1f);display:-webkit-box;display:-webkit-flex;display:flex;margin-top: 0;margin-bottom: 0;padding: 0;font-family:Google Sans,roboto,Noto Sans Myanmar UI,arial,sans-serif;font-weight: 400;font-size: 1.25rem;letter-spacing: 0rem;line-height: 1.5rem
}.ySLakb.S7S4N .ySLakb:not(.ZfdVuf) .xHr6Xe{font-family:Google Sans Text;font-weight: 500;font-size: 1rem;letter-spacing: 0rem;line-height: 1.5rem
}.ZfdVuf.u3bW4e .xHr6Xe{position:relative
}.ZfdVuf[data-expand-type="1"
].u3bW4e .xHr6Xe: :after{background:var(--gm3-sys-color-primary,#0b57d0);border-radius: 8px;inset: -4px -8px -4px;content: "";position:absolute;opacity: 0.12;z-index: -1
}.GliO4d{background:none;border:none;color:inherit;-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;font:inherit;margin: 0;outline: 0;padding: 0;text-align:inherit
}.GliO4d: :-moz-focus-inner{border: 0
}.GliO4d [jsslot
]{position:relative
}.h5Vxbc{margin-left: 16px
}.h5Vxbc .kV7hid{-webkit-box-align:center;-webkit-align-items:center;align-items:center;display:-webkit-box;display:-webkit-flex;display:flex;height: 24px;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-transition:-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1),-webkit-transform 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);width: 24px
}.ZfdVuf .h5Vxbc,.ZfdVuf .GliO4d,.ZfdVuf .T5OKle{pointer-events:none
}.ZfdVuf.jVwmLb .kV7hid{-webkit-transform:rotate(-180deg);-ms-transform:rotate(-180deg);transform:rotate(-180deg)
}.T5OKle{color:var(--gm3-sys-color-on-surface-variant,#444746);-webkit-flex-shrink: 0;flex-shrink: 0;height: 20px;margin-right: 16px;width: 20px
}.T5OKle .jLPeif{height: 100%;width: 100%
}.i3HiPd .T5OKle{margin-top: 0
}.i3HiPd.sj692e .T5OKle{color:var(--gm3-sys-color-primary,#0b57d0)
}.i3HiPd.Xq8bDe .T5OKle{color:var(--gm3-sys-color-error,#b3261e)
}.i3HiPd.rNe0id .T5OKle{color:var(
    --wf-color-warning-icon,#f09d00
  )
}.i3HiPd.YFdWic .T5OKle{height: 48px;left: 16px;position:absolute;top: 16px;width: 48px
}.XQ6hEf{color:var(--gm3-sys-color-on-surface-variant,#444746);margin-top: 8px;font-family:Google Sans Text;font-weight: 400;font-size: 0.875rem;letter-spacing: 0rem;line-height: 1.25rem
}.Y9aYob:empty+.F4tG3e{margin-top: 0
}.F4tG3e{margin-bottom: 16px;margin-top: 10px
}.Ci1RI .F4tG3e{margin-bottom: 0;margin-top: 16px
}.F4tG3e:only-child{margin-bottom: 0;margin-top: 0
}.ZfdVuf .F4tG3e{margin-top: 0;overflow:hidden;-webkit-transition: 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1);transition: 0.2s cubic-bezier(0.4,
    0,
    0.2,
    1)
}.ZfdVuf.jVwmLb .F4tG3e{margin-bottom: 0;margin-top: 0;max-height: 0;opacity: 0;visibility:hidden
}.F4tG3e>[jsslot
]>:first-child:not(.i3HiPd){margin-top: 0;padding-top: 0
}.F4tG3e>[jsslot
]>:last-child:not(.i3HiPd){margin-bottom: 0;padding-bottom: 0
}.iyXtud{margin-bottom: -12px
}.iyXtud{-webkit-align-self:center;align-self:center;margin-bottom: 0
}.qEYr5c{bottom: 1px solid var(--gm3-sys-color-outline-variant,#c4c7c5);display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-webkit-flex-direction:row;flex-direction:row;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;height: 0;margin-top: 12px
}.BJ3M4b{color:var(--gm3-sys-color-surface-container-lowest,#fff);display:-webkit-box;display:-webkit-flex;display:flex;height: 24px;margin-top: -12px
}.xe7Heb:not(.jVwmLb) .qEYr5c{display:none
}.VfPpkd-JGcpL-uI4vCe-LkdAo,.VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:#6200ee;stroke:var(--mdc-theme-primary,#6200ee)
}@media (-ms-high-contrast:active),screen and (forced-colors:active){.VfPpkd-JGcpL-uI4vCe-LkdAo,.VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.VfPpkd-JGcpL-uI4vCe-u014N{stroke:transparent
}@-webkit-keyframes mdc-circular-progress-container-rotate{to{-webkit-transform:rotate(1turn);transform:rotate(1turn)
    }
}@keyframes mdc-circular-progress-container-rotate{to{-webkit-transform:rotate(1turn);transform:rotate(1turn)
    }
}@-webkit-keyframes mdc-circular-progress-spinner-layer-rotate{
    12.5%{-webkit-transform:rotate(135deg);transform:rotate(135deg)
    }25%{-webkit-transform:rotate(270deg);transform:rotate(270deg)
    }37.5%{-webkit-transform:rotate(405deg);transform:rotate(405deg)
    }50%{-webkit-transform:rotate(540deg);transform:rotate(540deg)
    }62.5%{-webkit-transform:rotate(675deg);transform:rotate(675deg)
    }75%{-webkit-transform:rotate(810deg);transform:rotate(810deg)
    }87.5%{-webkit-transform:rotate(945deg);transform:rotate(945deg)
    }100%{-webkit-transform:rotate(3turn);transform:rotate(3turn)
    }
}@keyframes mdc-circular-progress-spinner-layer-rotate{
    12.5%{-webkit-transform:rotate(135deg);transform:rotate(135deg)
    }25%{-webkit-transform:rotate(270deg);transform:rotate(270deg)
    }37.5%{-webkit-transform:rotate(405deg);transform:rotate(405deg)
    }50%{-webkit-transform:rotate(540deg);transform:rotate(540deg)
    }62.5%{-webkit-transform:rotate(675deg);transform:rotate(675deg)
    }75%{-webkit-transform:rotate(810deg);transform:rotate(810deg)
    }87.5%{-webkit-transform:rotate(945deg);transform:rotate(945deg)
    }100%{-webkit-transform:rotate(3turn);transform:rotate(3turn)
    }
}@-webkit-keyframes mdc-circular-progress-color-1-fade-in-out{from{opacity:.99
    }25%{opacity:.99
    }26%{opacity: 0
    }89%{opacity: 0
    }90%{opacity:.99
    }to{opacity:.99
    }
}@keyframes mdc-circular-progress-color-1-fade-in-out{from{opacity:.99
    }25%{opacity:.99
    }26%{opacity: 0
    }89%{opacity: 0
    }90%{opacity:.99
    }to{opacity:.99
    }
}@-webkit-keyframes mdc-circular-progress-color-2-fade-in-out{from{opacity: 0
    }15%{opacity: 0
    }25%{opacity:.99
    }50%{opacity:.99
    }51%{opacity: 0
    }to{opacity: 0
    }
}@keyframes mdc-circular-progress-color-2-fade-in-out{from{opacity: 0
    }15%{opacity: 0
    }25%{opacity:.99
    }50%{opacity:.99
    }51%{opacity: 0
    }to{opacity: 0
    }
}@-webkit-keyframes mdc-circular-progress-color-3-fade-in-out{from{opacity: 0
    }40%{opacity: 0
    }50%{opacity:.99
    }75%{opacity:.99
    }76%{opacity: 0
    }to{opacity: 0
    }
}@keyframes mdc-circular-progress-color-3-fade-in-out{from{opacity: 0
    }40%{opacity: 0
    }50%{opacity:.99
    }75%{opacity:.99
    }76%{opacity: 0
    }to{opacity: 0
    }
}@-webkit-keyframes mdc-circular-progress-color-4-fade-in-out{from{opacity: 0
    }65%{opacity: 0
    }75%{opacity:.99
    }90%{opacity:.99
    }to{opacity: 0
    }
}@keyframes mdc-circular-progress-color-4-fade-in-out{from{opacity: 0
    }65%{opacity: 0
    }75%{opacity:.99
    }90%{opacity:.99
    }to{opacity: 0
    }
}@-webkit-keyframes mdc-circular-progress-left-spin{from{-webkit-transform:rotate(265deg);transform:rotate(265deg)
    }50%{-webkit-transform:rotate(130deg);transform:rotate(130deg)
    }to{-webkit-transform:rotate(265deg);transform:rotate(265deg)
    }
}@keyframes mdc-circular-progress-left-spin{from{-webkit-transform:rotate(265deg);transform:rotate(265deg)
    }50%{-webkit-transform:rotate(130deg);transform:rotate(130deg)
    }to{-webkit-transform:rotate(265deg);transform:rotate(265deg)
    }
}@-webkit-keyframes mdc-circular-progress-right-spin{from{-webkit-transform:rotate(-265deg);transform:rotate(-265deg)
    }50%{-webkit-transform:rotate(-130deg);transform:rotate(-130deg)
    }to{-webkit-transform:rotate(-265deg);transform:rotate(-265deg)
    }
}@keyframes mdc-circular-progress-right-spin{from{-webkit-transform:rotate(-265deg);transform:rotate(-265deg)
    }50%{-webkit-transform:rotate(-130deg);transform:rotate(-130deg)
    }to{-webkit-transform:rotate(-265deg);transform:rotate(-265deg)
    }
}.VfPpkd-JGcpL-P1ekSe{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative;direction:ltr;line-height: 0;overflow:hidden;-webkit-transition:opacity .25s 0ms cubic-bezier(.4,
    0,.6,
    1);transition:opacity .25s 0ms cubic-bezier(.4,
    0,.6,
    1)
}.VfPpkd-JGcpL-uI4vCe-haAclf,.VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G,.VfPpkd-JGcpL-IdXvz-haAclf,.VfPpkd-JGcpL-QYI5B-pbTTYe{position:absolute;width: 100%;height: 100%
}.VfPpkd-JGcpL-uI4vCe-haAclf{-webkit-transform:rotate(-90deg);-ms-transform:rotate(-90deg);transform:rotate(-90deg)
}.VfPpkd-JGcpL-IdXvz-haAclf{font-size: 0;letter-spacing: 0;white-space:nowrap;opacity: 0
}.VfPpkd-JGcpL-uI4vCe-LkdAo-Bd00G,.VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{fill:transparent
}.VfPpkd-JGcpL-uI4vCe-LkdAo{-webkit-transition:stroke-dashoffset .5s 0ms cubic-bezier(0,
    0,.2,
    1);transition:stroke-dashoffset .5s 0ms cubic-bezier(0,
    0,.2,
    1)
}.VfPpkd-JGcpL-OcUoKf-TpMipd{position:absolute;top: 0;left: 47.5%;-webkit-box-sizing:border-box;box-sizing:border-box;width: 5%;height: 100%;overflow:hidden
}.VfPpkd-JGcpL-OcUoKf-TpMipd .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{left: -900%;width: 2000%;-webkit-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg)
}.VfPpkd-JGcpL-lLvYUc-e9ayKc{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative;width: 50%;height: 100%;overflow:hidden
}.VfPpkd-JGcpL-lLvYUc-e9ayKc .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{width: 200%
}.VfPpkd-JGcpL-lLvYUc-qwU8Me .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{left: -100%
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-A9y3zc .VfPpkd-JGcpL-uI4vCe-haAclf{opacity: 0
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-A9y3zc .VfPpkd-JGcpL-IdXvz-haAclf{opacity: 1
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-A9y3zc .VfPpkd-JGcpL-IdXvz-haAclf{-webkit-animation:mdc-circular-progress-container-rotate 1.5682352941176s linear infinite;animation:mdc-circular-progress-container-rotate 1.5682352941176s linear infinite
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-A9y3zc .VfPpkd-JGcpL-QYI5B-pbTTYe{-webkit-animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both;animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-A9y3zc .VfPpkd-JGcpL-Ydhldb-R6PoUb{-webkit-animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both,mdc-circular-progress-color-1-fade-in-out 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both;animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both,mdc-circular-progress-color-1-fade-in-out 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-A9y3zc .VfPpkd-JGcpL-Ydhldb-ibL1re{-webkit-animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both,mdc-circular-progress-color-2-fade-in-out 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both;animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both,mdc-circular-progress-color-2-fade-in-out 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-A9y3zc .VfPpkd-JGcpL-Ydhldb-c5RTEf{-webkit-animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both,mdc-circular-progress-color-3-fade-in-out 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both;animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both,mdc-circular-progress-color-3-fade-in-out 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-A9y3zc .VfPpkd-JGcpL-Ydhldb-II5mzb{-webkit-animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both,mdc-circular-progress-color-4-fade-in-out 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both;animation:mdc-circular-progress-spinner-layer-rotate 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both,mdc-circular-progress-color-4-fade-in-out 5332ms cubic-bezier(.4,
    0,.2,
    1) infinite both
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-A9y3zc .VfPpkd-JGcpL-lLvYUc-LK5yu .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{-webkit-animation:mdc-circular-progress-left-spin 1333ms cubic-bezier(.4,
    0,.2,
    1) infinite both;animation:mdc-circular-progress-left-spin 1333ms cubic-bezier(.4,
    0,.2,
    1) infinite both
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-A9y3zc .VfPpkd-JGcpL-lLvYUc-qwU8Me .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{-webkit-animation:mdc-circular-progress-right-spin 1333ms cubic-bezier(.4,
    0,.2,
    1) infinite both;animation:mdc-circular-progress-right-spin 1333ms cubic-bezier(.4,
    0,.2,
    1) infinite both
}.VfPpkd-JGcpL-P1ekSe-OWXEXe-xTMeO{opacity: 0
}.DU29of{position:relative
}.DU29of .VfPpkd-JGcpL-uI4vCe-LkdAo,.DU29of .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:#4285f4
}@media screen and (forced-colors:active),(-ms-high-contrast:active){.DU29of .VfPpkd-JGcpL-uI4vCe-LkdAo,.DU29of .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.DU29of .VfPpkd-JGcpL-Ydhldb-R6PoUb .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:#4285f4
}@media screen and (forced-colors:active),(-ms-high-contrast:active){.DU29of .VfPpkd-JGcpL-Ydhldb-R6PoUb .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.DU29of .VfPpkd-JGcpL-Ydhldb-ibL1re .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:#ea4335
}@media screen and (forced-colors:active),(-ms-high-contrast:active){.DU29of .VfPpkd-JGcpL-Ydhldb-ibL1re .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.DU29of .VfPpkd-JGcpL-Ydhldb-c5RTEf .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:#fbbc04
}@media screen and (forced-colors:active),(-ms-high-contrast:active){.DU29of .VfPpkd-JGcpL-Ydhldb-c5RTEf .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.DU29of .VfPpkd-JGcpL-Ydhldb-II5mzb .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:#34a853
}@media screen and (forced-colors:active),(-ms-high-contrast:active){.DU29of .VfPpkd-JGcpL-Ydhldb-II5mzb .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}.DU29of .VfPpkd-JGcpL-Mr8B3-V67aGc{height: 100%;width: 100%;position:absolute;opacity: 0;overflow:hidden;z-index: -1
}.VfPpkd-BFbNVe-bF1uUb{position:absolute;border-radius:inherit;pointer-events:none;opacity: 0;opacity:var(--mdc-elevation-overlay-opacity,
    0);-webkit-transition:opacity .28s cubic-bezier(.4,
    0,.2,
    1);transition:opacity .28s cubic-bezier(.4,
    0,.2,
    1);background-color:#fff;background-color:var(--mdc-elevation-overlay-color,#fff)
}.NZp2ef{background-color:#e8eaed
}html[dir=rtl
] .giSqbe{-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1)
}.VfPpkd-z59Tgd{border-radius: 4px;border-radius:var(--mdc-shape-small,
    4px)
}.VfPpkd-Djsh7e-XxIAqe-ma6Yeb,.VfPpkd-Djsh7e-XxIAqe-cGMI2b{border-radius: 4px;border-radius:var(--mdc-shape-small,
    4px)
}.VfPpkd-z59Tgd{color:white;color:var(--mdc-theme-text-primary-on-dark,white)
}.VfPpkd-z59Tgd{background-color:rgba(0,
    0,
    0,.6)
}.VfPpkd-MlC99b{color:rgba(0,
    0,
    0,.87);color:var(--mdc-theme-text-primary-on-light,rgba(0,
    0,
    0,.87))
}.VfPpkd-IqDDtd{color:rgba(0,
    0,
    0,.6)
}.VfPpkd-IqDDtd-hSRGPd{color:#6200ee;color:var(--mdc-theme-primary,#6200ee)
}.VfPpkd-a1tyJ-bN97Pc{overflow-x:unset;overflow-y:auto
}.VfPpkd-suEOdc.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd,.VfPpkd-suEOdc.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-ma6Yeb,.VfPpkd-suEOdc.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-cGMI2b{background-color:#fff
}.VfPpkd-z59Tgd{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-caption-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size:.75rem;font-size:var(--mdc-typography-caption-font-size,.75rem);font-weight: 400;font-weight:var(--mdc-typography-caption-font-weight,
    400);letter-spacing:.0333333333em;letter-spacing:var(--mdc-typography-caption-letter-spacing,.0333333333em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-caption-text-decoration,inherit);text-decoration:var(--mdc-typography-caption-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-caption-text-transform,inherit)
}.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd{-webkit-box-shadow: 0 3px 1px -2px rgba(0,
    0,
    0,.2),
    0 2px 2px 0 rgba(0,
    0,
    0,.14),
    0 1px 5px 0 rgba(0,
    0,
    0,.12);box-shadow: 0 3px 1px -2px rgba(0,
    0,
    0,.2),
    0 2px 2px 0 rgba(0,
    0,
    0,.14),
    0 1px 5px 0 rgba(0,
    0,
    0,.12);border-radius: 4px;line-height: 20px
}.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd .VfPpkd-BFbNVe-bF1uUb{width: 100%;height: 100%;top: 0;left: 0
}.VfPpkd-z59Tgd .VfPpkd-MlC99b{display:block;margin-top: 0;line-height: 20px;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-subtitle2-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size:.875rem;font-size:var(--mdc-typography-subtitle2-font-size,.875rem);line-height: 1.375rem;line-height:var(--mdc-typography-subtitle2-line-height,
    1.375rem);font-weight: 500;font-weight:var(--mdc-typography-subtitle2-font-weight,
    500);letter-spacing:.0071428571em;letter-spacing:var(--mdc-typography-subtitle2-letter-spacing,.0071428571em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-subtitle2-text-decoration,inherit);text-decoration:var(--mdc-typography-subtitle2-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-subtitle2-text-transform,inherit)
}.VfPpkd-z59Tgd .VfPpkd-MlC99b: :before{display:inline-block;width: 0;height: 24px;content: "";vertical-align: 0
}.VfPpkd-z59Tgd .VfPpkd-IqDDtd{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-body2-font-family,var(--mdc-typography-font-family,Roboto,sans-serif));font-size:.875rem;font-size:var(--mdc-typography-body2-font-size,.875rem);line-height: 1.25rem;line-height:var(--mdc-typography-body2-line-height,
    1.25rem);font-weight: 400;font-weight:var(--mdc-typography-body2-font-weight,
    400);letter-spacing:.0178571429em;letter-spacing:var(--mdc-typography-body2-letter-spacing,.0178571429em);text-decoration:inherit;-webkit-text-decoration:var(--mdc-typography-body2-text-decoration,inherit);text-decoration:var(--mdc-typography-body2-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-body2-text-transform,inherit)
}.VfPpkd-z59Tgd{word-break:break-all;word-break:var(--mdc-tooltip-word-break,normal);overflow-wrap:anywhere
}.VfPpkd-suEOdc-OWXEXe-eo9XGd-RCfa3e .VfPpkd-z59Tgd-OiiCO{-webkit-transition:opacity .15s 0ms cubic-bezier(0,
    0,.2,
    1),-webkit-transform .15s 0ms cubic-bezier(0,
    0,.2,
    1);transition:opacity .15s 0ms cubic-bezier(0,
    0,.2,
    1),-webkit-transform .15s 0ms cubic-bezier(0,
    0,.2,
    1);transition:opacity .15s 0ms cubic-bezier(0,
    0,.2,
    1),transform .15s 0ms cubic-bezier(0,
    0,.2,
    1);transition:opacity .15s 0ms cubic-bezier(0,
    0,.2,
    1),transform .15s 0ms cubic-bezier(0,
    0,.2,
    1),-webkit-transform .15s 0ms cubic-bezier(0,
    0,.2,
    1)
}.VfPpkd-suEOdc-OWXEXe-ZYIfFd-RCfa3e .VfPpkd-z59Tgd-OiiCO{-webkit-transition:opacity 75ms 0ms cubic-bezier(.4,
    0,
    1,
    1);transition:opacity 75ms 0ms cubic-bezier(.4,
    0,
    1,
    1)
}.VfPpkd-suEOdc{position:fixed;display:none;z-index: 9
}.VfPpkd-suEOdc-sM5MNb-OWXEXe-nzrxxc{position:relative
}.VfPpkd-suEOdc-OWXEXe-TSZdd,.VfPpkd-suEOdc-OWXEXe-eo9XGd,.VfPpkd-suEOdc-OWXEXe-ZYIfFd{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex
}.VfPpkd-suEOdc-OWXEXe-TSZdd.VfPpkd-suEOdc-OWXEXe-nzrxxc,.VfPpkd-suEOdc-OWXEXe-eo9XGd.VfPpkd-suEOdc-OWXEXe-nzrxxc,.VfPpkd-suEOdc-OWXEXe-ZYIfFd.VfPpkd-suEOdc-OWXEXe-nzrxxc{display:inline-block;left: -320px;position:absolute
}.VfPpkd-z59Tgd{line-height: 16px;padding: 4px 8px;min-width: 40px;max-width: 200px;min-height: 24px;max-height: 40vh;-webkit-box-sizing:border-box;box-sizing:border-box;overflow:hidden;text-align:center
}.VfPpkd-z59Tgd: :before{position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;width: 100%;height: 100%;top: 0;left: 0;border: 1px solid transparent;border-radius:inherit;content: "";pointer-events:none
}@media screen and (forced-colors:active){.VfPpkd-z59Tgd: :before{border-color:CanvasText
    }
}.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd{-webkit-box-align:start;-webkit-align-items:flex-start;align-items:flex-start;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;min-height: 24px;min-width: 40px;max-width: 320px;position:relative;text-align:left
}[dir=rtl
] .VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd,.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd[dir=rtl
]{text-align:right
}.VfPpkd-suEOdc-OWXEXe-LlMNQd .VfPpkd-z59Tgd{text-align:left
}[dir=rtl
] .VfPpkd-suEOdc-OWXEXe-LlMNQd .VfPpkd-z59Tgd,.VfPpkd-suEOdc-OWXEXe-LlMNQd .VfPpkd-z59Tgd[dir=rtl
]{text-align:right
}.VfPpkd-z59Tgd .VfPpkd-MlC99b{margin: 0 8px
}.VfPpkd-z59Tgd .VfPpkd-IqDDtd{max-width: 184px;margin: 8px
}.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd .VfPpkd-IqDDtd{max-width: 304px;-webkit-align-self:stretch;align-self:stretch
}.VfPpkd-z59Tgd .VfPpkd-IqDDtd-hSRGPd{text-decoration:none
}.VfPpkd-suEOdc-OWXEXe-nzrxxc-LQLjdd,.VfPpkd-IqDDtd,.VfPpkd-MlC99b{z-index: 1
}.VfPpkd-z59Tgd-OiiCO{opacity: 0;-webkit-transform:scale(.8);-ms-transform:scale(.8);transform:scale(.8);will-change:transform,opacity
}.VfPpkd-suEOdc-OWXEXe-TSZdd .VfPpkd-z59Tgd-OiiCO{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);opacity: 1
}.VfPpkd-suEOdc-OWXEXe-ZYIfFd .VfPpkd-z59Tgd-OiiCO{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)
}.VfPpkd-Djsh7e-XxIAqe-ma6Yeb,.VfPpkd-Djsh7e-XxIAqe-cGMI2b{position:absolute;height: 24px;width: 24px;-webkit-transform:rotate(35deg) skewY(20deg) scaleX(.9396926208);-ms-transform:rotate(35deg) skewY(20deg) scaleX(.9396926208);transform:rotate(35deg) skewY(20deg) scaleX(.9396926208)
}.VfPpkd-Djsh7e-XxIAqe-ma6Yeb .VfPpkd-BFbNVe-bF1uUb,.VfPpkd-Djsh7e-XxIAqe-cGMI2b .VfPpkd-BFbNVe-bF1uUb{width: 100%;height: 100%;top: 0;left: 0
}.VfPpkd-Djsh7e-XxIAqe-cGMI2b{-webkit-box-shadow: 0 3px 1px -2px rgba(0,
    0,
    0,.2),
    0 2px 2px 0 rgba(0,
    0,
    0,.14),
    0 1px 5px 0 rgba(0,
    0,
    0,.12);box-shadow: 0 3px 1px -2px rgba(0,
    0,
    0,.2),
    0 2px 2px 0 rgba(0,
    0,
    0,.14),
    0 1px 5px 0 rgba(0,
    0,
    0,.12);outline: 1px solid transparent;z-index: -1
}@media screen and (forced-colors:active){.VfPpkd-Djsh7e-XxIAqe-cGMI2b{outline-color:CanvasText
    }
}.EY8ABd{z-index: 2101
}.EY8ABd .VfPpkd-z59Tgd{background-color:#3c4043;color:#e8eaed
}.EY8ABd .VfPpkd-MlC99b,.EY8ABd .VfPpkd-IqDDtd{color:#3c4043
}.EY8ABd .VfPpkd-IqDDtd-hSRGPd{color:#1a73e8
}.EY8ABd.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd,.EY8ABd.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-ma6Yeb,.EY8ABd.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-cGMI2b{background-color:#fff
}.EY8ABd.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-MlC99b{font-family: "Google Sans",Roboto,Arial,sans-serif;line-height: 1.25rem;font-size:.875rem;letter-spacing:.0178571429em;font-weight: 500
}.EY8ABd.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd{-webkit-border-radius: 8px;-moz-border-radius: 8px;border-radius: 8px
}.ziykHb{z-index: 2101
}.ziykHb .VfPpkd-z59Tgd{background-color:#3c4043;color:#e8eaed
}.ziykHb .VfPpkd-MlC99b,.ziykHb .VfPpkd-IqDDtd{color:#3c4043
}.ziykHb .VfPpkd-IqDDtd-hSRGPd{color:#1a73e8
}.ziykHb.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd,.ziykHb.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-ma6Yeb,.ziykHb.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-cGMI2b{background-color:#fff
}.ziykHb.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-MlC99b{font-family: "Google Sans",Roboto,Arial,sans-serif;line-height: 1.25rem;font-size:.875rem;letter-spacing:.0178571429em;font-weight: 500
}.ziykHb.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd{-webkit-border-radius: 8px;-moz-border-radius: 8px;border-radius: 8px
}.EY8ABd-OWXEXe-TAWMXe{position:absolute;left: -10000px;top:auto;width: 1px;height: 1px;overflow:hidden;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none
}.NMm5M{fill:currentColor;-webkit-flex-shrink: 0;flex-shrink: 0
}html[dir=rtl
] .hhikbc{-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1)
}.PrDSKc,.v42QC{padding-bottom: 3px;padding-top: 9px
}.v42QC{margin: 0
}.PrDSKc:empty,.v42QC:empty{display:none
}.TyDcZc,.jC5pMd{padding-bottom: 3px;padding-top: 9px
}.jC5pMd{margin: 0
}.TyDcZc:empty,.jC5pMd:empty{display:none
}.iHd3uf{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex
}.iHd3uf.eLNT1d{display:none
}.ceOhk{--gm3-button-filled-container-height: 40px;--gm3-button-filled-container-shape: 20px;--gm3-button-filled-label-text-weight:var(--c-afwt,
    500)
}.WyRBD{--gm3-button-outlined-container-height: 40px;--gm3-button-outlined-label-text-weight:var(--c-afwt,
    500);--gm3-button-outlined-container-shape: 20px
}.Xq56fd{--gm3-button-text-container-height: 40px;--gm3-button-text-container-shape: 20px;--gm3-button-text-label-text-weight:var(--c-afwt,
    500)
}.hy0HVb{--gm3-button-filled-tonal-container-height: 40px;--gm3-button-filled-tonal-container-shape: 20px;--gm3-button-filled-tonal-label-text-weight:var(--c-afwt,
    500)
}.SXdXAb-BFbNVe,.SXdXAb-ugnUJb,.SXdXAb-BFbNVe: :before,.SXdXAb-BFbNVe: :after{border-radius:inherit;inset: 0;position:absolute;pointer-events:none
}.SXdXAb-ugnUJb{-webkit-transition: 75ms opacity linear;transition: 75ms opacity linear;background-color:var(--gm3-elevation-surface-tint-layer-color,transparent);opacity:calc(clamp(0, var(--gm3-elevation-level,
    0), .05) + clamp(0, var(--gm3-elevation-level,
    0) - 1, .03) + clamp(0, var(--gm3-elevation-level,
    0) - 2, .03) + clamp(0, var(--gm3-elevation-level,
    0) - 3, .01) + clamp(0, var(--gm3-elevation-level,
    0) - 4, .02))
}.SXdXAb-BFbNVe: :before,.SXdXAb-BFbNVe: :after{-webkit-transition: 75ms -webkit-box-shadow linear;transition: 75ms -webkit-box-shadow linear;transition: 75ms box-shadow linear;transition: 75ms box-shadow linear,
    75ms -webkit-box-shadow linear;content: ""
}.SXdXAb-BFbNVe: :before{-webkit-box-shadow: 0 calc(1px*(clamp(0, var(--gm3-elevation-level,
    0),
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 3,
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 4,
    1)*2)) calc(1px*(2*clamp(0, var(--gm3-elevation-level,
    0),
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 2,
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 4,
    1))) 0 var(--gm3-elevation-shadow-color,transparent);box-shadow: 0 calc(1px*(clamp(0, var(--gm3-elevation-level,
    0),
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 3,
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 4,
    1)*2)) calc(1px*(2*clamp(0, var(--gm3-elevation-level,
    0),
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 2,
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 4,
    1))) 0 var(--gm3-elevation-shadow-color,transparent);opacity:calc(clamp(0, var(--gm3-elevation-level,
    0),
    1)*.3)
}.SXdXAb-BFbNVe: :after{-webkit-box-shadow: 0 calc(1px*(clamp(0, var(--gm3-elevation-level,
    0),
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 1,
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 2,
    3)*2)) calc(1px*(clamp(0, var(--gm3-elevation-level,
    0),
    2)*3 + clamp(0, var(--gm3-elevation-level,
    0) - 2,
    3)*2)) calc(1px*(clamp(0, var(--gm3-elevation-level,
    0),
    4) + 2*clamp(0, var(--gm3-elevation-level,
    0) - 4,
    1))) var(--gm3-elevation-shadow-color,transparent);box-shadow: 0 calc(1px*(clamp(0, var(--gm3-elevation-level,
    0),
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 1,
    1) + clamp(0, var(--gm3-elevation-level,
    0) - 2,
    3)*2)) calc(1px*(clamp(0, var(--gm3-elevation-level,
    0),
    2)*3 + clamp(0, var(--gm3-elevation-level,
    0) - 2,
    3)*2)) calc(1px*(clamp(0, var(--gm3-elevation-level,
    0),
    4) + 2*clamp(0, var(--gm3-elevation-level,
    0) - 4,
    1))) var(--gm3-elevation-shadow-color,transparent);opacity:calc(clamp(0, var(--gm3-elevation-level,
    0),
    1)*.15)
}@media (forced-colors:active){.SXdXAb-BFbNVe{display:none
    }
}.OiePBf-zPjgPe{display:var(--gm3-focus-ring-outward-display,none);pointer-events:none;position:absolute;z-index: 1;border-start-start-radius:calc(var(--gm3-focus-ring-outward-target-shape-start-start,
    0px) + var(--gm3-focus-ring-outward-offset,
    2px));border-start-end-radius:calc(var(--gm3-focus-ring-outward-target-shape-start-end,
    0px) + var(--gm3-focus-ring-outward-offset,
    2px));border-end-end-radius:calc(var(--gm3-focus-ring-outward-target-shape-end-end,
    0px) + var(--gm3-focus-ring-outward-offset,
    2px));border-end-start-radius:calc(var(--gm3-focus-ring-outward-target-shape-end-start,
    0px) + var(--gm3-focus-ring-outward-offset,
    2px));inset:calc(var(--gm3-focus-ring-outward-offset,
    2px)*-1);-webkit-box-shadow: 0 0 0 var(--gm3-focus-ring-outward-track-width,
    3px) var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b));box-shadow: 0 0 0 var(--gm3-focus-ring-outward-track-width,
    3px) var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b));outline:var(--gm3-focus-ring-outward-track-width,
    3px) solid transparent;-webkit-animation-name:gm3-focus-ring-outward-grows,gm3-focus-ring-outward-shrinks;animation-name:gm3-focus-ring-outward-grows,gm3-focus-ring-outward-shrinks;-webkit-animation-duration:.15s,.45s;animation-duration:.15s,.45s;-webkit-animation-delay: 0s,.15s;animation-delay: 0s,.15s;-webkit-animation-timing-function:cubic-bezier(.2,
    0,
    0,
    1),cubic-bezier(.2,
    0,
    0,
    1);animation-timing-function:cubic-bezier(.2,
    0,
    0,
    1),cubic-bezier(.2,
    0,
    0,
    1)
}@-webkit-keyframes gm3-focus-ring-outward-grows{from{-webkit-box-shadow: 0 0 0 0 var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b));box-shadow: 0 0 0 0 var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b))
    }to{-webkit-box-shadow: 0 0 0 8px var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b));box-shadow: 0 0 0 8px var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b))
    }
}@keyframes gm3-focus-ring-outward-grows{from{-webkit-box-shadow: 0 0 0 0 var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b));box-shadow: 0 0 0 0 var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b))
    }to{-webkit-box-shadow: 0 0 0 8px var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b));box-shadow: 0 0 0 8px var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b))
    }
}@-webkit-keyframes gm3-focus-ring-outward-shrinks{from{-webkit-box-shadow: 0 0 0 8px var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b));box-shadow: 0 0 0 8px var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b))
    }
}@keyframes gm3-focus-ring-outward-shrinks{from{-webkit-box-shadow: 0 0 0 8px var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b));box-shadow: 0 0 0 8px var(--gm3-focus-ring-outward-color,var(--gm3-sys-color-secondary,#00639b))
    }
}@media (prefers-reduced-motion){.OiePBf-zPjgPe{-webkit-animation:none;animation:none
    }
}.RBHQF-ksKsZd{overflow:hidden;outline:none;-webkit-tap-highlight-color:transparent
}.RBHQF-ksKsZd,.RBHQF-ksKsZd: :before,.RBHQF-ksKsZd: :after{position:absolute;pointer-events:none;top: 0;left: 0;width: 100%;height: 100%;border-start-start-radius:var(--gm3-ripple-shape-start-start,inherit);border-start-end-radius:var(--gm3-ripple-shape-start-end,inherit);border-end-start-radius:var(--gm3-ripple-shape-end-start,inherit);border-end-end-radius:var(--gm3-ripple-shape-end-end,inherit)
}.RBHQF-ksKsZd: :before,.RBHQF-ksKsZd: :after{opacity: 0;content: ""
}.RBHQF-ksKsZd: :before{-webkit-transition:opacity 75ms linear,border-radius var(--gm3-ripple-border-radius-transition-duration,
    0ms) linear;transition:opacity 75ms linear,border-radius var(--gm3-ripple-border-radius-transition-duration,
    0ms) linear;background-color:var(--gm3-ripple-hover-color,transparent)
}.RBHQF-ksKsZd-OWXEXe-ZmdkE: :before{opacity:var(--gm3-ripple-hover-opacity,
    0)
}.RBHQF-ksKsZd: :after{opacity: 0;background:-webkit-radial-gradient(closest-side,var(--gm3-ripple-pressed-color,transparent) max(100% - 70px,
    65%),transparent 100%);background:radial-gradient(closest-side,var(--gm3-ripple-pressed-color,transparent) max(100% - 70px,
    65%),transparent 100%);-webkit-transition:opacity .25s linear,border-radius var(--gm3-ripple-border-radius-transition-duration,
    0ms) linear;transition:opacity .25s linear,border-radius var(--gm3-ripple-border-radius-transition-duration,
    0ms) linear;-webkit-transform-origin:center center;-ms-transform-origin:center center;transform-origin:center center
}.RBHQF-ksKsZd-OWXEXe-QDgCrf: :after{-webkit-transition-duration: 105ms;transition-duration: 105ms;opacity:var(--gm3-ripple-pressed-opacity,
    0)
}@media (forced-colors:active){.RBHQF-ksKsZd{display:none
    }
}.UywwFc-LgbsSe{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-box-sizing:border-box;box-sizing:border-box;border:none;outline:none;background:transparent;-webkit-appearance:none;-moz-appearance:none;appearance:none;line-height:inherit;text-rendering:inherit;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;vertical-align:middle;cursor:pointer;min-inline-size:var(--gm3-button-filled-container-min-width,
    64px);padding-block: 0;-webkit-padding-start:var(--gm3-button-filled-leading-space,
    24px);padding-inline-start:var(--gm3-button-filled-leading-space,
    24px);-webkit-padding-end:var(--gm3-button-filled-trailing-space,
    24px);padding-inline-end:var(--gm3-button-filled-trailing-space,
    24px);block-size:var(--gm3-button-filled-container-height,
    40px);border-radius:var(--gm3-button-filled-container-shape,
    9999px);--gm3-ripple-hover-color:var(--gm3-button-filled-hover-state-layer-color,var(--gm3-sys-color-on-primary,#fff));--gm3-ripple-hover-opacity:var(--gm3-button-filled-hover-state-layer-opacity,
    0.08);--gm3-ripple-pressed-color:var(--gm3-button-filled-hover-state-layer-color,var(--gm3-sys-color-on-primary,#fff));--gm3-ripple-pressed-opacity:var(--gm3-button-filled-pressed-state-layer-opacity,
    0.1);--gm3-focus-ring-outward-color:var(--gm3-button-filled-focus-indicator-color,var(--gm3-sys-color-secondary,#00639b));--gm3-focus-ring-outward-offset:var(--gm3-button-filled-focus-indicator-outline-offset,
    2px);--gm3-focus-ring-outward-track-width:var(--gm3-button-filled-focus-indicator-thickness,
    3px);--gm3-focus-ring-outward-target-shape-start-start:var(--gm3-button-filled-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-start-end:var(--gm3-button-filled-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-end-end:var(--gm3-button-filled-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-end-start:var(--gm3-button-filled-container-shape,
    9999px)
}.UywwFc-mRLv6:focus-visible{outline:none
}.UywwFc-LgbsSe:focus-visible,.UywwFc-mRLv6:focus-visible~.UywwFc-UHGRz{--gm3-focus-ring-outward-display:block
}.UywwFc-LgbsSe:disabled{cursor:default;pointer-events:none;--gm3-ripple-hover-opacity: 0;--gm3-ripple-pressed-opacity: 0
}.UywwFc-LgbsSe-OWXEXe-SfQLQb-suEOdc:disabled{pointer-events:auto
}.UywwFc-LgbsSe[hidden
]{display:none
}.UywwFc-vQzf8d{position:relative;text-align:center;color:var(--gm3-button-filled-label-text-color,var(--gm3-sys-color-on-primary,#fff));font-size:var(--gm3-button-filled-label-text-size,.875rem);font-family:var(--gm3-button-filled-label-text-font,
    "Google Sans",Roboto,Arial,sans-serif);font-weight:var(--gm3-button-filled-label-text-weight,
    500);letter-spacing:var(--gm3-button-filled-label-text-tracking,
    0)
}.UywwFc-LgbsSe:hover .UywwFc-vQzf8d{color:var(--gm3-button-filled-hover-label-text-color,var(--gm3-sys-color-on-primary,#fff))
}.UywwFc-LgbsSe:focus-visible .UywwFc-vQzf8d{color:var(--gm3-button-filled-focus-label-text-color,var(--gm3-sys-color-on-primary,#fff))
}.UywwFc-LgbsSe:active .UywwFc-vQzf8d{color:var(--gm3-button-filled-pressed-label-text-color,var(--gm3-sys-color-on-primary,#fff))
}.UywwFc-LgbsSe:disabled .UywwFc-vQzf8d{color:var(--gm3-button-filled-disabled-label-text-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.38))
}.UywwFc-LgbsSe-OWXEXe-zcdHbf .UywwFc-vQzf8d{white-space:nowrap;text-overflow:ellipsis;overflow:hidden
}.UywwFc-LgbsSe-OWXEXe-Bz112c-M1Soyc{-webkit-padding-start:var(--gm3-button-filled-with-leading-icon-leading-space,
    16px);padding-inline-start:var(--gm3-button-filled-with-leading-icon-leading-space,
    16px);-webkit-padding-end:var(--gm3-button-filled-with-leading-icon-trailing-space,
    24px);padding-inline-end:var(--gm3-button-filled-with-leading-icon-trailing-space,
    24px)
}.UywwFc-LgbsSe-OWXEXe-Bz112c-M1Soyc .UywwFc-kBDsod-Rtc0Jf :is(i,img,svg){-webkit-margin-end:var(--gm3-button-filled-with-icon-icon-label-space,
    8px);margin-inline-end:var(--gm3-button-filled-with-icon-icon-label-space,
    8px)
}.UywwFc-LgbsSe-OWXEXe-Bz112c-UbuQg{-webkit-padding-start:var(--gm3-button-filled-with-trailing-icon-leading-space,
    24px);padding-inline-start:var(--gm3-button-filled-with-trailing-icon-leading-space,
    24px);-webkit-padding-end:var(--gm3-button-filled-with-trailing-icon-trailing-space,
    16px);padding-inline-end:var(--gm3-button-filled-with-trailing-icon-trailing-space,
    16px)
}.UywwFc-LgbsSe-OWXEXe-Bz112c-UbuQg .UywwFc-kBDsod-Rtc0Jf :is(i,img,svg){-webkit-margin-start:var(--gm3-button-filled-with-icon-icon-label-space,
    8px);margin-inline-start:var(--gm3-button-filled-with-icon-icon-label-space,
    8px)
}.UywwFc-kBDsod-Rtc0Jf{display:none;position:relative;line-height: 0;color:var(--gm3-button-filled-with-icon-icon-color,var(--gm3-sys-color-on-primary,#fff))
}.UywwFc-kBDsod-Rtc0Jf i,.UywwFc-kBDsod-Rtc0Jf img,.UywwFc-kBDsod-Rtc0Jf svg{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative;direction:inherit;color:inherit;font-size:var(--gm3-button-filled-with-icon-icon-size,
    18px);inline-size:var(--gm3-button-filled-with-icon-icon-size,
    18px);block-size:var(--gm3-button-filled-with-icon-icon-size,
    18px)
}.UywwFc-LgbsSe:hover .UywwFc-kBDsod-Rtc0Jf{color:var(--gm3-button-filled-with-icon-hover-icon-color,var(--gm3-sys-color-on-primary,#fff))
}.UywwFc-LgbsSe:focus-visible .UywwFc-kBDsod-Rtc0Jf{color:var(--gm3-button-filled-with-icon-focus-icon-color,var(--gm3-sys-color-on-primary,#fff))
}.UywwFc-LgbsSe:active .UywwFc-kBDsod-Rtc0Jf{color:var(--gm3-button-filled-with-icon-pressed-icon-color,var(--gm3-sys-color-on-primary,#fff))
}.UywwFc-LgbsSe:disabled .UywwFc-kBDsod-Rtc0Jf{color:var(--gm3-button-filled-with-icon-disabled-icon-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.38))
}[dir=rtl
] .UywwFc-LgbsSe-OWXEXe-drxrmf-Bz112c .UywwFc-kBDsod-Rtc0Jf,.UywwFc-LgbsSe-OWXEXe-drxrmf-Bz112c .UywwFc-kBDsod-Rtc0Jf[dir=rtl
]{-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1)
}.UywwFc-LgbsSe-OWXEXe-Bz112c-M1Soyc .UywwFc-kBDsod-Rtc0Jf-OWXEXe-M1Soyc,.UywwFc-LgbsSe-OWXEXe-Bz112c-UbuQg .UywwFc-kBDsod-Rtc0Jf-OWXEXe-UbuQg{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex
}.UywwFc-mRLv6{position:absolute;inset: 0
}.UywwFc-LgbsSe-OWXEXe-dgl2Hf{margin-block:max((48px - var(--gm3-button-filled-container-height,
    40px))/2,
    0px)
}.UywwFc-RLmnJb{position:absolute;inline-size:max(48px,
    100%);block-size:max(48px,
    100%);inset:unset;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%)
}.UywwFc-LgbsSe{will-change:transform,opacity;background-color:var(--gm3-button-filled-container-color,var(--gm3-sys-color-primary,#0b57d0));--gm3-elevation-level:var(--gm3-button-filled-container-elevation,
    0);--gm3-elevation-shadow-color:var(--gm3-button-filled-container-shadow-color,var(--gm3-sys-color-shadow,#000))
}.UywwFc-LgbsSe:hover{--gm3-elevation-level:var(--gm3-button-filled-hover-container-elevation,
    1)
}.UywwFc-LgbsSe:focus-visible{--gm3-elevation-level:var(--gm3-button-filled-focus-container-elevation,
    0)
}.UywwFc-LgbsSe:active{--gm3-elevation-level:var(--gm3-button-filled-pressed-container-elevation,
    0)
}.UywwFc-LgbsSe:disabled{background-color:var(--gm3-button-filled-disabled-container-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.12));--gm3-elevation-level:var(--gm3-button-filled-disabled-container-elevation,
    0)
}.UywwFc-LgbsSe: :before{content: "";pointer-events:none;position:absolute;inset: 0;border-radius:inherit;border: 1px solid transparent
}@media (forced-colors:active){.UywwFc-LgbsSe: :before{border-color:CanvasText
    }
}.ne2Ple-suEOdc{position:fixed;display:none;z-index:var(--gm3-tooltip-plain-z-index,
    2101)
}.ne2Ple-z59Tgd{-webkit-box-sizing:border-box;box-sizing:border-box;min-block-size: 24px;min-inline-size: 40px;overflow-wrap:anywhere;overflow:hidden;padding-block: 4px;padding-inline: 8px;word-break:normal;max-block-size:var(--gm3-tooltip-plain-container-max-block-size,
    40vh)
}.ne2Ple-z59Tgd: :before{position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;inline-size: 100%;block-size: 100%;inset-block-start: 0;inset-inline-start: 0;border: 1px solid transparent;border-radius:inherit;content: "";pointer-events:none
}.ne2Ple-suEOdc-OWXEXe-TSZdd,.ne2Ple-suEOdc-OWXEXe-eo9XGd,.ne2Ple-suEOdc-OWXEXe-ZYIfFd{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex
}.ne2Ple-z59Tgd-OiiCO{opacity: 0;-webkit-transform:scale(.8);-ms-transform:scale(.8);transform:scale(.8);will-change:transform,opacity
}.ne2Ple-suEOdc-OWXEXe-TSZdd .ne2Ple-z59Tgd-OiiCO{opacity: 1;-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)
}.ne2Ple-suEOdc-OWXEXe-ZYIfFd .ne2Ple-z59Tgd-OiiCO{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)
}.ne2Ple-suEOdc-OWXEXe-eo9XGd-RCfa3e .ne2Ple-z59Tgd-OiiCO{-webkit-transition:opacity .15s 0ms cubic-bezier(0,
    0,.2,
    1),-webkit-transform .15s 0ms cubic-bezier(0,
    0,.2,
    1);transition:opacity .15s 0ms cubic-bezier(0,
    0,.2,
    1),-webkit-transform .15s 0ms cubic-bezier(0,
    0,.2,
    1);transition:opacity .15s 0ms cubic-bezier(0,
    0,.2,
    1),transform .15s 0ms cubic-bezier(0,
    0,.2,
    1);transition:opacity .15s 0ms cubic-bezier(0,
    0,.2,
    1),transform .15s 0ms cubic-bezier(0,
    0,.2,
    1),-webkit-transform .15s 0ms cubic-bezier(0,
    0,.2,
    1)
}.ne2Ple-suEOdc-OWXEXe-ZYIfFd-RCfa3e .ne2Ple-z59Tgd-OiiCO{-webkit-transition:opacity 75ms 0ms cubic-bezier(.4,
    0,
    1,
    1);transition:opacity 75ms 0ms cubic-bezier(.4,
    0,
    1,
    1)
}.ne2Ple-suEOdc-OWXEXe-pijamc .ne2Ple-z59Tgd{max-inline-size: 200px;background-color:var(--gm3-tooltip-plain-container-color,var(--gm3-sys-color-inverse-surface,#303030));border-radius:var(--gm3-tooltip-plain-container-shape,
    4px);color:var(--gm3-tooltip-plain-supporting-text-color,var(--gm3-sys-color-inverse-on-surface,#f2f2f2));font-family:var(--gm3-tooltip-plain-supporting-text-font,
    "Google Sans Text",
    "Google Sans");font-size:var(--gm3-tooltip-plain-supporting-text-size,.75rem);font-weight:var(--gm3-tooltip-plain-supporting-text-weight,
    400);letter-spacing:var(--gm3-tooltip-plain-supporting-text-tracking,.00625rem);line-height:var(--gm3-tooltip-plain-supporting-text-line-height,
    1rem);text-align:center
}.ne2Ple-suEOdc-OWXEXe-LlMNQd .ne2Ple-z59Tgd{text-align:start
}.ne2Ple-oshW8e-V67aGc{position:absolute;left: -10000px;top:auto;inline-size: 1px;height: 1px;overflow:hidden;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none
}.AeBiU-LgbsSe{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-box-sizing:border-box;box-sizing:border-box;border:none;outline:none;background:transparent;-webkit-appearance:none;-moz-appearance:none;appearance:none;line-height:inherit;text-rendering:inherit;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;vertical-align:middle;cursor:pointer;min-inline-size:var(--gm3-button-outlined-container-min-width,
    64px);padding-block: 0;-webkit-padding-start:var(--gm3-button-outlined-leading-space,
    24px);padding-inline-start:var(--gm3-button-outlined-leading-space,
    24px);-webkit-padding-end:var(--gm3-button-outlined-trailing-space,
    24px);padding-inline-end:var(--gm3-button-outlined-trailing-space,
    24px);block-size:var(--gm3-button-outlined-container-height,
    40px);border-radius:var(--gm3-button-outlined-container-shape,
    9999px);--gm3-ripple-hover-color:var(--gm3-button-outlined-hover-state-layer-color,var(--gm3-sys-color-primary,#0b57d0));--gm3-ripple-hover-opacity:var(--gm3-button-outlined-hover-state-layer-opacity,
    0.08);--gm3-ripple-pressed-color:var(--gm3-button-outlined-hover-state-layer-color,var(--gm3-sys-color-primary,#0b57d0));--gm3-ripple-pressed-opacity:var(--gm3-button-outlined-pressed-state-layer-opacity,
    0.1);--gm3-focus-ring-outward-color:var(--gm3-button-outlined-focus-indicator-color,var(--gm3-sys-color-secondary,#00639b));--gm3-focus-ring-outward-offset:var(--gm3-button-outlined-focus-indicator-outline-offset,
    2px);--gm3-focus-ring-outward-track-width:var(--gm3-button-outlined-focus-indicator-thickness,
    3px);--gm3-focus-ring-outward-target-shape-start-start:var(--gm3-button-outlined-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-start-end:var(--gm3-button-outlined-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-end-end:var(--gm3-button-outlined-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-end-start:var(--gm3-button-outlined-container-shape,
    9999px)
}.AeBiU-mRLv6:focus-visible{outline:none
}.AeBiU-LgbsSe:focus-visible,.AeBiU-mRLv6:focus-visible~.AeBiU-UHGRz{--gm3-focus-ring-outward-display:block
}.AeBiU-LgbsSe:disabled{cursor:default;pointer-events:none;--gm3-ripple-hover-opacity: 0;--gm3-ripple-pressed-opacity: 0
}.AeBiU-LgbsSe-OWXEXe-SfQLQb-suEOdc:disabled{pointer-events:auto
}.AeBiU-LgbsSe[hidden
]{display:none
}.AeBiU-vQzf8d{position:relative;text-align:center;color:var(--gm3-button-outlined-label-text-color,var(--gm3-sys-color-primary,#0b57d0));font-size:var(--gm3-button-outlined-label-text-size,.875rem);font-family:var(--gm3-button-outlined-label-text-font,
    "Google Sans",Roboto,Arial,sans-serif);font-weight:var(--gm3-button-outlined-label-text-weight,
    500);letter-spacing:var(--gm3-button-outlined-label-text-tracking,
    0)
}.AeBiU-LgbsSe:hover .AeBiU-vQzf8d{color:var(--gm3-button-outlined-hover-label-text-color,var(--gm3-sys-color-primary,#0b57d0))
}.AeBiU-LgbsSe:focus-visible .AeBiU-vQzf8d{color:var(--gm3-button-outlined-focus-label-text-color,var(--gm3-sys-color-primary,#0b57d0))
}.AeBiU-LgbsSe:active .AeBiU-vQzf8d{color:var(--gm3-button-outlined-pressed-label-text-color,var(--gm3-sys-color-primary,#0b57d0))
}.AeBiU-LgbsSe:disabled .AeBiU-vQzf8d{color:var(--gm3-button-outlined-disabled-label-text-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.38))
}.AeBiU-LgbsSe-OWXEXe-zcdHbf .AeBiU-vQzf8d{white-space:nowrap;text-overflow:ellipsis;overflow:hidden
}.AeBiU-LgbsSe-OWXEXe-Bz112c-M1Soyc{-webkit-padding-start:var(--gm3-button-outlined-with-leading-icon-leading-space,
    16px);padding-inline-start:var(--gm3-button-outlined-with-leading-icon-leading-space,
    16px);-webkit-padding-end:var(--gm3-button-outlined-with-leading-icon-trailing-space,
    24px);padding-inline-end:var(--gm3-button-outlined-with-leading-icon-trailing-space,
    24px)
}.AeBiU-LgbsSe-OWXEXe-Bz112c-M1Soyc .AeBiU-kBDsod-Rtc0Jf :is(i,img,svg){-webkit-margin-end:var(--gm3-button-outlined-with-icon-icon-label-space,
    8px);margin-inline-end:var(--gm3-button-outlined-with-icon-icon-label-space,
    8px)
}.AeBiU-LgbsSe-OWXEXe-Bz112c-UbuQg{-webkit-padding-start:var(--gm3-button-outlined-with-trailing-icon-leading-space,
    24px);padding-inline-start:var(--gm3-button-outlined-with-trailing-icon-leading-space,
    24px);-webkit-padding-end:var(--gm3-button-outlined-with-trailing-icon-trailing-space,
    16px);padding-inline-end:var(--gm3-button-outlined-with-trailing-icon-trailing-space,
    16px)
}.AeBiU-LgbsSe-OWXEXe-Bz112c-UbuQg .AeBiU-kBDsod-Rtc0Jf :is(i,img,svg){-webkit-margin-start:var(--gm3-button-outlined-with-icon-icon-label-space,
    8px);margin-inline-start:var(--gm3-button-outlined-with-icon-icon-label-space,
    8px)
}.AeBiU-kBDsod-Rtc0Jf{display:none;position:relative;line-height: 0;color:var(--gm3-button-outlined-with-icon-icon-color,var(--gm3-sys-color-primary,#0b57d0))
}.AeBiU-kBDsod-Rtc0Jf i,.AeBiU-kBDsod-Rtc0Jf img,.AeBiU-kBDsod-Rtc0Jf svg{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative;direction:inherit;color:inherit;font-size:var(--gm3-button-outlined-with-icon-icon-size,
    18px);inline-size:var(--gm3-button-outlined-with-icon-icon-size,
    18px);block-size:var(--gm3-button-outlined-with-icon-icon-size,
    18px)
}.AeBiU-LgbsSe:hover .AeBiU-kBDsod-Rtc0Jf{color:var(--gm3-button-outlined-with-icon-hover-icon-color,var(--gm3-sys-color-primary,#0b57d0))
}.AeBiU-LgbsSe:focus-visible .AeBiU-kBDsod-Rtc0Jf{color:var(--gm3-button-outlined-with-icon-focus-icon-color,var(--gm3-sys-color-primary,#0b57d0))
}.AeBiU-LgbsSe:active .AeBiU-kBDsod-Rtc0Jf{color:var(--gm3-button-outlined-with-icon-pressed-icon-color,var(--gm3-sys-color-primary,#0b57d0))
}.AeBiU-LgbsSe:disabled .AeBiU-kBDsod-Rtc0Jf{color:var(--gm3-button-outlined-with-icon-disabled-icon-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.38))
}[dir=rtl
] .AeBiU-LgbsSe-OWXEXe-drxrmf-Bz112c .AeBiU-kBDsod-Rtc0Jf,.AeBiU-LgbsSe-OWXEXe-drxrmf-Bz112c .AeBiU-kBDsod-Rtc0Jf[dir=rtl
]{-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1)
}.AeBiU-LgbsSe-OWXEXe-Bz112c-M1Soyc .AeBiU-kBDsod-Rtc0Jf-OWXEXe-M1Soyc,.AeBiU-LgbsSe-OWXEXe-Bz112c-UbuQg .AeBiU-kBDsod-Rtc0Jf-OWXEXe-UbuQg{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex
}.AeBiU-mRLv6{position:absolute;inset: 0
}.AeBiU-LgbsSe-OWXEXe-dgl2Hf{margin-block:max((48px - var(--gm3-button-outlined-container-height,
    40px))/2,
    0px)
}.AeBiU-RLmnJb{position:absolute;inline-size:max(48px,
    100%);block-size:max(48px,
    100%);inset:unset;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%)
}.AeBiU-LgbsSe{border-style:solid;border-width:var(--gm3-button-outlined-outline-width,
    1px);border-color:var(--gm3-button-outlined-outline-color,var(--gm3-sys-color-outline,#747775));--gm3-focus-ring-outward-offset: 3px;--gm3-focus-ring-outward-target-shape-start-start:calc(var(--gm3-button-outlined-container-shape,
    9999px) - var(--gm3-button-outlined-outline-width,
    1px));--gm3-focus-ring-outward-target-shape-start-end:calc(var(--gm3-button-outlined-container-shape,
    9999px) - var(--gm3-button-outlined-outline-width,
    1px));--gm3-focus-ring-outward-target-shape-end-end:calc(var(--gm3-button-outlined-container-shape,
    9999px) - var(--gm3-button-outlined-outline-width,
    1px));--gm3-focus-ring-outward-target-shape-end-start:calc(var(--gm3-button-outlined-container-shape,
    9999px) - var(--gm3-button-outlined-outline-width,
    1px))
}.AeBiU-LgbsSe:hover{border-color:var(--gm3-button-outlined-hover-outline-color,var(--gm3-sys-color-outline,#747775))
}.AeBiU-LgbsSe:focus-visible{border-color:var(--gm3-button-outlined-focus-outline-color,var(--gm3-sys-color-primary,#0b57d0))
}.AeBiU-LgbsSe:active{border-color:var(--gm3-button-outlined-pressed-outline-color,var(--gm3-sys-color-outline,#747775))
}.AeBiU-LgbsSe:disabled{border-color:var(--gm3-button-outlined-disabled-outline-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.12))
}@media (forced-colors:active){.AeBiU-LgbsSe:disabled{border-color:GrayText
    }
}.AeBiU-RLmnJb{inline-size:max(48px,
    100% + var(--gm3-button-outlined-outline-width,
    1px) * 2)
}.mUIrbf-LgbsSe{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-box-sizing:border-box;box-sizing:border-box;border:none;outline:none;background:transparent;-webkit-appearance:none;-moz-appearance:none;appearance:none;line-height:inherit;text-rendering:inherit;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;vertical-align:middle;cursor:pointer;min-inline-size:var(--gm3-button-text-container-min-width,
    64px);padding-block: 0;-webkit-padding-start:var(--gm3-button-text-leading-space,
    12px);padding-inline-start:var(--gm3-button-text-leading-space,
    12px);-webkit-padding-end:var(--gm3-button-text-trailing-space,
    12px);padding-inline-end:var(--gm3-button-text-trailing-space,
    12px);block-size:var(--gm3-button-text-container-height,
    40px);border-radius:var(--gm3-button-text-container-shape,
    9999px);--gm3-ripple-hover-color:var(--gm3-button-text-hover-state-layer-color,var(--gm3-sys-color-primary,#0b57d0));--gm3-ripple-hover-opacity:var(--gm3-button-text-hover-state-layer-opacity,
    0.08);--gm3-ripple-pressed-color:var(--gm3-button-text-hover-state-layer-color,var(--gm3-sys-color-primary,#0b57d0));--gm3-ripple-pressed-opacity:var(--gm3-button-text-pressed-state-layer-opacity,
    0.1);--gm3-focus-ring-outward-color:var(--gm3-button-text-focus-indicator-color,var(--gm3-sys-color-secondary,#00639b));--gm3-focus-ring-outward-offset:var(--gm3-button-text-focus-indicator-outline-offset,
    2px);--gm3-focus-ring-outward-track-width:var(--gm3-button-text-focus-indicator-thickness,
    3px);--gm3-focus-ring-outward-target-shape-start-start:var(--gm3-button-text-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-start-end:var(--gm3-button-text-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-end-end:var(--gm3-button-text-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-end-start:var(--gm3-button-text-container-shape,
    9999px)
}.mUIrbf-mRLv6:focus-visible{outline:none
}.mUIrbf-LgbsSe:focus-visible,.mUIrbf-mRLv6:focus-visible~.mUIrbf-UHGRz{--gm3-focus-ring-outward-display:block
}.mUIrbf-LgbsSe:disabled{cursor:default;pointer-events:none;--gm3-ripple-hover-opacity: 0;--gm3-ripple-pressed-opacity: 0
}.mUIrbf-LgbsSe-OWXEXe-SfQLQb-suEOdc:disabled{pointer-events:auto
}.mUIrbf-LgbsSe[hidden
]{display:none
}.mUIrbf-vQzf8d{position:relative;text-align:center;color:var(--gm3-button-text-label-text-color,var(--gm3-sys-color-primary,#0b57d0));font-size:var(--gm3-button-text-label-text-size,.875rem);font-family:var(--gm3-button-text-label-text-font,
    "Google Sans",Roboto,Arial,sans-serif);font-weight:var(--gm3-button-text-label-text-weight,
    500);letter-spacing:var(--gm3-button-text-label-text-tracking,
    0)
}.mUIrbf-LgbsSe:hover .mUIrbf-vQzf8d{color:var(--gm3-button-text-hover-label-text-color,var(--gm3-sys-color-primary,#0b57d0))
}.mUIrbf-LgbsSe:focus-visible .mUIrbf-vQzf8d{color:var(--gm3-button-text-focus-label-text-color,var(--gm3-sys-color-primary,#0b57d0))
}.mUIrbf-LgbsSe:active .mUIrbf-vQzf8d{color:var(--gm3-button-text-pressed-label-text-color,var(--gm3-sys-color-primary,#0b57d0))
}.mUIrbf-LgbsSe:disabled .mUIrbf-vQzf8d{color:var(--gm3-button-text-disabled-label-text-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.38))
}.mUIrbf-LgbsSe-OWXEXe-zcdHbf .mUIrbf-vQzf8d{white-space:nowrap;text-overflow:ellipsis;overflow:hidden
}.mUIrbf-LgbsSe-OWXEXe-Bz112c-M1Soyc{-webkit-padding-start:var(--gm3-button-text-with-leading-icon-leading-space,
    12px);padding-inline-start:var(--gm3-button-text-with-leading-icon-leading-space,
    12px);-webkit-padding-end:var(--gm3-button-text-with-leading-icon-trailing-space,
    16px);padding-inline-end:var(--gm3-button-text-with-leading-icon-trailing-space,
    16px)
}.mUIrbf-LgbsSe-OWXEXe-Bz112c-M1Soyc .mUIrbf-kBDsod-Rtc0Jf :is(i,img,svg){-webkit-margin-end:var(--gm3-button-text-with-icon-icon-label-space,
    8px);margin-inline-end:var(--gm3-button-text-with-icon-icon-label-space,
    8px)
}.mUIrbf-LgbsSe-OWXEXe-Bz112c-UbuQg{-webkit-padding-start:var(--gm3-button-text-with-trailing-icon-leading-space,
    16px);padding-inline-start:var(--gm3-button-text-with-trailing-icon-leading-space,
    16px);-webkit-padding-end:var(--gm3-button-text-with-trailing-icon-trailing-space,
    12px);padding-inline-end:var(--gm3-button-text-with-trailing-icon-trailing-space,
    12px)
}.mUIrbf-LgbsSe-OWXEXe-Bz112c-UbuQg .mUIrbf-kBDsod-Rtc0Jf :is(i,img,svg){-webkit-margin-start:var(--gm3-button-text-with-icon-icon-label-space,
    8px);margin-inline-start:var(--gm3-button-text-with-icon-icon-label-space,
    8px)
}.mUIrbf-kBDsod-Rtc0Jf{display:none;position:relative;line-height: 0;color:var(--gm3-button-text-with-icon-icon-color,var(--gm3-sys-color-primary,#0b57d0))
}.mUIrbf-kBDsod-Rtc0Jf i,.mUIrbf-kBDsod-Rtc0Jf img,.mUIrbf-kBDsod-Rtc0Jf svg{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative;direction:inherit;color:inherit;font-size:var(--gm3-button-text-with-icon-icon-size,
    18px);inline-size:var(--gm3-button-text-with-icon-icon-size,
    18px);block-size:var(--gm3-button-text-with-icon-icon-size,
    18px)
}.mUIrbf-LgbsSe:hover .mUIrbf-kBDsod-Rtc0Jf{color:var(--gm3-button-text-with-icon-hover-icon-color,var(--gm3-sys-color-primary,#0b57d0))
}.mUIrbf-LgbsSe:focus-visible .mUIrbf-kBDsod-Rtc0Jf{color:var(--gm3-button-text-with-icon-focus-icon-color,var(--gm3-sys-color-primary,#0b57d0))
}.mUIrbf-LgbsSe:active .mUIrbf-kBDsod-Rtc0Jf{color:var(--gm3-button-text-with-icon-pressed-icon-color,var(--gm3-sys-color-primary,#0b57d0))
}.mUIrbf-LgbsSe:disabled .mUIrbf-kBDsod-Rtc0Jf{color:var(--gm3-button-text-with-icon-disabled-icon-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.38))
}[dir=rtl
] .mUIrbf-LgbsSe-OWXEXe-drxrmf-Bz112c .mUIrbf-kBDsod-Rtc0Jf,.mUIrbf-LgbsSe-OWXEXe-drxrmf-Bz112c .mUIrbf-kBDsod-Rtc0Jf[dir=rtl
]{-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1)
}.mUIrbf-LgbsSe-OWXEXe-Bz112c-M1Soyc .mUIrbf-kBDsod-Rtc0Jf-OWXEXe-M1Soyc,.mUIrbf-LgbsSe-OWXEXe-Bz112c-UbuQg .mUIrbf-kBDsod-Rtc0Jf-OWXEXe-UbuQg{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex
}.mUIrbf-mRLv6{position:absolute;inset: 0
}.mUIrbf-LgbsSe-OWXEXe-dgl2Hf{margin-block:max((48px - var(--gm3-button-text-container-height,
    40px))/2,
    0px)
}.mUIrbf-RLmnJb{position:absolute;inline-size:max(48px,
    100%);block-size:max(48px,
    100%);inset:unset;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%)
}.mUIrbf-LgbsSe{will-change:transform,opacity
}.mUIrbf-LgbsSe: :before{content: "";pointer-events:none;position:absolute;inset: 0;border-radius:inherit;border: 1px solid transparent
}@media (forced-colors:active){.mUIrbf-LgbsSe: :before{border-color:CanvasText
    }
}.FOBRw-LgbsSe{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-box-sizing:border-box;box-sizing:border-box;border:none;outline:none;background:transparent;-webkit-appearance:none;-moz-appearance:none;appearance:none;line-height:inherit;text-rendering:inherit;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;vertical-align:middle;cursor:pointer;min-inline-size:var(--gm3-button-filled-tonal-container-min-width,
    64px);padding-block: 0;-webkit-padding-start:var(--gm3-button-filled-tonal-leading-space,
    24px);padding-inline-start:var(--gm3-button-filled-tonal-leading-space,
    24px);-webkit-padding-end:var(--gm3-button-filled-tonal-trailing-space,
    24px);padding-inline-end:var(--gm3-button-filled-tonal-trailing-space,
    24px);block-size:var(--gm3-button-filled-tonal-container-height,
    40px);border-radius:var(--gm3-button-filled-tonal-container-shape,
    9999px);--gm3-ripple-hover-color:var(--gm3-button-filled-tonal-hover-state-layer-color,var(--gm3-sys-color-on-secondary-container,#001d35));--gm3-ripple-hover-opacity:var(--gm3-button-filled-tonal-hover-state-layer-opacity,
    0.08);--gm3-ripple-pressed-color:var(--gm3-button-filled-tonal-hover-state-layer-color,var(--gm3-sys-color-on-secondary-container,#001d35));--gm3-ripple-pressed-opacity:var(--gm3-button-filled-tonal-pressed-state-layer-opacity,
    0.1);--gm3-focus-ring-outward-color:var(--gm3-button-filled-tonal-focus-indicator-color,var(--gm3-sys-color-secondary,#00639b));--gm3-focus-ring-outward-offset:var(--gm3-button-filled-tonal-focus-indicator-outline-offset,
    2px);--gm3-focus-ring-outward-track-width:var(--gm3-button-filled-tonal-focus-indicator-thickness,
    3px);--gm3-focus-ring-outward-target-shape-start-start:var(--gm3-button-filled-tonal-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-start-end:var(--gm3-button-filled-tonal-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-end-end:var(--gm3-button-filled-tonal-container-shape,
    9999px);--gm3-focus-ring-outward-target-shape-end-start:var(--gm3-button-filled-tonal-container-shape,
    9999px)
}.FOBRw-mRLv6:focus-visible{outline:none
}.FOBRw-LgbsSe:focus-visible,.FOBRw-mRLv6:focus-visible~.FOBRw-UHGRz{--gm3-focus-ring-outward-display:block
}.FOBRw-LgbsSe:disabled{cursor:default;pointer-events:none;--gm3-ripple-hover-opacity: 0;--gm3-ripple-pressed-opacity: 0
}.FOBRw-LgbsSe-OWXEXe-SfQLQb-suEOdc:disabled{pointer-events:auto
}.FOBRw-LgbsSe[hidden
]{display:none
}.FOBRw-vQzf8d{position:relative;text-align:center;color:var(--gm3-button-filled-tonal-label-text-color,var(--gm3-sys-color-on-secondary-container,#001d35));font-size:var(--gm3-button-filled-tonal-label-text-size,.875rem);font-family:var(--gm3-button-filled-tonal-label-text-font,
    "Google Sans",Roboto,Arial,sans-serif);font-weight:var(--gm3-button-filled-tonal-label-text-weight,
    500);letter-spacing:var(--gm3-button-filled-tonal-label-text-tracking,
    0)
}.FOBRw-LgbsSe:hover .FOBRw-vQzf8d{color:var(--gm3-button-filled-tonal-hover-label-text-color,var(--gm3-sys-color-on-secondary-container,#001d35))
}.FOBRw-LgbsSe:focus-visible .FOBRw-vQzf8d{color:var(--gm3-button-filled-tonal-focus-label-text-color,var(--gm3-sys-color-on-secondary-container,#001d35))
}.FOBRw-LgbsSe:active .FOBRw-vQzf8d{color:var(--gm3-button-filled-tonal-pressed-label-text-color,var(--gm3-sys-color-on-secondary-container,#001d35))
}.FOBRw-LgbsSe:disabled .FOBRw-vQzf8d{color:var(--gm3-button-filled-tonal-disabled-label-text-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.38))
}.FOBRw-LgbsSe-OWXEXe-zcdHbf .FOBRw-vQzf8d{white-space:nowrap;text-overflow:ellipsis;overflow:hidden
}.FOBRw-LgbsSe-OWXEXe-Bz112c-M1Soyc{-webkit-padding-start:var(--gm3-button-filled-tonal-with-leading-icon-leading-space,
    16px);padding-inline-start:var(--gm3-button-filled-tonal-with-leading-icon-leading-space,
    16px);-webkit-padding-end:var(--gm3-button-filled-tonal-with-leading-icon-trailing-space,
    24px);padding-inline-end:var(--gm3-button-filled-tonal-with-leading-icon-trailing-space,
    24px)
}.FOBRw-LgbsSe-OWXEXe-Bz112c-M1Soyc .FOBRw-kBDsod-Rtc0Jf :is(i,img,svg){-webkit-margin-end:var(--gm3-button-filled-tonal-with-icon-icon-label-space,
    8px);margin-inline-end:var(--gm3-button-filled-tonal-with-icon-icon-label-space,
    8px)
}.FOBRw-LgbsSe-OWXEXe-Bz112c-UbuQg{-webkit-padding-start:var(--gm3-button-filled-tonal-with-trailing-icon-leading-space,
    24px);padding-inline-start:var(--gm3-button-filled-tonal-with-trailing-icon-leading-space,
    24px);-webkit-padding-end:var(--gm3-button-filled-tonal-with-trailing-icon-trailing-space,
    16px);padding-inline-end:var(--gm3-button-filled-tonal-with-trailing-icon-trailing-space,
    16px)
}.FOBRw-LgbsSe-OWXEXe-Bz112c-UbuQg .FOBRw-kBDsod-Rtc0Jf :is(i,img,svg){-webkit-margin-start:var(--gm3-button-filled-tonal-with-icon-icon-label-space,
    8px);margin-inline-start:var(--gm3-button-filled-tonal-with-icon-icon-label-space,
    8px)
}.FOBRw-kBDsod-Rtc0Jf{display:none;position:relative;line-height: 0;color:var(--gm3-button-filled-tonal-with-icon-icon-color,var(--gm3-sys-color-on-secondary-container,#001d35))
}.FOBRw-kBDsod-Rtc0Jf i,.FOBRw-kBDsod-Rtc0Jf img,.FOBRw-kBDsod-Rtc0Jf svg{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative;direction:inherit;color:inherit;font-size:var(--gm3-button-filled-tonal-with-icon-icon-size,
    18px);inline-size:var(--gm3-button-filled-tonal-with-icon-icon-size,
    18px);block-size:var(--gm3-button-filled-tonal-with-icon-icon-size,
    18px)
}.FOBRw-LgbsSe:hover .FOBRw-kBDsod-Rtc0Jf{color:var(--gm3-button-filled-tonal-with-icon-hover-icon-color,var(--gm3-sys-color-on-secondary-container,#001d35))
}.FOBRw-LgbsSe:focus-visible .FOBRw-kBDsod-Rtc0Jf{color:var(--gm3-button-filled-tonal-with-icon-focus-icon-color,var(--gm3-sys-color-on-secondary-container,#001d35))
}.FOBRw-LgbsSe:active .FOBRw-kBDsod-Rtc0Jf{color:var(--gm3-button-filled-tonal-with-icon-pressed-icon-color,var(--gm3-sys-color-on-secondary-container,#001d35))
}.FOBRw-LgbsSe:disabled .FOBRw-kBDsod-Rtc0Jf{color:var(--gm3-button-filled-tonal-with-icon-disabled-icon-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.38))
}[dir=rtl
] .FOBRw-LgbsSe-OWXEXe-drxrmf-Bz112c .FOBRw-kBDsod-Rtc0Jf,.FOBRw-LgbsSe-OWXEXe-drxrmf-Bz112c .FOBRw-kBDsod-Rtc0Jf[dir=rtl
]{-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1)
}.FOBRw-LgbsSe-OWXEXe-Bz112c-M1Soyc .FOBRw-kBDsod-Rtc0Jf-OWXEXe-M1Soyc,.FOBRw-LgbsSe-OWXEXe-Bz112c-UbuQg .FOBRw-kBDsod-Rtc0Jf-OWXEXe-UbuQg{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex
}.FOBRw-mRLv6{position:absolute;inset: 0
}.FOBRw-LgbsSe-OWXEXe-dgl2Hf{margin-block:max((48px - var(--gm3-button-filled-tonal-container-height,
    40px))/2,
    0px)
}.FOBRw-RLmnJb{position:absolute;inline-size:max(48px,
    100%);block-size:max(48px,
    100%);inset:unset;top: 50%;left: 50%;-webkit-transform:translate(-50%,
    -50%);-ms-transform:translate(-50%,
    -50%);transform:translate(-50%,
    -50%)
}.FOBRw-LgbsSe{will-change:transform,opacity;background-color:var(--gm3-button-filled-tonal-container-color,var(--gm3-sys-color-secondary-container,#c2e7ff));--gm3-elevation-level:var(--gm3-button-filled-tonal-container-elevation,
    0);--gm3-elevation-shadow-color:var(--gm3-button-filled-tonal-container-shadow-color,var(--gm3-sys-color-shadow,#000))
}.FOBRw-LgbsSe:hover{--gm3-elevation-level:var(--gm3-button-filled-tonal-hover-container-elevation,
    1)
}.FOBRw-LgbsSe:focus-visible{--gm3-elevation-level:var(--gm3-button-filled-tonal-focus-container-elevation,
    0)
}.FOBRw-LgbsSe:active{--gm3-elevation-level:var(--gm3-button-filled-tonal-pressed-container-elevation,
    0)
}.FOBRw-LgbsSe:disabled{background-color:var(--gm3-button-filled-tonal-disabled-container-color,rgba(var(--gm3-sys-color-on-surface-rgb,
    31,
    31,
    31),.12));--gm3-elevation-level:var(--gm3-button-filled-tonal-disabled-container-elevation,
    0)
}.FOBRw-LgbsSe: :before{content: "";pointer-events:none;position:absolute;inset: 0;border-radius:inherit;border: 1px solid transparent
}@media (forced-colors:active){.FOBRw-LgbsSe: :before{border-color:CanvasText
    }
}.tB5Jxf-xl07Ob-XxIAqe{display:none;position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;margin: 0;padding: 0;border-radius: 4px;-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);-webkit-transform-origin:top left;-ms-transform-origin:top left;transform-origin:top left;opacity: 0;will-change:transform,opacity;-webkit-transition:opacity .03s linear,height .25s cubic-bezier(0,
    0,.2,
    1),-webkit-transform .12s cubic-bezier(0,
    0,.2,
    1);transition:opacity .03s linear,height .25s cubic-bezier(0,
    0,.2,
    1),-webkit-transform .12s cubic-bezier(0,
    0,.2,
    1);transition:opacity .03s linear,transform .12s cubic-bezier(0,
    0,.2,
    1),height .25s cubic-bezier(0,
    0,.2,
    1);transition:opacity .03s linear,transform .12s cubic-bezier(0,
    0,.2,
    1),height .25s cubic-bezier(0,
    0,.2,
    1),-webkit-transform .12s cubic-bezier(0,
    0,.2,
    1);z-index: 8;--gm3-elevation-level:var(--gm3-menu-surface-container-elevation,
    2);--gm3-elevation-shadow-color:var(--gm3-menu-surface-container-shadow-color,var(--gm3-sys-color-shadow,#000));--gm3-elevation-surface-tint-layer-color:var(--gm3-menu-surface-container-surface-tint-layer-color,transparent);max-width:calc(100vw - 32px);max-height:calc(100vw - 32px);background-color:var(--gm3-menu-surface-container-color,var(--gm3-sys-color-surface,#fff));color:#000
}[dir=rtl
] .tB5Jxf-xl07Ob-XxIAqe,.tB5Jxf-xl07Ob-XxIAqe[dir=rtl
]{-webkit-transform-origin:top right;-ms-transform-origin:top right;transform-origin:top right
}.tB5Jxf-xl07Ob-XxIAqe-OWXEXe-Vkfede-QBLLGd{width: 100%
}.tB5Jxf-xl07Ob-S5Cmsd{overflow:auto;max-height:inherit;border-radius:inherit
}.tB5Jxf-xl07Ob-XxIAqe:focus{outline:none
}.tB5Jxf-xl07Ob-XxIAqe-OWXEXe-oT9UPb-FNFY6c{display:inline-block;-webkit-transform:scale(.8);-ms-transform:scale(.8);transform:scale(.8);opacity: 0
}.tB5Jxf-xl07Ob-XxIAqe-OWXEXe-FNFY6c{display:inline-block;-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);opacity: 1
}.tB5Jxf-xl07Ob-XxIAqe-OWXEXe-oT9UPb-xTMeO{display:inline-block;opacity: 0;-webkit-transition:opacity 75ms linear;transition:opacity 75ms linear
}.tB5Jxf-xl07Ob-XxIAqe-OWXEXe-oYxtQd{position:relative;overflow:visible
}.tB5Jxf-xl07Ob-XxIAqe-OWXEXe-qbOKL{position:fixed
}.tB5Jxf-xl07Ob-XxIAqe-OWXEXe-uxVfW-FNFY6c-uFfGwd{border-start-start-radius: 0;border-start-end-radius: 0
}.dMNVAe,.FSdAW{padding-bottom: 3px;padding-top: 9px
}.FSdAW{margin: 0
}.dMNVAe:empty,.FSdAW:empty{display:none
}@media screen and (prefers-color-scheme:dark){
    :root{--wf-color-warning-bg:#754200;--wf-color-warning-icon:#ffdf99;--wf-color-warning-text:#fff0d1
    }
}@media screen and (prefers-color-scheme:light){
    :root{--wf-color-warning-bg:#fff0d1;--wf-color-warning-icon:#f09d00;--wf-color-warning-text:#421f00
    }
}@media screen and (prefers-color-scheme:dark){.nPt1pc{display:none
    }.Dzz9Db:not(.GtvzYd){display:none
    }
}.hZUije{border: 0
}.hZUije.WS4XDd{max-height:1.3333em;padding: 0 2px;vertical-align:middle;width:auto
}.kHluYc{border: 0;-o-object-fit:contain;object-fit:contain
}.kHluYc.WS4XDd{max-height:1.3333em;padding: 0 2px;vertical-align:middle;width:auto
}.vOZun,.gomQac{padding-bottom: 3px;padding-top: 9px;margin-bottom: 0;margin-top: 0
}.gomQac{margin: 0
}.vOZun:empty{display:none
}.JnOM6e{background-color:transparent;border:none;border-radius: 4px;-webkit-box-sizing:border-box;box-sizing:border-box;display:inline-block;font-size: 14px;height: 36px;letter-spacing:.15px;line-height: 34px;padding: 0 24px;position:relative;text-align:center
}.JnOM6e:focus-visible{outline:none;position:relative
}.JnOM6e:focus-visible: :after{border: 2px solid rgb(24,
    90,
    188);border-radius: 6px;bottom: -4px;-webkit-box-shadow: 0 0 0 2px rgb(232,
    240,
    254);box-shadow: 0 0 0 2px rgb(232,
    240,
    254);content: "";left: -4px;position:absolute;right: -4px;top: -4px
}.rDisVe:focus:not(:focus-visible),.GjFdVe:focus:not(:focus-visible){-webkit-box-shadow: 0 1px 1px 0 rgba(66,
    133,
    244,.3),
    0 1px 3px 1px rgba(66,
    133,
    244,.15);box-shadow: 0 1px 1px 0 rgba(66,
    133,
    244,.3),
    0 1px 3px 1px rgba(66,
    133,
    244,.15)
}.rDisVe:hover:not(:focus-visible),.GjFdVe:hover:not(:focus-visible){-webkit-box-shadow: 0 1px 1px 0 rgba(66,
    133,
    244,.45),
    0 1px 3px 1px rgba(66,
    133,
    244,.3);box-shadow: 0 1px 1px 0 rgba(66,
    133,
    244,.45),
    0 1px 3px 1px rgba(66,
    133,
    244,.3)
}.JnOM6e:disabled{pointer-events:none
}.JnOM6e:hover{cursor:pointer
}.JnOM6e.kTeh9{line-height: 36px;text-decoration:none
}.JnOM6e.eLNT1d{display:none
}.rDisVe{background-color:rgb(26,
    115,
    232);color:#fff
}.rDisVe:disabled{background-color:rgb(232,
    234,
    237);color:rgb(154,
    160,
    166)
}.rDisVe:focus,.rDisVe:hover{background-color:rgb(24,
    90,
    188)
}.GjFdVe{border: 1px solid rgb(218,
    220,
    224);color:rgb(26,
    115,
    232)
}.GjFdVe:disabled{color:rgb(189,
    193,
    198)
}.GjFdVe:active{background-color:rgb(174,
    203,
    250);color:rgb(23,
    78,
    166)
}.GjFdVe:focus{background-color:rgb(232,
    240,
    254);border-color:rgb(24,
    90,
    188);color:rgb(23,
    78,
    166)
}.GjFdVe:hover{background-color:rgb(232,
    240,
    254);color:rgb(23,
    78,
    166)
}.KXbQ4b{color:rgb(26,
    115,
    232);min-width: 0;padding-left: 8px;padding-right: 8px
}.KXbQ4b:disabled{color:rgb(189,
    193,
    198)
}.KXbQ4b:active,.KXbQ4b:hover{color:rgb(24,
    90,
    188)
}.KXbQ4b:active{background-color:rgba(26,
    115,
    232,.12)
}.KXbQ4b:focus,.KXbQ4b:hover{background-color:rgba(26,
    115,
    232,.04)
}.aN1Vld{margin: 16px 0;outline:none
}.aN1Vld+.aN1Vld{margin-top: 24px
}.aN1Vld:first-child{margin-top: 0
}.aN1Vld:last-child{margin-bottom: 0
}.fegW5d{border-radius: 8px;padding: 16px
}.fegW5d>:first-child{margin-top: 0
}.fegW5d>:last-child{margin-bottom: 0
}.fegW5d .cySqRb,.fegW5d .yOnVIb{color:rgb(32,
    33,
    36)
}.fegW5d.YFdWic .yOnVIb{color:rgb(95,
    99,
    104);margin-top: 4px;padding: 0
}.fegW5d.YFdWic .wSQNd,.fegW5d.YFdWic .yOnVIb{margin-left: 64px;width:calc(100% - 64px)
}.fegW5d.YFdWic:not(.S7S4N) .wSQNd{margin-left: 0;width: 0
}.fegW5d:not(.S7S4N)>.yOnVIb{margin-top: 0
}.fegW5d.sj692e{background:rgb(232,
    240,
    254)
}.fegW5d.Xq8bDe{background:rgb(252,
    232,
    230)
}.fegW5d.rNe0id{background:rgb(254,
    247,
    224)
}.fegW5d.YFdWic{border: 1px solid rgb(218,
    220,
    224);min-height: 80px;position:relative
}.fegW5d:not(.S7S4N){display:-webkit-box;display:-webkit-flex;display:flex
}.aN1Vld.eLNT1d{display:none
}.aN1Vld.RDPZE{opacity:.5;pointer-events:none
}.aN1Vld.RDPZE .aN1Vld.RDPZE{opacity: 1
}.wlrzMe{border: 1px solid rgb(218,
    220,
    224);border-radius: 8px;padding: 16px
}.wlrzMe .EEiyWe{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-pack:end;-webkit-justify-content:flex-end;justify-content:flex-end;margin-top: 16px
}.wlrzMe .EEiyWe .GjFdVe{margin-bottom: 0;margin-top: 0
}.wSQNd:empty{display:none
}.wSQNd>:first-child{margin-top: 0;padding-top: 0
}.wSQNd>:last-child{margin-bottom: 0;padding-bottom: 0
}.cySqRb{-webkit-box-align:center;-webkit-align-items:center;align-items:center;color:rgb(32,
    33,
    36);display:-webkit-box;display:-webkit-flex;display:flex;font-size: 16px;font-weight: 500;letter-spacing:.1px;line-height: 1.4286;margin-bottom: 0;margin-top: 0;padding: 0
}.zlrrr{color:rgb(95,
    99,
    104);-webkit-flex-shrink: 0;flex-shrink: 0;height: 20px;margin-right: 16px;width: 20px
}.zlrrr .GxLRef{height: 100%;width: 100%
}.fegW5d .zlrrr{margin-top: 0
}.fegW5d.sj692e .zlrrr{color:rgb(25,
    103,
    210)
}.fegW5d.Xq8bDe .zlrrr{color:rgb(197,
    34,
    31)
}.fegW5d.rNe0id .zlrrr{color:rgb(234,
    134,
    0)
}.fegW5d.YFdWic .zlrrr{height: 48px;left: 16px;position:absolute;top: 16px;width: 48px
}.yOnVIb{margin:auto -24px;padding-left: 24px;padding-right: 24px;margin-bottom: 16px;margin-top: 10px
}.wlrzMe .yOnVIb{margin-bottom: 0;margin-top: 16px
}.yOnVIb>:first-child:not(section){margin-top: 0;padding-top: 0
}.yOnVIb>:last-child:not(section){margin-bottom: 0;padding-bottom: 0
}.wSQNd:empty+.yOnVIb{margin-top: 0
}.yOnVIb:only-child{margin-bottom: 0;margin-top: 0
}c-wiz{contain:style
}c-wiz>c-data{display:none
}c-wiz.rETSD{contain:none
}c-wiz.Ubi8Z{contain:layout style
}.ObDc3{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;margin-bottom: 32px
}@media (min-width: 840px){.ObDc3{margin-bottom: 32px
    }
}.wsArZ[data-ss-mode="1"
] .ObDc3{margin-bottom: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .ObDc3{margin-bottom: 0
    }
}.Su9bff{-webkit-box-align:center;-webkit-align-items:center;align-items:center;text-align:center
}.vAV9bf{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-weight: 400;font-weight:var(--c-tfwt,
    400);line-height: 1.25;margin-bottom: 0;margin-bottom:var(--c-ts-b,
    0);margin-top: 24px;margin-top:var(--c-ts-t,
    24px);word-break:break-word;font-size: 2rem;font-size:var(--wf-tfs,
    2rem)
}@media (min-width: 840px){.vAV9bf{line-height: 1.2222222222;font-size: 2.25rem;font-size:var(--wf-tfs-bp3,
        2.25rem)
    }
}@media (min-width: 960px){.vAV9bf{line-height: 1.2222222222;font-size: 2.25rem;font-size:var(--wf-tfs-bp3,
        2.25rem)
    }
}@media (min-width: 1600px){.vAV9bf{line-height: 1.1818181818;font-size: 2.75rem;font-size:var(--wf-tfs-bp5,
        2.75rem)
    }
}.gNJDp{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-weight: 400;font-weight:var(--c-stfwt,
    400);letter-spacing: 0rem;line-height: 1.5;margin-bottom: 0;margin-bottom:var(--c-sts-b,
    0);margin-top: 16px;margin-top:var(--c-sts-t,
    16px);font-size: 1rem;font-size:var(--wf-stfs,
    1rem)
}@media (min-width: 1600px){.gNJDp{line-height: 1.5;font-size: 1rem;font-size:var(--wf-stfs-bp5,
        1rem)
    }
}.gNJDp:empty{display:none
}.I7GnLc{font-weight: 500;letter-spacing:.25px;min-height: 24px
}.SOeSgb{height: 32px
}.I7GnLc,.SOeSgb{margin-bottom: 0;margin-bottom:var(--c-sts-b,
    0);margin-top: 16px;margin-top:var(--c-sts-t,
    16px)
}.ObDc3.ZYOIke .I7GnLc,.ObDc3.ZYOIke .SOeSgb{margin-bottom: 0;margin-top: 16px
}.SfkAJe{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1
}.llhEMd{-webkit-transition:opacity .15s cubic-bezier(0.4,
    0,
    0.2,
    1) .15s;-moz-transition:opacity .15s cubic-bezier(0.4,
    0,
    0.2,
    1) .15s;-o-transition:opacity .15s cubic-bezier(0.4,
    0,
    0.2,
    1) .15s;transition:opacity .15s cubic-bezier(0.4,
    0,
    0.2,
    1) .15s;background-color:rgba(0,
    0,
    0,
    0.502);bottom: 0;left: 0;opacity: 0;position:fixed;right: 0;top: 0;z-index: 5000
}.llhEMd.iWO5td{-webkit-transition:opacity .05s cubic-bezier(0.4,
    0,
    0.2,
    1);-moz-transition:opacity .05s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-transition:opacity .05s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:opacity .05s cubic-bezier(0.4,
    0,
    0.2,
    1);opacity: 1
}.mjANdc{-o-transition:-webkit-transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:-webkit-transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-transition:-webkit-transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-transition:transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-transition:transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1);-webkit-transition:transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1),-webkit-transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1);-o-transition:transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1),-webkit-transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1);transition:transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1),-webkit-transform .4s cubic-bezier(0.4,
    0,
    0.2,
    1);-ms-flex-align:center;-moz-box-align:center;-webkit-box-align:center;box-align:center;-webkit-align-items:center;align-items:center;display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-moz-box-orient:vertical;-webkit-box-orient:vertical;box-orient:vertical;-ms-flex-direction:column;-webkit-flex-direction:column;flex-direction:column;bottom: 0;left: 0;padding: 0 5%;position:absolute;right: 0;top: 0
}.x3wWge,.ONJhl{display:block;height:3em
}.eEPege>.x3wWge,.eEPege>.ONJhl{-webkit-box-flex: 1;box-flex: 1;-ms-flex-positive: 1;-webkit-flex-grow: 1;flex-grow: 1
}.J9Nfi{-webkit-flex-shrink: 1;-ms-flex-negative: 1;flex-shrink: 1;max-height: 100%
}*,*: :before,*: :after{-webkit-box-sizing:inherit;box-sizing:inherit
}html{-webkit-box-sizing:border-box;box-sizing:border-box;-webkit-tap-highlight-color:rgba(0,
    0,
    0,
    0)
}.jR8x9d{color-scheme:light
}.jR8x9d,.jR8x9d input,.jR8x9d textarea,.jR8x9d select,.jR8x9d button{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif
}.jR8x9d{background-color:white;background-color:var(--gm3-sys-color-background,white);direction:ltr;font-size: 0.875rem;font-weight: 400;letter-spacing: 0rem;line-height: 1.4285714286;margin: 0;padding: 0
}.jR8x9d [data-style=heading
]{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f);font-family: "Google Sans",roboto,
    "Noto Sans Myanmar UI",arial,sans-serif;font-size: 1.25rem;font-weight: 400;letter-spacing: 0rem;line-height: 1.2
}.S7xv8{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;min-height: 100vh;background:#fff;background:var(--gm3-sys-color-surface-container-lowest,#fff);-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;padding: 0
}@media (min-width: 600px){.S7xv8{background:#f0f4f9;background:var(--gm3-sys-color-surface-container,#f0f4f9);-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;padding: 48px 0
    }
}@media (min-width: 600px) and (orientation:landscape){.S7xv8{background:#fff;background:var(--gm3-sys-color-surface-container-lowest,#fff);-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;padding: 0
    }
}@media (min-width: 960px) and (orientation:landscape){.S7xv8{background:#f0f4f9;background:var(--gm3-sys-color-surface-container,#f0f4f9);-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;padding: 48px 0
    }
}.fAlnEc a:not(.TrZEUc):not(.WpHeLc){outline-offset: 2px;text-decoration:none
}.fAlnEc a:not(.TrZEUc):not(.WpHeLc):hover{text-decoration:underline
}.fAlnEc button:not(.TrZEUc){background-color:transparent;border: 0;cursor:pointer;font-size:inherit;outline:none;padding: 0;position:relative;text-align:left
}.fAlnEc a:not(.TrZEUc):not(.WpHeLc),.fAlnEc button:not(.TrZEUc){color:#0b57d0;color:var(--gm3-sys-color-primary,#0b57d0);border-radius: 4px;font-weight: 500;letter-spacing: 0.015625rem;z-index: 1
}.fAlnEc a:not(.TrZEUc):not(.WpHeLc):focus-visible{outline: 2px solid #0b57d0;outline: 2px solid var(--gm3-sys-color-primary,#0b57d0)
}.fAlnEc .gNJDp a:not(.TrZEUc):not(.WpHeLc),.fAlnEc .gNJDp button:not(.TrZEUc){font-weight: 500;font-weight:var(--c-stfwt,
    500)
}.fAlnEc .PsAlOe a:not(.TrZEUc),.fAlnEc .PsAlOe button:not(.TrZEUc){text-decoration:underline
}.fAlnEc .PsAlOe.sj692e a:not(.TrZEUc),.fAlnEc .PsAlOe.sj692e button:not(.TrZEUc){color:#041e49;color:var(--gm3-sys-color-on-primary-container,#041e49)
}.fAlnEc .Su9bff a:not(.L3JCSb),.fAlnEc .Su9bff button:not(.L3JCSb){text-align:center
}.fAlnEc .PsAlOe.Xq8bDe a:not(.TrZEUc),.fAlnEc .PsAlOe.Xq8bDe button:not(.TrZEUc){color:#410e0b;color:var(--gm3-sys-color-on-error-container,#410e0b)
}.fAlnEc .PsAlOe.rNe0id a:not(.TrZEUc),.fAlnEc .PsAlOe.rNe0id button:not(.TrZEUc){color:var(--wf-color-warning-text,#421f00)
}.fAlnEc .PsAlOe.YFdWic a:not(.TrZEUc),.fAlnEc .PsAlOe.YFdWic button:not(.TrZEUc){color:#444746;color:var(--gm3-sys-color-on-surface-variant,#444746)
}.fAlnEc button:not(.TrZEUc): :-moz-focus-inner{border: 0
}.fAlnEc button:not(.TrZEUc):focus-visible: :after{border: 2px solid;border-color:#0b57d0;border-color:var(--gm3-sys-color-primary,#0b57d0);-webkit-box-shadow: 0 0 0 2px #d3e3fd;box-shadow: 0 0 0 2px #d3e3fd;-webkit-box-shadow: 0 0 0 2px var(--gm3-sys-color-primary-container,#d3e3fd);box-shadow: 0 0 0 2px var(--gm3-sys-color-primary-container,#d3e3fd);border-radius: 12px;content: "";position:absolute;pointer-events:none;inset: -9px;bottom: -5px;top: -5px
}.fAlnEc button:not(.TrZEUc): :before{background-color:#0b57d0;background-color:var(--gm3-sys-color-primary,#0b57d0);border-radius: 8px;bottom: -1px;content: "";left: -5px;opacity: 0;pointer-events:none;position:absolute;right: -5px;top: -1px;z-index: -1
}.fAlnEc button:not(.TrZEUc):hover: :before{opacity:.08
}.fAlnEc button:not(.TrZEUc):focus: :before,.fAlnEc button:not(.TrZEUc):active: :before{opacity:.1
}.fAlnEc img:not(.TrZEUc){border: 0;max-height:1.3em;vertical-align:middle
}.iv5ilf{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-flow:column wrap;flex-flow:column wrap;-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;-webkit-box-pack:end;-webkit-justify-content:flex-end;justify-content:flex-end;margin-bottom: -6px;margin-left: -16px;margin-top: 32px
}.wsArZ[data-ss-mode="1"
] .iv5ilf{width: 100%
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf{width: 100%
    }
}.iv5ilf.fXx9Lc{margin: 0;min-height: 0;padding: 0
}.szuFIb{-webkit-align-self:flex-start;align-self:flex-start;-webkit-flex-shrink: 0;flex-shrink: 0;margin-bottom: 24px
}.Te5wkb{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-flow:row-reverse wrap;flex-flow:row-reverse wrap;width: 100%
}.v8y8Fe,.zdUG4b{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .v8y8Fe,.wsArZ[data-ss-mode="1"
    ] .zdUG4b{-webkit-box-flex:unset;-webkit-flex-grow:unset;flex-grow:unset
    }
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf:not(.NNItQ) .v8y8Fe,.NQ5OL .iv5ilf:not(.NNItQ) .zdUG4b{-webkit-box-flex:unset;-webkit-flex-grow:unset;flex-grow:unset
    }
}.zdUG4b{-webkit-box-pack:flex-start;-webkit-justify-content:flex-start;justify-content:flex-start
}.wsArZ[data-ss-mode="1"
] .zdUG4b{margin-left: 0;margin-right: -16px
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .zdUG4b{margin-left: 0;margin-right: -16px
    }
}.v8y8Fe{-webkit-box-pack:flex-end;-webkit-justify-content:flex-end;justify-content:flex-end
}.wsArZ[data-ss-mode="1"
] .v8y8Fe{margin-left: 40px;margin-right: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .v8y8Fe{margin-left: 40px;margin-right: 0
    }
}.wsArZ[data-ss-mode="1"
] .v8y8Fe:empty{margin-left: 0;margin-right: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .v8y8Fe:empty{margin-left: 0;margin-right: 0
    }
}.iv5ilf.NNItQ .v8y8Fe,.iv5ilf.NNItQ .zdUG4b{-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center
}.iv5ilf.NNItQ .v8y8Fe,.iv5ilf.F8PBrb .v8y8Fe{padding-left: 16px
}.iv5ilf.F8PBrb .v8y8Fe{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;-webkit-flex-shrink: 0;flex-shrink: 0;-webkit-flex-wrap:wrap;flex-wrap:wrap;width: 100%
}.iv5ilf.NNItQ .zdUG4b,.iv5ilf.F8PBrb .v8y8Fe+.zdUG4b{margin-top: 16px
}.iv5ilf:not(.NNItQ) .zdUG4b .HTOaH,.iv5ilf:not(.NNItQ) .zdUG4b .BQxrO,.iv5ilf:not(.NNItQ) .zdUG4b .VnSG3b{text-align:left
}.WoZjZd{display:block;width:calc(100% - 2px)
}.iv5ilf.F8PBrb .Te5wkb{margin: 0 -6px;width:calc(100% + 12px)
}.iv5ilf.F8PBrb .zdUG4b{margin: 0 6px
}.sOXXCe{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;margin: 0 6px;min-width:calc(50% - 12px)
}.WoZjZd{white-space:nowrap;width: 100%
}.WoZjZd .WyRBD,.WoZjZd .ceOhk{display:block
}.HTOaH+.rWJGb,.BQxrO+.rWJGb{margin-top: 32px
}.rWJGb .q6oraf{border-radius: 16px
}.iv5ilf .VnSG3b.u3bW4e{background-color:transparent
}.VnSG3b .snByac{color:var(--gm3-sys-color-primary,#0b57d0);line-height: 1.25rem;margin: 16px;text-transform:none
}.VnSG3b [jsslot
]{margin: 0
}.WoZjZd .WyRBD,.WoZjZd .ceOhk{width: 100%
}.wsArZ[data-ss-mode="1"
] .Cny7p.lUWEgd.F8PBrb{margin-left: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .Cny7p.lUWEgd.F8PBrb{margin-left: 0
    }
}.wsArZ[data-ss-mode="1"
] .Cny7p.lUWEgd.F8PBrb .v8y8Fe{margin-left: 0;padding-left: 0;width:calc(50% - ((var(
    --c-gutw,
    48px
  ))/2) + 12px)
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .Cny7p.lUWEgd.F8PBrb .v8y8Fe{margin-left: 0;padding-left: 0;width:calc(50% - ((var(
    --c-gutw,
        48px
  ))/2) + 12px)
    }
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .Cny7p.lUWEgd.F8PBrb .v8y8Fe{width:calc(50% - ((var(
    --c-gutw,
        76px
  ))/2) + 12px)
    }
}.Cny7p.lUWEgd.F8PBrb .zdUG4b{margin-top: 2px
}.Cny7p.lUWEgd.F8PBrb .Te5wkb{margin: 0 -6px;width:calc(100% + 12px)
}.wsArZ[data-ss-mode="1"
] .Cny7p.lUWEgd.F8PBrb .Te5wkb{-webkit-align-self:flex-end;align-self:flex-end;width: 100%
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .Cny7p.lUWEgd.F8PBrb .Te5wkb{-webkit-align-self:flex-end;align-self:flex-end;width: 100%
    }
}.iv5ilf.F8PBrb.lUWEgd.N0osAb .v8y8Fe{-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-flow:column;flex-flow:column
}.wsArZ[data-ss-mode="1"
] .iv5ilf.F8PBrb.lUWEgd.N0osAb .v8y8Fe{width: 100%
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf.F8PBrb.lUWEgd.N0osAb .v8y8Fe{width: 100%
    }
}.iv5ilf.F8PBrb.lUWEgd.N0osAb .zdUG4b{-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;margin-left: 16px;margin-right: 2px;margin-top: 0
}.wsArZ[data-ss-mode="1"
] .iv5ilf.F8PBrb.lUWEgd.N0osAb .zdUG4b{margin-left: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf.F8PBrb.lUWEgd.N0osAb .zdUG4b{margin-left: 0
    }
}.iv5ilf.F8PBrb.lUWEgd.N0osAb .Te5wkb{-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-flow:column;flex-flow:column
}.wsArZ[data-ss-mode="1"
] .iv5ilf.F8PBrb.lUWEgd.N0osAb .Te5wkb{width:calc(50% - ((var(
    --c-gutw,
    48px
  ))/2) + 12px)
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf.F8PBrb.lUWEgd.N0osAb .Te5wkb{width:calc(50% - ((var(
    --c-gutw,
        48px
  ))/2) + 12px)
    }
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .iv5ilf.F8PBrb.lUWEgd.N0osAb .Te5wkb{width:calc(50% - ((var(
    --c-gutw,
        76px
  ))/2) + 12px)
    }
}.iv5ilf.F8PBrb.lUWEgd.N0osAb .zdUG4b{margin: 0;padding-left: 16px;width:calc(100% - 12px)
}.wsArZ[data-ss-mode="1"
] .iv5ilf.F8PBrb.lUWEgd.N0osAb .zdUG4b{padding-left: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf.F8PBrb.lUWEgd.N0osAb .zdUG4b{padding-left: 0
    }
}.iv5ilf.F8PBrb.N0osAb .HTOaH,.iv5ilf.F8PBrb.N0osAb .HTOaH .WyRBD{display:block;width: 100%
}.iv5ilf.F8PBrb.lUWEgd.N0osAb .WoZjZd .ceOhk,.iv5ilf.F8PBrb.lUWEgd.N0osAb .HTOaH .WyRBD{margin-top: 4px;margin-bottom: 4px
}*,*:before,*:after{-webkit-box-sizing:inherit;box-sizing:inherit
}html{-webkit-box-sizing:border-box;box-sizing:border-box;-webkit-tap-highlight-color:transparent
}body,input,textarea,select,button{color:rgb(32,
    33,
    36);font-family:arial,sans-serif
}body{background:#fff;direction:ltr;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;font-size: 14px;line-height: 1.4286;margin: 0;min-height: 100vh;padding: 0;position:relative
}@media (min-width: 601px){body{-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center
    }
}[data-style=heading
]{color:rgb(32,
    33,
    36);font-size: 16px;font-weight: 500;letter-spacing:.1px;line-height: 1.4286
}.BDEI9 h2:not(.TrZEUc){color:rgb(32,
    33,
    36);font-size: 16px;font-weight: 500;letter-spacing:.1px;line-height: 1.4286
}.BDEI9 .fegW5d a:not(.TrZEUc),.BDEI9 .fegW5d button:not(.TrZEUc){color:rgb(25,
    103,
    210)
}.BDEI9 a{text-decoration:none
}.BDEI9 a:not(.TrZEUc),.BDEI9 button:not(.TrZEUc){border-radius: 4px;color:rgb(26,
    115,
    232);display:inline-block;font-weight: 500;letter-spacing:.25px;outline: 0;position:relative;z-index: 1
}.BDEI9 button:not(.TrZEUc){background-color:transparent;cursor:pointer;padding: 0;text-align:left
}.BDEI9 button:not(.TrZEUc){border: 0
}.BDEI9 button: :-moz-focus-inner{border: 0
}.BDEI9 a:not(.TrZEUc):focus-visible,.BDEI9 button:not(.TrZEUc):focus-visible{outline:none;position:relative
}.BDEI9 a:not(.TrZEUc):focus-visible: :after,.BDEI9 button:not(.TrZEUc):focus-visible: :after{border: 2px solid rgb(24,
    90,
    188);border-radius: 6px;bottom: -4px;-webkit-box-shadow: 0 0 0 2px rgb(232,
    240,
    254);box-shadow: 0 0 0 2px rgb(232,
    240,
    254);content: "";left: -4px;position:absolute;right: -4px;top: -4px
}.BDEI9 a:not(.TrZEUc):focus: :after,.BDEI9 a:not(.TrZEUc):active: :after,.BDEI9 button:not(.TrZEUc):focus: :after,.BDEI9 button:not(.TrZEUc):active: :after{background-color:rgba(26,
    115,
    232,.15);content: "";position:absolute;z-index: -1
}.BDEI9 img:not(.TrZEUc){border: 0;max-height:1.3em;vertical-align:middle
}@media (min-width: 601px){.BDEI9{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;min-height: 100vh;position:relative
    }.BDEI9: :before,.BDEI9: :after{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;content: "";height: 24px
    }.BDEI9: :before{min-height: 30px
    }.BDEI9: :after{min-height: 24px
    }.BDEI9.LZgQXe: :after{min-height: 63.9996px
    }
}.gEc4r{display:-webkit-box;display:-webkit-flex;display:flex;height: 24px;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center
}.gEc4r.jlqJKb{height:auto;min-height: 24px;padding-top: 24px
}.BivnM{-webkit-box-align:center;-webkit-align-items:center;align-items:center;border-bottom: 1px solid #ccc;display:-webkit-box;display:-webkit-flex;display:flex;height: 36px;left: 0;padding: 0 16px;position:absolute;right: 0;top: 0
}.BivnM .ji6sFc{height: 14px;margin-right: 12px
}.O3jdWc{color:rgb(95,
    99,
    104);font-size: 14px;height: 14px;margin-top: -2px
}.Zwk8S{display:block;height: 37px;width: 37px
}.wFNE4e{color:rgb(26,
    115,
    232)
}.HUYFt{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;font-size: 12px;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;padding: 0 24px 14px
}@media (min-width: 601px){.HUYFt{padding-left: 0;padding-right: 0;position:absolute;width: 100%
    }
}.hXs2T .pUP0Nd{color:rgb(60,
    64,
    67)
}.hXs2T{margin-left: -16px;margin-right: 16px
}.N158t{-moz-appearance:none;-webkit-appearance:none;appearance:none;background-color:transparent;background-image:url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGhlaWdodD0iMjRweCIgdmlld0JveD0iMCAwIDI0IDI0IiB3aWR0aD0iMjRweCIgZmlsbD0iIzQ1NUE2NCI+PHBhdGggZD0iTTAgMGgyNHYyNEgwVjB6IiBmaWxsPSJub25lIi8+PHBhdGggZD0iTTcgMTBsNSA1IDUtNUg3eiIvPjwvc3ZnPg==");background-position:right;background-repeat:no-repeat;border:none;border-radius: 4px;color:rgb(95,
    99,
    104);cursor:pointer;font-size: 12px;line-height: 15.9996px;outline:none;padding: 16.0002px 24px 16.0002px 16px
}.N158t:focus{background-color:rgb(232,
    234,
    237)
}.M2nKge{list-style:none;margin: 0 -16px;padding: 0
}.vomtoe{display:inline-block;margin: 0
}.pUP0Nd{background-color:transparent;border-radius: 4px;color:rgb(95,
    99,
    104);display:inline-block;line-height: 15.9996px;outline:none;padding: 16px
}.pUP0Nd:focus{background-color:rgb(232,
    234,
    237)
}.pUP0Nd:focus-visible{outline:none;position:relative
}.pUP0Nd:focus-visible: :after{border: 2px solid rgb(24,
    90,
    188);border-radius: 4px;bottom: -2px;-webkit-box-shadow: 0 0 0 2px rgb(232,
    240,
    254);box-shadow: 0 0 0 2px rgb(232,
    240,
    254);content: "";left: -2px;position:absolute;right: -2px;top: -2px
}.JYXaTc{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;-webkit-flex-wrap:wrap;flex-wrap:wrap;-webkit-box-pack:end;-webkit-justify-content:flex-end;justify-content:flex-end;margin-bottom: -6px;margin-left: -16px;margin-top: 32px
}.wsArZ[data-ss-mode="1"
] .JYXaTc{width: 100%
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc{width: 100%
    }
}.JYXaTc.fXx9Lc{margin: 0;min-height: 0;padding: 0
}.S1zJGd{-webkit-align-self:flex-start;align-self:flex-start;-webkit-flex-shrink: 0;flex-shrink: 0;margin-bottom: 24px
}.O1Slxf{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:row-reverse;flex-direction:row-reverse;-webkit-flex-wrap:wrap;flex-wrap:wrap;width: 100%
}.TNTaPb,.FO2vFd{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .TNTaPb,.wsArZ[data-ss-mode="1"
    ] .FO2vFd{-webkit-box-flex:unset;-webkit-flex-grow:unset;flex-grow:unset
    }
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc:not(.NNItQ) .TNTaPb,.NQ5OL .JYXaTc:not(.NNItQ) .FO2vFd{-webkit-box-flex:unset;-webkit-flex-grow:unset;flex-grow:unset
    }
}.FO2vFd{-webkit-box-pack:flex-start;-webkit-justify-content:flex-start;justify-content:flex-start
}.wsArZ[data-ss-mode="1"
] .FO2vFd{margin-left: 0;margin-right: -16px
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .FO2vFd{margin-left: 0;margin-right: -16px
    }
}.TNTaPb{-webkit-box-pack:flex-end;-webkit-justify-content:flex-end;justify-content:flex-end
}.wsArZ[data-ss-mode="1"
] .TNTaPb{margin-left: 40px;margin-right: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .TNTaPb{margin-left: 40px;margin-right: 0
    }
}.wsArZ[data-ss-mode="1"
] .TNTaPb:empty{margin-left: 0;margin-right: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .TNTaPb:empty{margin-left: 0;margin-right: 0
    }
}.JYXaTc.NNItQ .TNTaPb,.JYXaTc.NNItQ .FO2vFd{-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center
}.JYXaTc.NNItQ .TNTaPb,.JYXaTc.F8PBrb .TNTaPb{padding-left: 16px
}.JYXaTc.F8PBrb .TNTaPb{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;-webkit-flex-shrink: 0;flex-shrink: 0;-webkit-flex-wrap:wrap;flex-wrap:wrap;width: 100%
}.JYXaTc.NNItQ .FO2vFd,.JYXaTc.F8PBrb .TNTaPb+.FO2vFd{margin-top: 16px
}.JYXaTc:not(.NNItQ) .FO2vFd .mWv92d,.JYXaTc:not(.NNItQ) .FO2vFd .JLt0ke,.JYXaTc:not(.NNItQ) .FO2vFd .J7pUA{text-align:left
}.BbN10e{display:block;width:calc(100% - 2px)
}.JYXaTc.F8PBrb .O1Slxf{margin: 0 -6px;width:calc(100% + 12px)
}.JYXaTc.F8PBrb .FO2vFd{margin: 0 6px
}.o3Yfjb{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;margin: 0 6px;min-width:calc(50% - 12px)
}.BbN10e{white-space:nowrap;width: 100%
}.BbN10e .pIzcPc,.BbN10e .Jskylb{display:block
}.mWv92d+.n3Clv,.JLt0ke+.n3Clv{margin-top: 32px
}.n3Clv .q6oraf{border-radius: 16px
}.JYXaTc .J7pUA.u3bW4e{background-color:transparent
}.J7pUA .snByac{color:#0b57d0;color:var(--gm3-sys-color-primary,#0b57d0);line-height: 1.4285714286;margin: 16px;text-transform:none
}.JYXaTc .KMdFve{--mdc-ripple-color:var(--gm3-sys-color-on-surface,#1f1f1f);background-color:var(--gm3-sys-color-surface-container,#f0f4f9)
}.JYXaTc .KMdFve .VfPpkd-BFbNVe-bF1uUb{background-color:var(--gm3-sys-color-surface-tint,#6991d6)
}.JYXaTc .KMdFve .VfPpkd-xl07Ob-ibnC6b-OWXEXe-gk6SMd{background-color:var(--gm3-sys-color-secondary-container,#c2e7ff)
}.gNVsKb{color:#1f1f1f;color:var(--gm3-sys-color-on-surface,#1f1f1f)
}.J7pUA [jsslot
]{margin: 0
}.BbN10e .pIzcPc,.BbN10e .Jskylb{width: 100%
}.wsArZ[data-ss-mode="1"
] .COi2Ke.lUWEgd.F8PBrb{margin-left: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .COi2Ke.lUWEgd.F8PBrb{margin-left: 0
    }
}.wsArZ[data-ss-mode="1"
] .COi2Ke.lUWEgd.F8PBrb .TNTaPb{margin-left: 0;padding-left: 0;width:calc(50% - 24px + 12px)
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .COi2Ke.lUWEgd.F8PBrb .TNTaPb{margin-left: 0;padding-left: 0;width:calc(50% - 24px + 12px)
    }
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .COi2Ke.lUWEgd.F8PBrb .TNTaPb{width:calc(50% - 38px + 12px)
    }
}.COi2Ke.lUWEgd.F8PBrb .FO2vFd{margin-top: 2px
}.COi2Ke.lUWEgd.F8PBrb .O1Slxf{margin: 0 -6px;width:calc(100% + 12px)
}.wsArZ[data-ss-mode="1"
] .COi2Ke.lUWEgd.F8PBrb .O1Slxf{-webkit-align-self:flex-end;align-self:flex-end;width: 100%
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .COi2Ke.lUWEgd.F8PBrb .O1Slxf{-webkit-align-self:flex-end;align-self:flex-end;width: 100%
    }
}.JYXaTc.F8PBrb.lUWEgd.hhh8Yc .FO2vFd{margin-left: 10px;margin-right: 2px
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.hhh8Yc .O1Slxf{-webkit-box-align:end;-webkit-align-items:flex-end;align-items:flex-end;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-flow:column;flex-flow:column
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb.lUWEgd.hhh8Yc .O1Slxf{-webkit-box-align:end;-webkit-align-items:flex-end;align-items:flex-end;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-flow:column;flex-flow:column
    }
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.c0e3be .TNTaPb,.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.c0e3be .FO2vFd{-webkit-box-flex:unset;-webkit-flex-grow:unset;flex-grow:unset
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb.lUWEgd.c0e3be .TNTaPb,.NQ5OL .JYXaTc.F8PBrb.lUWEgd.c0e3be .FO2vFd{-webkit-box-flex:unset;-webkit-flex-grow:unset;flex-grow:unset
    }
}.JYXaTc.F8PBrb.lUWEgd.c0e3be.NNItQ .TNTaPb{width: 100%
}.JYXaTc.F8PBrb.lUWEgd.c0e3be .FO2vFd{-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;padding-left: 16px
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.c0e3be .FO2vFd{-webkit-box-pack:start;-webkit-justify-content:flex-start;justify-content:flex-start;margin-top: 0;margin-right: 6px;padding-left: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb.lUWEgd.c0e3be .FO2vFd{-webkit-box-pack:start;-webkit-justify-content:flex-start;justify-content:flex-start;margin-top: 0;margin-right: 6px;padding-left: 0
    }
}.JYXaTc.F8PBrb.lUWEgd.c0e3be.NNItQ .O1Slxf{-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-flow:column;flex-flow:column
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.c0e3be.NNItQ .O1Slxf{width:calc(50% - 24px + 12px)
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb.lUWEgd.c0e3be.NNItQ .O1Slxf{width:calc(50% - 24px + 12px)
    }
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .JYXaTc.F8PBrb.lUWEgd.c0e3be.NNItQ .O1Slxf{width:calc(50% - 38px + 12px)
    }
}.JYXaTc.F8PBrb.lUWEgd.x8Ikx .TNTaPb,.JYXaTc.F8PBrb.lUWEgd.N0osAb .TNTaPb{-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-flow:column;flex-flow:column
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.x8Ikx .TNTaPb,.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.N0osAb .TNTaPb{width: 100%
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb.lUWEgd.x8Ikx .TNTaPb,.NQ5OL .JYXaTc.F8PBrb.lUWEgd.N0osAb .TNTaPb{width: 100%
    }
}.JYXaTc.F8PBrb.lUWEgd.x8Ikx .FO2vFd,.JYXaTc.F8PBrb.lUWEgd.N0osAb .FO2vFd{-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;margin-left: 16px;margin-right: 2px;margin-top: 0
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.x8Ikx .FO2vFd,.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.N0osAb .FO2vFd{margin-left: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb.lUWEgd.x8Ikx .FO2vFd,.NQ5OL .JYXaTc.F8PBrb.lUWEgd.N0osAb .FO2vFd{margin-left: 0
    }
}.JYXaTc.F8PBrb.lUWEgd.x8Ikx .O1Slxf,.JYXaTc.F8PBrb.lUWEgd.N0osAb .O1Slxf{-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-flow:column;flex-flow:column
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.x8Ikx .O1Slxf,.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.N0osAb .O1Slxf{width:calc(50% - 24px + 12px)
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb.lUWEgd.x8Ikx .O1Slxf,.NQ5OL .JYXaTc.F8PBrb.lUWEgd.N0osAb .O1Slxf{width:calc(50% - 24px + 12px)
    }
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .JYXaTc.F8PBrb.lUWEgd.x8Ikx .O1Slxf,.wsArZ[data-ss-mode="1"
    ] .JYXaTc.F8PBrb.lUWEgd.N0osAb .O1Slxf{width:calc(50% - 38px + 12px)
    }
}.JYXaTc.F8PBrb.lUWEgd.N0osAb .FO2vFd{margin: 0;padding-left: 16px;width:calc(100% - 12px)
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.lUWEgd.N0osAb .FO2vFd{padding-left: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb.lUWEgd.N0osAb .FO2vFd{padding-left: 0
    }
}.JYXaTc.F8PBrb.N0osAb .mWv92d,.JYXaTc.F8PBrb.N0osAb .mWv92d .pIzcPc{display:block;width: 100%
}.JYXaTc.F8PBrb.lUWEgd.N0osAb .BbN10e .Jskylb,.JYXaTc.F8PBrb.lUWEgd.N0osAb .mWv92d .pIzcPc{margin-top: 4px;margin-bottom: 4px
}@media screen and (prefers-color-scheme:dark){.jR8x9d{color-scheme:dark
    }.jR8x9d .Y5O54e{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative
    }.jR8x9d .Y5O54e[hidden
    ]{display:none
    }.jR8x9d .Y5O54e .UMrnmb-lP5Lpb-yrriRe{width:inherit
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 16px;padding-right: 16px
    }[dir=rtl
    ] .jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
    ]{padding-left: 16px;padding-right: 16px
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-f7MjDc{margin-left: 0;margin-right: 8px
    }[dir=rtl
    ] .jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-f7MjDc,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
    ]{margin-left: 8px;margin-right: 0
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb.UMrnmb-h0T7hb-M1Soyc-Bz112c .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 48px;padding-right: 16px
    }[dir=rtl
    ] .jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb.UMrnmb-h0T7hb-M1Soyc-Bz112c .VfPpkd-StrnGf-rymPhb-ibnC6b,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb.UMrnmb-h0T7hb-M1Soyc-Bz112c .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
    ]{padding-left: 16px;padding-right: 48px
    }.jR8x9d .Y5O54e .VfPpkd-xl07Ob-XxIAqe-OWXEXe-uxVfW-FNFY6c-uFfGwd{border-top-left-radius: 0;border-top-right-radius: 0
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:hover .VfPpkd-fmcmS-OyKIhb: :before,.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-fmcmS-OyKIhb: :before{opacity:.08;opacity:var(--mdc-ripple-hover-opacity,.08)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-fmcmS-OyKIhb: :before,.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-fmcmS-OyKIhb: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe .VfPpkd-fmcmS-OyKIhb: :before,.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe .VfPpkd-fmcmS-OyKIhb: :after{background-color:rgb(241,
        243,
        244);background-color:var(--mdc-ripple-color,rgb(241,
        243,
        244))
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd,.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd{color:rgb(154,
        160,
        166)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe .VfPpkd-fmcmS-wGMbrd{caret-color:rgb(138,
        180,
        248)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd{color:rgb(232,
        234,
        237)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me){background-color:rgb(60,
        64,
        67)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(189,
        193,
        198)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(248,
        249,
        250)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(248,
        249,
        250)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(154,
        160,
        166)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :after{border-bottom-color:rgb(138,
        180,
        248)
    }
}@media screen and (prefers-color-scheme:dark){.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledAutocompleteDarkTheme .mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__input: :-webkit-input-placeholder{color:rgb(189,
        193,
        198)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledAutocompleteDarkTheme .mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__input: :-moz-placeholder{color:rgb(189,
        193,
        198)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledAutocompleteDarkTheme .mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__input:-ms-input-placeholder{color:rgb(189,
        193,
        198)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledAutocompleteDarkTheme .mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__input: :-ms-input-placeholder{color:rgb(189,
        193,
        198)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd: :placeholder{color:rgb(189,
        193,
        198)
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd:-ms-input-placeholder{color:rgb(189,
        193,
        198)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-MvKemf-OWXEXe-qdIk2c{color:rgb(154,
        160,
        166)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-MvKemf-OWXEXe-iJ4yB{color:rgb(154,
        160,
        166)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-M1Soyc{color:rgb(154,
        160,
        166)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(154,
        160,
        166)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me{background-color:rgba(232,
        234,
        237,.04)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-NLUYnc-V67aGc,.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-TvZj5c-OWXEXe-M1Soyc,.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg,.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS,.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd,.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd{color:rgba(232,
        234,
        237,.38)
    }
}@media screen and (prefers-color-scheme:dark){.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledAutocompleteDarkTheme .mdc-text-field.mdc-text-field--disabled .mdc-text-field__input: :-webkit-input-placeholder{color:rgba(232,
        234,
        237,.38)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledAutocompleteDarkTheme .mdc-text-field.mdc-text-field--disabled .mdc-text-field__input: :-moz-placeholder{color:rgba(232,
        234,
        237,.38)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledAutocompleteDarkTheme .mdc-text-field.mdc-text-field--disabled .mdc-text-field__input:-ms-input-placeholder{color:rgba(232,
        234,
        237,.38)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledAutocompleteDarkTheme .mdc-text-field.mdc-text-field--disabled .mdc-text-field__input: :-ms-input-placeholder{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd: :placeholder{color:rgba(232,
        234,
        237,.38)
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd:-ms-input-placeholder{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-MvKemf-OWXEXe-qdIk2c,.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-MvKemf-OWXEXe-iJ4yB{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(138,
        180,
        248)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc .VfPpkd-fmcmS-wGMbrd{caret-color:rgb(246,
        174,
        169)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(242,
        139,
        130)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(242,
        139,
        130)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(246,
        174,
        169)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :after{border-bottom-color:rgb(246,
        174,
        169)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(246,
        174,
        169)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(246,
        174,
        169)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(246,
        174,
        169)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(246,
        174,
        169)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe .VfPpkd-NLUYnc-V67aGc{color:rgb(138,
        180,
        248)
    }.jR8x9d .Y5O54e .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(246,
        174,
        169)
    }.jR8x9d .Y5O54e .VfPpkd-xl07Ob-XxIAqe{-webkit-box-shadow: 0 2px 1px -1px rgba(0,
        0,
        0,.2),
        0 1px 1px 0 rgba(0,
        0,
        0,.14),
        0 1px 3px 0 rgba(0,
        0,
        0,.12);box-shadow: 0 2px 1px -1px rgba(0,
        0,
        0,.2),
        0 1px 1px 0 rgba(0,
        0,
        0,.14),
        0 1px 3px 0 rgba(0,
        0,
        0,.12);background-color:rgb(32,
        33,
        36)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb{font-family:Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 400;color:rgb(232,
        234,
        237);position:relative
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-IhFlZd{color:rgb(154,
        160,
        166)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity:.38
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity: 0
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(138,
        180,
        248);background-color:var(--mdc-ripple-color,rgb(138,
        180,
        248))
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic{border-bottom-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:GrayText
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-BFbNVe-bF1uUb{width: 100%;height: 100%;top: 0;left: 0
    }.jR8x9d .Y5O54e .VfPpkd-StrnGf-rymPhb .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .NGdKgb{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;position:relative
    }.jR8x9d .NGdKgb[hidden
    ]{display:none
    }.jR8x9d .NGdKgb .UMrnmb-lP5Lpb-yrriRe{width:inherit
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 16px;padding-right: 16px
    }[dir=rtl
    ] .jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
    ]{padding-left: 16px;padding-right: 16px
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-f7MjDc{margin-left: 0;margin-right: 8px
    }[dir=rtl
    ] .jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-f7MjDc,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb.VfPpkd-StrnGf-rymPhb-OWXEXe-Bz112c-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-f7MjDc[dir=rtl
    ]{margin-left: 8px;margin-right: 0
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb.UMrnmb-h0T7hb-M1Soyc-Bz112c .VfPpkd-StrnGf-rymPhb-ibnC6b{padding-left: 48px;padding-right: 16px
    }[dir=rtl
    ] .jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb.UMrnmb-h0T7hb-M1Soyc-Bz112c .VfPpkd-StrnGf-rymPhb-ibnC6b,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb.UMrnmb-h0T7hb-M1Soyc-Bz112c .VfPpkd-StrnGf-rymPhb-ibnC6b[dir=rtl
    ]{padding-left: 16px;padding-right: 48px
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd{color:rgb(232,
        234,
        237);color:var(--gm-outlinedtextfield-ink-color,rgb(232,
        234,
        237))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe .VfPpkd-fmcmS-wGMbrd{caret-color:rgb(138,
        180,
        248);caret-color:var(--gm-outlinedtextfield-caret-color,rgb(138,
        180,
        248))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(154,
        160,
        166);color:var(--gm-outlinedtextfield-helper-text-color,rgb(154,
        160,
        166))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd{color:rgb(154,
        160,
        166)
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(154,
        160,
        166);color:var(--gm-outlinedtextfield-label-color,rgb(154,
        160,
        166))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(248,
        249,
        250)
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(189,
        193,
        198);border-color:var(--gm-outlinedtextfield-outline-color,rgb(189,
        193,
        198))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(248,
        249,
        250)
    }
}@media screen and (prefers-color-scheme:dark){.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedAutocompleteDarkTheme .mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__input: :-webkit-input-placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedAutocompleteDarkTheme .mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__input: :-moz-placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedAutocompleteDarkTheme .mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__input:-ms-input-placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedAutocompleteDarkTheme .mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__input: :-ms-input-placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd: :placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd:-ms-input-placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-MvKemf-OWXEXe-qdIk2c{color:rgb(154,
        160,
        166);color:var(--gm-outlinedtextfield-prefix-color,rgb(154,
        160,
        166))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-MvKemf-OWXEXe-iJ4yB{color:rgb(154,
        160,
        166);color:var(--gm-outlinedtextfield-suffix-color,rgb(154,
        160,
        166))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-M1Soyc{color:rgb(154,
        160,
        166)
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(154,
        160,
        166)
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-ink-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-NSFCdd-MpmGFe{border-color:rgba(232,
        234,
        237,.12);border-color:var(--gm-outlinedtextfield-outline-color--disabled,rgba(232,
        234,
        237,.12))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-NLUYnc-V67aGc{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-label-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-TvZj5c-OWXEXe-M1Soyc{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-icon-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-icon-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-helper-text-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-character-counter-color--disabled,rgba(232,
        234,
        237,.38))
    }
}@media screen and (prefers-color-scheme:dark){.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedAutocompleteDarkTheme .mdc-text-field.mdc-text-field--disabled .mdc-text-field__input: :-webkit-input-placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedAutocompleteDarkTheme .mdc-text-field.mdc-text-field--disabled .mdc-text-field__input: :-moz-placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedAutocompleteDarkTheme .mdc-text-field.mdc-text-field--disabled .mdc-text-field__input:-ms-input-placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedAutocompleteDarkTheme .mdc-text-field.mdc-text-field--disabled .mdc-text-field__input: :-ms-input-placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd: :placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd:-ms-input-placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-MvKemf-OWXEXe-qdIk2c{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-prefix-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-MvKemf-OWXEXe-iJ4yB{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-suffix-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(138,
        180,
        248);border-color:var(--gm-outlinedtextfield-outline-color--stateful,rgb(138,
        180,
        248))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(138,
        180,
        248);color:var(--gm-outlinedtextfield-label-color--stateful,rgb(138,
        180,
        248))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc .VfPpkd-fmcmS-wGMbrd{caret-color:rgb(242,
        139,
        130);caret-color:var(--gm-outlinedtextfield-caret-color--error,rgb(242,
        139,
        130))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(242,
        139,
        130);color:var(--gm-outlinedtextfield-helper-text-color--error,rgb(242,
        139,
        130))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(246,
        174,
        169)
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(246,
        174,
        169)
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(246,
        174,
        169)
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(246,
        174,
        169)
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(242,
        139,
        130);border-color:var(--gm-outlinedtextfield-outline-color--error,rgb(242,
        139,
        130))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(242,
        139,
        130);color:var(--gm-outlinedtextfield-icon-color--error,rgb(242,
        139,
        130))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(242,
        139,
        130);border-color:var(--gm-outlinedtextfield-outline-color--error-stateful,rgb(242,
        139,
        130))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe .VfPpkd-NLUYnc-V67aGc{color:rgb(138,
        180,
        248);color:var(--gm-outlinedtextfield-label-color--stateful,rgb(138,
        180,
        248))
    }.jR8x9d .NGdKgb .VfPpkd-fmcmS-yrriRe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(242,
        139,
        130);color:var(--gm-outlinedtextfield-label-color--error,rgb(242,
        139,
        130))
    }.jR8x9d .NGdKgb .VfPpkd-xl07Ob-XxIAqe{-webkit-box-shadow: 0 2px 1px -1px rgba(0,
        0,
        0,.2),
        0 1px 1px 0 rgba(0,
        0,
        0,.14),
        0 1px 3px 0 rgba(0,
        0,
        0,.12);box-shadow: 0 2px 1px -1px rgba(0,
        0,
        0,.2),
        0 1px 1px 0 rgba(0,
        0,
        0,.14),
        0 1px 3px 0 rgba(0,
        0,
        0,.12);background-color:rgb(32,
        33,
        36);margin-bottom: 8px
    }.jR8x9d .NGdKgb.UMrnmb-h0T7hb-OWXEXe-di8rgd-V67aGc .VfPpkd-xl07Ob-XxIAqe,.jR8x9d .NGdKgb .VfPpkd-xl07Ob-XxIAqe-OWXEXe-uxVfW-FNFY6c-uFfGwd{margin-bottom: 0
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb{font-family:Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 400;color:rgb(232,
        234,
        237);position:relative
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-IhFlZd{color:rgb(154,
        160,
        166)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity:.38
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity: 0
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(138,
        180,
        248);background-color:var(--mdc-ripple-color,rgb(138,
        180,
        248))
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic{border-bottom-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:GrayText
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-BFbNVe-bF1uUb{width: 100%;height: 100%;top: 0;left: 0
    }.jR8x9d .NGdKgb .VfPpkd-StrnGf-rymPhb .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .DUonjc{background-color:rgb(32,
        33,
        36);border-bottom-color:rgb(95,
        99,
        104)
    }.jR8x9d .DUonjc .VfPpkd-WLXbod{background-color:rgb(32,
        33,
        36)
    }.jR8x9d .DUonjc .VfPpkd-Rj7Y9b{color:rgb(232,
        234,
        237)
    }.jR8x9d .DUonjc .VfPpkd-WLXbod{border-bottom-color:rgb(95,
        99,
        104)
    }.jR8x9d .DUonjc .VfPpkd-r7nwK{color:rgb(32,
        33,
        36)
    }.jR8x9d .DUonjc .VfPpkd-r7nwK{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:not(:disabled){background-color:transparent
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:not(:disabled){color:rgb(138,
        180,
        248);color:var(--gm-colortextbutton-ink-color,rgb(138,
        180,
        248))
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:disabled{color:rgba(232,
        234,
        237,.38);color:var(--gm-colortextbutton-disabled-ink-color,rgba(232,
        234,
        237,.38))
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .DUonjc .VfPpkd-LgbsSe .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(138,
        180,
        248)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .DUonjc .VfPpkd-LgbsSe .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .DUonjc .VfPpkd-LgbsSe .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .DUonjc .VfPpkd-LgbsSe:hover:not(:disabled),.jR8x9d .DUonjc .VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.jR8x9d .DUonjc .VfPpkd-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.jR8x9d .DUonjc .VfPpkd-LgbsSe:active:not(:disabled){color:rgb(174,
        203,
        250);color:var(--gm-colortextbutton-ink-color--stateful,rgb(174,
        203,
        250))
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe .VfPpkd-Jh9lGc: :before,.jR8x9d .DUonjc .VfPpkd-LgbsSe .VfPpkd-Jh9lGc: :after{background-color:rgb(174,
        203,
        250);background-color:var(--gm-colortextbutton-state-color,rgb(174,
        203,
        250))
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .DUonjc .VfPpkd-LgbsSe.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .DUonjc .VfPpkd-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:disabled:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .DUonjc .VfPpkd-LgbsSe:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
        0)
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .DUonjc .VfPpkd-LgbsSe:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .DUonjc .VfPpkd-LgbsSe:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .DUonjc .UMrnmb-jsLfKf-JIbuQc{margin-right: 8px
    }.jR8x9d .AjY5Oe{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none;-webkit-transition:border .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),box-shadow .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);-webkit-box-shadow:none;box-shadow:none
    }.jR8x9d .AjY5Oe .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
    }.jR8x9d .AjY5Oe:not(:disabled){background-color:rgb(138,
        180,
        248);background-color:var(--gm-fillbutton-container-color,rgb(138,
        180,
        248))
    }.jR8x9d .AjY5Oe:not(:disabled){color:rgb(32,
        33,
        36);color:var(--gm-fillbutton-ink-color,rgb(32,
        33,
        36))
    }.jR8x9d .AjY5Oe:disabled{background-color:rgba(232,
        234,
        237,.12);background-color:var(--gm-fillbutton-disabled-container-color,rgba(232,
        234,
        237,.12))
    }.jR8x9d .AjY5Oe:disabled{color:rgba(232,
        234,
        237,.38);color:var(--gm-fillbutton-disabled-ink-color,rgba(232,
        234,
        237,.38))
    }.jR8x9d .AjY5Oe .VfPpkd-Jh9lGc: :before,.jR8x9d .AjY5Oe .VfPpkd-Jh9lGc: :after{background-color:#fff;background-color:var(--gm-fillbutton-state-color,#fff)
    }.jR8x9d .AjY5Oe:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .AjY5Oe.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.16;opacity:var(--mdc-ripple-hover-opacity,.16)
    }.jR8x9d .AjY5Oe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .AjY5Oe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
    }.jR8x9d .AjY5Oe:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .AjY5Oe:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-ripple-press-opacity,.2)
    }.jR8x9d .AjY5Oe.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.2)
    }.jR8x9d .AjY5Oe .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .AjY5Oe .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .AjY5Oe .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(32,
        33,
        36)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .AjY5Oe .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .AjY5Oe .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .AjY5Oe:hover{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-fillbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 1px 3px 1px var(--gm-fillbutton-ambientshadow-color,rgba(0,
        0,
        0,.15));box-shadow: 0 1px 2px 0 var(--gm-fillbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 1px 3px 1px var(--gm-fillbutton-ambientshadow-color,rgba(0,
        0,
        0,.15))
    }.jR8x9d .AjY5Oe:hover .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .AjY5Oe:active{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-fillbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 2px 6px 2px var(--gm-fillbutton-ambientshadow-color,rgba(0,
        0,
        0,.15));box-shadow: 0 1px 2px 0 var(--gm-fillbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 2px 6px 2px var(--gm-fillbutton-ambientshadow-color,rgba(0,
        0,
        0,.15))
    }.jR8x9d .AjY5Oe:active .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .AjY5Oe:disabled{-webkit-box-shadow:none;box-shadow:none
    }.jR8x9d .AjY5Oe:disabled:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .AjY5Oe:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
        0)
    }.jR8x9d .AjY5Oe:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .AjY5Oe:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .AjY5Oe:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .AjY5Oe:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .AjY5Oe:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .AjY5Oe:disabled .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .OLiIxf{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none;-webkit-transition:border .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),box-shadow .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);-webkit-box-shadow:none;box-shadow:none
    }.jR8x9d .OLiIxf .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
    }.jR8x9d .OLiIxf:not(:disabled){color:rgb(138,
        180,
        248);color:var(--gm-hairlinebutton-ink-color,rgb(138,
        180,
        248))
    }.jR8x9d .OLiIxf:not(:disabled){border-color:rgb(95,
        99,
        104);border-color:var(--gm-hairlinebutton-outline-color,rgb(95,
        99,
        104))
    }.jR8x9d .OLiIxf:not(:disabled):hover{border-color:rgb(95,
        99,
        104);border-color:var(--gm-hairlinebutton-outline-color,rgb(95,
        99,
        104))
    }.jR8x9d .OLiIxf:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .OLiIxf:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{border-color:rgb(174,
        203,
        250);border-color:var(--gm-hairlinebutton-outline-color--stateful,rgb(174,
        203,
        250))
    }.jR8x9d .OLiIxf:not(:disabled):active,.jR8x9d .OLiIxf:not(:disabled):focus:active{border-color:rgb(95,
        99,
        104);border-color:var(--gm-hairlinebutton-outline-color,rgb(95,
        99,
        104))
    }.jR8x9d .OLiIxf:disabled{color:rgba(232,
        234,
        237,.38);color:var(--gm-hairlinebutton-disabled-ink-color,rgba(232,
        234,
        237,.38))
    }.jR8x9d .OLiIxf:disabled{border-color:rgba(232,
        234,
        237,.12);border-color:var(--gm-hairlinebutton-disabled-outline-color,rgba(232,
        234,
        237,.12))
    }.jR8x9d .OLiIxf:hover:not(:disabled),.jR8x9d .OLiIxf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.jR8x9d .OLiIxf:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.jR8x9d .OLiIxf:active:not(:disabled){color:rgb(174,
        203,
        250);color:var(--gm-hairlinebutton-ink-color--stateful,rgb(174,
        203,
        250))
    }.jR8x9d .OLiIxf .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .OLiIxf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .OLiIxf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(138,
        180,
        248)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .OLiIxf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .OLiIxf .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .OLiIxf .VfPpkd-Jh9lGc: :before,.jR8x9d .OLiIxf .VfPpkd-Jh9lGc: :after{background-color:rgb(138,
        180,
        248);background-color:var(--gm-hairlinebutton-state-color,rgb(138,
        180,
        248))
    }.jR8x9d .OLiIxf:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .OLiIxf.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .OLiIxf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .OLiIxf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .OLiIxf:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .OLiIxf:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .OLiIxf.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .OLiIxf:disabled:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .OLiIxf:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
        0)
    }.jR8x9d .OLiIxf:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .OLiIxf:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .OLiIxf:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .OLiIxf:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .OLiIxf:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .MQas1c{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none;-webkit-transition:border .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),box-shadow .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 1px 3px 1px var(--gm-protectedbutton-ambientshadow-color,rgba(0,
        0,
        0,.15));box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 1px 3px 1px var(--gm-protectedbutton-ambientshadow-color,rgba(0,
        0,
        0,.15))
    }.jR8x9d .MQas1c .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
    }.jR8x9d .MQas1c:not(:disabled){background-color:rgb(32,
        33,
        36);background-color:var(--gm-protectedbutton-container-color,rgb(32,
        33,
        36))
    }.jR8x9d .MQas1c:not(:disabled){color:rgb(138,
        180,
        248);color:var(--gm-protectedbutton-ink-color,rgb(138,
        180,
        248))
    }.jR8x9d .MQas1c:disabled{background-color:rgba(232,
        234,
        237,.12);background-color:var(--gm-protectedbutton-disabled-container-color,rgba(232,
        234,
        237,.12))
    }.jR8x9d .MQas1c:disabled{color:rgba(232,
        234,
        237,.38);color:var(--gm-protectedbutton-disabled-ink-color,rgba(232,
        234,
        237,.38))
    }.jR8x9d .MQas1c:hover:not(:disabled),.jR8x9d .MQas1c.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.jR8x9d .MQas1c:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.jR8x9d .MQas1c:active:not(:disabled){color:rgb(174,
        203,
        250);color:var(--gm-protectedbutton-ink-color--stateful,rgb(174,
        203,
        250))
    }.jR8x9d .MQas1c .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .MQas1c .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .MQas1c .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(138,
        180,
        248)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .MQas1c .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .MQas1c .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .MQas1c.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .MQas1c:not(.VfPpkd-ksKsZd-mWPk3d):focus{border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 1px 3px 1px var(--gm-protectedbutton-ambientshadow-color,rgba(0,
        0,
        0,.15));box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 1px 3px 1px var(--gm-protectedbutton-ambientshadow-color,rgba(0,
        0,
        0,.15))
    }.jR8x9d .MQas1c.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-BFbNVe-bF1uUb,.jR8x9d .MQas1c:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .MQas1c:hover{border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 2px 6px 2px var(--gm-protectedbutton-ambientshadow-color,rgba(0,
        0,
        0,.15));box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 2px 6px 2px var(--gm-protectedbutton-ambientshadow-color,rgba(0,
        0,
        0,.15))
    }.jR8x9d .MQas1c:hover .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .MQas1c:not(:disabled):active{border-width: 0;-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);-webkit-box-shadow: 0 1px 3px 0 var(--gm-protectedbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 4px 8px 3px var(--gm-protectedbutton-ambientshadow-color,rgba(0,
        0,
        0,.15));box-shadow: 0 1px 3px 0 var(--gm-protectedbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 4px 8px 3px var(--gm-protectedbutton-ambientshadow-color,rgba(0,
        0,
        0,.15))
    }.jR8x9d .MQas1c:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .MQas1c .VfPpkd-Jh9lGc: :before,.jR8x9d .MQas1c .VfPpkd-Jh9lGc: :after{background-color:rgb(174,
        203,
        250);background-color:var(--gm-protectedbutton-state-color,rgb(174,
        203,
        250))
    }.jR8x9d .MQas1c:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .MQas1c.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .MQas1c.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .MQas1c:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .MQas1c:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .MQas1c:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .MQas1c.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .MQas1c:disabled{border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);-webkit-box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 1px 3px 1px var(--gm-protectedbutton-ambientshadow-color,rgba(0,
        0,
        0,.15));box-shadow: 0 1px 2px 0 var(--gm-protectedbutton-keyshadow-color,rgba(0,
        0,
        0,.3)),
        0 1px 3px 1px var(--gm-protectedbutton-ambientshadow-color,rgba(0,
        0,
        0,.15))
    }.jR8x9d .MQas1c:disabled .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .MQas1c:disabled:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .MQas1c:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
        0)
    }.jR8x9d .MQas1c:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .MQas1c:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .MQas1c:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .MQas1c:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .MQas1c:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .C1Uh5b{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none;-webkit-transition:border .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),box-shadow .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);-webkit-box-shadow:none;box-shadow:none
    }.jR8x9d .C1Uh5b .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
    }.jR8x9d .C1Uh5b:not(:disabled){background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .C1Uh5b:not(:disabled){color:rgb(210,
        227,
        252)
    }.jR8x9d .C1Uh5b:disabled{background-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .C1Uh5b:disabled{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .C1Uh5b:hover:not(:disabled),.jR8x9d .C1Uh5b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.jR8x9d .C1Uh5b:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.jR8x9d .C1Uh5b:active:not(:disabled){color:#fff
    }.jR8x9d .C1Uh5b .VfPpkd-Jh9lGc: :before,.jR8x9d .C1Uh5b .VfPpkd-Jh9lGc: :after{background-color:#fff;background-color:var(--mdc-ripple-color,#fff)
    }.jR8x9d .C1Uh5b:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .C1Uh5b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .C1Uh5b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .C1Uh5b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .C1Uh5b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .C1Uh5b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .C1Uh5b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .C1Uh5b .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .C1Uh5b .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .C1Uh5b .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(210,
        227,
        252)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .C1Uh5b .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .C1Uh5b .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .C1Uh5b:hover{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .C1Uh5b:hover .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .C1Uh5b:not(:disabled):active{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .C1Uh5b:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .C1Uh5b:disabled{-webkit-box-shadow:none;box-shadow:none
    }.jR8x9d .C1Uh5b:disabled .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .C1Uh5b:disabled:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .C1Uh5b:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
        0)
    }.jR8x9d .C1Uh5b:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .C1Uh5b:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .C1Uh5b:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .C1Uh5b:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .C1Uh5b:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .lKxP2d{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none
    }.jR8x9d .lKxP2d .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
    }.jR8x9d .lKxP2d:not(:disabled){background-color:transparent
    }.jR8x9d .lKxP2d:not(:disabled){color:rgb(138,
        180,
        248);color:var(--gm-colortextbutton-ink-color,rgb(138,
        180,
        248))
    }.jR8x9d .lKxP2d:disabled{color:rgba(232,
        234,
        237,.38);color:var(--gm-colortextbutton-disabled-ink-color,rgba(232,
        234,
        237,.38))
    }.jR8x9d .lKxP2d .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .lKxP2d .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(138,
        180,
        248)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .lKxP2d .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .lKxP2d .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .lKxP2d:hover:not(:disabled),.jR8x9d .lKxP2d.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.jR8x9d .lKxP2d:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.jR8x9d .lKxP2d:active:not(:disabled){color:rgb(174,
        203,
        250);color:var(--gm-colortextbutton-ink-color--stateful,rgb(174,
        203,
        250))
    }.jR8x9d .lKxP2d .VfPpkd-Jh9lGc: :before,.jR8x9d .lKxP2d .VfPpkd-Jh9lGc: :after{background-color:rgb(174,
        203,
        250);background-color:var(--gm-colortextbutton-state-color,rgb(174,
        203,
        250))
    }.jR8x9d .lKxP2d:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .lKxP2d.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .lKxP2d.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .lKxP2d:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .lKxP2d:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .lKxP2d:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .lKxP2d.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .lKxP2d:disabled:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .lKxP2d:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
        0)
    }.jR8x9d .lKxP2d:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .lKxP2d:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .lKxP2d:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .lKxP2d:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .lKxP2d:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .XhPA0b{font-family: "Google Sans",Roboto,Arial,sans-serif;font-size:.875rem;letter-spacing:.0107142857em;font-weight: 500;text-transform:none
    }.jR8x9d .XhPA0b .VfPpkd-Jh9lGc{height: 100%;position:absolute;overflow:hidden;width: 100%;z-index: 0
    }.jR8x9d .XhPA0b:not(:disabled){color:rgb(232,
        234,
        237);color:var(--gm-neutraltextbutton-ink-color,rgb(232,
        234,
        237))
    }.jR8x9d .XhPA0b:disabled{color:rgba(232,
        234,
        237,.38);color:var(--gm-neutraltextbutton-disabled-ink-color,rgba(232,
        234,
        237,.38))
    }.jR8x9d .XhPA0b:hover:not(:disabled),.jR8x9d .XhPA0b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.jR8x9d .XhPA0b:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.jR8x9d .XhPA0b:active:not(:disabled){color:rgb(248,
        249,
        250);color:var(--gm-neutraltextbutton-ink-color--stateful,rgb(248,
        249,
        250))
    }.jR8x9d .XhPA0b .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .XhPA0b .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(232,
        234,
        237)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .XhPA0b .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .XhPA0b .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .XhPA0b .VfPpkd-Jh9lGc: :before,.jR8x9d .XhPA0b .VfPpkd-Jh9lGc: :after{background-color:rgb(232,
        234,
        237);background-color:var(--gm-neutraltextbutton-state-color,rgb(232,
        234,
        237))
    }.jR8x9d .XhPA0b:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .XhPA0b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .XhPA0b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .XhPA0b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .XhPA0b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .XhPA0b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .XhPA0b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .XhPA0b:disabled:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .XhPA0b:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
        0)
    }.jR8x9d .XhPA0b:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .XhPA0b:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .XhPA0b:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .XhPA0b:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .XhPA0b:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .eT1oJ{z-index: 0
    }.jR8x9d .eT1oJ .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .eT1oJ .VfPpkd-Bz112c-Jh9lGc: :after{z-index: -1
    }.jR8x9d .eT1oJ:disabled{color:rgba(232,
        234,
        237,.38);color:var(--gm-iconbutton-disabled-ink-color,rgba(232,
        234,
        237,.38))
    }.jR8x9d .eT1oJ .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .eT1oJ .VfPpkd-Bz112c-Jh9lGc: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .eT1oJ:hover .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .eT1oJ.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Bz112c-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .eT1oJ.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .eT1oJ:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .eT1oJ:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .eT1oJ:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .eT1oJ.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .eT1oJ:disabled:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .eT1oJ:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
        0)
    }.jR8x9d .eT1oJ:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .eT1oJ:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .eT1oJ:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .eT1oJ:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .eT1oJ:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .tmJved{z-index: 0
    }.jR8x9d .tmJved .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .tmJved .VfPpkd-Bz112c-Jh9lGc: :after{z-index: -1
    }.jR8x9d .tmJved:disabled{color:rgba(232,
        234,
        237,.38);color:var(--gm-iconbutton-disabled-ink-color,rgba(232,
        234,
        237,.38))
    }.jR8x9d .tmJved .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .tmJved .VfPpkd-Bz112c-Jh9lGc: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .tmJved:hover .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .tmJved.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Bz112c-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .tmJved.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .tmJved:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .tmJved:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .tmJved:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .tmJved.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .tmJved:disabled:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .tmJved:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
        0)
    }.jR8x9d .tmJved:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .tmJved:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .tmJved:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .tmJved:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .tmJved:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .AaN0Dd{background-color:rgb(32,
        33,
        36);border: 1px solid rgb(95,
        99,
        104);-webkit-box-shadow:none;box-shadow:none
    }.jR8x9d .AaN0Dd .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .AaN0Dd .VfPpkd-EScbFb-JIbuQc .VfPpkd-FJ5hab: :before,.jR8x9d .AaN0Dd .VfPpkd-EScbFb-JIbuQc .VfPpkd-FJ5hab: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .AaN0Dd .VfPpkd-EScbFb-JIbuQc:hover .VfPpkd-FJ5hab: :before,.jR8x9d .AaN0Dd .VfPpkd-EScbFb-JIbuQc.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-FJ5hab: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .AaN0Dd .VfPpkd-EScbFb-JIbuQc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-FJ5hab: :before,.jR8x9d .AaN0Dd .VfPpkd-EScbFb-JIbuQc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-FJ5hab: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .AaN0Dd .VfPpkd-EScbFb-JIbuQc:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-FJ5hab: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .AaN0Dd .VfPpkd-EScbFb-JIbuQc:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-FJ5hab: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .AaN0Dd .VfPpkd-EScbFb-JIbuQc.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .AaN0Dd .VfPpkd-gBNGNe{z-index: 1
    }.jR8x9d .BKdRne{background-color:rgb(32,
        33,
        36);border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .BKdRne .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .BKdRne .VfPpkd-EScbFb-JIbuQc .VfPpkd-FJ5hab: :before,.jR8x9d .BKdRne .VfPpkd-EScbFb-JIbuQc .VfPpkd-FJ5hab: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .BKdRne .VfPpkd-EScbFb-JIbuQc:hover .VfPpkd-FJ5hab: :before,.jR8x9d .BKdRne .VfPpkd-EScbFb-JIbuQc.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-FJ5hab: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .BKdRne .VfPpkd-EScbFb-JIbuQc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-FJ5hab: :before,.jR8x9d .BKdRne .VfPpkd-EScbFb-JIbuQc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-FJ5hab: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .BKdRne .VfPpkd-EScbFb-JIbuQc:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-FJ5hab: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .BKdRne .VfPpkd-EScbFb-JIbuQc:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-FJ5hab: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .BKdRne .VfPpkd-EScbFb-JIbuQc.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .BKdRne .VfPpkd-gBNGNe{z-index: 1
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe[disabled
    ]:not(:checked):not(:indeterminate):not([data-indeterminate=true
    ])~.VfPpkd-YQoJzd{border-color:rgba(232,
        234,
        237,.38);border-color:var(--mdc-checkbox-disabled-unselected-icon-color,rgba(232,
        234,
        237,.38));background-color:transparent
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe[disabled
    ]:checked~.VfPpkd-YQoJzd,.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe[disabled
    ]:indeterminate~.VfPpkd-YQoJzd,.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true
    ][disabled
    ]~.VfPpkd-YQoJzd{border-color:transparent;background-color:rgba(232,
        234,
        237,.38);background-color:var(--mdc-checkbox-disabled-selected-icon-color,rgba(232,
        234,
        237,.38))
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd .VfPpkd-HUofsb{color:#202124;color:var(--mdc-checkbox-selected-checkmark-color,#202124)
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd .VfPpkd-SJnn3d{border-color:#202124;border-color:var(--mdc-checkbox-selected-checkmark-color,#202124)
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:disabled~.VfPpkd-YQoJzd .VfPpkd-HUofsb{color:#202124;color:var(--mdc-checkbox-disabled-selected-checkmark-color,#202124)
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:disabled~.VfPpkd-YQoJzd .VfPpkd-SJnn3d{border-color:#202124;border-color:var(--mdc-checkbox-disabled-selected-checkmark-color,#202124)
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:enabled:not(:checked):not(:indeterminate):not([data-indeterminate=true
    ])~.VfPpkd-YQoJzd{border-color:#9aa0a6;border-color:var(--mdc-checkbox-unselected-icon-color,#9aa0a6);background-color:transparent
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:enabled:checked~.VfPpkd-YQoJzd,.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:enabled:indeterminate~.VfPpkd-YQoJzd,.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true
    ]:enabled~.VfPpkd-YQoJzd{border-color:#8ab4f8;border-color:var(--mdc-checkbox-selected-icon-color,#8ab4f8);background-color:#8ab4f8;background-color:var(--mdc-checkbox-selected-icon-color,#8ab4f8)
    }@-webkit-keyframes mdc-checkbox-fade-in-background-FF9AA0A6FF8AB4F800000000FF8AB4F8{
        0%{border-color:#9aa0a6;border-color:var(--mdc-checkbox-unselected-icon-color,#9aa0a6);background-color:transparent
        }50%{border-color:#8ab4f8;border-color:var(--mdc-checkbox-selected-icon-color,#8ab4f8);background-color:#8ab4f8;background-color:var(--mdc-checkbox-selected-icon-color,#8ab4f8)
        }
    }@keyframes mdc-checkbox-fade-in-background-FF9AA0A6FF8AB4F800000000FF8AB4F8{
        0%{border-color:#9aa0a6;border-color:var(--mdc-checkbox-unselected-icon-color,#9aa0a6);background-color:transparent
        }50%{border-color:#8ab4f8;border-color:var(--mdc-checkbox-selected-icon-color,#8ab4f8);background-color:#8ab4f8;background-color:var(--mdc-checkbox-selected-icon-color,#8ab4f8)
        }
    }@-webkit-keyframes mdc-checkbox-fade-out-background-FF9AA0A6FF8AB4F800000000FF8AB4F8{
        0%,
        80%{border-color:#8ab4f8;border-color:var(--mdc-checkbox-selected-icon-color,#8ab4f8);background-color:#8ab4f8;background-color:var(--mdc-checkbox-selected-icon-color,#8ab4f8)
        }100%{border-color:#9aa0a6;border-color:var(--mdc-checkbox-unselected-icon-color,#9aa0a6);background-color:transparent
        }
    }@keyframes mdc-checkbox-fade-out-background-FF9AA0A6FF8AB4F800000000FF8AB4F8{
        0%,
        80%{border-color:#8ab4f8;border-color:var(--mdc-checkbox-selected-icon-color,#8ab4f8);background-color:#8ab4f8;background-color:var(--mdc-checkbox-selected-icon-color,#8ab4f8)
        }100%{border-color:#9aa0a6;border-color:var(--mdc-checkbox-unselected-icon-color,#9aa0a6);background-color:transparent
        }
    }.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-barxie .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-A9y3zc .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{-webkit-animation-name:mdc-checkbox-fade-in-background-FF9AA0A6FF8AB4F800000000FF8AB4F8;animation-name:mdc-checkbox-fade-in-background-FF9AA0A6FF8AB4F800000000FF8AB4F8
    }.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-vwu2ne-barxie-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-vwu2ne-A9y3zc-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{-webkit-animation-name:mdc-checkbox-fade-out-background-FF9AA0A6FF8AB4F800000000FF8AB4F8;animation-name:mdc-checkbox-fade-out-background-FF9AA0A6FF8AB4F800000000FF8AB4F8
    }.jR8x9d .swXlm:hover .VfPpkd-muHVFf-bMcfAe:enabled:not(:checked):not(:indeterminate):not([data-indeterminate=true
    ])~.VfPpkd-YQoJzd{border-color:#f8f9fa;border-color:var(--mdc-checkbox-unselected-hover-icon-color,#f8f9fa);background-color:transparent
    }.jR8x9d .swXlm:hover .VfPpkd-muHVFf-bMcfAe:enabled:checked~.VfPpkd-YQoJzd,.jR8x9d .swXlm:hover .VfPpkd-muHVFf-bMcfAe:enabled:indeterminate~.VfPpkd-YQoJzd,.jR8x9d .swXlm:hover .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true
    ]:enabled~.VfPpkd-YQoJzd{border-color:#aecbfa;border-color:var(--mdc-checkbox-selected-hover-icon-color,#aecbfa);background-color:#aecbfa;background-color:var(--mdc-checkbox-selected-hover-icon-color,#aecbfa)
    }@-webkit-keyframes mdc-checkbox-fade-in-background-FFF8F9FAFFAECBFA00000000FFAECBFA{
        0%{border-color:#f8f9fa;border-color:var(--mdc-checkbox-unselected-hover-icon-color,#f8f9fa);background-color:transparent
        }50%{border-color:#aecbfa;border-color:var(--mdc-checkbox-selected-hover-icon-color,#aecbfa);background-color:#aecbfa;background-color:var(--mdc-checkbox-selected-hover-icon-color,#aecbfa)
        }
    }@-webkit-keyframes mdc-checkbox-fade-out-background-FFF8F9FAFFAECBFA00000000FFAECBFA{
        0%,
        80%{border-color:#aecbfa;border-color:var(--mdc-checkbox-selected-hover-icon-color,#aecbfa);background-color:#aecbfa;background-color:var(--mdc-checkbox-selected-hover-icon-color,#aecbfa)
        }100%{border-color:#f8f9fa;border-color:var(--mdc-checkbox-unselected-hover-icon-color,#f8f9fa);background-color:transparent
        }
    }.jR8x9d .swXlm:hover.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-barxie .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm:hover.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-A9y3zc .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{-webkit-animation-name:mdc-checkbox-fade-in-background-FFF8F9FAFFAECBFA00000000FFAECBFA;animation-name:mdc-checkbox-fade-in-background-FFF8F9FAFFAECBFA00000000FFAECBFA
    }.jR8x9d .swXlm:hover.VfPpkd-MPu53c-OWXEXe-vwu2ne-barxie-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm:hover.VfPpkd-MPu53c-OWXEXe-vwu2ne-A9y3zc-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{-webkit-animation-name:mdc-checkbox-fade-out-background-FFF8F9FAFFAECBFA00000000FFAECBFA;animation-name:mdc-checkbox-fade-out-background-FFF8F9FAFFAECBFA00000000FFAECBFA
    }.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-muHVFf-bMcfAe:enabled:not(:checked):not(:indeterminate):not([data-indeterminate=true
    ])~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-muHVFf-bMcfAe:enabled:not(:checked):not(:indeterminate):not([data-indeterminate=true
    ])~.VfPpkd-YQoJzd{border-color:#f8f9fa;border-color:var(--mdc-checkbox-unselected-focus-icon-color,#f8f9fa);background-color:transparent
    }.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-muHVFf-bMcfAe:enabled:checked~.VfPpkd-YQoJzd,.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-muHVFf-bMcfAe:enabled:indeterminate~.VfPpkd-YQoJzd,.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true
    ]:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-muHVFf-bMcfAe:enabled:checked~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-muHVFf-bMcfAe:enabled:indeterminate~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true
    ]:enabled~.VfPpkd-YQoJzd{border-color:#aecbfa;border-color:var(--mdc-checkbox-selected-focus-icon-color,#aecbfa);background-color:#aecbfa;background-color:var(--mdc-checkbox-selected-focus-icon-color,#aecbfa)
    }.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-barxie .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-A9y3zc .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d):focus.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-barxie .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d):focus.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-A9y3zc .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{-webkit-animation-name:mdc-checkbox-fade-in-background-FFF8F9FAFFAECBFA00000000FFAECBFA;animation-name:mdc-checkbox-fade-in-background-FFF8F9FAFFAECBFA00000000FFAECBFA
    }.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-vwu2ne-barxie-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-vwu2ne-A9y3zc-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d):focus.VfPpkd-MPu53c-OWXEXe-vwu2ne-barxie-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d):focus.VfPpkd-MPu53c-OWXEXe-vwu2ne-A9y3zc-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{-webkit-animation-name:mdc-checkbox-fade-out-background-FFF8F9FAFFAECBFA00000000FFAECBFA;animation-name:mdc-checkbox-fade-out-background-FFF8F9FAFFAECBFA00000000FFAECBFA
    }.jR8x9d .swXlm:not(:disabled):active .VfPpkd-muHVFf-bMcfAe:enabled:not(:checked):not(:indeterminate):not([data-indeterminate=true
    ])~.VfPpkd-YQoJzd{border-color:#f8f9fa;border-color:var(--mdc-checkbox-unselected-pressed-icon-color,#f8f9fa);background-color:transparent
    }.jR8x9d .swXlm:not(:disabled):active .VfPpkd-muHVFf-bMcfAe:enabled:checked~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(:disabled):active .VfPpkd-muHVFf-bMcfAe:enabled:indeterminate~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(:disabled):active .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true
    ]:enabled~.VfPpkd-YQoJzd{border-color:#aecbfa;border-color:var(--mdc-checkbox-selected-pressed-icon-color,#aecbfa);background-color:#aecbfa;background-color:var(--mdc-checkbox-selected-pressed-icon-color,#aecbfa)
    }@keyframes mdc-checkbox-fade-in-background-FFF8F9FAFFAECBFA00000000FFAECBFA{
        0%{border-color:#f8f9fa;border-color:var(--mdc-checkbox-unselected-pressed-icon-color,#f8f9fa);background-color:transparent
        }50%{border-color:#aecbfa;border-color:var(--mdc-checkbox-selected-pressed-icon-color,#aecbfa);background-color:#aecbfa;background-color:var(--mdc-checkbox-selected-pressed-icon-color,#aecbfa)
        }
    }@keyframes mdc-checkbox-fade-out-background-FFF8F9FAFFAECBFA00000000FFAECBFA{
        0%,
        80%{border-color:#aecbfa;border-color:var(--mdc-checkbox-selected-pressed-icon-color,#aecbfa);background-color:#aecbfa;background-color:var(--mdc-checkbox-selected-pressed-icon-color,#aecbfa)
        }100%{border-color:#f8f9fa;border-color:var(--mdc-checkbox-unselected-pressed-icon-color,#f8f9fa);background-color:transparent
        }
    }.jR8x9d .swXlm:not(:disabled):active.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-barxie .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(:disabled):active.VfPpkd-MPu53c-OWXEXe-vwu2ne-iAfbIe-A9y3zc .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{-webkit-animation-name:mdc-checkbox-fade-in-background-FFF8F9FAFFAECBFA00000000FFAECBFA;animation-name:mdc-checkbox-fade-in-background-FFF8F9FAFFAECBFA00000000FFAECBFA
    }.jR8x9d .swXlm:not(:disabled):active.VfPpkd-MPu53c-OWXEXe-vwu2ne-barxie-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd,.jR8x9d .swXlm:not(:disabled):active.VfPpkd-MPu53c-OWXEXe-vwu2ne-A9y3zc-iAfbIe .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd{-webkit-animation-name:mdc-checkbox-fade-out-background-FFF8F9FAFFAECBFA00000000FFAECBFA;animation-name:mdc-checkbox-fade-out-background-FFF8F9FAFFAECBFA00000000FFAECBFA
    }.jR8x9d .swXlm .VfPpkd-OYHm6b: :before,.jR8x9d .swXlm .VfPpkd-OYHm6b: :after{background-color:#e8eaed;background-color:var(--mdc-checkbox-unselected-hover-state-layer-color,#e8eaed)
    }.jR8x9d .swXlm:hover .VfPpkd-OYHm6b: :before,.jR8x9d .swXlm.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-OYHm6b: :before{opacity:.04;opacity:var(--mdc-checkbox-unselected-hover-state-layer-opacity,.04)
    }.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-OYHm6b: :before,.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-OYHm6b: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-checkbox-unselected-focus-state-layer-opacity,.12)
    }.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-OYHm6b: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .swXlm:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-OYHm6b: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-checkbox-unselected-pressed-state-layer-opacity,.1)
    }.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-checkbox-unselected-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .swXlm .VfPpkd-OYHm6b: :before{background-color:#e8eaed;background-color:var(--mdc-checkbox-unselected-hover-state-layer-color,#e8eaed)
    }.jR8x9d .swXlm .VfPpkd-OYHm6b: :after{background-color:#8ab4f8;background-color:var(--mdc-checkbox-unselected-pressed-state-layer-color,#8ab4f8)
    }.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-gk6SMd .VfPpkd-OYHm6b: :before,.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-gk6SMd .VfPpkd-OYHm6b: :after{background-color:#8ab4f8;background-color:var(--mdc-checkbox-selected-hover-state-layer-color,#8ab4f8)
    }.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-gk6SMd:hover .VfPpkd-OYHm6b: :before,.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-OYHm6b: :before{opacity:.04;opacity:var(--mdc-checkbox-selected-hover-state-layer-opacity,.04)
    }.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-OYHm6b: :before,.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-OYHm6b: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-checkbox-selected-focus-state-layer-opacity,.12)
    }.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-OYHm6b: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-OYHm6b: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-checkbox-selected-pressed-state-layer-opacity,.1)
    }.jR8x9d .swXlm.VfPpkd-MPu53c-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-checkbox-selected-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-gk6SMd .VfPpkd-OYHm6b: :before,.jR8x9d .swXlm.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-MPu53c-OWXEXe-gk6SMd .VfPpkd-OYHm6b: :after{background-color:#8ab4f8;background-color:var(--mdc-checkbox-selected-hover-state-layer-color,#8ab4f8)
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe[disabled
    ]:not(:checked):not(:indeterminate):not([data-indeterminate=true
    ])~.VfPpkd-YQoJzd{border-color:GrayText;border-color:var(--mdc-checkbox-disabled-unselected-icon-color,GrayText);background-color:transparent
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe[disabled
    ]:checked~.VfPpkd-YQoJzd,.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe[disabled
    ]:indeterminate~.VfPpkd-YQoJzd,.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe[data-indeterminate=true
    ][disabled
    ]~.VfPpkd-YQoJzd{border-color:GrayText;background-color:GrayText;background-color:var(--mdc-checkbox-disabled-selected-icon-color,GrayText)
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd .VfPpkd-HUofsb{color:ButtonText;color:var(--mdc-checkbox-selected-checkmark-color,ButtonText)
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:enabled~.VfPpkd-YQoJzd .VfPpkd-SJnn3d{border-color:ButtonText;border-color:var(--mdc-checkbox-selected-checkmark-color,ButtonText)
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:disabled~.VfPpkd-YQoJzd .VfPpkd-HUofsb{color:ButtonFace;color:var(--mdc-checkbox-disabled-selected-checkmark-color,ButtonFace)
    }.jR8x9d .swXlm .VfPpkd-muHVFf-bMcfAe:disabled~.VfPpkd-YQoJzd .VfPpkd-SJnn3d{border-color:ButtonFace;border-color:var(--mdc-checkbox-disabled-selected-checkmark-color,ButtonFace)
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .MhRzze{font-family: "Google Sans",Roboto,Arial,sans-serif;line-height: 1.25rem;font-size:.875rem;letter-spacing:.0178571429em;font-weight: 500;-webkit-transition:-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:box-shadow .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);z-index: 0;color:rgb(154,
        160,
        166);color:var(--gm-chip-ink-color,rgb(154,
        160,
        166))
    }.jR8x9d .MhRzze.VfPpkd-XPtOyb-OWXEXe-SNIJTd{-webkit-transition:opacity 75ms cubic-bezier(.4,
        0,.2,
        1),width .15s cubic-bezier(0,
        0,.2,
        1),padding .1s linear,margin .1s linear,-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:opacity 75ms cubic-bezier(.4,
        0,.2,
        1),width .15s cubic-bezier(0,
        0,.2,
        1),padding .1s linear,margin .1s linear,-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:box-shadow .28s cubic-bezier(.4,
        0,.2,
        1),opacity 75ms cubic-bezier(.4,
        0,.2,
        1),width .15s cubic-bezier(0,
        0,.2,
        1),padding .1s linear,margin .1s linear;transition:box-shadow .28s cubic-bezier(.4,
        0,.2,
        1),opacity 75ms cubic-bezier(.4,
        0,.2,
        1),width .15s cubic-bezier(0,
        0,.2,
        1),padding .1s linear,margin .1s linear,-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1)
    }.jR8x9d .MhRzze .VfPpkd-v1cqY: :before,.jR8x9d .MhRzze .VfPpkd-v1cqY: :after{z-index: -1
    }.jR8x9d .MhRzze .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc{color:#9aa0a6
    }.jR8x9d .MhRzze .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc{color:rgb(154,
        160,
        166);color:var(--gm-chip-ink-color,rgb(154,
        160,
        166))
    }.jR8x9d .MhRzze .VfPpkd-Zr1Nwf-OWXEXe-UbuQg{color:#9aa0a6
    }.jR8x9d .MhRzze .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover{color:#9aa0a6
    }.jR8x9d .MhRzze .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus{color:#9aa0a6
    }.jR8x9d .MhRzze .VfPpkd-PvL5qd-Jt5cK{stroke:rgb(154,
        160,
        166);stroke:var(--gm-chip-ink-color,rgb(154,
        160,
        166))
    }.jR8x9d .MhRzze:hover,.jR8x9d .MhRzze.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .MhRzze:not(.VfPpkd-ksKsZd-mWPk3d):focus,.jR8x9d .MhRzze:active{color:rgb(232,
        234,
        237);color:var(--gm-chip-ink-color--stateful,rgb(232,
        234,
        237))
    }.jR8x9d .MhRzze:hover .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc,.jR8x9d .MhRzze.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc,.jR8x9d .MhRzze:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc,.jR8x9d .MhRzze:active .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc{color:#e8eaed
    }.jR8x9d .MhRzze:hover .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc,.jR8x9d .MhRzze.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc,.jR8x9d .MhRzze:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc,.jR8x9d .MhRzze:active .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc{color:rgb(232,
        234,
        237);color:var(--gm-chip-ink-color--stateful,rgb(232,
        234,
        237))
    }.jR8x9d .MhRzze:hover .VfPpkd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .MhRzze.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .MhRzze:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .MhRzze:active .VfPpkd-Zr1Nwf-OWXEXe-UbuQg{color:#e8eaed
    }.jR8x9d .MhRzze:hover .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover,.jR8x9d .MhRzze.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover,.jR8x9d .MhRzze:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover,.jR8x9d .MhRzze:active .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover{color:#e8eaed
    }.jR8x9d .MhRzze:hover .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus,.jR8x9d .MhRzze.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus,.jR8x9d .MhRzze:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus,.jR8x9d .MhRzze:active .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus{color:#e8eaed
    }.jR8x9d .MhRzze:hover .VfPpkd-PvL5qd-Jt5cK,.jR8x9d .MhRzze.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-PvL5qd-Jt5cK,.jR8x9d .MhRzze:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-PvL5qd-Jt5cK,.jR8x9d .MhRzze:active .VfPpkd-PvL5qd-Jt5cK{stroke:rgb(232,
        234,
        237);stroke:var(--gm-chip-ink-color--stateful,rgb(232,
        234,
        237))
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24);background-color:var(--gm-chip-container-color,rgba(138,
        180,
        248,.24));color:rgb(210,
        227,
        252);color:var(--gm-chip-ink-color,rgb(210,
        227,
        252));border-color:transparent;border-color:var(--gm-chip-outline-color--stateful,transparent)
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc{color:#d2e3fc
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc{color:rgb(210,
        227,
        252);color:var(--gm-chip-ink-color,rgb(210,
        227,
        252))
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-Zr1Nwf-OWXEXe-UbuQg{color:#d2e3fc
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover{color:#d2e3fc
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus{color:#d2e3fc
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-PvL5qd-Jt5cK{stroke:rgb(210,
        227,
        252);stroke:var(--gm-chip-ink-color,rgb(210,
        227,
        252))
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:hover,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:active{color:#fff;color:var(--gm-chip-ink-color--stateful,#fff)
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:hover .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:active .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc{color:white
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:active .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc{color:#fff;color:var(--gm-chip-ink-color--stateful,#fff)
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:hover .VfPpkd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:active .VfPpkd-Zr1Nwf-OWXEXe-UbuQg{color:white
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:hover .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:active .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover{color:white
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:hover .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:active .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus{color:white
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:hover .VfPpkd-PvL5qd-Jt5cK,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-PvL5qd-Jt5cK,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-PvL5qd-Jt5cK,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:active .VfPpkd-PvL5qd-Jt5cK{stroke:#fff;stroke:var(--gm-chip-ink-color--stateful,#fff)
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-v1cqY: :before,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-v1cqY: :after{background-color:rgb(210,
        227,
        252);background-color:var(--gm-chip-state-color,rgb(210,
        227,
        252))
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:hover .VfPpkd-v1cqY: :before,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-v1cqY: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-v1cqY: :before,.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-v1cqY: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-v1cqY: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-v1cqY: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .MhRzze.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .fNK4Mb{background-color:rgb(32,
        33,
        36);background-color:var(--gm-chip-container-color,rgb(32,
        33,
        36));padding-right: 16px;padding-left: 16px;border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .fNK4Mb .VfPpkd-v1cqY: :before,.jR8x9d .fNK4Mb .VfPpkd-v1cqY: :after{background-color:rgb(232,
        234,
        237);background-color:var(--gm-chip-state-color,rgb(232,
        234,
        237))
    }.jR8x9d .fNK4Mb:hover .VfPpkd-v1cqY: :before,.jR8x9d .fNK4Mb.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-v1cqY: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .fNK4Mb.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-v1cqY: :before,.jR8x9d .fNK4Mb:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-v1cqY: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .fNK4Mb:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-v1cqY: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .fNK4Mb:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-v1cqY: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .fNK4Mb.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .fNK4Mb .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .fNK4Mb:hover{border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .fNK4Mb:hover .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .fNK4Mb:active{border-width: 0;-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .fNK4Mb:active .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .EuHQ0d{background-color:transparent;background-color:var(--gm-chip-container-color,transparent);border-style:solid;padding-right: 15px;padding-left: 15px;border-width: 1px;border-color:rgb(95,
        99,
        104);border-color:var(--gm-chip-outline-color,rgb(95,
        99,
        104))
    }.jR8x9d .EuHQ0d .VfPpkd-v1cqY{top: -1px;left: -1px;border: 1px solid transparent
    }.jR8x9d .EuHQ0d .VfPpkd-v1cqY: :before,.jR8x9d .EuHQ0d .VfPpkd-v1cqY: :after{background-color:rgb(232,
        234,
        237);background-color:var(--gm-chip-state-color,rgb(232,
        234,
        237))
    }.jR8x9d .EuHQ0d:hover .VfPpkd-v1cqY: :before,.jR8x9d .EuHQ0d.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-v1cqY: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .EuHQ0d.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-v1cqY: :before,.jR8x9d .EuHQ0d:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-v1cqY: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .EuHQ0d:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-v1cqY: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .EuHQ0d:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-v1cqY: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .EuHQ0d.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .EuHQ0d:focus,.jR8x9d .EuHQ0d.VfPpkd-XPtOyb-OWXEXe-ssJRIf-JIbuQc-XpnDCe{border-color:rgb(232,
        234,
        237);border-color:var(--gm-chip-outline-color--stateful,rgb(232,
        234,
        237))
    }.jR8x9d .EuHQ0d:active{-webkit-box-shadow:none;box-shadow:none
    }.jR8x9d .EuHQ0d:active .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .EuHQ0d.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd{padding-right: 16px;padding-left: 16px;border-width: 0
    }.jR8x9d .EuHQ0d.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-v1cqY{top: 0;left: 0;border: 0 solid transparent
    }.jR8x9d .EuHQ0d.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:hover{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .EuHQ0d.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:hover .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .EuHQ0d.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:focus,.jR8x9d .EuHQ0d.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-XPtOyb-OWXEXe-ssJRIf-JIbuQc-XpnDCe{padding-right: 15px;padding-left: 15px;border-width: 1px
    }.jR8x9d .EuHQ0d.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:focus .VfPpkd-v1cqY,.jR8x9d .EuHQ0d.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-XPtOyb-OWXEXe-ssJRIf-JIbuQc-XpnDCe .VfPpkd-v1cqY{top: -1px;left: -1px;border: 1px solid transparent
    }.jR8x9d .X4PEqe{color:rgb(232,
        234,
        237);color:var(--gm-chip-ink-color,rgb(232,
        234,
        237))
    }.jR8x9d .X4PEqe .VfPpkd-Zr1Nwf.VfPpkd-Zr1Nwf-OWXEXe-M1Soyc:not(.VfPpkd-Zr1Nwf-OWXEXe-M1Soyc-L6cTce){width: 20px;height: 20px;font-size: 20px
    }.jR8x9d .X4PEqe.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-PvL5qd,.jR8x9d .X4PEqe .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc:not(.VfPpkd-Zr1Nwf-OWXEXe-M1Soyc-L6cTce){margin-left: -8px;margin-right: 8px
    }[dir=rtl
    ] .jR8x9d .X4PEqe.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-PvL5qd,
    [dir=rtl
    ] .jR8x9d .X4PEqe .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc:not(.VfPpkd-Zr1Nwf-OWXEXe-M1Soyc-L6cTce),.jR8x9d .X4PEqe.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-PvL5qd[dir=rtl
    ],.jR8x9d .X4PEqe .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc:not(.VfPpkd-Zr1Nwf-OWXEXe-M1Soyc-L6cTce)[dir=rtl
    ]{margin-left: 8px;margin-right: -8px
    }.jR8x9d .X4PEqe .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc{color:#e8eaed
    }.jR8x9d .X4PEqe .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc{color:rgb(232,
        234,
        237);color:var(--gm-chip-ink-color,rgb(232,
        234,
        237))
    }.jR8x9d .X4PEqe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg{color:#e8eaed
    }.jR8x9d .X4PEqe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover{color:#e8eaed
    }.jR8x9d .X4PEqe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus{color:#e8eaed
    }.jR8x9d .X4PEqe .VfPpkd-PvL5qd-Jt5cK{stroke:rgb(232,
        234,
        237);stroke:var(--gm-chip-ink-color,rgb(232,
        234,
        237))
    }.jR8x9d .X4PEqe:hover,.jR8x9d .X4PEqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .X4PEqe:not(.VfPpkd-ksKsZd-mWPk3d):focus,.jR8x9d .X4PEqe:active{color:rgb(248,
        249,
        250);color:var(--gm-chip-ink-color--stateful,rgb(248,
        249,
        250))
    }.jR8x9d .X4PEqe:hover .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc,.jR8x9d .X4PEqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc,.jR8x9d .X4PEqe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc,.jR8x9d .X4PEqe:active .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc{color:#f8f9fa
    }.jR8x9d .X4PEqe:hover .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc,.jR8x9d .X4PEqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc,.jR8x9d .X4PEqe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc,.jR8x9d .X4PEqe:active .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc{color:rgb(248,
        249,
        250);color:var(--gm-chip-ink-color--stateful,rgb(248,
        249,
        250))
    }.jR8x9d .X4PEqe:hover .VfPpkd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .X4PEqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .X4PEqe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .X4PEqe:active .VfPpkd-Zr1Nwf-OWXEXe-UbuQg{color:#f8f9fa
    }.jR8x9d .X4PEqe:hover .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover,.jR8x9d .X4PEqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover,.jR8x9d .X4PEqe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover,.jR8x9d .X4PEqe:active .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:hover{color:#f8f9fa
    }.jR8x9d .X4PEqe:hover .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus,.jR8x9d .X4PEqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus,.jR8x9d .X4PEqe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus,.jR8x9d .X4PEqe:active .VfPpkd-Zr1Nwf-OWXEXe-UbuQg:focus{color:#f8f9fa
    }.jR8x9d .X4PEqe:hover .VfPpkd-PvL5qd-Jt5cK,.jR8x9d .X4PEqe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-PvL5qd-Jt5cK,.jR8x9d .X4PEqe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-PvL5qd-Jt5cK,.jR8x9d .X4PEqe:active .VfPpkd-PvL5qd-Jt5cK{stroke:rgb(248,
        249,
        250);stroke:var(--gm-chip-ink-color--stateful,rgb(248,
        249,
        250))
    }.jR8x9d .Vo0FCd{font-family:Roboto,Arial,sans-serif;line-height: 1.25rem;font-size:.875rem;letter-spacing:.0178571429em;font-weight: 500;padding-right: 11px;padding-left: 11px;border-width: 1px
    }.jR8x9d .Vo0FCd .VfPpkd-Zr1Nwf.VfPpkd-Zr1Nwf-OWXEXe-M1Soyc:not(.VfPpkd-Zr1Nwf-OWXEXe-M1Soyc-L6cTce){width: 20px;height: 20px;font-size: 20px
    }.jR8x9d .Vo0FCd.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-PvL5qd,.jR8x9d .Vo0FCd .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc:not(.VfPpkd-Zr1Nwf-OWXEXe-M1Soyc-L6cTce){margin-left: -3px;margin-right: 8px
    }[dir=rtl
    ] .jR8x9d .Vo0FCd.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-PvL5qd,
    [dir=rtl
    ] .jR8x9d .Vo0FCd .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc:not(.VfPpkd-Zr1Nwf-OWXEXe-M1Soyc-L6cTce),.jR8x9d .Vo0FCd.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-PvL5qd[dir=rtl
    ],.jR8x9d .Vo0FCd .VfPpkd-Zr1Nwf-OWXEXe-M1Soyc:not(.VfPpkd-Zr1Nwf-OWXEXe-M1Soyc-L6cTce)[dir=rtl
    ]{margin-left: 8px;margin-right: -3px
    }.jR8x9d .Vo0FCd .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc{margin-left: 8px;margin-right: -7px
    }[dir=rtl
    ] .jR8x9d .Vo0FCd .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc,.jR8x9d .Vo0FCd .VfPpkd-StrnGf-XPtOyb-UbuQg-JIbuQc[dir=rtl
    ]{margin-left: -7px;margin-right: 8px
    }.jR8x9d .Vo0FCd .VfPpkd-Zr1Nwf-OWXEXe-UbuQg{margin-left: 8px;margin-right: -7px
    }[dir=rtl
    ] .jR8x9d .Vo0FCd .VfPpkd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .Vo0FCd .VfPpkd-Zr1Nwf-OWXEXe-UbuQg[dir=rtl
    ]{margin-left: -7px;margin-right: 8px
    }.jR8x9d .Vo0FCd .VfPpkd-v1cqY{top: -1px;left: -1px;border: 1px solid transparent
    }.jR8x9d .Vo0FCd.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd{padding-right: 11px;padding-left: 11px;border-width: 1px;border-color:transparent;border-color:var(--gm-chip-outline-color,transparent)
    }.jR8x9d .Vo0FCd.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:focus,.jR8x9d .Vo0FCd.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-XPtOyb-OWXEXe-ssJRIf-JIbuQc-XpnDCe{padding-right: 11px;padding-left: 11px;border-width: 1px
    }.jR8x9d .Vo0FCd.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:focus .VfPpkd-v1cqY,.jR8x9d .Vo0FCd.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-XPtOyb-OWXEXe-ssJRIf-JIbuQc-XpnDCe .VfPpkd-v1cqY{top: -1px;left: -1px;border: 1px solid transparent
    }.jR8x9d .Vo0FCd.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-v1cqY{top: -1px;left: -1px;border: 1px solid transparent
    }.jR8x9d .Vo0FCd.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd:focus,.jR8x9d .Vo0FCd.ALA4kc.VfPpkd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-XPtOyb-OWXEXe-ssJRIf-JIbuQc-XpnDCe{border-color:transparent;border-color:var(--gm-chip-outline-color--stateful,transparent)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-ssJRIf{color:rgb(154,
        160,
        166)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):hover .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-ssJRIf{color:rgb(232,
        234,
        237)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-ssJRIf,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-ssJRIf{color:rgb(232,
        234,
        237)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-ssJRIf{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-TfeOUb-V67aGc{color:rgb(154,
        160,
        166)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):hover .VfPpkd-rOvkhd-TfeOUb-V67aGc{color:rgb(232,
        234,
        237)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rOvkhd-TfeOUb-V67aGc,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rOvkhd-TfeOUb-V67aGc{color:rgb(232,
        234,
        237)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me .VfPpkd-rOvkhd-TfeOUb-V67aGc{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf .VfPpkd-rOvkhd-v1cqY: :before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf .VfPpkd-rOvkhd-v1cqY: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:hover .VfPpkd-rOvkhd-v1cqY: :before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rOvkhd-v1cqY: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rOvkhd-v1cqY: :before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rOvkhd-v1cqY: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rOvkhd-v1cqY: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rOvkhd-v1cqY: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-OmTp3c-to915-Ia7Qfc .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-ssJRIf{color:rgb(138,
        180,
        248)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-OmTp3c-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):hover .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-ssJRIf{color:rgb(138,
        180,
        248)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-OmTp3c-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-ssJRIf,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-OmTp3c-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-ssJRIf{color:rgb(138,
        180,
        248)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-OmTp3c-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-ssJRIf{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-OmTp3c-to915-Ia7Qfc .VfPpkd-rOvkhd-TfeOUb-V67aGc{color:rgb(232,
        234,
        237)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me{background-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:before{border-color:transparent
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:before{border-color:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):not(.VfPpkd-ksKsZd-mWPk3d):focus:before{border-color:transparent
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:before{border-color:transparent
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:before{border-color:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-TfeOUb-V67aGc{color:rgb(210,
        227,
        252)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):hover .VfPpkd-rOvkhd-TfeOUb-V67aGc{color:#fff
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rOvkhd-TfeOUb-V67aGc,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rOvkhd-TfeOUb-V67aGc{color:#fff
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me .VfPpkd-rOvkhd-TfeOUb-V67aGc{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc .VfPpkd-rOvkhd-PvL5qd{color:rgb(210,
        227,
        252)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):hover .VfPpkd-rOvkhd-PvL5qd{color:#fff
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rOvkhd-PvL5qd,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rOvkhd-PvL5qd{color:#fff
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me .VfPpkd-rOvkhd-PvL5qd{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf .VfPpkd-rOvkhd-v1cqY: :before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf .VfPpkd-rOvkhd-v1cqY: :after{background-color:#fff;background-color:var(--mdc-ripple-color,#fff)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:hover .VfPpkd-rOvkhd-v1cqY: :before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rOvkhd-v1cqY: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rOvkhd-v1cqY: :before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rOvkhd-v1cqY: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rOvkhd-v1cqY: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rOvkhd-v1cqY: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-yOOK0-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-gk6SMd .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-UbuQg{color:rgb(154,
        160,
        166)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg:hover .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-UbuQg{color:rgb(232,
        234,
        237)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-UbuQg,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-UbuQg{color:rgb(232,
        234,
        237)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me .VfPpkd-rOvkhd-Zr1Nwf-OWXEXe-UbuQg{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg .VfPpkd-rOvkhd-v1cqY: :before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg .VfPpkd-rOvkhd-v1cqY: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg:hover .VfPpkd-rOvkhd-v1cqY: :before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rOvkhd-v1cqY: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rOvkhd-v1cqY: :before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rOvkhd-v1cqY: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rOvkhd-v1cqY: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rOvkhd-v1cqY: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-YPqjbf-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-UbuQg.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-aSvl1d-to915-Ia7Qfc{background-color:transparent
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-aSvl1d-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:before{border-width: 1px
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-aSvl1d-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:before{border-style:solid
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-aSvl1d-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me{background-color:transparent
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-aSvl1d-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:before{border-color:rgb(95,
        99,
        104)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-aSvl1d-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:before,.jR8x9d .UMrnmb-XPtOyb-OWXEXe-aSvl1d-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:not(.VfPpkd-rOvkhd-jPmIDe-OWXEXe-SdanKc):not(.VfPpkd-ksKsZd-mWPk3d):focus:before{border-color:rgb(232,
        234,
        237)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-aSvl1d-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:before{border-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc{background-color:rgb(32,
        33,
        36);-webkit-transition:border .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);transition:border .28s cubic-bezier(.4,
        0,.2,
        1),box-shadow .28s cubic-bezier(.4,
        0,.2,
        1),-webkit-box-shadow .28s cubic-bezier(.4,
        0,.2,
        1);-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:before{border-width: 1px
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc .VfPpkd-rOvkhd-jPmIDe-OWXEXe-ssJRIf:before{border-style:solid
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me{background-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc:hover{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc:hover .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc:active{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc:active .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me{-webkit-box-shadow:none;box-shadow:none
    }.jR8x9d .UMrnmb-XPtOyb-OWXEXe-ITYOJe-to915-Ia7Qfc.VfPpkd-rOvkhd-XPtOyb-OWXEXe-OWB6Me .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .a9u1Hb .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .a9u1Hb .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(102,
        157,
        246)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .a9u1Hb .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .a9u1Hb .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .a9u1Hb .VfPpkd-JGcpL-Ydhldb-R6PoUb .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(66,
        133,
        244)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .a9u1Hb .VfPpkd-JGcpL-Ydhldb-R6PoUb .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .a9u1Hb .VfPpkd-JGcpL-Ydhldb-ibL1re .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(234,
        67,
        53)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .a9u1Hb .VfPpkd-JGcpL-Ydhldb-ibL1re .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .a9u1Hb .VfPpkd-JGcpL-Ydhldb-c5RTEf .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(251,
        188,
        4)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .a9u1Hb .VfPpkd-JGcpL-Ydhldb-c5RTEf .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .a9u1Hb .VfPpkd-JGcpL-Ydhldb-II5mzb .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(52,
        168,
        83)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .a9u1Hb .VfPpkd-JGcpL-Ydhldb-II5mzb .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .tKSZFd{background-color:rgb(32,
        33,
        36);border-color:rgb(95,
        99,
        104)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf{background-color:rgb(32,
        33,
        36)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf,.jR8x9d .tKSZFd .VfPpkd-wZVHld-gruSEe-j4LONd,.jR8x9d .tKSZFd .VfPpkd-wZVHld-gruSEe-YMi5E-I8r9Db-DARUcf-V67aGc,.jR8x9d .tKSZFd .VfPpkd-wZVHld-aOtOmf{color:rgb(232,
        234,
        237)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-xMbwt-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-gruSEe-YMi5E-I8r9Db-DARUcf-O1htCb-OWXEXe-INsAgc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .tKSZFd .VfPpkd-wZVHld-gruSEe-YMi5E-I8r9Db-DARUcf-O1htCb-OWXEXe-INsAgc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .tKSZFd .VfPpkd-wZVHld-gruSEe-YMi5E-I8r9Db-DARUcf-O1htCb-OWXEXe-INsAgc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(95,
        99,
        104)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-aOtOmf,.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf{border-bottom-color:rgb(95,
        99,
        104)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-gruSEe{border-top-color:rgb(95,
        99,
        104)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-xMbwt:not(.VfPpkd-wZVHld-xMbwt-OWXEXe-gk6SMd):hover{background-color:rgba(232,
        234,
        237,.04)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe{color:rgb(154,
        160,
        166)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .tKSZFd .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :after{background-color:rgb(154,
        160,
        166);background-color:var(--mdc-ripple-color,rgb(154,
        160,
        166))
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe:hover .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .tKSZFd .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Bz112c-Jh9lGc: :before{opacity:.08;opacity:var(--mdc-ripple-hover-opacity,.08)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .tKSZFd .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-press-opacity,.24)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.24)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf-OWXEXe-Evexob .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe{color:rgb(232,
        234,
        237)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf-OWXEXe-Evexob .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf-OWXEXe-Evexob .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe .VfPpkd-Bz112c-Jh9lGc: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf-OWXEXe-Evexob .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe:hover .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf-OWXEXe-Evexob .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Bz112c-Jh9lGc: :before{opacity:.08;opacity:var(--mdc-ripple-hover-opacity,.08)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf-OWXEXe-Evexob .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf-OWXEXe-Evexob .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf-OWXEXe-Evexob .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf-OWXEXe-Evexob .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-press-opacity,.24)
    }.jR8x9d .tKSZFd .VfPpkd-wZVHld-vqLbZd-eEDwDf-OWXEXe-Evexob .VfPpkd-wZVHld-EcJZQc-Bz112c-LgbsSe.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.24)
    }.jR8x9d .zNgRPc .bwNLcf{color:rgb(232,
        234,
        237);font-family:Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 400
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-IhFlZd{color:rgb(154,
        160,
        166)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity:.38
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity: 0
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(138,
        180,
        248);background-color:var(--mdc-ripple-color,rgb(138,
        180,
        248))
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-clz4Ic{border-bottom-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:GrayText
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-fpDzbe-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-L8ivfd-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-bC5pod-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-JMEf7e{color:rgb(154,
        160,
        166)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-L8ivfd-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-bC5pod-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{color:rgb(232,
        234,
        237)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-KkROqb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-JMEf7e{opacity:.38
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb{color:rgb(232,
        234,
        237)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before{opacity: 0
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :after{background-color:rgb(138,
        180,
        248);background-color:var(--mdc-ripple-color,rgb(138,
        180,
        248))
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-L8ivfd-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-clz4Ic{background-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e{color:rgb(232,
        234,
        237)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b:hover .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-L8ivfd-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-bC5pod-fmcmS,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{color:GrayText
    }.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-KkROqb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .zNgRPc .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-JMEf7e{opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo{color:rgb(154,
        160,
        166)
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo:hover{color:rgb(248,
        249,
        250)
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo:not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(248,
        249,
        250)
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo:not(:disabled):active{color:rgb(248,
        249,
        250)
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo .VfPpkd-Bz112c-Jh9lGc: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo-OWXEXe-FGU2Pb-OWB6Me{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo-OWXEXe-FGU2Pb-OWB6Me:hover,.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo-OWXEXe-FGU2Pb-OWB6Me.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo-OWXEXe-FGU2Pb-OWB6Me:not(.VfPpkd-ksKsZd-mWPk3d):focus,.jR8x9d .zNgRPc .VfPpkd-XqMb-hFsbo-OWXEXe-FGU2Pb-OWB6Me:not(:disabled):active{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-S2QgGf-kj0dLd:not(:disabled){color:rgb(154,
        160,
        166);color:var(--mdc-text-button-label-text-color,rgb(154,
        160,
        166))
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-S2QgGf-kj0dLd:not(:disabled):hover{color:rgb(248,
        249,
        250);color:var(--mdc-text-button-hover-label-text-color,rgb(248,
        249,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-S2QgGf-kj0dLd:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-XqMb-S2QgGf-kj0dLd:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(248,
        249,
        250);color:var(--mdc-text-button-focus-label-text-color,rgb(248,
        249,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-S2QgGf-kj0dLd:not(:disabled):not(:disabled):active{color:rgb(248,
        249,
        250);color:var(--mdc-text-button-pressed-label-text-color,rgb(248,
        249,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-XqMb-S2QgGf-kj0dLd:disabled{color:rgb(154,
        160,
        166);color:var(--mdc-text-button-disabled-label-text-color,rgb(154,
        160,
        166))
    }.jR8x9d .zNgRPc .VfPpkd-hOoMI-haAclf .VfPpkd-hOoMI-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:transparent
    }.jR8x9d .zNgRPc .VfPpkd-hOoMI-haAclf .VfPpkd-hOoMI-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .zNgRPc .VfPpkd-hOoMI-haAclf .VfPpkd-hOoMI-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .zNgRPc .VfPpkd-hOoMI-haAclf{background-color:rgb(32,
        33,
        36)
    }.jR8x9d .zNgRPc.VfPpkd-Zc28rc-OWXEXe-Mgvhmd-S2QgGf-FNFY6c .VfPpkd-XqMb-S2QgGf-kj0dLd:not(:disabled),.jR8x9d .zNgRPc.VfPpkd-Zc28rc-OWXEXe-WRCQcd-S2QgGf-FNFY6c .VfPpkd-XqMb-S2QgGf-kj0dLd:not(:disabled){color:rgb(248,
        249,
        250);color:var(--mdc-text-button-label-text-color,rgb(248,
        249,
        250))
    }.jR8x9d .zNgRPc.VfPpkd-Zc28rc-OWXEXe-Mgvhmd-S2QgGf-FNFY6c .VfPpkd-XqMb-S2QgGf-kj0dLd:not(:disabled),.jR8x9d .zNgRPc.VfPpkd-Zc28rc-OWXEXe-WRCQcd-S2QgGf-FNFY6c .VfPpkd-XqMb-S2QgGf-kj0dLd:not(:disabled){background-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .zNgRPc.VfPpkd-Zc28rc-OWXEXe-Mgvhmd-S2QgGf-FNFY6c .VfPpkd-hOoMI-haAclf,.jR8x9d .zNgRPc.VfPpkd-Zc28rc-OWXEXe-WRCQcd-S2QgGf-FNFY6c .VfPpkd-hOoMI-haAclf{border-top-color:rgb(95,
        99,
        104)
    }.jR8x9d .zNgRPc .VfPpkd-HhDot-tJHJj{color:rgb(154,
        160,
        166)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe:not(:disabled){color:rgb(232,
        234,
        237);color:var(--mdc-outlined-button-label-text-color,rgb(232,
        234,
        237))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe:not(:disabled):hover{color:rgb(248,
        249,
        250);color:var(--mdc-outlined-button-hover-label-text-color,rgb(248,
        249,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(248,
        249,
        250);color:var(--mdc-outlined-button-focus-label-text-color,rgb(248,
        249,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe:not(:disabled):not(:disabled):active{color:rgb(248,
        249,
        250);color:var(--mdc-outlined-button-pressed-label-text-color,rgb(248,
        249,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe:disabled{color:rgb(154,
        160,
        166);color:var(--mdc-outlined-button-disabled-label-text-color,rgb(154,
        160,
        166))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe .VfPpkd-Jh9lGc: :before{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-outlined-button-hover-state-layer-color,rgb(232,
        234,
        237))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe .VfPpkd-Jh9lGc: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-outlined-button-pressed-state-layer-color,rgb(232,
        234,
        237))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-outlined-button-hover-state-layer-opacity,.04)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-outlined-button-focus-state-layer-opacity,.12)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,.1)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled){color:rgb(138,
        180,
        248);color:var(--mdc-outlined-button-label-text-color,rgb(138,
        180,
        248))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):hover{color:rgb(174,
        203,
        250);color:var(--mdc-outlined-button-hover-label-text-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(174,
        203,
        250);color:var(--mdc-outlined-button-focus-label-text-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):not(:disabled):active{color:rgb(174,
        203,
        250);color:var(--mdc-outlined-button-pressed-label-text-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l .VfPpkd-Jh9lGc: :before{background-color:rgb(174,
        203,
        250);background-color:var(--mdc-outlined-button-hover-state-layer-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l .VfPpkd-Jh9lGc: :after{background-color:rgb(174,
        203,
        250);background-color:var(--mdc-outlined-button-pressed-state-layer-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-outlined-button-hover-state-layer-opacity,.04)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-outlined-button-focus-state-layer-opacity,.12)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,.1)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled){border-color:rgb(138,
        180,
        248);border-color:var(--mdc-outlined-button-outline-color,rgb(138,
        180,
        248))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{border-color:rgb(174,
        203,
        250);border-color:var(--mdc-outlined-button-focus-outline-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):hover{border-color:rgb(174,
        203,
        250)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):active,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):focus:active{border-color:rgb(174,
        203,
        250)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled){color:rgb(32,
        33,
        36);color:var(--mdc-outlined-button-label-text-color,rgb(32,
        33,
        36))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):hover{color:rgb(32,
        33,
        36);color:var(--mdc-outlined-button-hover-label-text-color,rgb(32,
        33,
        36))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(32,
        33,
        36);color:var(--mdc-outlined-button-focus-label-text-color,rgb(32,
        33,
        36))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):not(:disabled):active{color:rgb(32,
        33,
        36);color:var(--mdc-outlined-button-pressed-label-text-color,rgb(32,
        33,
        36))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd .VfPpkd-Jh9lGc: :before{background-color:#fff;background-color:var(--mdc-outlined-button-hover-state-layer-color,#fff)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd .VfPpkd-Jh9lGc: :after{background-color:#fff;background-color:var(--mdc-outlined-button-pressed-state-layer-color,#fff)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.16;opacity:var(--mdc-outlined-button-hover-state-layer-opacity,.16)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-outlined-button-focus-state-layer-opacity,.24)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,.2)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,
        0.2)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled){background-color:rgb(138,
        180,
        248)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):hover{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):not(:disabled):active{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-OWB6Me:not(:disabled){color:rgb(154,
        160,
        166);color:var(--mdc-outlined-button-label-text-color,rgb(154,
        160,
        166))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-OWB6Me:not(:disabled):hover{color:rgb(154,
        160,
        166);color:var(--mdc-outlined-button-hover-label-text-color,rgb(154,
        160,
        166))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-OWB6Me:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-OWB6Me:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(154,
        160,
        166);color:var(--mdc-outlined-button-focus-label-text-color,rgb(154,
        160,
        166))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-OWB6Me:not(:disabled):not(:disabled):active{color:rgb(154,
        160,
        166);color:var(--mdc-outlined-button-pressed-label-text-color,rgb(154,
        160,
        166))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6:not(:disabled){color:rgb(154,
        160,
        166);color:var(--mdc-outlined-button-label-text-color,rgb(154,
        160,
        166))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6:not(:disabled):hover{color:rgb(248,
        249,
        250);color:var(--mdc-outlined-button-hover-label-text-color,rgb(248,
        249,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(248,
        249,
        250);color:var(--mdc-outlined-button-focus-label-text-color,rgb(248,
        249,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6:not(:disabled):not(:disabled):active{color:rgb(248,
        249,
        250);color:var(--mdc-outlined-button-pressed-label-text-color,rgb(248,
        249,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled){color:rgb(138,
        180,
        248);color:var(--mdc-outlined-button-label-text-color,rgb(138,
        180,
        248))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):hover{color:rgb(174,
        203,
        250);color:var(--mdc-outlined-button-hover-label-text-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(174,
        203,
        250);color:var(--mdc-outlined-button-focus-label-text-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):not(:disabled):active{color:rgb(174,
        203,
        250);color:var(--mdc-outlined-button-pressed-label-text-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l .VfPpkd-Jh9lGc: :before{background-color:rgb(174,
        203,
        250);background-color:var(--mdc-outlined-button-hover-state-layer-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l .VfPpkd-Jh9lGc: :after{background-color:rgb(174,
        203,
        250);background-color:var(--mdc-outlined-button-pressed-state-layer-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-outlined-button-hover-state-layer-opacity,.04)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-outlined-button-focus-state-layer-opacity,.12)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,.1)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled){border-color:rgb(138,
        180,
        248);border-color:var(--mdc-outlined-button-outline-color,rgb(138,
        180,
        248))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{border-color:rgb(174,
        203,
        250);border-color:var(--mdc-outlined-button-focus-outline-color,rgb(174,
        203,
        250))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):hover{border-color:rgb(174,
        203,
        250)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):active,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-bAa4l:not(:disabled):focus:active{border-color:rgb(174,
        203,
        250)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled){color:rgb(32,
        33,
        36);color:var(--mdc-outlined-button-label-text-color,rgb(32,
        33,
        36))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):hover{color:rgb(32,
        33,
        36);color:var(--mdc-outlined-button-hover-label-text-color,rgb(32,
        33,
        36))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(32,
        33,
        36);color:var(--mdc-outlined-button-focus-label-text-color,rgb(32,
        33,
        36))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):not(:disabled):active{color:rgb(32,
        33,
        36);color:var(--mdc-outlined-button-pressed-label-text-color,rgb(32,
        33,
        36))
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd .VfPpkd-Jh9lGc: :before{background-color:#fff;background-color:var(--mdc-outlined-button-hover-state-layer-color,#fff)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd .VfPpkd-Jh9lGc: :after{background-color:#fff;background-color:var(--mdc-outlined-button-pressed-state-layer-color,#fff)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.16;opacity:var(--mdc-outlined-button-hover-state-layer-opacity,.16)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-outlined-button-focus-state-layer-opacity,.24)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,.2)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-outlined-button-pressed-state-layer-opacity,
        0.2)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled){background-color:rgb(138,
        180,
        248)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):hover{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .zNgRPc .VfPpkd-RKhZBe-LgbsSe-OWXEXe-C3kE6.VfPpkd-RKhZBe-LgbsSe-OWXEXe-gk6SMd:not(:disabled):not(:disabled):active{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .f8F5Dd{background-color:rgb(32,
        33,
        36);border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .f8F5Dd .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .ad0uI .VfPpkd-GRS59e:not(:disabled){color:rgb(138,
        180,
        248);color:var(--mdc-text-button-label-text-color,rgb(138,
        180,
        248))
    }.jR8x9d .ad0uI .VfPpkd-GRS59e:not(:disabled):hover{color:rgb(174,
        203,
        250);color:var(--mdc-text-button-hover-label-text-color,rgb(174,
        203,
        250))
    }.jR8x9d .ad0uI .VfPpkd-GRS59e:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .ad0uI .VfPpkd-GRS59e:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(174,
        203,
        250);color:var(--mdc-text-button-focus-label-text-color,rgb(174,
        203,
        250))
    }.jR8x9d .ad0uI .VfPpkd-GRS59e:not(:disabled):not(:disabled):active{color:rgb(174,
        203,
        250);color:var(--mdc-text-button-pressed-label-text-color,rgb(174,
        203,
        250))
    }.jR8x9d .ad0uI .VfPpkd-GRS59e .VfPpkd-Jh9lGc: :before{background-color:rgb(174,
        203,
        250);background-color:var(--mdc-text-button-hover-state-layer-color,rgb(174,
        203,
        250))
    }.jR8x9d .ad0uI .VfPpkd-GRS59e .VfPpkd-Jh9lGc: :after{background-color:rgb(174,
        203,
        250);background-color:var(--mdc-text-button-pressed-state-layer-color,rgb(174,
        203,
        250))
    }.jR8x9d .ad0uI .VfPpkd-GRS59e:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .ad0uI .VfPpkd-GRS59e.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-text-button-hover-state-layer-opacity,.04)
    }.jR8x9d .ad0uI .VfPpkd-GRS59e.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .ad0uI .VfPpkd-GRS59e:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-text-button-focus-state-layer-opacity,.12)
    }.jR8x9d .ad0uI .VfPpkd-GRS59e:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .ad0uI .VfPpkd-GRS59e:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-text-button-pressed-state-layer-opacity,.1)
    }.jR8x9d .ad0uI .VfPpkd-GRS59e.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-text-button-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .zF2sRd .VfPpkd-Cv7pCf-ornU0b{color:rgb(189,
        193,
        198)
    }.jR8x9d .zF2sRd .VfPpkd-Cv7pCf-ornU0b:disabled{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .zF2sRd .VfPpkd-Cv7pCf-ornU0b .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .zF2sRd .VfPpkd-Cv7pCf-ornU0b .VfPpkd-Bz112c-Jh9lGc: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .zF2sRd .VfPpkd-Cv7pCf-ornU0b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .zF2sRd .VfPpkd-Cv7pCf-ornU0b:not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(248,
        249,
        250)
    }.jR8x9d .zF2sRd .VfPpkd-Cv7pCf-ornU0b:not(:disabled):active{color:rgb(248,
        249,
        250)
    }.jR8x9d .zF2sRd.VfPpkd-Zc28rc-OWXEXe-xl07Ob-FNFY6c .VfPpkd-Cv7pCf-ornU0b{color:rgb(248,
        249,
        250);background-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .zF2sRd .VfPpkd-Cv7pCf-ornU0b:hover,.jR8x9d .zF2sRd .VfPpkd-oEZKA:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-Cv7pCf-ornU0b{color:rgb(248,
        249,
        250)
    }.jR8x9d .zF2sRd .VfPpkd-Cv7pCf-ornU0b:hover:disabled,.jR8x9d .zF2sRd .VfPpkd-oEZKA:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-Cv7pCf-ornU0b:disabled{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .cNUpL .VfPpkd-Cv7pCf-ornU0b{color:rgb(154,
        160,
        166)
    }.jR8x9d .cNUpL .VfPpkd-Cv7pCf-ornU0b:disabled{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .cNUpL .VfPpkd-Cv7pCf-ornU0b .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .cNUpL .VfPpkd-Cv7pCf-ornU0b .VfPpkd-Bz112c-Jh9lGc: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .cNUpL .VfPpkd-Cv7pCf-ornU0b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .cNUpL .VfPpkd-Cv7pCf-ornU0b:not(.VfPpkd-ksKsZd-mWPk3d):focus{color:rgb(248,
        249,
        250)
    }.jR8x9d .cNUpL .VfPpkd-Cv7pCf-ornU0b:not(:disabled):active{color:rgb(248,
        249,
        250)
    }.jR8x9d .cNUpL.VfPpkd-Zc28rc-OWXEXe-xl07Ob-FNFY6c .VfPpkd-Cv7pCf-ornU0b{color:rgb(248,
        249,
        250);background-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .cNUpL .VfPpkd-Cv7pCf-ornU0b:hover,.jR8x9d .cNUpL .VfPpkd-oEZKA:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-Cv7pCf-ornU0b{color:rgb(248,
        249,
        250)
    }.jR8x9d .cNUpL .VfPpkd-Cv7pCf-ornU0b:hover:disabled,.jR8x9d .cNUpL .VfPpkd-oEZKA:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-Cv7pCf-ornU0b:disabled{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UDxLd .VfPpkd-k2Wrsb{color:#e8eaed
    }.jR8x9d .UDxLd .VfPpkd-cnG4Wd{color:#9aa0a6
    }.jR8x9d .UDxLd .VfPpkd-zMU9ub{color:rgb(154,
        160,
        166)
    }.jR8x9d .UDxLd .VfPpkd-zMU9ub .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .UDxLd .VfPpkd-zMU9ub .VfPpkd-Bz112c-Jh9lGc: :after{background-color:rgb(154,
        160,
        166);background-color:var(--mdc-ripple-color,rgb(154,
        160,
        166))
    }.jR8x9d .UDxLd .VfPpkd-zMU9ub:hover .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .UDxLd .VfPpkd-zMU9ub.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Bz112c-Jh9lGc: :before{opacity:.08;opacity:var(--mdc-ripple-hover-opacity,.08)
    }.jR8x9d .UDxLd .VfPpkd-zMU9ub.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .UDxLd .VfPpkd-zMU9ub:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
    }.jR8x9d .UDxLd .VfPpkd-zMU9ub:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .UDxLd .VfPpkd-zMU9ub:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-press-opacity,.24)
    }.jR8x9d .UDxLd .VfPpkd-zMU9ub.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.24)
    }.jR8x9d .UDxLd .VfPpkd-IE5DDf,.jR8x9d .UDxLd .VfPpkd-P5QLlc-GGAcbc{background-color:rgba(0,
        0,
        0,.87)
    }.jR8x9d .UDxLd .VfPpkd-P5QLlc{background-color:rgb(32,
        33,
        36)
    }.jR8x9d .UDxLd .VfPpkd-P5QLlc{border-width: 0;-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .UDxLd .VfPpkd-P5QLlc .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .ZD5Qo{color:rgb(138,
        180,
        248)
    }.jR8x9d .NNFoTc{background-color:rgb(32,
        33,
        36);height: 56px;width: 56px;padding-top: 2px;padding-top:max(0px,
        2px);padding-right: 2px;padding-right:max(0px,
        2px);padding-bottom: 2px;padding-bottom:max(0px,
        2px);padding-left: 2px;padding-left:max(0px,
        2px)
    }.jR8x9d .NNFoTc:not(:disabled){-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .NNFoTc:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .NNFoTc:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .NNFoTc:not(:disabled):hover{-webkit-box-shadow: 0 2px 3px 0 rgba(0,
        0,
        0,.3),
        0 6px 10px 4px rgba(0,
        0,
        0,.15);box-shadow: 0 2px 3px 0 rgba(0,
        0,
        0,.3),
        0 6px 10px 4px rgba(0,
        0,
        0,.15)
    }.jR8x9d .NNFoTc:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{opacity:.12
    }.jR8x9d .NNFoTc:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .NNFoTc:not(:disabled):focus{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .NNFoTc:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .NNFoTc:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .NNFoTc:not(:disabled):active{-webkit-box-shadow: 0 4px 4px 0 rgba(0,
        0,
        0,.3),
        0 8px 12px 6px rgba(0,
        0,
        0,.15);box-shadow: 0 4px 4px 0 rgba(0,
        0,
        0,.3),
        0 8px 12px 6px rgba(0,
        0,
        0,.15)
    }.jR8x9d .NNFoTc:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity:.14
    }.jR8x9d .NNFoTc:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .NNFoTc:disabled{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .NNFoTc:disabled .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .NNFoTc:disabled .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .NNFoTc .VfPpkd-Q0XOV{width: 36px;height: 36px;font-size: 36px
    }.jR8x9d .NNFoTc:not(:disabled) .VfPpkd-Q0XOV{color:rgb(232,
        234,
        237)
    }.jR8x9d .NNFoTc:not(:disabled):hover .VfPpkd-Q0XOV{color:rgb(174,
        203,
        250)
    }.jR8x9d .NNFoTc:not(:disabled):focus .VfPpkd-Q0XOV{color:rgb(174,
        203,
        250)
    }.jR8x9d .NNFoTc .VfPpkd-wbSZ0b: :before,.jR8x9d .NNFoTc .VfPpkd-wbSZ0b: :after{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .NNFoTc:hover .VfPpkd-wbSZ0b: :before,.jR8x9d .NNFoTc.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-wbSZ0b: :before{opacity:.04
    }.jR8x9d .NNFoTc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-wbSZ0b: :before,.jR8x9d .NNFoTc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-wbSZ0b: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12
    }.jR8x9d .NNFoTc:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-wbSZ0b: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .NNFoTc:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-wbSZ0b: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1
    }.jR8x9d .NNFoTc.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-fab-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .NNFoTc:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .NNFoTc:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{border-color:rgb(102,
        157,
        246)
    }.jR8x9d .NNFoTc:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .NNFoTc:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{border-style:solid;border-width: 2px;padding-top: 2px;padding-top:max(-2px,
        2px);padding-right: 2px;padding-right:max(-2px,
        2px);padding-bottom: 2px;padding-bottom:max(-2px,
        2px);padding-left: 2px;padding-left:max(-2px,
        2px)
    }.jR8x9d .NNFoTc:not(.VfPpkd-BIzmGd-OWXEXe-X9G3K){border-radius: 28px 28px 28px 28px
    }.jR8x9d .NNFoTc:not(.VfPpkd-BIzmGd-OWXEXe-X9G3K) .VfPpkd-wbSZ0b{border-radius: 28px 28px 28px 28px
    }.jR8x9d .gl6QPb{background-color:rgb(32,
        33,
        36);height: 48px;padding-top:max(0px,
        2px);padding-right: 2px;padding-right:max(0px,
        2px);padding-bottom:max(0px,
        2px);padding-left: 2px;padding-left:max(0px,
        2px);border-radius: 24px 24px 24px 24px;font-family:Google Sans,Roboto,Arial,sans-serif;font-size:.875rem;font-weight: 500;letter-spacing:.0178571429em;padding-top: 2px;padding-right: 24px;padding-bottom: 2px;padding-left: 24px
    }.jR8x9d .gl6QPb:not(:disabled){-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .gl6QPb:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .gl6QPb:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .gl6QPb:not(:disabled):hover{-webkit-box-shadow: 0 2px 3px 0 rgba(0,
        0,
        0,.3),
        0 6px 10px 4px rgba(0,
        0,
        0,.15);box-shadow: 0 2px 3px 0 rgba(0,
        0,
        0,.3),
        0 6px 10px 4px rgba(0,
        0,
        0,.15)
    }.jR8x9d .gl6QPb:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{opacity:.12
    }.jR8x9d .gl6QPb:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .gl6QPb:not(:disabled):focus{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .gl6QPb:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .gl6QPb:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .gl6QPb:not(:disabled):active{-webkit-box-shadow: 0 4px 4px 0 rgba(0,
        0,
        0,.3),
        0 8px 12px 6px rgba(0,
        0,
        0,.15);box-shadow: 0 4px 4px 0 rgba(0,
        0,
        0,.3),
        0 8px 12px 6px rgba(0,
        0,
        0,.15)
    }.jR8x9d .gl6QPb:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity:.14
    }.jR8x9d .gl6QPb:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .gl6QPb:disabled{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .gl6QPb:disabled .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .gl6QPb:disabled .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .gl6QPb .VfPpkd-Q0XOV{width: 36px;height: 36px;font-size: 36px
    }.jR8x9d .gl6QPb:not(:disabled) .VfPpkd-Q0XOV{color:rgb(232,
        234,
        237)
    }.jR8x9d .gl6QPb:not(:disabled):hover .VfPpkd-Q0XOV{color:rgb(174,
        203,
        250)
    }.jR8x9d .gl6QPb:not(:disabled):focus .VfPpkd-Q0XOV{color:rgb(174,
        203,
        250)
    }.jR8x9d .gl6QPb .VfPpkd-wbSZ0b: :before,.jR8x9d .gl6QPb .VfPpkd-wbSZ0b: :after{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .gl6QPb:hover .VfPpkd-wbSZ0b: :before,.jR8x9d .gl6QPb.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-wbSZ0b: :before{opacity:.04
    }.jR8x9d .gl6QPb.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-wbSZ0b: :before,.jR8x9d .gl6QPb:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-wbSZ0b: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12
    }.jR8x9d .gl6QPb:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-wbSZ0b: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .gl6QPb:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-wbSZ0b: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1
    }.jR8x9d .gl6QPb.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-extended-fab-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .gl6QPb:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .gl6QPb:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{border-color:rgb(102,
        157,
        246)
    }.jR8x9d .gl6QPb:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .gl6QPb:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{padding-top:max(-2px,
        2px);padding-right: 2px;padding-right:max(-2px,
        2px);padding-bottom:max(-2px,
        2px);padding-left: 2px;padding-left:max(-2px,
        2px)
    }.jR8x9d .gl6QPb .VfPpkd-wbSZ0b{border-radius: 24px 24px 24px 24px
    }.jR8x9d .gl6QPb:not(:disabled) .VfPpkd-nBWOSb{color:rgb(232,
        234,
        237)
    }.jR8x9d .gl6QPb:not(:disabled):hover .VfPpkd-nBWOSb{color:rgb(174,
        203,
        250)
    }.jR8x9d .gl6QPb:not(:disabled):focus .VfPpkd-nBWOSb{color:rgb(174,
        203,
        250)
    }.jR8x9d .gl6QPb:not(:disabled):active .VfPpkd-nBWOSb{color:rgb(174,
        203,
        250)
    }.jR8x9d .gl6QPb .VfPpkd-Q0XOV{margin-left: -12px;margin-right: 12px
    }[dir=rtl
    ] .jR8x9d .gl6QPb .VfPpkd-Q0XOV,.jR8x9d .gl6QPb .VfPpkd-Q0XOV[dir=rtl
    ]{margin-left: 12px;margin-right: -12px
    }.jR8x9d .gl6QPb .VfPpkd-nBWOSb+.VfPpkd-Q0XOV{margin-left: 12px;margin-right: -12px
    }[dir=rtl
    ] .jR8x9d .gl6QPb .VfPpkd-nBWOSb+.VfPpkd-Q0XOV,.jR8x9d .gl6QPb .VfPpkd-nBWOSb+.VfPpkd-Q0XOV[dir=rtl
    ]{margin-left: -12px;margin-right: 12px
    }.jR8x9d .gl6QPb:not(:disabled).VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe,.jR8x9d .gl6QPb:not(:disabled):not(.VfPpkd-ksKsZd-mWPk3d):focus{border-style:solid;border-width: 2px;padding-top: 2px;padding-right: 22px;padding-bottom: 2px;padding-left: 22px
    }.jR8x9d .Aykzec{background-color:rgb(138,
        180,
        248);height: 48px;border-radius: 24px 24px 24px 24px;font-family:Google Sans,Roboto,Arial,sans-serif;font-size:.875rem;font-weight: 500;letter-spacing:.0178571429em
    }.jR8x9d .Aykzec:not(:disabled){-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .Aykzec:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .Aykzec:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .Aykzec:not(:disabled):hover{-webkit-box-shadow: 0 2px 3px 0 rgba(0,
        0,
        0,.3),
        0 6px 10px 4px rgba(0,
        0,
        0,.15);box-shadow: 0 2px 3px 0 rgba(0,
        0,
        0,.3),
        0 6px 10px 4px rgba(0,
        0,
        0,.15)
    }.jR8x9d .Aykzec:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{opacity:.12
    }.jR8x9d .Aykzec:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .Aykzec:not(:disabled):focus{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .Aykzec:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .Aykzec:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .Aykzec:not(:disabled):active{-webkit-box-shadow: 0 4px 4px 0 rgba(0,
        0,
        0,.3),
        0 8px 12px 6px rgba(0,
        0,
        0,.15);box-shadow: 0 4px 4px 0 rgba(0,
        0,
        0,.3),
        0 8px 12px 6px rgba(0,
        0,
        0,.15)
    }.jR8x9d .Aykzec:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity:.14
    }.jR8x9d .Aykzec:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .Aykzec:disabled{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .Aykzec:disabled .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .Aykzec:disabled .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .Aykzec .VfPpkd-Q0XOV{width: 24px;height: 24px;font-size: 24px
    }.jR8x9d .Aykzec:not(:disabled) .VfPpkd-Q0XOV{color:rgb(32,
        33,
        36)
    }.jR8x9d .Aykzec .VfPpkd-wbSZ0b: :before,.jR8x9d .Aykzec .VfPpkd-wbSZ0b: :after{background-color:rgb(255,
        255,
        255)
    }.jR8x9d .Aykzec:hover .VfPpkd-wbSZ0b: :before,.jR8x9d .Aykzec.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-wbSZ0b: :before{opacity:.16
    }.jR8x9d .Aykzec.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-wbSZ0b: :before,.jR8x9d .Aykzec:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-wbSZ0b: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24
    }.jR8x9d .Aykzec:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-wbSZ0b: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .Aykzec:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-wbSZ0b: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2
    }.jR8x9d .Aykzec.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-extended-fab-pressed-state-layer-opacity,
        0.2)
    }.jR8x9d .Aykzec .VfPpkd-wbSZ0b{border-radius: 24px 24px 24px 24px
    }.jR8x9d .Aykzec:not(:disabled) .VfPpkd-nBWOSb{color:rgb(32,
        33,
        36)
    }.jR8x9d .W7mYUe{background-color:rgb(32,
        33,
        36);height: 48px;border-radius: 24px 24px 24px 24px;font-family:Google Sans,Roboto,Arial,sans-serif;font-size:.875rem;font-weight: 500;letter-spacing:.0178571429em
    }.jR8x9d .W7mYUe:not(:disabled){-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .W7mYUe:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .W7mYUe:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .W7mYUe:not(:disabled):hover{-webkit-box-shadow: 0 2px 3px 0 rgba(0,
        0,
        0,.3),
        0 6px 10px 4px rgba(0,
        0,
        0,.15);box-shadow: 0 2px 3px 0 rgba(0,
        0,
        0,.3),
        0 6px 10px 4px rgba(0,
        0,
        0,.15)
    }.jR8x9d .W7mYUe:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{opacity:.12
    }.jR8x9d .W7mYUe:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .W7mYUe:not(:disabled):focus{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .W7mYUe:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .W7mYUe:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .W7mYUe:not(:disabled):active{-webkit-box-shadow: 0 4px 4px 0 rgba(0,
        0,
        0,.3),
        0 8px 12px 6px rgba(0,
        0,
        0,.15);box-shadow: 0 4px 4px 0 rgba(0,
        0,
        0,.3),
        0 8px 12px 6px rgba(0,
        0,
        0,.15)
    }.jR8x9d .W7mYUe:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity:.14
    }.jR8x9d .W7mYUe:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .W7mYUe:disabled{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .W7mYUe:disabled .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .W7mYUe:disabled .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .W7mYUe .VfPpkd-Q0XOV{width: 24px;height: 24px;font-size: 24px
    }.jR8x9d .W7mYUe:not(:disabled) .VfPpkd-Q0XOV{color:rgb(138,
        180,
        248)
    }.jR8x9d .W7mYUe:not(:disabled):hover .VfPpkd-Q0XOV{color:rgb(174,
        203,
        250)
    }.jR8x9d .W7mYUe:not(:disabled):focus .VfPpkd-Q0XOV{color:rgb(174,
        203,
        250)
    }.jR8x9d .W7mYUe:not(:disabled):active .VfPpkd-Q0XOV{color:rgb(174,
        203,
        250)
    }.jR8x9d .W7mYUe .VfPpkd-wbSZ0b: :before,.jR8x9d .W7mYUe .VfPpkd-wbSZ0b: :after{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .W7mYUe:hover .VfPpkd-wbSZ0b: :before,.jR8x9d .W7mYUe.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-wbSZ0b: :before{opacity:.04
    }.jR8x9d .W7mYUe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-wbSZ0b: :before,.jR8x9d .W7mYUe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-wbSZ0b: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12
    }.jR8x9d .W7mYUe:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-wbSZ0b: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .W7mYUe:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-wbSZ0b: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1
    }.jR8x9d .W7mYUe.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-extended-fab-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .W7mYUe .VfPpkd-wbSZ0b{border-radius: 24px 24px 24px 24px
    }.jR8x9d .W7mYUe:not(:disabled) .VfPpkd-nBWOSb{color:rgb(138,
        180,
        248)
    }.jR8x9d .W7mYUe:not(:disabled):hover .VfPpkd-nBWOSb{color:rgb(174,
        203,
        250)
    }.jR8x9d .W7mYUe:not(:disabled):focus .VfPpkd-nBWOSb{color:rgb(174,
        203,
        250)
    }.jR8x9d .W7mYUe:not(:disabled):active .VfPpkd-nBWOSb{color:rgb(174,
        203,
        250)
    }.jR8x9d .OoEosd{background-color:rgb(32,
        33,
        36);height: 56px;width: 56px
    }.jR8x9d .OoEosd:not(:disabled){-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .OoEosd:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .OoEosd:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .OoEosd:not(:disabled):hover{-webkit-box-shadow: 0 2px 3px 0 rgba(0,
        0,
        0,.3),
        0 6px 10px 4px rgba(0,
        0,
        0,.15);box-shadow: 0 2px 3px 0 rgba(0,
        0,
        0,.3),
        0 6px 10px 4px rgba(0,
        0,
        0,.15)
    }.jR8x9d .OoEosd:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{opacity:.12
    }.jR8x9d .OoEosd:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .OoEosd:not(:disabled):focus{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .OoEosd:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .OoEosd:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .OoEosd:not(:disabled):active{-webkit-box-shadow: 0 4px 4px 0 rgba(0,
        0,
        0,.3),
        0 8px 12px 6px rgba(0,
        0,
        0,.15);box-shadow: 0 4px 4px 0 rgba(0,
        0,
        0,.3),
        0 8px 12px 6px rgba(0,
        0,
        0,.15)
    }.jR8x9d .OoEosd:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity:.14
    }.jR8x9d .OoEosd:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .OoEosd:disabled{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .OoEosd:disabled .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .OoEosd:disabled .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .OoEosd .VfPpkd-Q0XOV{width: 24px;height: 24px;font-size: 24px
    }.jR8x9d .OoEosd:not(:disabled) .VfPpkd-Q0XOV{color:rgb(138,
        180,
        248)
    }.jR8x9d .OoEosd:not(:disabled):hover .VfPpkd-Q0XOV{color:rgb(174,
        203,
        250)
    }.jR8x9d .OoEosd:not(:disabled):focus .VfPpkd-Q0XOV{color:rgb(174,
        203,
        250)
    }.jR8x9d .OoEosd:not(:disabled):active .VfPpkd-Q0XOV{color:rgb(174,
        203,
        250)
    }.jR8x9d .OoEosd .VfPpkd-wbSZ0b: :before,.jR8x9d .OoEosd .VfPpkd-wbSZ0b: :after{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .OoEosd:hover .VfPpkd-wbSZ0b: :before,.jR8x9d .OoEosd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-wbSZ0b: :before{opacity:.04
    }.jR8x9d .OoEosd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-wbSZ0b: :before,.jR8x9d .OoEosd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-wbSZ0b: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12
    }.jR8x9d .OoEosd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-wbSZ0b: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .OoEosd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-wbSZ0b: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1
    }.jR8x9d .OoEosd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-fab-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .OoEosd:not(.VfPpkd-BIzmGd-OWXEXe-X9G3K){border-radius: 28px 28px 28px 28px
    }.jR8x9d .OoEosd:not(.VfPpkd-BIzmGd-OWXEXe-X9G3K) .VfPpkd-wbSZ0b{border-radius: 28px 28px 28px 28px
    }.jR8x9d .vd3sk:not(:disabled){-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .vd3sk:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .vd3sk:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .vd3sk:not(:disabled):hover{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .vd3sk:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .vd3sk:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .vd3sk:not(:disabled):focus{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .vd3sk:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .vd3sk:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .vd3sk:not(:disabled):active{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .vd3sk:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .vd3sk:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .vd3sk:disabled{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .vd3sk:disabled .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .vd3sk:disabled .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .N7pe4e:not(:disabled){-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .N7pe4e:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .N7pe4e:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .N7pe4e:not(:disabled):hover{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .N7pe4e:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .N7pe4e:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .N7pe4e:not(:disabled):focus{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .N7pe4e:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .N7pe4e:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .N7pe4e:not(:disabled):active{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .N7pe4e:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .N7pe4e:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .N7pe4e:disabled{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .N7pe4e:disabled .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .N7pe4e:disabled .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .JJMOVe:not(:disabled){-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .JJMOVe:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .JJMOVe:not(:disabled) .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .JJMOVe:not(:disabled):hover{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .JJMOVe:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .JJMOVe:not(:disabled):hover .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .JJMOVe:not(:disabled):focus{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .JJMOVe:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .JJMOVe:not(:disabled):focus .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .JJMOVe:not(:disabled):active{-webkit-box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 3px 0 rgba(0,
        0,
        0,.3),
        0 4px 8px 3px rgba(0,
        0,
        0,.15)
    }.jR8x9d .JJMOVe:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{opacity:.11
    }.jR8x9d .JJMOVe:not(:disabled):active .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .JJMOVe:disabled{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .JJMOVe:disabled .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .JJMOVe:disabled .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .E9mvxc{height: 40px;width: 40px
    }.jR8x9d .ZCuY4{font-family:Roboto,Arial,sans-serif;line-height: 1.25rem;font-size:.875rem;letter-spacing:.0142857143em;font-weight: 400;color:rgb(232,
        234,
        237)
    }.jR8x9d .ZCuY4 gm-checkbox[disabled
    ]~.VfPpkd-V67aGc,.jR8x9d .ZCuY4 gm-radio[disabled
    ]~.VfPpkd-V67aGc,.jR8x9d .ZCuY4 .VfPpkd-MPu53c-OWXEXe-OWB6Me~.VfPpkd-V67aGc,.jR8x9d .ZCuY4 .VfPpkd-GCYh9b-OWXEXe-OWB6Me~.VfPpkd-V67aGc{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .E2obDf .VfPpkd-qNpTzb-P4pF8c-SmKAyb{border-color:rgb(102,
        157,
        246)
    }.jR8x9d .E2obDf .VfPpkd-qNpTzb-ajuXxc-RxYbNe{background-color:rgba(138,
        180,
        248,.24)
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .E2obDf .VfPpkd-qNpTzb-ajuXxc-RxYbNe{background-color:ButtonBorder
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (-ms-high-contrast:none){.jR8x9d .E2obDf .VfPpkd-qNpTzb-ajuXxc-RxYbNe{background-color:transparent;background-image:url("data:image/svg+xml,%3Csvg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' enable-background='new 0 0 5 2' xml:space='preserve' viewBox='0 0 5 2' preserveAspectRatio='none slice'%3E%3Ccircle cx='1' cy='1' r='1' fill='rgba(138, 180, 248, 0.24)'/%3E%3C/svg%3E")
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .E2obDf .VfPpkd-qNpTzb-ajuXxc-ZMv3u{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .bwNLcf{color:rgb(232,
        234,
        237);font-family:Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 400
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-IhFlZd{color:rgb(154,
        160,
        166)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity:.38
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity: 0
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(138,
        180,
        248);background-color:var(--mdc-ripple-color,rgb(138,
        180,
        248))
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-clz4Ic{border-bottom-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:GrayText
    }.jR8x9d .bwNLcf .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .bwNLcf .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-fpDzbe-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-L8ivfd-fmcmS,.jR8x9d .bwNLcf .VfPpkd-rymPhb-bC5pod-fmcmS,.jR8x9d .bwNLcf .VfPpkd-rymPhb-JMEf7e{color:rgb(154,
        160,
        166)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-L8ivfd-fmcmS,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-bC5pod-fmcmS,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{color:rgb(232,
        234,
        237)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-KkROqb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-JMEf7e{opacity:.38
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb{color:rgb(232,
        234,
        237)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before{opacity: 0
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :after{background-color:rgb(138,
        180,
        248);background-color:var(--mdc-ripple-color,rgb(138,
        180,
        248))
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-L8ivfd-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-clz4Ic{background-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e{color:rgb(232,
        234,
        237)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b:hover .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-L8ivfd-fmcmS,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-bC5pod-fmcmS,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{color:GrayText
    }.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-KkROqb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .bwNLcf .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-JMEf7e{opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .f8F5Dd{background-color:rgb(32,
        33,
        36);border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .f8F5Dd .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .P77izf{background-color:rgb(32,
        33,
        36);border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb{font-family:Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 400;color:rgb(232,
        234,
        237)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-IhFlZd{color:rgb(154,
        160,
        166)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity:.38
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity: 0
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(138,
        180,
        248);background-color:var(--mdc-ripple-color,rgb(138,
        180,
        248))
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic{border-bottom-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:GrayText
    }.jR8x9d .P77izf .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .P77izf .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .ZCYEwf{z-index: 0
    }.jR8x9d .ZCYEwf .VfPpkd-eHTEvd: :before,.jR8x9d .ZCYEwf .VfPpkd-eHTEvd: :after{z-index: -1
    }.jR8x9d .ZCYEwf .VfPpkd-eHTEvd: :before,.jR8x9d .ZCYEwf .VfPpkd-eHTEvd: :after{background-color:rgb(138,
        180,
        248);background-color:var(--gm-radio-state-color,rgb(138,
        180,
        248))
    }.jR8x9d .ZCYEwf:hover .VfPpkd-eHTEvd: :before,.jR8x9d .ZCYEwf.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-eHTEvd: :before{opacity:.16;opacity:var(--mdc-ripple-hover-opacity,.16)
    }.jR8x9d .ZCYEwf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-eHTEvd: :before,.jR8x9d .ZCYEwf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-eHTEvd: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
    }.jR8x9d .ZCYEwf:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-eHTEvd: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .ZCYEwf:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-eHTEvd: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-ripple-press-opacity,.2)
    }.jR8x9d .ZCYEwf .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)~.VfPpkd-eHTEvd: :before,.jR8x9d .ZCYEwf .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)~.VfPpkd-eHTEvd: :after{background-color:rgb(232,
        234,
        237);background-color:var(--gm-radio-state-color,rgb(232,
        234,
        237))
    }.jR8x9d .ZCYEwf:hover .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)~.VfPpkd-eHTEvd: :before,.jR8x9d .ZCYEwf.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)~.VfPpkd-eHTEvd: :before{opacity:.16;opacity:var(--mdc-ripple-hover-opacity,.16)
    }.jR8x9d .ZCYEwf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)~.VfPpkd-eHTEvd: :before,.jR8x9d .ZCYEwf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)~.VfPpkd-eHTEvd: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
    }.jR8x9d .ZCYEwf:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)~.VfPpkd-eHTEvd: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .ZCYEwf:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)~.VfPpkd-eHTEvd: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.2;opacity:var(--mdc-ripple-press-opacity,.2)
    }.jR8x9d .ZCYEwf.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.2)
    }.jR8x9d .ZCYEwf .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo{border-color:rgb(154,
        160,
        166);border-color:var(--gm-radio-stroke-color--unchecked,rgb(154,
        160,
        166))
    }.jR8x9d .ZCYEwf .VfPpkd-gBXA9-bMcfAe:enabled:checked+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo{border-color:rgb(138,
        180,
        248);border-color:var(--gm-radio-stroke-color--checked,rgb(138,
        180,
        248))
    }.jR8x9d .ZCYEwf .VfPpkd-gBXA9-bMcfAe:enabled+.VfPpkd-RsCWK .VfPpkd-Z5TpLc-LkdAo{border-color:rgb(138,
        180,
        248);border-color:var(--gm-radio-ink-color,rgb(138,
        180,
        248))
    }.jR8x9d .ZCYEwf [aria-disabled=true
    ] .VfPpkd-gBXA9-bMcfAe:not(:checked)+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo,.jR8x9d .ZCYEwf .VfPpkd-gBXA9-bMcfAe:disabled:not(:checked)+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo{border-color:rgba(232,
        234,
        237,.38);border-color:var(--gm-radio-disabled-stroke-color--unchecked,rgba(232,
        234,
        237,.38))
    }.jR8x9d .ZCYEwf [aria-disabled=true
    ] .VfPpkd-gBXA9-bMcfAe:checked+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo,.jR8x9d .ZCYEwf .VfPpkd-gBXA9-bMcfAe:disabled:checked+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo{border-color:rgba(232,
        234,
        237,.38);border-color:var(--gm-radio-disabled-stroke-color--checked,rgba(232,
        234,
        237,.38))
    }.jR8x9d .ZCYEwf [aria-disabled=true
    ] .VfPpkd-gBXA9-bMcfAe+.VfPpkd-RsCWK .VfPpkd-Z5TpLc-LkdAo,.jR8x9d .ZCYEwf .VfPpkd-gBXA9-bMcfAe:disabled+.VfPpkd-RsCWK .VfPpkd-Z5TpLc-LkdAo{border-color:rgba(232,
        234,
        237,.38);border-color:var(--gm-radio-disabled-ink-color,rgba(232,
        234,
        237,.38))
    }.jR8x9d .ZCYEwf .VfPpkd-RsCWK: :before{background-color:rgb(138,
        180,
        248);background-color:var(--gm-radio-state-color,rgb(138,
        180,
        248))
    }.jR8x9d .ZCYEwf:hover .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo,.jR8x9d .ZCYEwf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo,.jR8x9d .ZCYEwf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo,.jR8x9d .ZCYEwf:active .VfPpkd-gBXA9-bMcfAe:enabled:not(:checked)+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo{border-color:rgb(232,
        234,
        237);border-color:var(--gm-radio-stroke-color--unchecked-stateful,rgb(232,
        234,
        237))
    }.jR8x9d .ZCYEwf:hover .VfPpkd-gBXA9-bMcfAe:enabled:checked+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo,.jR8x9d .ZCYEwf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-gBXA9-bMcfAe:enabled:checked+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo,.jR8x9d .ZCYEwf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-gBXA9-bMcfAe:enabled:checked+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo,.jR8x9d .ZCYEwf:active .VfPpkd-gBXA9-bMcfAe:enabled:checked+.VfPpkd-RsCWK .VfPpkd-wVo5xe-LkdAo{border-color:rgb(174,
        203,
        250);border-color:var(--gm-radio-stroke-color--checked-stateful,rgb(174,
        203,
        250))
    }.jR8x9d .ZCYEwf:hover .VfPpkd-gBXA9-bMcfAe:enabled+.VfPpkd-RsCWK .VfPpkd-Z5TpLc-LkdAo,.jR8x9d .ZCYEwf.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-gBXA9-bMcfAe:enabled+.VfPpkd-RsCWK .VfPpkd-Z5TpLc-LkdAo,.jR8x9d .ZCYEwf:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-gBXA9-bMcfAe:enabled+.VfPpkd-RsCWK .VfPpkd-Z5TpLc-LkdAo,.jR8x9d .ZCYEwf:active .VfPpkd-gBXA9-bMcfAe:enabled+.VfPpkd-RsCWK .VfPpkd-Z5TpLc-LkdAo{border-color:rgb(174,
        203,
        250);border-color:var(--gm-radio-ink-color--stateful,rgb(174,
        203,
        250))
    }.jR8x9d .dmaMHc{background-color:rgb(32,
        33,
        36);border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);font-family:Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 400
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb{font-family:Roboto,Arial,sans-serif;line-height: 1.5rem;font-size: 1rem;letter-spacing:.00625em;font-weight: 400;color:rgb(232,
        234,
        237)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-IhFlZd{color:rgb(154,
        160,
        166)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity:.38
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-f7MjDc,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity: 0
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(138,
        180,
        248);background-color:var(--mdc-ripple-color,rgb(138,
        180,
        248))
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-clz4Ic{border-bottom-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc{color:rgb(232,
        234,
        237)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-fpDzbe-fmcmS,.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:GrayText
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-StrnGf-rymPhb-b9t22c{opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .dmaMHc .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-fpDzbe-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-L8ivfd-fmcmS,.jR8x9d .dmaMHc .VfPpkd-rymPhb-bC5pod-fmcmS,.jR8x9d .dmaMHc .VfPpkd-rymPhb-JMEf7e{color:rgb(154,
        160,
        166)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-L8ivfd-fmcmS,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-bC5pod-fmcmS,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{color:rgb(232,
        234,
        237)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-KkROqb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-JMEf7e{opacity:.38
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-pXU01b.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb{color:rgb(232,
        234,
        237)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before{opacity: 0
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgba(138,
        180,
        248,.24)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :after{background-color:rgb(138,
        180,
        248);background-color:var(--mdc-ripple-color,rgb(138,
        180,
        248))
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-L8ivfd-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-clz4Ic{background-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e{color:rgb(232,
        234,
        237)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b .VfPpkd-rymPhb-pZXsl: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b:hover .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-fpDzbe-fmcmS,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-L8ivfd-fmcmS,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-bC5pod-fmcmS,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me.VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-r4m2rf .VfPpkd-rymPhb-JMEf7e{color:GrayText
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-KkROqb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-Gtdoyb,.jR8x9d .dmaMHc .VfPpkd-rymPhb-ibnC6b-OWXEXe-OWB6Me .VfPpkd-rymPhb-JMEf7e{opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-L8ivfd-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .dmaMHc .VfPpkd-StrnGf-rymPhb .VfPpkd-StrnGf-rymPhb-f7MjDc,.jR8x9d .dmaMHc .VfPpkd-rymPhb .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-M1Soyc-Bz112c .VfPpkd-rymPhb-KkROqb,.jR8x9d .dmaMHc .VfPpkd-rymPhb .VfPpkd-rymPhb-ibnC6b-OWXEXe-SfQLQb-UbuQg-Bz112c .VfPpkd-rymPhb-JMEf7e{color:rgb(232,
        234,
        237)
    }.jR8x9d .dmaMHc .VfPpkd-rymPhb-fpDzbe-fmcmS{letter-spacing:.00625em
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd{background-color:rgba(242,
        139,
        130,.24)
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-StrnGf-rymPhb-pZXsl: :after{background-color:rgb(242,
        139,
        130);background-color:var(--mdc-ripple-color,rgb(242,
        139,
        130))
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-StrnGf-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-StrnGf-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-StrnGf-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-StrnGf-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :after,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd .VfPpkd-rymPhb-pZXsl: :after{background-color:rgb(242,
        139,
        130);background-color:var(--mdc-ripple-color,rgb(242,
        139,
        130))
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:hover .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-rymPhb-pZXsl: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-rymPhb-pZXsl: :before,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-rymPhb-pZXsl: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-rymPhb-pZXsl: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-StrnGf-rymPhb-ibnC6b.VfPpkd-StrnGf-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d,.jR8x9d .dmaMHc.VfPpkd-YPmvEd-OWXEXe-UJflGc .VfPpkd-rymPhb-ibnC6b.VfPpkd-rymPhb-ibnC6b-OWXEXe-gk6SMd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-TkwUic{background-color:rgb(60,
        64,
        67)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-TkwUic{background-color:rgba(232,
        234,
        237,.04)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(154,
        160,
        166)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):hover .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(248,
        249,
        250)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :after{border-bottom-color:rgb(138,
        180,
        248)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(189,
        193,
        198)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-NLUYnc-V67aGc{color:rgb(138,
        180,
        248)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover .VfPpkd-NLUYnc-V67aGc{color:rgb(248,
        249,
        250)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-NLUYnc-V67aGc{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me)+.VfPpkd-O1htCb-W0vJo-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-OWB6Me+.VfPpkd-O1htCb-W0vJo-fmcmS{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-UJflGc+.VfPpkd-O1htCb-W0vJo-fmcmS-OWXEXe-Rfh2Tc-EglORb{color:rgb(246,
        174,
        169)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover.VfPpkd-O1htCb-OWXEXe-UJflGc+.VfPpkd-O1htCb-W0vJo-fmcmS-OWXEXe-Rfh2Tc-EglORb{color:rgb(246,
        174,
        169)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-uusGie-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-uusGie-fmcmS{color:rgba(232,
        234,
        237,.38)
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-NLUYnc-V67aGc,.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-uusGie-fmcmS{color:GrayText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-t08AT-Bz112c{fill:rgb(189,
        193,
        198)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover .VfPpkd-t08AT-Bz112c{fill:rgb(248,
        249,
        250)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-t08AT-Bz112c{fill:rgb(138,
        180,
        248)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-t08AT-Bz112c{fill:rgba(232,
        234,
        237,.38)
    }.jR8x9d .RnXJS:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-cTi5dd{color:rgb(189,
        193,
        198)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-cTi5dd{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(246,
        174,
        169)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):hover .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(246,
        174,
        169)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :after{border-bottom-color:rgb(246,
        174,
        169)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(246,
        174,
        169)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover .VfPpkd-NLUYnc-V67aGc{color:rgb(246,
        174,
        169)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc-OWXEXe-TATcMc-KLRBe{color:rgb(246,
        174,
        169)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover .VfPpkd-NLUYnc-V67aGc-OWXEXe-TATcMc-KLRBe{color:rgb(246,
        174,
        169)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-t08AT-Bz112c{fill:rgb(242,
        139,
        130)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover .VfPpkd-t08AT-Bz112c{fill:rgb(246,
        174,
        169)
    }.jR8x9d .RnXJS.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-t08AT-Bz112c{fill:rgb(242,
        139,
        130)
    }.jR8x9d .RnXJS .VfPpkd-TkwUic .VfPpkd-woaZLe: :before,.jR8x9d .RnXJS .VfPpkd-TkwUic .VfPpkd-woaZLe: :after{background-color:rgb(241,
        243,
        244);background-color:var(--mdc-ripple-color,rgb(241,
        243,
        244))
    }.jR8x9d .RnXJS .VfPpkd-TkwUic:hover .VfPpkd-woaZLe: :before,.jR8x9d .RnXJS .VfPpkd-TkwUic.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-woaZLe: :before{opacity:.08;opacity:var(--mdc-ripple-hover-opacity,.08)
    }.jR8x9d .RnXJS .VfPpkd-TkwUic.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-woaZLe: :before,.jR8x9d .RnXJS .VfPpkd-TkwUic:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-woaZLe: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .RnXJS .VfPpkd-TkwUic:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-woaZLe: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .RnXJS .VfPpkd-TkwUic:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-woaZLe: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .RnXJS .VfPpkd-TkwUic.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(189,
        193,
        198)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe) .VfPpkd-TkwUic:hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe) .VfPpkd-TkwUic:hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe) .VfPpkd-TkwUic:hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(248,
        249,
        250)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(138,
        180,
        248)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-NSFCdd-MpmGFe{border-color:rgba(232,
        234,
        237,.12)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(154,
        160,
        166)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-NLUYnc-V67aGc{color:rgb(138,
        180,
        248)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover .VfPpkd-NLUYnc-V67aGc{color:rgb(248,
        249,
        250)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-NLUYnc-V67aGc{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me)+.VfPpkd-O1htCb-W0vJo-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-OWB6Me+.VfPpkd-O1htCb-W0vJo-fmcmS{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-UJflGc+.VfPpkd-O1htCb-W0vJo-fmcmS-OWXEXe-Rfh2Tc-EglORb{color:rgb(242,
        139,
        130)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover.VfPpkd-O1htCb-OWXEXe-UJflGc+.VfPpkd-O1htCb-W0vJo-fmcmS-OWXEXe-Rfh2Tc-EglORb{color:rgb(246,
        174,
        169)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-uusGie-fmcmS{color:rgb(232,
        234,
        237)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-uusGie-fmcmS{color:rgba(232,
        234,
        237,.38)
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-NLUYnc-V67aGc,.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-uusGie-fmcmS{color:GrayText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-t08AT-Bz112c{fill:rgb(154,
        160,
        166)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover .VfPpkd-t08AT-Bz112c{fill:rgb(248,
        249,
        250)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-t08AT-Bz112c{fill:rgb(138,
        180,
        248)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-t08AT-Bz112c{fill:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UAQDDf:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-cTi5dd{color:rgb(154,
        160,
        166)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-OWB6Me .VfPpkd-cTi5dd{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(242,
        139,
        130)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe) .VfPpkd-TkwUic:hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe) .VfPpkd-TkwUic:hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe) .VfPpkd-TkwUic:hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(246,
        174,
        169)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(242,
        139,
        130)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(242,
        139,
        130)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover .VfPpkd-NLUYnc-V67aGc{color:rgb(246,
        174,
        169)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc-OWXEXe-TATcMc-KLRBe{color:rgb(242,
        139,
        130)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover .VfPpkd-NLUYnc-V67aGc-OWXEXe-TATcMc-KLRBe{color:rgb(246,
        174,
        169)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me) .VfPpkd-t08AT-Bz112c{fill:rgb(242,
        139,
        130)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me):not(.VfPpkd-O1htCb-OWXEXe-XpnDCe):hover .VfPpkd-t08AT-Bz112c{fill:rgb(246,
        174,
        169)
    }.jR8x9d .UAQDDf.VfPpkd-O1htCb-OWXEXe-UJflGc:not(.VfPpkd-O1htCb-OWXEXe-OWB6Me).VfPpkd-O1htCb-OWXEXe-XpnDCe .VfPpkd-t08AT-Bz112c{fill:rgb(242,
        139,
        130)
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec-tmWYNe{background-color:rgb(138,
        180,
        248);border-color:rgb(138,
        180,
        248)
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec-OWXEXe-ma6Yeb .VfPpkd-UTM9ec-tmWYNe,.jR8x9d .UlwoYd .VfPpkd-UTM9ec-OWXEXe-ma6Yeb.VfPpkd-UTM9ec:hover .VfPpkd-UTM9ec-tmWYNe,.jR8x9d .UlwoYd .VfPpkd-UTM9ec-OWXEXe-ma6Yeb.VfPpkd-UTM9ec-OWXEXe-XpnDCe .VfPpkd-UTM9ec-tmWYNe{border-color:#fff
    }.jR8x9d .UlwoYd.VfPpkd-SxecR-OWXEXe-OWB6Me .VfPpkd-UTM9ec-tmWYNe{background-color:rgb(232,
        234,
        237);border-color:rgb(232,
        234,
        237)
    }.jR8x9d .UlwoYd.VfPpkd-SxecR-OWXEXe-OWB6Me .VfPpkd-UTM9ec-OWXEXe-ma6Yeb .VfPpkd-UTM9ec-tmWYNe,.jR8x9d .UlwoYd.VfPpkd-SxecR-OWXEXe-OWB6Me .VfPpkd-UTM9ec-OWXEXe-ma6Yeb.VfPpkd-UTM9ec:hover .VfPpkd-UTM9ec-tmWYNe,.jR8x9d .UlwoYd.VfPpkd-SxecR-OWXEXe-OWB6Me .VfPpkd-UTM9ec-OWXEXe-ma6Yeb.VfPpkd-UTM9ec-OWXEXe-XpnDCe .VfPpkd-UTM9ec-tmWYNe{border-color:#fff
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec: :before,.jR8x9d .UlwoYd .VfPpkd-UTM9ec: :after{background-color:rgb(138,
        180,
        248);background-color:var(--mdc-ripple-color,rgb(138,
        180,
        248))
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec:hover: :before,.jR8x9d .UlwoYd .VfPpkd-UTM9ec.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE: :before{opacity:.08;opacity:var(--mdc-ripple-hover-opacity,.08)
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe: :before,.jR8x9d .UlwoYd .VfPpkd-UTM9ec:not(.VfPpkd-ksKsZd-mWPk3d):focus: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec:not(.VfPpkd-ksKsZd-mWPk3d): :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec:not(.VfPpkd-ksKsZd-mWPk3d):active: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.24;opacity:var(--mdc-ripple-press-opacity,.24)
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.24)
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec:hover .VfPpkd-UTM9ec-tmWYNe,.jR8x9d .UlwoYd .VfPpkd-UTM9ec-OWXEXe-XpnDCe .VfPpkd-UTM9ec-tmWYNe{background-color:rgb(210,
        227,
        252);border-color:rgb(210,
        227,
        252)
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec:hover .VfPpkd-UTM9ec-OWXEXe-ma6Yeb .VfPpkd-UTM9ec-tmWYNe,.jR8x9d .UlwoYd .VfPpkd-UTM9ec:hover .VfPpkd-UTM9ec-OWXEXe-ma6Yeb.VfPpkd-UTM9ec:hover .VfPpkd-UTM9ec-tmWYNe,.jR8x9d .UlwoYd .VfPpkd-UTM9ec:hover .VfPpkd-UTM9ec-OWXEXe-ma6Yeb.VfPpkd-UTM9ec-OWXEXe-XpnDCe .VfPpkd-UTM9ec-tmWYNe,.jR8x9d .UlwoYd .VfPpkd-UTM9ec-OWXEXe-XpnDCe .VfPpkd-UTM9ec-OWXEXe-ma6Yeb .VfPpkd-UTM9ec-tmWYNe,.jR8x9d .UlwoYd .VfPpkd-UTM9ec-OWXEXe-XpnDCe .VfPpkd-UTM9ec-OWXEXe-ma6Yeb.VfPpkd-UTM9ec:hover .VfPpkd-UTM9ec-tmWYNe,.jR8x9d .UlwoYd .VfPpkd-UTM9ec-OWXEXe-XpnDCe .VfPpkd-UTM9ec-OWXEXe-ma6Yeb.VfPpkd-UTM9ec-OWXEXe-XpnDCe .VfPpkd-UTM9ec-tmWYNe{border-color:#fff
    }.jR8x9d .UlwoYd .VfPpkd-yCQwvc-OWXEXe-bp49T{border-color:rgb(138,
        180,
        248)
    }.jR8x9d .UlwoYd.VfPpkd-SxecR-OWXEXe-OWB6Me .VfPpkd-yCQwvc-OWXEXe-bp49T{border-color:rgb(232,
        234,
        237)
    }.jR8x9d .UlwoYd .VfPpkd-yCQwvc-OWXEXe-mt1Mkb{background-color:rgb(32,
        33,
        36);opacity: 1
    }.jR8x9d .UlwoYd.VfPpkd-SxecR-OWXEXe-OWB6Me .VfPpkd-yCQwvc-OWXEXe-mt1Mkb{background-color:rgba(232,
        234,
        237,.38);opacity: 1
    }.jR8x9d .UlwoYd .VfPpkd-zD2WHb-SYOSDb-OWXEXe-auswjd,.jR8x9d .UlwoYd.VfPpkd-SxecR-OWXEXe-OWB6Me .VfPpkd-zD2WHb-SYOSDb-OWXEXe-auswjd{background-color:rgb(32,
        33,
        36);opacity:.38
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .UlwoYd .VfPpkd-zD2WHb-SYOSDb-OWXEXe-auswjd{background-color:Canvas;opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .UlwoYd .VfPpkd-zD2WHb-SYOSDb-OWXEXe-mt1Mkb{background-color:rgb(138,
        180,
        248);opacity:.38
    }.jR8x9d .UlwoYd.VfPpkd-SxecR-OWXEXe-OWB6Me .VfPpkd-zD2WHb-SYOSDb-OWXEXe-mt1Mkb{background-color:rgb(232,
        234,
        237);opacity:.38
    }
}@media screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .UlwoYd .VfPpkd-zD2WHb-SYOSDb-OWXEXe-mt1Mkb{background-color:CanvasText;opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .UlwoYd:not(.VfPpkd-SxecR-OWXEXe-OWB6Me) .VfPpkd-yCQwvc-OWXEXe-mt1Mkb: :before{background-color:rgba(138,
        180,
        248,.24);border-radius:inherit;content: "";height: 100%;position:absolute;width: 100%
    }.jR8x9d .UlwoYd .VfPpkd-MIfjnf-uDEFge{background-color:rgb(138,
        180,
        248);opacity: 1
    }.jR8x9d .UlwoYd .VfPpkd-MIfjnf-uDEFge: :before{border-top-color:rgb(138,
        180,
        248)
    }.jR8x9d .UlwoYd .VfPpkd-MIfjnf-uDEFge{color:rgb(32,
        33,
        36)
    }.jR8x9d .UlwoYd.VfPpkd-SxecR .VfPpkd-yCQwvc-OWXEXe-bp49T{-webkit-transform-origin:left;-ms-transform-origin:left;transform-origin:left
    }.jR8x9d .UlwoYd .VfPpkd-MIfjnf-uDEFge{border-radius: 16px;height: 28px;padding: 0 8px
    }.jR8x9d .UlwoYd .VfPpkd-MIfjnf-uDEFge-fmcmS{font-family: "Roboto Mono",Roboto,sans-serif;font-size:.75rem;font-weight: 500;white-space:nowrap
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec.VfPpkd-UTM9ec-OWXEXe-fmcmS-YuD1xf-lTBxed .VfPpkd-MIfjnf-uDEFge-fmcmS{font-family:Roboto,sans-serif
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec.VfPpkd-UTM9ec-OWXEXe-Wetbn-lTBxed .VfPpkd-MIfjnf-uDEFge-haAclf{bottom: 40px;-webkit-transform:rotate(-45deg);-ms-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:bottom left;-ms-transform-origin:bottom left;transform-origin:bottom left
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec.VfPpkd-UTM9ec-OWXEXe-Wetbn-lTBxed .VfPpkd-MIfjnf-uDEFge{border-radius: 50% 50% 50% 0;height: 28px;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;padding: 0;position:relative;width: 28px
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec.VfPpkd-UTM9ec-OWXEXe-Wetbn-lTBxed .VfPpkd-MIfjnf-uDEFge: :before{display:none
    }.jR8x9d .UlwoYd .VfPpkd-UTM9ec.VfPpkd-UTM9ec-OWXEXe-Wetbn-lTBxed .VfPpkd-MIfjnf-uDEFge-fmcmS{-webkit-transform:rotate(45deg);-ms-transform:rotate(45deg);transform:rotate(45deg)
    }.jR8x9d .TFhMef .VfPpkd-YAxtVc{background-color:#fff
    }.jR8x9d .TFhMef .VfPpkd-gIZMF{color:rgb(60,
        64,
        67)
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:not(:disabled){background-color:transparent
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:not(:disabled){color:rgb(26,
        115,
        232);color:var(--gm-colortextbutton-ink-color,rgb(26,
        115,
        232))
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:disabled{color:rgba(60,
        64,
        67,.38);color:var(--gm-colortextbutton-disabled-ink-color,rgba(60,
        64,
        67,.38))
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .TFhMef .VfPpkd-IkaYrd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:rgb(26,
        115,
        232)
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .TFhMef .VfPpkd-IkaYrd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-uI4vCe-LkdAo,.jR8x9d .TFhMef .VfPpkd-IkaYrd .VfPpkd-UdE5de-uDEFge .VfPpkd-JGcpL-IdXvz-LkdAo-Bd00G{stroke:CanvasText
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .TFhMef .VfPpkd-IkaYrd:hover:not(:disabled),.jR8x9d .TFhMef .VfPpkd-IkaYrd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:disabled),.jR8x9d .TFhMef .VfPpkd-IkaYrd:not(.VfPpkd-ksKsZd-mWPk3d):focus:not(:disabled),.jR8x9d .TFhMef .VfPpkd-IkaYrd:active:not(:disabled){color:rgb(23,
        78,
        166);color:var(--gm-colortextbutton-ink-color--stateful,rgb(23,
        78,
        166))
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd .VfPpkd-Jh9lGc: :before,.jR8x9d .TFhMef .VfPpkd-IkaYrd .VfPpkd-Jh9lGc: :after{background-color:rgb(26,
        115,
        232);background-color:var(--gm-colortextbutton-state-color,rgb(26,
        115,
        232))
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .TFhMef .VfPpkd-IkaYrd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .TFhMef .VfPpkd-IkaYrd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.12)
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:disabled:hover .VfPpkd-Jh9lGc: :before,.jR8x9d .TFhMef .VfPpkd-IkaYrd:disabled.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Jh9lGc: :before{opacity: 0;opacity:var(--mdc-ripple-hover-opacity,
        0)
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:disabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Jh9lGc: :before,.jR8x9d .TFhMef .VfPpkd-IkaYrd:disabled:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:disabled:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:disabled:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .TFhMef .VfPpkd-IkaYrd:disabled.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0)
    }.jR8x9d .TFhMef .VfPpkd-TolmDb{color:rgb(60,
        64,
        67);z-index: 0
    }.jR8x9d .TFhMef .VfPpkd-TolmDb .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .TFhMef .VfPpkd-TolmDb .VfPpkd-Bz112c-Jh9lGc: :after{background-color:rgb(60,
        64,
        67);background-color:var(--mdc-ripple-color,rgb(60,
        64,
        67))
    }.jR8x9d .TFhMef .VfPpkd-TolmDb:hover .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .TFhMef .VfPpkd-TolmDb.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Bz112c-Jh9lGc: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .TFhMef .VfPpkd-TolmDb.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .TFhMef .VfPpkd-TolmDb:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Bz112c-Jh9lGc: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .TFhMef .VfPpkd-TolmDb:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .TFhMef .VfPpkd-TolmDb:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Bz112c-Jh9lGc: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-press-opacity,.12)
    }.jR8x9d .TFhMef .VfPpkd-TolmDb.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.12)
    }.jR8x9d .TFhMef .VfPpkd-TolmDb .VfPpkd-Bz112c-Jh9lGc: :before,.jR8x9d .TFhMef .VfPpkd-TolmDb .VfPpkd-Bz112c-Jh9lGc: :after{z-index: -1
    }.jR8x9d .TFhMef .VfPpkd-TolmDb:disabled{color:rgba(60,
        64,
        67,.38);color:var(--gm-iconbutton-disabled-ink-color,rgba(60,
        64,
        67,.38))
    }.jR8x9d .pBHsAc{width: 36px
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled .VfPpkd-uMhiad: :after{background:rgb(138,
        180,
        248)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-uMhiad: :after{background:rgb(174,
        203,
        250)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-uMhiad: :after{background:rgb(174,
        203,
        250)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active .VfPpkd-uMhiad: :after{background:rgb(174,
        203,
        250)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:disabled .VfPpkd-uMhiad: :after{background:rgb(232,
        234,
        237)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled .VfPpkd-uMhiad: :after{background:rgb(154,
        160,
        166)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-uMhiad: :after{background:rgb(248,
        249,
        250)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-uMhiad: :after{background:rgb(248,
        249,
        250)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active .VfPpkd-uMhiad: :after{background:rgb(248,
        249,
        250)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:disabled .VfPpkd-uMhiad: :after{background:rgb(232,
        234,
        237)
    }.jR8x9d .pBHsAc .VfPpkd-uMhiad: :before{background:rgb(32,
        33,
        36)
    }.jR8x9d .pBHsAc:enabled .VfPpkd-VRSVNe{-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 1px 3px 1px rgba(0,
        0,
        0,.15)
    }.jR8x9d .pBHsAc:enabled .VfPpkd-VRSVNe .VfPpkd-BFbNVe-bF1uUb{opacity:.05
    }.jR8x9d .pBHsAc:enabled .VfPpkd-VRSVNe .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .pBHsAc:disabled .VfPpkd-VRSVNe{-webkit-box-shadow:none;box-shadow:none
    }.jR8x9d .pBHsAc:disabled .VfPpkd-VRSVNe .VfPpkd-BFbNVe-bF1uUb{opacity: 0
    }.jR8x9d .pBHsAc:disabled .VfPpkd-VRSVNe .VfPpkd-BFbNVe-bF1uUb{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .pBHsAc .VfPpkd-DVBDLb-LhBDec-sM5MNb,.jR8x9d .pBHsAc .VfPpkd-uMhiad{height: 20px
    }.jR8x9d .pBHsAc:disabled .VfPpkd-uMhiad: :after{opacity:.38
    }.jR8x9d .pBHsAc .VfPpkd-uMhiad{border-radius: 10px 10px 10px 10px
    }.jR8x9d .pBHsAc .VfPpkd-uMhiad{width: 20px
    }.jR8x9d .pBHsAc .VfPpkd-uMhiad-u014N{width:calc(100% - 20px)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled .VfPpkd-pafCAf{fill:rgb(32,
        33,
        36)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:disabled .VfPpkd-pafCAf{fill:rgb(32,
        33,
        36)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled .VfPpkd-pafCAf{fill:rgb(32,
        33,
        36)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:disabled .VfPpkd-pafCAf{fill:rgb(32,
        33,
        36)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:disabled .VfPpkd-lw9akd{opacity:.38
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:disabled .VfPpkd-lw9akd{opacity:.38
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd .VfPpkd-pafCAf,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd .VfPpkd-pafCAf{width: 18px;height: 18px
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe) .VfPpkd-Qsb3yd: :before,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe) .VfPpkd-Qsb3yd: :after{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd: :before,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd: :after{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active .VfPpkd-Qsb3yd: :before,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active .VfPpkd-Qsb3yd: :after{background-color:rgb(138,
        180,
        248)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe) .VfPpkd-Qsb3yd: :before,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe) .VfPpkd-Qsb3yd: :after{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd: :before,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd: :after{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active .VfPpkd-Qsb3yd: :before,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active .VfPpkd-Qsb3yd: :after{background-color:rgb(232,
        234,
        237)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):hover .VfPpkd-Qsb3yd: :before,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe).VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Qsb3yd: :before{opacity:.04
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd: :before,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Qsb3yd: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Qsb3yd: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Qsb3yd: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled:active.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-switch-selected-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):hover .VfPpkd-Qsb3yd: :before,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe).VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-Qsb3yd: :before{opacity:.04
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-Qsb3yd: :before,.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-Qsb3yd: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-Qsb3yd: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-Qsb3yd: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled:active.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-switch-unselected-pressed-state-layer-opacity,
        0.1)
    }.jR8x9d .pBHsAc .VfPpkd-Qsb3yd{height: 48px;width: 48px
    }.jR8x9d .pBHsAc .VfPpkd-l6JLsf{height: 14px
    }.jR8x9d .pBHsAc:disabled .VfPpkd-l6JLsf{opacity:.12
    }.jR8x9d .pBHsAc:enabled .VfPpkd-l6JLsf: :after{background:rgb(26,
        115,
        232)
    }.jR8x9d .pBHsAc:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-l6JLsf: :after{background:rgb(26,
        115,
        232)
    }.jR8x9d .pBHsAc:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-l6JLsf: :after{background:rgb(26,
        115,
        232)
    }.jR8x9d .pBHsAc:enabled:active .VfPpkd-l6JLsf: :after{background:rgb(26,
        115,
        232)
    }.jR8x9d .pBHsAc:disabled .VfPpkd-l6JLsf: :after{background:rgb(232,
        234,
        237)
    }.jR8x9d .pBHsAc:enabled .VfPpkd-l6JLsf: :before{background:rgb(95,
        99,
        104)
    }.jR8x9d .pBHsAc:enabled:hover:not(.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe):not(:active) .VfPpkd-l6JLsf: :before{background:rgb(95,
        99,
        104)
    }.jR8x9d .pBHsAc:enabled.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe:not(:active) .VfPpkd-l6JLsf: :before{background:rgb(95,
        99,
        104)
    }.jR8x9d .pBHsAc:enabled:active .VfPpkd-l6JLsf: :before{background:rgb(95,
        99,
        104)
    }.jR8x9d .pBHsAc:disabled .VfPpkd-l6JLsf: :before{background:rgb(232,
        234,
        237)
    }.jR8x9d .pBHsAc .VfPpkd-l6JLsf{border-radius: 7px 7px 7px 7px
    }
}@media screen and (prefers-color-scheme:dark) and (-ms-high-contrast:active),screen and (prefers-color-scheme:dark) and (forced-colors:active){.jR8x9d .pBHsAc:disabled .VfPpkd-uMhiad: :after{opacity: 1
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:enabled .VfPpkd-pafCAf{fill:ButtonText
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:disabled .VfPpkd-pafCAf{fill:GrayText
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:enabled .VfPpkd-pafCAf{fill:ButtonText
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:disabled .VfPpkd-pafCAf{fill:GrayText
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-gk6SMd:disabled .VfPpkd-lw9akd{opacity: 1
    }.jR8x9d .pBHsAc.VfPpkd-scr2fc-OWXEXe-uqeOfd:disabled .VfPpkd-lw9akd{opacity: 1
    }.jR8x9d .pBHsAc:disabled .VfPpkd-l6JLsf{opacity: 1
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .FEsNhd{font-family: "Google Sans",Roboto,Arial,sans-serif;line-height: 1.25rem;font-size:.875rem;letter-spacing:.0178571429em;font-weight: 500;padding-right: 16px;padding-left: 16px;text-transform:none;min-width:auto
    }.jR8x9d .FEsNhd .VfPpkd-jY41G-V67aGc{color:rgb(154,
        160,
        166)
    }.jR8x9d .FEsNhd .VfPpkd-cfyjzb{color:rgb(154,
        160,
        166);fill:currentColor
    }.jR8x9d .FEsNhd:hover .VfPpkd-YVzG2b: :before,.jR8x9d .FEsNhd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-YVzG2b: :before{opacity:.08;opacity:var(--mdc-ripple-hover-opacity,.08)
    }.jR8x9d .FEsNhd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-YVzG2b: :before,.jR8x9d .FEsNhd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-YVzG2b: :before{opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
    }.jR8x9d .FEsNhd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-YVzG2b: :after{opacity:.24;opacity:var(--mdc-ripple-press-opacity,.24)
    }.jR8x9d .FEsNhd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.24)
    }.jR8x9d .FEsNhd:hover .VfPpkd-jY41G-V67aGc,.jR8x9d .FEsNhd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-jY41G-V67aGc,.jR8x9d .FEsNhd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-jY41G-V67aGc,.jR8x9d .FEsNhd:active .VfPpkd-jY41G-V67aGc{color:rgb(232,
        234,
        237)
    }.jR8x9d .FEsNhd:hover .VfPpkd-cfyjzb,.jR8x9d .FEsNhd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-cfyjzb,.jR8x9d .FEsNhd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-cfyjzb,.jR8x9d .FEsNhd:active .VfPpkd-cfyjzb{color:rgb(232,
        234,
        237);fill:currentColor
    }.jR8x9d .FEsNhd .VfPpkd-YVzG2b: :before,.jR8x9d .FEsNhd .VfPpkd-YVzG2b: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .FEsNhd:hover .VfPpkd-YVzG2b: :before,.jR8x9d .FEsNhd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-YVzG2b: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .FEsNhd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-YVzG2b: :before,.jR8x9d .FEsNhd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-YVzG2b: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .FEsNhd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-YVzG2b: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .FEsNhd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-YVzG2b: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .FEsNhd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd:hover .VfPpkd-YVzG2b: :before,.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-YVzG2b: :before{opacity:.08;opacity:var(--mdc-ripple-hover-opacity,.08)
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-YVzG2b: :before,.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-YVzG2b: :before{opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-YVzG2b: :after{opacity:.24;opacity:var(--mdc-ripple-press-opacity,.24)
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.24)
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-jY41G-V67aGc{color:rgb(138,
        180,
        248)
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-cfyjzb{color:rgb(138,
        180,
        248);fill:currentColor
    }.jR8x9d .FEsNhd:hover.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-jY41G-V67aGc,.jR8x9d .FEsNhd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-jY41G-V67aGc,.jR8x9d .FEsNhd:not(.VfPpkd-ksKsZd-mWPk3d):focus.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-jY41G-V67aGc,.jR8x9d .FEsNhd:active.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-jY41G-V67aGc{color:rgb(174,
        203,
        250)
    }.jR8x9d .FEsNhd:hover.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-cfyjzb,.jR8x9d .FEsNhd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-cfyjzb,.jR8x9d .FEsNhd:not(.VfPpkd-ksKsZd-mWPk3d):focus.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-cfyjzb,.jR8x9d .FEsNhd:active.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-cfyjzb{color:rgb(174,
        203,
        250);fill:currentColor
    }.jR8x9d .FEsNhd:hover .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb,.jR8x9d .FEsNhd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb,.jR8x9d .FEsNhd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb,.jR8x9d .FEsNhd:active .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb{border-color:rgb(174,
        203,
        250)
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-YVzG2b: :before,.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-YVzG2b: :after{background-color:rgb(174,
        203,
        250);background-color:var(--mdc-ripple-color,rgb(174,
        203,
        250))
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd:hover .VfPpkd-YVzG2b: :before,.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-YVzG2b: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-YVzG2b: :before,.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-YVzG2b: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-YVzG2b: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-YVzG2b: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .FEsNhd.VfPpkd-AznF2e-OWXEXe-auswjd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .V0XHEd{font-family: "Google Sans",Roboto,Arial,sans-serif;line-height: 1.25rem;font-size:.875rem;letter-spacing:.0178571429em;font-weight: 500;padding-right: 16px;padding-left: 16px;text-transform:none;min-width:auto
    }.jR8x9d .V0XHEd .VfPpkd-jY41G-V67aGc{color:rgb(154,
        160,
        166)
    }.jR8x9d .V0XHEd .VfPpkd-cfyjzb{color:rgb(154,
        160,
        166);fill:currentColor
    }.jR8x9d .V0XHEd:hover .VfPpkd-jY41G-V67aGc,.jR8x9d .V0XHEd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-jY41G-V67aGc,.jR8x9d .V0XHEd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-jY41G-V67aGc,.jR8x9d .V0XHEd:active .VfPpkd-jY41G-V67aGc{color:rgb(232,
        234,
        237)
    }.jR8x9d .V0XHEd:hover .VfPpkd-cfyjzb,.jR8x9d .V0XHEd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-cfyjzb,.jR8x9d .V0XHEd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-cfyjzb,.jR8x9d .V0XHEd:active .VfPpkd-cfyjzb{color:rgb(232,
        234,
        237);fill:currentColor
    }.jR8x9d .V0XHEd:hover .VfPpkd-YVzG2b: :before,.jR8x9d .V0XHEd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-YVzG2b: :before{opacity:.08;opacity:var(--mdc-ripple-hover-opacity,.08)
    }.jR8x9d .V0XHEd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-YVzG2b: :before,.jR8x9d .V0XHEd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-YVzG2b: :before{opacity:.24;opacity:var(--mdc-ripple-focus-opacity,.24)
    }.jR8x9d .V0XHEd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-YVzG2b: :after{opacity:.24;opacity:var(--mdc-ripple-press-opacity,.24)
    }.jR8x9d .V0XHEd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.24)
    }.jR8x9d .V0XHEd.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-jY41G-V67aGc{color:rgb(232,
        234,
        237)
    }.jR8x9d .V0XHEd.VfPpkd-AznF2e-OWXEXe-auswjd .VfPpkd-cfyjzb{color:rgb(232,
        234,
        237);fill:currentColor
    }.jR8x9d .V0XHEd:hover .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb,.jR8x9d .V0XHEd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb,.jR8x9d .V0XHEd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb,.jR8x9d .V0XHEd:active .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb{border-color:rgb(174,
        203,
        250)
    }.jR8x9d .V0XHEd .VfPpkd-YVzG2b: :before,.jR8x9d .V0XHEd .VfPpkd-YVzG2b: :after{background-color:rgb(232,
        234,
        237);background-color:var(--mdc-ripple-color,rgb(232,
        234,
        237))
    }.jR8x9d .V0XHEd:hover .VfPpkd-YVzG2b: :before,.jR8x9d .V0XHEd.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-YVzG2b: :before{opacity:.04;opacity:var(--mdc-ripple-hover-opacity,.04)
    }.jR8x9d .V0XHEd.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-YVzG2b: :before,.jR8x9d .V0XHEd:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-YVzG2b: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.12;opacity:var(--mdc-ripple-focus-opacity,.12)
    }.jR8x9d .V0XHEd:not(.VfPpkd-ksKsZd-mWPk3d) .VfPpkd-YVzG2b: :after{-webkit-transition:opacity .15s linear;transition:opacity .15s linear
    }.jR8x9d .V0XHEd:not(.VfPpkd-ksKsZd-mWPk3d):active .VfPpkd-YVzG2b: :after{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity:.1;opacity:var(--mdc-ripple-press-opacity,.1)
    }.jR8x9d .V0XHEd.VfPpkd-ksKsZd-mWPk3d{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity,
        0.1)
    }.jR8x9d .kte1hc .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb{border-color:rgb(138,
        180,
        248)
    }.jR8x9d .kte1hc .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb{border-top-width: 3px
    }.jR8x9d .kte1hc .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb{border-top-left-radius: 3px;border-top-right-radius: 3px
    }.jR8x9d .p4biwf .VfPpkd-AznF2e-wEcVzc-OWXEXe-NowJzb{border-color:rgb(138,
        180,
        248)
    }.jR8x9d .gOPnwc:hover .VfPpkd-fmcmS-OyKIhb: :before,.jR8x9d .gOPnwc.VfPpkd-ksKsZd-XxIAqe-OWXEXe-ZmdkE .VfPpkd-fmcmS-OyKIhb: :before{opacity:.08;opacity:var(--mdc-ripple-hover-opacity,.08)
    }.jR8x9d .gOPnwc.VfPpkd-ksKsZd-mWPk3d-OWXEXe-AHe6Kc-XpnDCe .VfPpkd-fmcmS-OyKIhb: :before,.jR8x9d .gOPnwc:not(.VfPpkd-ksKsZd-mWPk3d):focus .VfPpkd-fmcmS-OyKIhb: :before{-webkit-transition-duration: 75ms;transition-duration: 75ms;opacity: 0;opacity:var(--mdc-ripple-focus-opacity,
        0)
    }.jR8x9d .gOPnwc .VfPpkd-fmcmS-OyKIhb: :before,.jR8x9d .gOPnwc .VfPpkd-fmcmS-OyKIhb: :after{background-color:rgb(241,
        243,
        244);background-color:var(--mdc-ripple-color,rgb(241,
        243,
        244))
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd,.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd{color:rgb(154,
        160,
        166)
    }.jR8x9d .gOPnwc .VfPpkd-fmcmS-wGMbrd{caret-color:rgb(138,
        180,
        248)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd{color:rgb(232,
        234,
        237)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me){background-color:rgb(60,
        64,
        67)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(154,
        160,
        166)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(189,
        193,
        198)
    }.jR8x9d .gOPnwc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(248,
        249,
        250)
    }.jR8x9d .gOPnwc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(248,
        249,
        250)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(154,
        160,
        166)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :after{border-bottom-color:rgb(138,
        180,
        248)
    }
}@media screen and (prefers-color-scheme:dark){.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledTextFieldDarkTheme:not(.mdc-text-field--disabled) .mdc-text-field__input: :-webkit-input-placeholder{color:rgb(189,
        193,
        198)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledTextFieldDarkTheme:not(.mdc-text-field--disabled) .mdc-text-field__input: :-moz-placeholder{color:rgb(189,
        193,
        198)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledTextFieldDarkTheme:not(.mdc-text-field--disabled) .mdc-text-field__input:-ms-input-placeholder{color:rgb(189,
        193,
        198)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledTextFieldDarkTheme:not(.mdc-text-field--disabled) .mdc-text-field__input: :-ms-input-placeholder{color:rgb(189,
        193,
        198)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd: :placeholder{color:rgb(189,
        193,
        198)
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd:-ms-input-placeholder{color:rgb(189,
        193,
        198)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-MvKemf-OWXEXe-qdIk2c{color:rgb(154,
        160,
        166)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-MvKemf-OWXEXe-iJ4yB{color:rgb(154,
        160,
        166)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-M1Soyc{color:rgb(154,
        160,
        166)
    }.jR8x9d .gOPnwc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(154,
        160,
        166)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me{background-color:rgba(232,
        234,
        237,.04)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-NLUYnc-V67aGc,.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-TvZj5c-OWXEXe-M1Soyc,.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg,.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS,.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd,.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd{color:rgba(232,
        234,
        237,.38)
    }
}@media screen and (prefers-color-scheme:dark){.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledTextFieldDarkTheme.mdc-text-field--disabled .mdc-text-field__input: :-webkit-input-placeholder{color:rgba(232,
        234,
        237,.38)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledTextFieldDarkTheme.mdc-text-field--disabled .mdc-text-field__input: :-moz-placeholder{color:rgba(232,
        234,
        237,.38)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledTextFieldDarkTheme.mdc-text-field--disabled .mdc-text-field__input:-ms-input-placeholder{color:rgba(232,
        234,
        237,.38)
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmFilledTextFieldDarkTheme.mdc-text-field--disabled .mdc-text-field__input: :-ms-input-placeholder{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd: :placeholder{color:rgba(232,
        234,
        237,.38)
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd:-ms-input-placeholder{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-MvKemf-OWXEXe-qdIk2c,.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-MvKemf-OWXEXe-iJ4yB{color:rgba(232,
        234,
        237,.38)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(138,
        180,
        248)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc .VfPpkd-fmcmS-wGMbrd{caret-color:rgb(246,
        174,
        169)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(242,
        139,
        130)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(242,
        139,
        130)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(246,
        174,
        169)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :after{border-bottom-color:rgb(246,
        174,
        169)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(246,
        174,
        169)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(246,
        174,
        169)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(246,
        174,
        169)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-RWgCYc-ksKsZd: :before{border-bottom-color:rgb(246,
        174,
        169)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe .VfPpkd-NLUYnc-V67aGc{color:rgb(138,
        180,
        248)
    }.jR8x9d .gOPnwc.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(246,
        174,
        169)
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd{color:rgb(232,
        234,
        237);color:var(--gm-outlinedtextfield-ink-color,rgb(232,
        234,
        237))
    }.jR8x9d .orScbe .VfPpkd-fmcmS-wGMbrd{caret-color:rgb(138,
        180,
        248);caret-color:var(--gm-outlinedtextfield-caret-color,rgb(138,
        180,
        248))
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(154,
        160,
        166);color:var(--gm-outlinedtextfield-helper-text-color,rgb(154,
        160,
        166))
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd,.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd{color:rgb(154,
        160,
        166)
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(154,
        160,
        166);color:var(--gm-outlinedtextfield-label-color,rgb(154,
        160,
        166))
    }.jR8x9d .orScbe:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(248,
        249,
        250)
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(189,
        193,
        198);border-color:var(--gm-outlinedtextfield-outline-color,rgb(189,
        193,
        198))
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(248,
        249,
        250)
    }
}@media screen and (prefers-color-scheme:dark){.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedTextFieldDarkTheme:not(.mdc-text-field--disabled) .mdc-text-field__input: :-webkit-input-placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedTextFieldDarkTheme:not(.mdc-text-field--disabled) .mdc-text-field__input: :-moz-placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedTextFieldDarkTheme:not(.mdc-text-field--disabled) .mdc-text-field__input:-ms-input-placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedTextFieldDarkTheme:not(.mdc-text-field--disabled) .mdc-text-field__input: :-ms-input-placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd: :placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-wGMbrd:-ms-input-placeholder{color:rgb(189,
        193,
        198);color:var(--gm-outlinedtextfield-placeholder-color,rgb(189,
        193,
        198))
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-MvKemf-OWXEXe-qdIk2c{color:rgb(154,
        160,
        166);color:var(--gm-outlinedtextfield-prefix-color,rgb(154,
        160,
        166))
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-MvKemf-OWXEXe-iJ4yB{color:rgb(154,
        160,
        166);color:var(--gm-outlinedtextfield-suffix-color,rgb(154,
        160,
        166))
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-M1Soyc{color:rgb(154,
        160,
        166)
    }.jR8x9d .orScbe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(154,
        160,
        166)
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-ink-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-NSFCdd-MpmGFe{border-color:rgba(232,
        234,
        237,.12);border-color:var(--gm-outlinedtextfield-outline-color--disabled,rgba(232,
        234,
        237,.12))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-NLUYnc-V67aGc{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-label-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-TvZj5c-OWXEXe-M1Soyc{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-icon-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-icon-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-helper-text-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-JZnCve-gmhCAd{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-character-counter-color--disabled,rgba(232,
        234,
        237,.38))
    }
}@media screen and (prefers-color-scheme:dark){.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedTextFieldDarkTheme.mdc-text-field--disabled .mdc-text-field__input: :-webkit-input-placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedTextFieldDarkTheme.mdc-text-field--disabled .mdc-text-field__input: :-moz-placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedTextFieldDarkTheme.mdc-text-field--disabled .mdc-text-field__input:-ms-input-placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }.boqAccountsWireframeThemesMaterialnextBaseBodyEl .GmOutlinedTextFieldDarkTheme.mdc-text-field--disabled .mdc-text-field__input: :-ms-input-placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd: :placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }
}@media screen and (prefers-color-scheme:dark){.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-wGMbrd:-ms-input-placeholder{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-placeholder-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-MvKemf-OWXEXe-qdIk2c{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-prefix-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me .VfPpkd-fmcmS-MvKemf-OWXEXe-iJ4yB{color:rgba(232,
        234,
        237,.38);color:var(--gm-outlinedtextfield-suffix-color--disabled,rgba(232,
        234,
        237,.38))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(138,
        180,
        248);border-color:var(--gm-outlinedtextfield-outline-color--stateful,rgb(138,
        180,
        248))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(138,
        180,
        248);color:var(--gm-outlinedtextfield-label-color--stateful,rgb(138,
        180,
        248))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc .VfPpkd-fmcmS-wGMbrd{caret-color:rgb(242,
        139,
        130);caret-color:var(--gm-outlinedtextfield-caret-color--error,rgb(242,
        139,
        130))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(242,
        139,
        130);color:var(--gm-outlinedtextfield-helper-text-color--error,rgb(242,
        139,
        130))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me)+.VfPpkd-fmcmS-yrriRe-W0vJo-RWgCYc .VfPpkd-fmcmS-yrriRe-W0vJo-fmcmS{color:rgb(246,
        174,
        169)
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(246,
        174,
        169)
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:hover:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(246,
        174,
        169)
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me):not(.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe):hover .VfPpkd-NSFCdd-i5vt6e .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(246,
        174,
        169)
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(242,
        139,
        130);border-color:var(--gm-outlinedtextfield-outline-color--error,rgb(242,
        139,
        130))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-fmcmS-TvZj5c-OWXEXe-UbuQg{color:rgb(242,
        139,
        130);color:var(--gm-outlinedtextfield-icon-color--error,rgb(242,
        139,
        130))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Brv4Fb,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-Ra9xwd,.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NSFCdd-MpmGFe{border-color:rgb(242,
        139,
        130);border-color:var(--gm-outlinedtextfield-outline-color--error-stateful,rgb(242,
        139,
        130))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-XpnDCe .VfPpkd-NLUYnc-V67aGc{color:rgb(138,
        180,
        248);color:var(--gm-outlinedtextfield-label-color--stateful,rgb(138,
        180,
        248))
    }.jR8x9d .orScbe.VfPpkd-fmcmS-yrriRe-OWXEXe-UJflGc:not(.VfPpkd-fmcmS-yrriRe-OWXEXe-OWB6Me) .VfPpkd-NLUYnc-V67aGc{color:rgb(242,
        139,
        130);color:var(--gm-outlinedtextfield-label-color--error,rgb(242,
        139,
        130))
    }.jR8x9d .TA5ace .VfPpkd-z59Tgd{background-color:rgb(60,
        64,
        67)
    }.jR8x9d .TA5ace .VfPpkd-z59Tgd,.jR8x9d .TA5ace .VfPpkd-MlC99b,.jR8x9d .TA5ace .VfPpkd-IqDDtd{color:rgb(232,
        234,
        237)
    }.jR8x9d .TA5ace .VfPpkd-IqDDtd-hSRGPd{color:rgb(138,
        180,
        248)
    }.jR8x9d .TA5ace.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd,.jR8x9d .TA5ace.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-ma6Yeb,.jR8x9d .TA5ace.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-cGMI2b{background-color:rgb(32,
        33,
        36)
    }.jR8x9d .TA5ace.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-MlC99b{font-family: "Google Sans",Roboto,Arial,sans-serif;line-height: 1.25rem;font-size:.875rem;letter-spacing:.0178571429em;font-weight: 500
    }.jR8x9d .TA5ace.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd{border-radius: 8px
    }.jR8x9d .TA5ace.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd,.jR8x9d .TA5ace.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-cGMI2b{border-width: 0;-webkit-box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15);box-shadow: 0 1px 2px 0 rgba(0,
        0,
        0,.3),
        0 2px 6px 2px rgba(0,
        0,
        0,.15)
    }.jR8x9d .TA5ace.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-z59Tgd .VfPpkd-BFbNVe-bF1uUb,.jR8x9d .TA5ace.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-cGMI2b .VfPpkd-BFbNVe-bF1uUb,.jR8x9d .TA5ace.VfPpkd-suEOdc-OWXEXe-nzrxxc .VfPpkd-Djsh7e-XxIAqe-ma6Yeb .VfPpkd-BFbNVe-bF1uUb{opacity:.08
    }
}.Ha17qf{background:#fff;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;max-width: 100%;min-height: 100vh;position:relative
}@media (min-width: 601px){.Ha17qf{background:#fff;border: 1px solid rgb(218,
        220,
        224);border-radius: 8px;display:block;-webkit-flex-shrink: 0;flex-shrink: 0;margin: 0 auto;min-height: 0;width: 450px
    }.Ha17qf.qmmlRd{width: 450px
    }.Ha17qf.qmmlRd .Or16q{height:auto;min-height: 500px
    }
}.Or16q{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;overflow:hidden;padding: 24px 24px 36px
}@media (min-width: 601px){.Or16q{height:auto;min-height: 500px;overflow-y:auto
    }
}@media (min-width: 450px){.Or16q{padding: 48px 40px 36px
    }
}.iEhbme{padding: 24px 0 0
}.iEhbme.RDPZE{opacity:.5;pointer-events:none
}.BrpTO{margin:auto;max-width: 380px;overflow:hidden;position:relative
}.BrpTO .Q8ElWe{position:relative;text-align:center
}.viAgtf{border-radius: 50%;color:rgb(95,
    99,
    104);overflow:hidden
}.eCirAf{line-height: 1.4286
}.cABCAe{width: 100%
}.cABCAe .viAgtf{-webkit-box-flex: 0;-webkit-flex:none;flex:none;height: 28px;margin-right: 12px;width: 28px
}.cABCAe .Q8ElWe,.TPmpLe .Q8ElWe{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center
}.cABCAe .Q8ElWe{-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center
}.BrpTO .viAgtf{height: 64px;margin: 0 auto 8px;width: 64px
}.rs3gSb{border-radius: 50%;display:block
}.cABCAe .rs3gSb,.cABCAe .hZUije,.cABCAe .kHluYc{max-height: 100%;max-width: 100%
}.BrpTO .rs3gSb,.BrpTO .hZUije,.BrpTO .kHluYc{height: 64px;width: 64px
}.TPmpLe{height: 20px
}.TPmpLe .viAgtf{display:-webkit-box;display:-webkit-flex;display:flex;height: 20px;margin-right: 8px;min-width: 20px
}.TPmpLe .rs3gSb,.TPmpLe .hZUije,.TPmpLe .kHluYc{color:rgb(60,
    64,
    67);height: 20px;width: 20px
}.TPmpLe .kk39Eb{overflow:hidden
}.TPmpLe .yavlK{overflow:hidden;text-overflow:ellipsis;white-space:nowrap
}.cABCAe .kk39Eb{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1
}.cABCAe .eCirAf{color:rgb(60,
    64,
    67);font-size: 14px;font-weight: 500
}.BrpTO .eCirAf{color:rgb(32,
    33,
    36);font-size: 16px
}.yavlK,.LAkAYd,.FzDwd{direction:ltr;font-size: 12px;text-align:left;line-height: 1.3333;word-break:break-all
}.FzDwd{color:rgb(95,
    99,
    104)
}.TPmpLe .yavlK{color:rgb(60,
    64,
    67)
}.cABCAe .yavlK{color:rgb(95,
    99,
    104)
}.cABCAe .LAkAYd{color:rgb(95,
    99,
    104)
}.BrpTO .yavlK{color:rgb(95,
    99,
    104);text-align:center
}.BtUzhd{color:rgb(95,
    99,
    104);font-size: 12px
}.cABCAe .BtUzhd{-webkit-align-self:flex-start;align-self:flex-start;-webkit-box-flex: 0;-webkit-flex:none;flex:none;line-height: 1.3333
}.HDuqac{background:transparent;border:none;color:rgb(60,
    64,
    67);cursor:pointer;display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;font-size: 14px;letter-spacing:.25px;max-width: 100%
}.BOs5fd{-webkit-box-align:center;-webkit-align-items:center;align-items:center;background:#fff;border: 1px solid rgb(218,
    220,
    224);display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;max-width: 100%;position:relative
}.HDuqac:focus-visible{outline:none
}.HDuqac:focus-visible .BOs5fd{outline:none;position:relative;background:rgba(60,
    64,
    67,.12)
}.HDuqac:focus-visible .BOs5fd: :after{border: 2px solid rgb(24,
    90,
    188);border-radius: 20px;bottom: -5px;-webkit-box-shadow: 0 0 0 2px rgb(232,
    240,
    254);box-shadow: 0 0 0 2px rgb(232,
    240,
    254);content: "";left: -5px;position:absolute;right: -5px;top: -5px
}.HDuqac:focus:not(:focus-visible) .BOs5fd{-webkit-box-shadow: 0 1px 1px 0 rgba(66,
    133,
    244,.3),
    0 1px 3px 1px rgba(66,
    133,
    244,.15);box-shadow: 0 1px 1px 0 rgba(66,
    133,
    244,.3),
    0 1px 3px 1px rgba(66,
    133,
    244,.15);border-color:rgb(218,
    220,
    224);-webkit-box-shadow:none;box-shadow:none
}.HDuqac:hover:not(:focus-visible) .BOs5fd{background:rgba(60,
    64,
    67,.04)
}.HDuqac:focus .BOs5fd,.HDuqac:hover .BOs5fd{border-color:rgb(218,
    220,
    224)
}.HDuqac:active:focus .BOs5fd{background:rgba(60,
    64,
    67,.12);border-color:rgb(60,
    64,
    67);color:rgb(60,
    64,
    67)
}.EI77qf{line-height: 30px;margin: -8px 0;padding: 8px 0
}.EI77qf.DbQnIe{color:rgb(26,
    115,
    232);font-size: 12px;line-height: 22px
}.EI77qf .BOs5fd{border-radius: 16px;padding: 0 15px 0 15px
}.EI77qf.DbQnIe .BOs5fd{border-radius: 12px;padding: 0 10px 0 10px
}.EI77qf.iiFyne .BOs5fd{padding-right: 7px
}.EI77qf.cd29Sd .BOs5fd{padding-left: 5px
}.EI77qf.DbQnIe.cd29Sd .BOs5fd{padding-left: 2px
}.EI77qf.DbQnIe.iiFyne .BOs5fd{padding-right: 7px
}.hMeYtd{border-radius: 10px;height: 20px;margin-right: 8px
}.hMeYtd .rs3gSb,.hMeYtd .hZUije,.hMeYtd .kHluYc{border-radius: 50%;color:rgb(60,
    64,
    67);display:block;height: 20px;width: 20px
}.wJxLsd{direction:ltr;overflow:hidden;text-align:left;text-overflow:ellipsis;white-space:nowrap
}.znpTjf{color:rgb(60,
    64,
    67);-webkit-flex-shrink: 0;flex-shrink: 0;height: 18px;margin-left: 4px;width: 18px
}.HDuqac.DbQnIe .znpTjf{height: 16px;width: 16px
}.JC0zZc{display:block;height: 100%;width: 100%
}.aMfydd{text-align:center
}.aMfydd .Tn0LBd{padding-bottom: 0;padding-top: 16px;color:rgb(32,
    33,
    36);font-size: 24px;font-weight: 400;line-height: 1.3333;margin-bottom: 0;margin-top: 0
}.a2CQh{padding-bottom: 3px;padding-top: 1px;margin-bottom: 0;margin-top: 0
}.a2CQh{font-size: 16px;font-weight: 400;letter-spacing:.1px;line-height: 1.5;padding-bottom: 0;padding-top: 8px
}.a2CQh:empty{display:none
}.n868rf{display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;letter-spacing:.25px;min-height: 24px;padding-bottom: 0;padding-top: 8px
}.C7uRJc{margin-top: 8px
}.NveWz{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1
}.i2knIc{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:reverse;-webkit-flex-direction:column-reverse;flex-direction:column-reverse;-webkit-box-flex: 0;-webkit-flex-grow: 0;flex-grow: 0;-webkit-flex-wrap:wrap;flex-wrap:wrap;margin-left: -8px;margin-top: 32px;margin-bottom: -16px;min-height: 48px;padding-bottom: 20px
}.i2knIc.fXx9Lc,.i2knIc.fXx9Lc .RhTxBf,.i2knIc.fXx9Lc .tmMcIf{margin: 0;min-height: 0;padding: 0
}.sXlxWd{margin-bottom: 32px;width: 100%
}.wg0fFb{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:reverse;-webkit-flex-direction:row-reverse;flex-direction:row-reverse;-webkit-flex-wrap:wrap;flex-wrap:wrap;width: 100%
}.RhTxBf,.tmMcIf{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;margin-bottom: 16px
}.i2knIc.NNItQ:not(.F8PBrb) .RhTxBf,.i2knIc.NNItQ:not(.F8PBrb) .tmMcIf{text-align:center
}.RhTxBf{text-align:right
}.i2knIc.F8PBrb{margin-left: 0
}.i2knIc.F8PBrb .wg0fFb{margin: 0 -2px;width:calc(100% + 4px)
}.i2knIc.F8PBrb .RhTxBf{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;width: 100%
}.i2knIc.F8PBrb .tmMcIf{margin: 0 2px
}.xOs3Jc{-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1;margin: 0 2px;min-width:calc(50% - 4px)
}.Cokknd{margin-bottom: 6px;margin-top: 6px;white-space:nowrap;width: 100%
}.D4rY0b{color:rgb(95,
    99,
    104);font-size: 14px;line-height: 1.4286;margin-top: 32px
}.wsArZ[data-ss-mode="1"
] .iv5ilf.F8PBrb{margin-left: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf.F8PBrb{margin-left: 0
    }
}.wsArZ[data-ss-mode="1"
] .iv5ilf.F8PBrb .v8y8Fe{-webkit-box-flex:unset;-webkit-flex-grow:unset;flex-grow:unset;margin-left: 0;padding-left: 0;width:calc(50% - ((var(
    --c-gutw,
    48px
  ))/2) + 12px)
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf.F8PBrb .v8y8Fe{-webkit-box-flex:unset;-webkit-flex-grow:unset;flex-grow:unset;margin-left: 0;padding-left: 0;width:calc(50% - ((var(
    --c-gutw,
        48px
  ))/2) + 12px)
    }
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .iv5ilf.F8PBrb .v8y8Fe{width:calc(50% - ((var(
    --c-gutw,
        76px
  ))/2) + 12px)
    }
}.iv5ilf.F8PBrb.NNItQ .v8y8Fe{width: 100%
}.iv5ilf.F8PBrb .zdUG4b{margin-left: 6px;margin-right: 6px
}.wsArZ[data-ss-mode="1"
] .iv5ilf.F8PBrb .zdUG4b{margin-left: 2px
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf.F8PBrb .zdUG4b{margin-left: 2px
    }
}.iv5ilf.F8PBrb .Te5wkb{-webkit-box-align:start;-webkit-align-items:flex-start;align-items:flex-start;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;margin: 0 -6px;width:calc(100% + 12px)
}.wsArZ[data-ss-mode="1"
] .iv5ilf.F8PBrb .Te5wkb{-webkit-box-align:end;-webkit-align-items:flex-end;align-items:flex-end;-webkit-align-self:flex-end;align-self:flex-end;width: 100%
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf.F8PBrb .Te5wkb{-webkit-box-align:end;-webkit-align-items:flex-end;align-items:flex-end;-webkit-align-self:flex-end;align-self:flex-end;width: 100%
    }
}.iv5ilf.F8PBrb.NNItQ .Te5wkb{-webkit-box-align:center;-webkit-align-items:center;align-items:center
}.wsArZ[data-ss-mode="1"
] .iv5ilf.F8PBrb.NNItQ .Te5wkb{width:calc(50% - ((var(
    --c-gutw,
    48px
  ))/2) + 12px)
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .iv5ilf.F8PBrb.NNItQ .Te5wkb{width:calc(50% - ((var(
    --c-gutw,
        48px
  ))/2) + 12px)
    }
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .iv5ilf.F8PBrb.NNItQ .Te5wkb{width:calc(50% - ((var(
    --c-gutw,
        76px
  ))/2) + 12px)
    }
}.Cny7p.lUWEgd.F8PBrb .zdUG4b{margin-right: 2px
}.iv5ilf.F8PBrb.lUWEgd.c0e3be .zdUG4b{margin-left: 2px
}.iv5ilf.F8PBrb.lUWEgd.c0e3be .Te5wkb{-webkit-box-orient:horizontal;-webkit-box-direction:reverse;-webkit-flex-direction:row-reverse;flex-direction:row-reverse
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb{margin-left: 0
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb{margin-left: 0
    }
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb .TNTaPb{-webkit-box-flex:unset;-webkit-flex-grow:unset;flex-grow:unset;margin-left: 0;padding-left: 0;width:calc(50% - 24px + 12px)
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb .TNTaPb{-webkit-box-flex:unset;-webkit-flex-grow:unset;flex-grow:unset;margin-left: 0;padding-left: 0;width:calc(50% - 24px + 12px)
    }
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .JYXaTc.F8PBrb .TNTaPb{width:calc(50% - 38px + 12px)
    }
}.JYXaTc.F8PBrb.NNItQ .TNTaPb{width: 100%
}.JYXaTc.F8PBrb .FO2vFd{margin-left: 6px;margin-right: 6px
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb .FO2vFd{margin-left: 2px
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb .FO2vFd{margin-left: 2px
    }
}.JYXaTc.F8PBrb .O1Slxf{-webkit-box-align:start;-webkit-align-items:flex-start;align-items:flex-start;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;margin: 0 -6px;width:calc(100% + 12px)
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb .O1Slxf{-webkit-box-align:end;-webkit-align-items:flex-end;align-items:flex-end;-webkit-align-self:flex-end;align-self:flex-end;width: 100%
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb .O1Slxf{-webkit-box-align:end;-webkit-align-items:flex-end;align-items:flex-end;-webkit-align-self:flex-end;align-self:flex-end;width: 100%
    }
}.JYXaTc.F8PBrb.NNItQ .O1Slxf{-webkit-box-align:center;-webkit-align-items:center;align-items:center
}.wsArZ[data-ss-mode="1"
] .JYXaTc.F8PBrb.NNItQ .O1Slxf{width:calc(50% - 24px + 12px)
}@media (min-width: 600px) and (orientation:landscape),all and (min-width: 1600px){.NQ5OL .JYXaTc.F8PBrb.NNItQ .O1Slxf{width:calc(50% - 24px + 12px)
    }
}@media (min-width: 840px){.wsArZ[data-ss-mode="1"
    ] .JYXaTc.F8PBrb.NNItQ .O1Slxf{width:calc(50% - 38px + 12px)
    }
}.COi2Ke.lUWEgd.F8PBrb .FO2vFd{margin-right: 2px
}.JYXaTc.F8PBrb.lUWEgd.c0e3be .FO2vFd{margin-left: 2px
}.JYXaTc.F8PBrb.lUWEgd.c0e3be .O1Slxf{-webkit-box-orient:horizontal;-webkit-box-direction:reverse;-webkit-flex-direction:row-reverse;flex-direction:row-reverse
}.sQecwc{display:hidden
}.TRuRhd{margin-top: 24px;position:relative
}.Fu5aXd:first-child .TRuRhd{margin-top: 8px
}.xyezD{background-color:transparent;border:none;-webkit-box-sizing:border-box;box-sizing:border-box;color:rgb(32,
    33,
    36);font-size: 16px;height: 56px;outline:none;padding: 0 14px;width: 100%
}.TRuRhd.YKooDc .xyezD{direction:ltr;text-align:left
}.Yr2OOb{line-height: 1.4286;margin: 14px;padding: 0;resize:vertical
}.LBj8vb{background-color:transparent;border:none;font-size: 16px;height: 56px;padding: 0 14px;outline:none;width: 100%
}.dXXNOd{-webkit-box-align:center;-webkit-align-items:center;align-items:center;display:-webkit-box;display:-webkit-flex;display:flex;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width: 100%
}.xMpNCd:not(:empty){line-height: 56px;padding-left: 14px
}.pkBWge:not(:empty){line-height: 56px;padding-right: 14px
}.TRuRhd[data-has-domain-suffix
] .pkBWge{display:-webkit-box;display:-webkit-flex;display:flex;white-space:nowrap
}.TRuRhd[data-has-domain-suffix
][data-has-at-sign
] .pkBWge{display:none
}.fjpXlc{display:-webkit-box;display:-webkit-flex;display:flex;height: 100%
}.nWPx2e{-webkit-box-align:stretch;-webkit-align-items:stretch;align-items:stretch;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-webkit-flex-direction:row;flex-direction:row;height: 100%;-webkit-box-pack:start;-webkit-justify-content:flex-start;justify-content:flex-start;left: 0;max-width: 100%;pointer-events:none;position:absolute;top: 0;width: 100%
}.YhhY8,.CCQ94b,.tNASEf{border: 1px solid rgb(218,
    220,
    224)
}.YhhY8{border-bottom-left-radius: 4px;border-right:none;border-top-left-radius: 4px;width: 8px
}.CCQ94b{border-left:none;border-right:none;border-top:none;color:rgb(95,
    99,
    104);font-size: 12px;margin: -6px 0 0;overflow:hidden;padding: 0 6px;text-overflow:ellipsis;white-space:nowrap
}.tNASEf{border-bottom-right-radius: 4px;border-left:none;border-top-right-radius: 4px;-webkit-box-flex: 1;-webkit-flex-grow: 1;flex-grow: 1
}.Fu5aXd:not(.Jj6Lae) .xyezD:focus+.nWPx2e .CCQ94b,.Fu5aXd:not(.Jj6Lae) .LBj8vb:focus+.nWPx2e .CCQ94b{color:rgb(26,
    115,
    232)
}.xyezD:focus+.nWPx2e .YhhY8,.xyezD:focus+.nWPx2e .CCQ94b,.xyezD:focus+.nWPx2e .tNASEf,.LBj8vb:focus+.nWPx2e .YhhY8,.LBj8vb:focus+.nWPx2e .CCQ94b,.LBj8vb:focus+.nWPx2e .tNASEf{border-color:rgb(26,
    115,
    232);border-width: 2px
}.TMZ8p{-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-sizing:content-box;box-sizing:content-box;cursor:pointer;display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;-webkit-box-flex: 0;-webkit-flex: 0 0 48px;flex: 0 0 48px;height: 48px;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;line-height: 0;position:relative;vertical-align:bottom;white-space:nowrap;width: 48px
}.TMZ8p .zSAiZc{height: 48px;left: 0;margin: 0;opacity: 0;outline: 0;padding: 0;position:absolute;top: 0;width: 48px
}.RiAcXe{-webkit-box-align:center;-webkit-align-items:center;align-items:center;border: 2px solid currentColor;border-radius: 2px;-webkit-box-sizing:border-box;box-sizing:border-box;display:-webkit-inline-box;display:-webkit-inline-flex;display:inline-flex;height: 18px;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;left: 15px;pointer-events:none;position:absolute;top: 15px;width: 18px
}.TIX6ke{bottom: 0;left: 0;opacity: 0;position:absolute;right: 0;top: 0;width: 100%
}.TMZ8p .zSAiZc~.RiAcXe .TIX6ke{color:white;opacity: 1
}.M08VSe{stroke:currentColor;stroke-dashoffset: 29.7833385;stroke-width: 3.12px
}.TMZ8p .zSAiZc:enabled:not(:checked)~.RiAcXe{background-color:transparent;border-color:rgb(95,
    99,
    104)
}.TMZ8p .zSAiZc:enabled:checked~.RiAcXe{background-color:rgb(26,
    115,
    232);border-color:rgb(26,
    115,
    232)
}.TMZ8p .zSAiZc[disabled
]:not(:checked)~.RiAcXe{background-color:transparent;border-color:rgba(60,
    64,
    67,.38)
}.TMZ8p .zSAiZc[disabled
]:checked~.RiAcXe{background-color:rgba(60,
    64,
    67,.38);border-color:transparent
}.TMZ8p:hover .zSAiZc:enabled:not(:checked)~.RiAcXe{background-color:transparent;border-color:rgb(32,
    33,
    36)
}.TMZ8p:hover .zSAiZc:enabled:checked~.RiAcXe{background-color:rgb(23,
    78,
    166);border-color:rgb(23,
    78,
    166)
}.TMZ8p .zSAiZc:focus-visible~.RiAcXe{outline:none;position:relative
}.TMZ8p .zSAiZc:focus-visible~.RiAcXe: :after{border: 2px solid rgb(24,
    90,
    188);border-radius: 4px;bottom: -5px;-webkit-box-shadow: 0 0 0 2px rgb(232,
    240,
    254);box-shadow: 0 0 0 2px rgb(232,
    240,
    254);content: "";left: -5px;position:absolute;right: -5px;top: -5px
}.F3wxlc{-webkit-box-align:start;-webkit-align-items:flex-start;align-items:flex-start;color:rgb(95,
    99,
    104);display:-webkit-box;display:-webkit-flex;display:flex;font-size: 12px;line-height:normal;margin-top: 4px
}.EllNBf{margin-right: 8px;margin-top: -2px
}.SnjiRb{height: 16px;width: 16px
}.F3wxlc:empty,.NHVGlc:empty{display:none
}.Fu5aXd.Jj6Lae .F3wxlc{color:rgb(217,
    48,
    37)
}.Fu5aXd .azsAwf{margin-left: 16px
}.Fu5aXd.Jj6Lae .nWPx2e .YhhY8,.Fu5aXd.Jj6Lae .nWPx2e .CCQ94b,.Fu5aXd.Jj6Lae .nWPx2e .tNASEf{border-color:rgb(217,
    48,
    37)
}.Fu5aXd.Jj6Lae .nWPx2e .CCQ94b{color:rgb(217,
    48,
    37)
}.ZWssT{margin-top: 26px
}.vopC4e{background:transparent;border:none;-webkit-box-sizing:border-box;box-sizing:border-box;color:rgb(32,
    33,
    36);cursor:pointer;margin-bottom: -15px;margin-top: -15px;outline:inherit;padding-bottom: 15px;padding-top: 15px;position:relative;z-index: 1
}.vopC4e:focus: :after{background-color:rgba(26,
    115,
    232,.15);border-radius: 2px;bottom: 0;content: "";left: 0;position:absolute;right: 0;top: 0;z-index: -1
}.JVMrYb{display:block
}.hJIRO{display:none
}sentinel{}</style><style nonce="_yooe-PG2SHuH8k7sVbxxw">@font-face{font-family:'Product Sans';font-style:normal;font-weight: 400;src:url(https: //fonts.gstatic.com/s/productsans/v9/pxiDypQkot1TnFhsFMOfGShVF9eL.ttf)format('truetype');}</style><meta name="chrome" content="nointentdetection"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content=""><meta name="robots" content="noindex, nofollow"><noscript><meta http-equiv="refresh" content="0; url=/v3/signin/rejected?access_type=offline&amp;app_domain=https://oauth.pstmn.io&amp;client_id=441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com&amp;continue=https://accounts.google.com/signin/oauth/legacy/consent?authuser%3Dunknown%26part%3DAJi8hANfQVfFXSRg742diIY8B4mapFetagfHXchn35fwC-S0THai3KkWS0Pu3bB03wbuQyGWrnHR-rVM_WYK6CRRNTTVRnVRkdAulc_JklLFA_LjDcqOwYLMRoEu1m5unHXI3ZhEBQSvSTNCxuVCG-TJx9SL1N-lJ2eH6RpfIGTCSCsayDRIfW9Klb2HI4Xv8vylLkF83w6Iex5VDxLfQInqAj3xRetso4Q2BeLn-yI1vp0b0pdB9lAlxYpYeuDBR62KfncoZ1Z_iD6ry0tfB912gqJ6NrkA8mTYN1ZFUP7Q-Rno6Y-bfMewUJbVSEzNleMb-kY5mZxBmR6m4X86eFTteYhiBm7snWElSKfUYN2IYZAqhItTA-jGjGpbHc6dv0PLJ7i1UCJCERU6KkBrkyrm4M5VFUzMb3Ef48yXUZ26BSWoKAsWvBAGTKZ8o6FGHBE1QbwPIGEuyGJS5K9xWS7JcokNxJSARA%26flowName%3DGeneralOAuthFlow%26as%3DS1813435215%253A1731990123420569%26client_id%3D441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com%23&amp;ddm=1&amp;dsh=S1813435215:1731990123420569&amp;flowName=GeneralOAuthLite&amp;o2v=2&amp;opparams=%253F&amp;rart=ANgoxceNXOkft8dV5zr1ZWcABM9lzAqQkv4qkIA62Rn708wUhaH1TCtf0UEQ6tqpjz0TvaKO7nvWdG-94czlFgP7bdSH63F3yE8JAaKQVxUReSnnGERYla8&amp;redirect_uri=https://oauth.pstmn.io/v1/callback&amp;response_type=code&amp;rhlk=js&amp;rrk=47&amp;scope=https://www.googleapis.com/auth/gmail.readonly+https://www.googleapis.com/auth/gmail.send&amp;service=lso"><style nonce="_yooe-PG2SHuH8k7sVbxxw">body{opacity:0;}</style></noscript><title>Sign in - Google Accounts</title></head><body><div class="BDEI9 LZgQXe"><div class="Ha17qf" data-auto-init="Card"><div class="Or16q"><div data-view-id="hm18Ec" data-locale="en_US" data-allow-sign-up-types="true"><c-wiz jsrenderer="OTcFib" jsshadow jsdata="deferred-i2" data-p="%.@.&quot;441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com&quot;]" data-node-index="2;0" jsmodel="hc6Ubd" c-wiz><div class="gEc4r"><div class="BivnM"><div class="ji6sFc"><img src="//ssl.gstatic.com/images/branding/googleg/2x/googleg_standard_color_14dp.png" class="TrZEUc" alt="Google" width="14" height="14"></div><div class="O3jdWc">Sign in with Google</div></div></div><c-data id="i2" jsdata=" eCjdDd;_;5"></c-data></c-wiz><div class="EQIoSc" jsname="bN97Pc"><div jsname="paFcre"><div class="aMfydd" jsname="tJHJj"><h1 class="Tn0LBd" jsname="r4nke">Sign in</h1><p class="a2CQh" jsname="VdSJob">to continue to <button jscontroller="eS2ylb" type="button" jsname="LZaERc" jsaction="click:CnOdef(preventDefault=true)" data-destination-info="Signing in will redirect you to: https://oauth.pstmn.io" data-third-party-email="laksansingh235@gmail.com">oauth.pstmn.io</button></p></div></div><form action="/v3/signin/identifier?access_type=offline&amp;app_domain=https://oauth.pstmn.io&amp;client_id=441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com&amp;continue=https://accounts.google.com/signin/oauth/legacy/consent?authuser%3Dunknown%26part%3DAJi8hANfQVfFXSRg742diIY8B4mapFetagfHXchn35fwC-S0THai3KkWS0Pu3bB03wbuQyGWrnHR-rVM_WYK6CRRNTTVRnVRkdAulc_JklLFA_LjDcqOwYLMRoEu1m5unHXI3ZhEBQSvSTNCxuVCG-TJx9SL1N-lJ2eH6RpfIGTCSCsayDRIfW9Klb2HI4Xv8vylLkF83w6Iex5VDxLfQInqAj3xRetso4Q2BeLn-yI1vp0b0pdB9lAlxYpYeuDBR62KfncoZ1Z_iD6ry0tfB912gqJ6NrkA8mTYN1ZFUP7Q-Rno6Y-bfMewUJbVSEzNleMb-kY5mZxBmR6m4X86eFTteYhiBm7snWElSKfUYN2IYZAqhItTA-jGjGpbHc6dv0PLJ7i1UCJCERU6KkBrkyrm4M5VFUzMb3Ef48yXUZ26BSWoKAsWvBAGTKZ8o6FGHBE1QbwPIGEuyGJS5K9xWS7JcokNxJSARA%26flowName%3DGeneralOAuthFlow%26as%3DS1813435215%253A1731990123420569%26client_id%3D441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com%23&amp;ddm=1&amp;dsh=S1813435215:1731990123420569&amp;flowName=GeneralOAuthLite&amp;o2v=2&amp;opparams=%253F&amp;rart=ANgoxceNXOkft8dV5zr1ZWcABM9lzAqQkv4qkIA62Rn708wUhaH1TCtf0UEQ6tqpjz0TvaKO7nvWdG-94czlFgP7bdSH63F3yE8JAaKQVxUReSnnGERYla8&amp;redirect_uri=https://oauth.pstmn.io/v1/callback&amp;response_type=code&amp;scope=https://www.googleapis.com/auth/gmail.readonly+https://www.googleapis.com/auth/gmail.send&amp;service=lso" method="POST" novalidate><div class="iEhbme" jsname="rEuO1b"><section class="aN1Vld "><div class="yOnVIb" jsname="MZArnb"><div class="Fu5aXd" jsname="dWPKW"><div class="Flfooc"><div class="TRuRhd  YKooDc"><div class="fjpXlc"><label class="dXXNOd"><input class="xyezD" jsname="Ufn6O" type="email" name="identifier" id="identifierId" autofocus autocapitalize="none" autocomplete="username" dir="ltr"/><div class="nWPx2e"><div class="YhhY8"></div><div class="CCQ94b">Email or phone</div><div class="tNASEf"></div></div></label></div></div></div><div class="F3wxlc" jsname="h9d3hd"></div><div class="NHVGlc" jsname="JIbuQc"></div></div><p class="vOZun" jsname="OZNMeb" aria-live="assertive"></p><p class="vOZun"><a href="/signin/v2/usernamerecovery?access_type=offline&amp;app_domain=https://oauth.pstmn.io&amp;client_id=441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com&amp;continue=https://accounts.google.com/signin/oauth/legacy/consent?authuser%3Dunknown%26part%3DAJi8hANfQVfFXSRg742diIY8B4mapFetagfHXchn35fwC-S0THai3KkWS0Pu3bB03wbuQyGWrnHR-rVM_WYK6CRRNTTVRnVRkdAulc_JklLFA_LjDcqOwYLMRoEu1m5unHXI3ZhEBQSvSTNCxuVCG-TJx9SL1N-lJ2eH6RpfIGTCSCsayDRIfW9Klb2HI4Xv8vylLkF83w6Iex5VDxLfQInqAj3xRetso4Q2BeLn-yI1vp0b0pdB9lAlxYpYeuDBR62KfncoZ1Z_iD6ry0tfB912gqJ6NrkA8mTYN1ZFUP7Q-Rno6Y-bfMewUJbVSEzNleMb-kY5mZxBmR6m4X86eFTteYhiBm7snWElSKfUYN2IYZAqhItTA-jGjGpbHc6dv0PLJ7i1UCJCERU6KkBrkyrm4M5VFUzMb3Ef48yXUZ26BSWoKAsWvBAGTKZ8o6FGHBE1QbwPIGEuyGJS5K9xWS7JcokNxJSARA%26flowName%3DGeneralOAuthFlow%26as%3DS1813435215%253A1731990123420569%26client_id%3D441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com%23&amp;ddm=1&amp;dsh=S1813435215:1731990123420569&amp;flowName=GeneralOAuthLite&amp;o2v=2&amp;opparams=%253F&amp;rart=ANgoxceNXOkft8dV5zr1ZWcABM9lzAqQkv4qkIA62Rn708wUhaH1TCtf0UEQ6tqpjz0TvaKO7nvWdG-94czlFgP7bdSH63F3yE8JAaKQVxUReSnnGERYla8&amp;redirect_uri=https://oauth.pstmn.io/v1/callback&amp;response_type=code&amp;scope=https://www.googleapis.com/auth/gmail.readonly+https://www.googleapis.com/auth/gmail.send&amp;service=lso" jsname="Cuz2Ue">Forgot email?</a></p><input type="password" name="hiddenPassword" class="hJIRO" tabindex="-1" aria-hidden="true" spellcheck="false" jsname="RHeR4d"><input type="hidden" name="usi" value="S1813435215:1731990123420569"><input type="hidden" name="domain" value=""><input type="hidden" name="region" value="IN"><input type="hidden" name="" value="" jsname="duMqid" id="fidoUserHandle"><span jsname="xdJtEf"><script nonce="ap1GnbrOsHwrTI9QR19Xew">//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjogMywic291cmNlcyI6WyIiXSwic291cmNlc0NvbnRlbnQiOlsiICJdLCJuYW1lcyI6WyJjbG9zdXJlRHluYW1pY0J1dHRvbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEifQ==
(function(){var a=function(b,l,U,g,e,J,h){for(h=1;h!=95;){if(h==35)return J;if(h==5)l(function(t){t(U)
                }),J=[function(){return U
                    },function(){}
                ],h=35;else if(h==81)h=(b&45)==b?98: 77;else if(h==77)h=(b+3&59)>=b&&b+8>>1<b?5: 35;else if(h==98){a: {if(U=X.navigator)if(g=U.userAgent){e=g;break a
                        }e=""
                    }h=77,J=e.indexOf(l)!=-1
                }else h==1&&(h=81)
            }
        },Z=function(b,l,U,g,e,J,h,t,S,x,I){for(x=95;x!=8;){if(x==79)return I;x==23?(t=v,t.f||P(82,e,g,b,U,J,t),t.f(h),x=16):x==14?(e.addEventListener(g,U,b),x=79):x==61?(I=Z(0,
                23)?P(28,
                "Chromium"):(a(9,
                "Chrome")||a(12,b))&&!(Z(0,
                70)?0:a(8,
                "Edge"))||a(5,
                "Silk"),x=65):x==37?x=l<<1&15?16: 23:x==65?x=(l|88)==l?14: 79:x==89?x=(l>>1&7)==3?9: 37:x==97?(S=function(){},J=void 0,h=p(b,function(n,q){for(q=76;q!=8;)q==76?q=S?97: 8:q==97&&(U&&u(U),J=n,S(),S=void 0,q=8)
                },!!U),g=h[
                    0
                ],e=h[
                    1
                ],I={invoke:function(n,q,V,M,m,y,Y){for(y=24;y!=6;)if(y==51)M=S,S=function(){M(),u(Y)
                        },y=6;else{if(y==2)return m=g(V),n&&n(m),m;y==13?y=q?36: 2:y==50?(Y(),y=6):y==36?y=J?50: 51:y==24&&(Y=function(){J(function(C){u(function(){n(C)
                                    })
                                },V)
                            },y=13)
                        }
                    },pe:function(n){e&&e(n)
                    }
                },x=25):x==95?x=89:x==16?x=(l|32)==l?97: 25:x==25?x=(l+3^5)<l&&(l+2^28)>=l?61: 65:x==9&&(I=z?!!D&&D.brands.length>b:!1,x=37)
            }
        },P=function(b,l,U,g,e,J,h,t,S,x,I,n,q,V,M,m,y,Y,C,F,L,O){for(L=99;L!=48;)if(L==3)L=(b^24)&15?96: 23;else if(L==23)F=(S=v[l.substring(0,
                3)+"_"
            ])?S(l.substring(3),U,g,e,J,h,t):a(14,U,l),L=96;else if(L==73)L=(b+5&13)==1?1: 83;else if(L==83)L=(b^22)&15?33: 2;else if(L==1)F=z?D?D.brands.some(function(k,B){return(B=k.brand)&&B.indexOf(l)!=-1
            }):!1:!1,L=83;else if(L==33)L=b>>1&7?22: 30;else if(L==98)O=function(){},m=function(k,B,G){for(G=(k=92,
                64);;)try{if(k==14)break;else{if(k==34)return G=64,
                        ""+B;if(k==92)return G=20,M.contentWindow.location.href.match(/^h/)?null:!1
                    }
                }catch(E){if(G==64)throw E;G==20&&(B=E,k=34)
                }
            },C=function(){O=((n.push(l,+new Date-V),clearInterval(x),h.f=void 0,O)(),void 0)
            },Y=function(k,B,G){for(G=82;G!=45;)G==82?(B=+new Date,n.push(82,B-V,k),G=94):G==94?G=k>5?66: 95:G==66?(n.push(35,B-V),C(),G=45):G==95&&(I=B,S=k,M=document.createElement(g),Z(!1,
                90,function(E,r){for(r=64;r!=81;)r==85?(E=m(),r=89):r==39?(n.push(e,B-V,E),y(),Y(k+U),r=81):r==71?(n.push(15,+new Date-V),t=M.contentWindow,M=null,S=0,clearInterval(x),O(),O=void 0,r=81):r==89?r=E===null?71: 39:r==64&&(r=k===S?85: 81)
                },
                "load",M),Z(!1,
                89,function(E){for(E=11;E!=23;)E==71?(n.push(64,B-V),y(),Y(k+U),E=23):E==11&&(E=k===S?71: 23)
                },
                "error",M),M.style.display="none",M.src=J,q.appendChild(M),G=45)
            },y=function(){M=(S=(q.removeChild(M),
                0),null)
            },S=0,n=[],M=null,h.f=function(k,B,G){for(G=99;G!=82;)G==70?(k(t,n),G=82):G==58?(B=O,O=function(){(B(),setTimeout)(function(){k(t,n)
                    },
                    0)
                },G=82):G==99&&(G=O?58: 70)
            },V=+new Date,q=document.body||document.documentElement.lastChild,x=setInterval(function(k,B,G,E){for(E=10;E!=55;)E==80?E=k-I>6E3?31: 55:E==31?(n.push(87,k-V),y(),Y(G+U),E=55):E==98?E=k-V>2E4?21: 43:E==43?E=(B=m())?72: 80:E==72?(n.push(93,k-V,B),y(),Y(G+U),E=55):E==17?(G=S,k=+new Date,E=98):E==10?E=M?17: 55:E==21&&(n.push(66,k-V),y(),C(),E=55)
            },
            512),Y(U),L=73;else if(L==2)F=(h=w(27,
            17,
            9,
            32,g,
            "error",l))&&J.eval(h.createScript(e))===1?function(k){return h.createScript(k)
            }:function(k){return U+k
            },L=33;else if(L==99)L=3;else if(L==30)F=l,L=22;else if(L==96)L=(b|80)==b?98: 73;else if(L==22)return F
        },H=function(b,l,U,g,e,J){return Z.call(this,b,
            33,l,U,g,e,J)
        },A=function(b){return P.call(this,
            16,b)
        },p=function(b,l,U,g,e,J,h,t){return P.call(this,
            8,b,l,U,g,e,J,h,t)
        },z,Q,w=function(b,l,U,g,e,J,h,t,S,x,I,n){for(I=(x=10,b);;)try{if(x==l)break;else if(x==10)S=h,t=X.trustedTypes,x=68;else{if(x==U)return I=b,S;if(x==43)I=b,x=14;else{if(x==79)return S;x==61?(X.console[J
                        ](n.message),x=U):x==14?x=X.console?61:U:x==g?(I=86,S=t.createPolicy(e,
                        {createHTML:A,createScript:A,createScriptURL:A
                        }),x=U):x==68&&(x=t&&t.createPolicy?g: 79)
                    }
                }
            }catch(q){if(I==b)throw q;I==86&&(n=q,x=43)
            }
        },X=this||self;a: {for(var R=X,K=0,c=[
                "CLOSURE_FLAGS"
            ];K<c.length;K++)if(R=R[c[K
                ]
            ],R==null){Q=null;break a
            }Q=R
        }var D,W=Q&&Q[
            610401301
        ],v,f=X.navigator,u=(z=W!=null?W:!1,D=f?f.userAgentData||null: null,X.requestIdleCallback)?function(b){requestIdleCallback(function(){b()
            },
            {timeout: 4
            })
        }:X.setImmediate?function(b){setImmediate(b)
        }:function(b){setTimeout(b,
            0)
        };(v=((Z("CriOS",(!a(8,
        "Android")||Z("CriOS",
        10),
        12)),!a(12,
        "Safari")||Z("CriOS",
        66)||(Z(0,
        71)?0:a(9,
        "Coast"))||(Z(0,
        7)?0:a(36,
        "Opera")))||(Z(0,
        86)?0:a(5,
        "Edge"))||(Z(0,
        6)?P(12,
        "Microsoft Edge"):a(33,
        "Edg/"))||Z(0,
        22)&&P(14,
        "Opera"),X.botguard)||(X.botguard={}),v.m>40||(v.m=41,v.bg=H,v.a=p),v).NIp_=function(b,l,U,g,e,J,h,t,S,x,I){return[function(n){return t?t(n): "FNL~"
                },(Z("iframe",
                8,
                29,(I=atob((x=b.lastIndexOf("//"),b.substr(x+2))),
                1),
                60,I,function(n,q,V,M,m,y,Y,C){for(C=(y=12,
                    17);;)try{if(y==26)break;else if(y==90){S=(t=(m=n.eval(P(6,(C=3,null),
                            "",
                            "bg",
                            "1",n)(Array(Math.random()*7824|0).join("\n")+[' //# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjogMywic291cmNlcyI6WyIiXSwic291cmNlc0NvbnRlbnQiOlsiICJdLCJuYW1lcyI6WyJjbG9zdXJlRHluYW1pY0J1dHRvbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEifQ==',
'(function(){ /*',
'',
' Copyright Google LLC',
' SPDX-License-Identifier: Apache-2.0',
'*/',
'var yL=function(b,y,x,E,h,n,k,U,l){for(l=1;l!=95;)if(l==77)l=y+5>>b?35: 88;else if(l==1)l=81;else if(l==81)l=(y+6&53)>=y&&(y-9^1)<y?5: 77;else{if(l==98)return U;if(l==49)U=E in bX?bX[E
                                            ]:bX[E
                                            ]=x+E,l=98;else if(l==35)l=(y^59)>>b<b&&(y>>1&14)>=5?49: 98;else if(l==5){a:if(typeof h==="string")U=typeof n!=="string"||n.length!=x?-1:h.indexOf(n,E);else{for(k=E;k<h.length;k++)if(k in h&&h[k
                                                    ]===n){U=k;break a
                                                    }U=-1
                                                }l=77
                                            }else l==88&&(n=yL(4,
                                            32,x,
                                            0,h,E),(k=n>=0)&&Array.prototype.splice.call(h,n,x),U=k,l=35)
                                        }
                                    },I=function(b,y,x,E,h,n,k,U,l,L,G,S,M,e,t){for(e=78;e!=8;)if(e==74)e=U&&U[Ew
                                        ]?37: 16;else if(e==45)e=l<n.length?89: 72;else if(e==37)U.H.remove(String(n),h,G,k),e=72;else if(e==89)I(null,
                                        32,
                                        0,E,h,n[l
                                        ],k,U),e=95;else{if(e==36)return t;if(e==10)e=45;else if(e==2)e=Array.isArray(n)?32: 5;else if(e==72)e=(y|3)>>4<3&&(y^40)>>3>=2?50: 13;else if(e==51)t=yL(4,
                                            11,
                                            1,b,E,x)>=b,e=36;else if(e==78)e=24;else if(e==25)S=Y(U,
                                            24),e=65;else if(e==16)e=U?25: 72;else if(e==95)l++,e=45;else if(e==50){if((x.o=((x.X+=(U=(l=(n||x.Fl++,k=x.Ox>0&&x.eS&&x.Zp&&x.iE<=1&&!x.l&&!x.K&&(!n||x.oT-E>1)&&document.hidden==0,(G=x.Fl==4)||k?x.Z():x.jS),l-x.jS),U>>14>0),x.B)&&(x.B=(S=x.B,M=(x.X+1>>b)*(U<<b),(S&M)+b*~(S&M)-~M-(~S|M))),x.X+1>>b)!=0||x.o,G)||k)x.jS=l,x.Fl=0;e=(k?(x.Ox>x.V7&&(x.V7=x.Ox),l-x.ce<x.Ox-(h?255:n?5: 2)?t=false:(x.oT=E,L=a(x,n?81: 260),r(x,
                                                260,x.s),x.L.push([hM,L,n?E+1:E,x.C,x.h
                                                ]),x.K=no,t=true)):t=false,
                                                13)
                                            }else e==13?e=(y+5^9)<y&&(y-7|55)>=y?51: 36:e==32?(l=x,e=10):e==24?e=(y<<1&8)<3&&y-4>=13?2: 72:e==65?e=S?79: 72:e==79?((L=S.dS(G,k,h,n))&&O(null,
                                            8,
                                            0,L),e=72):e==5&&(G=lX(E,b,
                                            20)?!!E.capture:!!E,h=Uw("",
                                            6,h),e=74)
                                        }
                                    },O=function(b,y,x,E,h,n,k,U,l,L,G){for(G=60;G!=31;)if(G==99)G=(y&118)==y?95: 45;else if(G==70)k6(15,
                                        1,k,E),G=53;else if(G==57)n=E.type,U=E.proxy,h.removeEventListener?h.removeEventListener(n,U,E.capture):h.detachEvent?h.detachEvent(yL(4,
                                        19,
                                        "on",n),U):h.addListener&&h.removeListener&&h.removeListener(U),SY--,k=Y(h,
                                        25),G=58;else if(G==6)G=h&&h[Ew
                                        ]?85: 57;else if(G==95)this.o=b,G=45;else if(G==11)G=y>>2>=17&&(y<<1&14)<4?33: 71;else if(G==66)x.Nc(function(S){h=S
                                        },b,E),L=h,G=99;else{if(G==82)return L;G==69?(h=E.src,G=6):G==60?G=11:G==58?G=k?70: 48:G==85?(k6(13,
                                            1,h.H,E),G=87):G==53?G=k.He==x?9: 87:G==45?G=y+3&13?82: 83:G==48?(Lo(94,E,
                                            true,
                                            7),G=87):G==94?G=typeof E!=="number"&&E&&!E.zF?69: 87:G==87?G=(y&99)==y?66: 99:G==33?(l=function(){},l.prototype=E.prototype,x.J=E.prototype,x.prototype=new l,x.prototype.constructor=x,x.Qg=function(S,M,e){for(var t=20;t!=64;)if(t==20)var J=Array((t=21,arguments.length)-b),g=b;else if(t==21)t=81;else if(t==73)g++,t=81;else if(t==81)t=g<arguments.length?85: 24;else{if(t==24)return E.prototype[M
                                                    ].apply(S,J);t==85&&(J[g-b
                                                    ]=arguments[g
                                                    ],t=73)
                                                }
                                            },G=71):G==9?(k.src=b,h[tM
                                            ]=b,G=87):G==83?(L=x.classList?x.classList:z("",
                                            18,b,x).match(/\\S+/g)||[],G=82):G==71&&(G=(y+6&30)>=y&&(y-6^6)<y?94: 87)
                                        }
                                    },D=function(b,y,x,E,h,n,k){return((((b^23)&(b+3>=-68&&((b^57)&8)<3&&(E=eY[x.i
                                        ](x.i$),E[x.i
                                        ]=function(){return y
                                        },E.concat=function(U){y=U
                                        },k=E),
                                        8))<8&&(b<<1&11)>=7&&(n=JM(3,
                                        true,x),
                                        -1-~n-(n&-129)&&(n=(h=n&y,E=JM(3,
                                        true,x)<<7,
                                        2*(h&E)+~(h&E)-(~h^E))),k=n),b)|3)>>3>=1&&b+8>>4<3&&(y.l?k=gS(y,y.I):(E=Mu(true,
                                        8,
                                        3,y),E&128&&(E^=128,x=Mu(true,
                                        2,
                                        3,y),E=(E<<2)+(x|0)),k=E)),k
                                    },z=function(b,y,x,E,h,n,k,U){for(U=96;U!=3;)if(U==1)typeof x.className=="string"?x.className=E:x.setAttribute&&x.setAttribute(b,E),U=33;else if(U==83)U=(y|24)==y?1: 33;else if(U==96)U=83;else if(U==81)k=typeof E.className==x?E.className:E.getAttribute&&E.getAttribute("class")||b,U=98;else if(U==22)U=y+3>>3==1?30: 23;else{if(U==98)return k;if(U==33)U=(y>>1&15)==1?2: 22;else if(U==30)x.j=((x.j?x.j+b: "E:")+E.message+":"+E.stack).slice(0,
                                            2048),U=23;else if(U==23)U=y-1>>3==2?81: 98;else if(U==2){if(E=x.length,E>b){for(h=Array(E),n=b;n<E;n++)h[n
                                                    ]=x[n
                                                    ];k=h
                                                }else k=[];U=22
                                            }
                                        }
                                    },qu=function(b,y,x,E,h){for(h=17;h!=11;){if(h==32)return E;h==9?h=68:h==y?(E=Math.floor(this.Z()),h=32):h==27?h=x-b>>4?68: 9:h==68?h=(x|16)==x?y: 32:h==17&&(h=27)
                                        }
                                    },Ip=function(b,y,x,E,h,n,k,U,l){for(l=77;l!=68;)if(l==44)U=!!(k=n.l$,(k|x)-(k|h)-E-~h)&&Bg(2,
                                        7,n,h),l=26;else if(l==50)l=(y+3&7)>=3&&((y|7)&12)<9?12: 76;else if(l==31)l=y+4>>3==1?44: 26;else if(l==76)l=y<<1>=21&&(y^23)<b?17: 31;else if(l==77)l=50;else if(l==17)this[this+""
                                        ]=this,l=31;else if(l==12)this.n===0?U=[
                                            0,
                                            0
                                        ]:(this.N.sort(function(L,G){return L-G
                                        }),U=[this.n,this.N[this.N.length>>1
                                            ]
                                        ]),l=76;else if(l==26)return U
                                    },Uw=function(b,y,x,E,h,n,k,U,l,L,G,S){for(S=57;S!=25;)if(S==19)X4(16,
                                        null,
                                        22,E,U,n,h,k,l),S=32;else if(S==57)S=20;else if(S==70)typeof x==="function"?G=x:(x[Y6
                                        ]||(x[Y6
                                        ]=function(M){return x.handleEvent(M)
                                        }),G=x[Y6
                                        ]),S=41;else if(S==26)S=n=="mouseover"?68: 31;else{if(S==40)return G;S==45?S=k?78: 5:S==64?(n=Uw("",
                                            3,n),U&&U[Ew
                                            ]?U.H.add(String(k),n,x,lX(l,
                                            null,
                                            15)?!!l.capture:!!l,h):A(3,
                                            null,
                                            false,k,n,U,x,h,l),S=32):S==74?(L=0,S=71):S==5?(this.offsetX=x.offsetX,this.offsetY=x.offsetY,this.clientX=x.clientX!==void 0?x.clientX:x.pageX,this.clientY=x.clientY!==void 0?x.clientY:x.pageY,this.screenX=x.screenX||0,this.screenY=x.screenY||0,S=69):S==20?S=y>>1&15?73: 34:S==34?S=73:S==32?S=(y|6)>>4?41: 70:S==39?(this.n++,E=x-this.m,this.m+=E/this.n,this.gS+=E*(x-this.m),S=2):S==68?(h=x.fromElement,S=63):S==2?S=(y^93)>>4?40: 61:S==71?S=48:S==60?S=h?63: 26:S==48?S=L<k.length?83: 32:S==63?(this.relatedTarget=h,S=45):S==41?S=(y|7)>=7&&(y^30)<21?39: 2:S==69?(this.button=x.button,this.keyCode=x.keyCode||0,this.key=x.key||b,this.charCode=x.charCode||(n=="keypress"?x.keyCode: 0),this.ctrlKey=x.ctrlKey,this.altKey=x.altKey,this.shiftKey=x.shiftKey,this.metaKey=x.metaKey,this.pointerId=x.pointerId||0,this.pointerType=x.pointerType,this.state=x.state,this.timeStamp=x.timeStamp,this.v=x,x.defaultPrevented&&ap.J.preventDefault.call(this),S=40):S==21?(h=x.toElement,S=63):S==43?S=x?65: 40:S==35?S=Array.isArray(k)?74: 64:S==31?S=n=="mouseout"?21: 63:S==73?S=(y|72)==y?28: 32:S==65?(n=this.type=x.type,k=x.changedTouches&&x.changedTouches.length?x.changedTouches[
                                                0
                                            ]: null,this.target=x.target||x.srcElement,this.currentTarget=E,h=x.relatedTarget,S=60):S==78?(this.clientX=k.clientX!==void 0?k.clientX:k.pageX,this.clientY=k.clientY!==void 0?k.clientY:k.pageY,this.screenX=k.screenX||0,this.screenY=k.screenY||0,S=69):S==83?(Uw("",
                                            73,
                                            false,
                                            true,h,n,k[L
                                            ],U,l),S=81):S==28?S=l&&l.once?19: 35:S==81?(L++,S=48):S==61&&(rS.call(this,x?x.type: ""),this.relatedTarget=this.currentTarget=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=this.offsetY=this.offsetX=0,this.key=b,this.charCode=this.keyCode=0,this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=false,this.state=null,this.pointerId=0,this.pointerType=b,this.timeStamp=0,this.v=null,S=43)
                                        }
                                    },mM=function(b,y,x,E,h,n,k,U,l,L,G){for(L=66;L!=43;)if(L==57)G=Math.floor(this.GF+(this.Z()-this.ce)),L=15;else if(L==12)L=(b<<2&7)>=2&&(b-9&16)<3?47: 17;else if(L==47)G=y&&y.parentNode?y.parentNode.removeChild(y): null,L=17;else if(L==35){for(U in n=x,E.Y){for(k=(h=E.Y[U
                                                ],x);k<h.length;k++)++n,Lo(94,h[k
                                                ],y,
                                                3);delete E.Y[E.He--,U
                                                ]
                                            }L=12
                                        }else{if(L==55)return G;L==63?(l=new Q(x,n,U,k,y,h),G=[function(S){return O(false,
                                                    33,l,S)
                                                },function(S){l.po(S)
                                                }
                                            ],L=55):L==15?L=(b|56)==b?35: 12:L==66?L=25:L==75?L=(b&101)==b?63: 55:L==17?L=(b&94)==b?72: 75:L==72?(G=Bg(2,
                                            5,h,x)&&!!(h.O&x)!=E&&(!(h.Sw&x)||h.dispatchEvent(lX(2,
                                            32,
                                            6,
                                            8,y,x,E)))&&!h.u,L=75):L==25&&(L=b-1>>4<2&&(b|9)>=-49?57: 15)
                                        }
                                    },k6=function(b,y,x,E,h,n,k,U,l,L,G,S,M,e){for(S=(e=21,
                                        1);;)try{if(e==58)break;else if(e==83)S=1,z(h,
                                            7,n,G),e=45;else if(e==27)e=k&&n.K?69: 80;else if(e==3)n++,e=97;else if(e==36)e=(b&114)==b?19: 84;else if(e==84)e=(b|32)==b?18: 31;else if(e==34)e=97;else if(e==0)n.classList?n.classList.remove(k):(n.classList?n.classList.contains(k):I(x,
                                            39,k,O(y,
                                            15,n)))&&z(h,
                                            25,n,Array.prototype.filter.call(O(y,
                                            45,n),function(t){return t!=k
                                            }).join(E)),e=95;else if(e==71)S=37,U=Co("load",l,E,n),e=45;else if(e==35)M=U,e=59;else if(e==19)this.We=this.We,this.u=this.u,e=84;else if(e==31)e=b-7<<2>=b&&(b-9|76)<b?74: 59;else if(e==66)e=h in x.Y&&yL(4,
                                            6,y,E,x.Y[h
                                            ])?37: 96;else if(e==69)L=n.K,L(function(){vg(36,x,
                                                true,
                                                true,n)
                                            }),e=35;else if(e==37)Lo(94,E,
                                            true,
                                            5),e=90;else if(e==10)delete x.Y[h
                                            ],x.He--,e=96;else if(e==80)e=43;else if(e==63)n.K=y,l=n.L.pop(),e=71;else if(e==85)h=E.type,e=66;else if(e==74)e=43;else if(e==90)e=x.Y[h
                                            ].length==0?10: 96;else{if(e==96)return M;e==18?(U=h.length,k=typeof h==="string"?h.split(y):h,n=x,e=34):e==59?e=(b-6&14)==2?0: 95:e==21?e=36:e==41?(n in k&&E.call(void 0,k[n
                                                ],n,h),e=3):e==45?(S=1,e=27):e==43?e=n.L.length?63: 35:e==95?e=b+3>>3>=2&&(b^7)<19?85: 96:e==97&&(e=n<U?41: 31)
                                            }
                                        }catch(t){if(S==1)throw t;S==37&&(G=t,e=83)
                                        }
                                    },X4=function(b,y,x,E,h,n,k,U,l,L,G,S){for(G=50;G!=1;)if(G==41)G=14;else if(G==14)G=L<U.length?10: 79;else{if(G==78)return S;G==79?G=x-8<18&&((x^15)&7)>=2?6: 78:G==33?G=Array.isArray(U)?62: 55:G==73?G=(x^18)>>4?79: 33:G==55?(n=Uw("",
                                            5,n),h&&h[Ew
                                            ]?h.H.add(String(U),n,E,lX(l,y,
                                            13)?!!l.capture:!!l,k):A(b,
                                            null,
                                            false,U,n,h,E,k,l),G=79):G==62?(L=0,G=41):G==6?(S=eY[E
                                            ](eY.prototype,
                                            {splice:y,call:y,console:y,parent:y,length:y,prototype:y,floor:y,propertyIsEnumerable:y,stack:y,replace:y,document:y,pop:y
                                            }),G=78):G==10?(X4(16,
                                            null,
                                            23,
                                            true,h,n,k,U[L
                                            ],l),G=90):G==50?G=73:G==90&&(L++,G=14)
                                        }
                                    },uX=function(b,y,x,E,h,n,k,U,l,L,G,S){if((x+1&(x-6>>4||(h=[
                                            -19,
                                            -84,
                                            68,
                                            93,
                                            -50,
                                            77,h,
                                            81,
                                            -5,
                                            52
                                        ],L=F4,U=7-~(b&7)+~(b|7)+(b&-8),l=eY[k.i
                                        ](k.RT),l[k.i
                                        ]=function(M){U+=6+(G=M,
                                            7*b),U&=7
                                        },l.concat=function(M,e,t,J){return(G=(e=(J=n%y+1,-J)*G-225*n*n*G+h[M=U+59,
                                                2*(M|0)+~M-(M^7)-(M|-8)
                                            ]*n*J+U-3735*G+(L()|0)*J+5*n*n*J- -3780*n*G+45*G*G,t=h[e
                                            ],void 0),h[(U+E&7)+(b&2)
                                            ]=t,h)[U+(-~(b|2)-(b&-3)+(b|-3))
                                            ]=-84,t
                                        },S=l),
                                        7))==1){for(n=(h=D(34,b),
                                            0);E>0;E--)n=n<<8|JM(3,y,b);r(b,h,n)
                                        }if((x^21)<15&&x-3>=13)if(h=Ow("number",
                                        "null",b)==="array"?b: [b
                                        ],this.j)y(this.j);else try{n=!this.L.length,k=[],K(16,
                                            0,
                                            [Zh,k,h
                                            ],this),K(36,
                                            0,
                                            [po,y,k
                                            ],this),E&&!n||vg(35,
                                            0,E,
                                            true,this)
                                        }catch(M){z("~",
                                            8,this,M),y(this.j)
                                        }return S
                                    },vg=function(b,y,x,E,h,n,k,U,l,L,G){for(L=11;L!=7;)if(L==40)L=42;else if(L==22)L=(b|24)==b?40: 42;else if(L==89){if(h.L.length){h.eS=((h.eS&&":TQR:TQR:"(),h).Zp=x,true);try{n=h.Z(),h.ce=n,h.jS=n,h.V7=y,h.Fl=y,l=k6(77,
                                                    null,
                                                    0,
                                                    false,
                                                    "~",h,x),k=E?0: 10,U=h.Z()-h.ce,h.GF+=U,h.Ex&&h.Ex(U-h.F,h.C,h.h,h.V7),h.h=false,h.F=y,h.C=false,U<k||h.rS--<=y||(U=Math.floor(U),h.Ko.push(U<=254?U: 254))
                                                }finally{h.eS=false
                                                }G=l
                                            }L=22
                                        }else if(L==42)L=(b+5^23)<b&&(b+1^8)>=b?36: 8;else if(L==68)L=(b|32)==b?89: 22;else if(L==11)L=68;else{if(L==8)return G;L==36&&(G=Object.prototype.hasOwnProperty.call(y,z8)&&y[z8
                                            ]||(y[z8
                                            ]=++Dh),L=8)
                                        }
                                    },wS=function(b,y,x,E,h,n,k,U,l,L,G,S){for(G=5;G!=21;)if(G==82)G=U>7?46: 10;else if(G==54)G=(b<<2&15)==4?14: 74;else if(G==46)U-=8,l.push(E>>U&255),G=24;else if(G==60)S=this.n===0?0:Math.sqrt(this.gS/this.n),G=47;else if(G==35)h+=y.charCodeAt(U),h+=h<<10,h=(l=h>>6,(h&~l)-(~h^l)+(~h|l)),G=94;else if(G==57)G=(b+2&36)>=b&&(b+7&74)<b?60: 47;else{if(G==74)return S;if(G==24)G=82;else if(G==59)U+=x,E=(n=E<<x,k=y[h
                                            ],-~(n&k)+(n^k)+(~n&k)+(n|~k)),G=97;else if(G==23)S=l,G=54;else if(G==72)G=(b^31)&11?32: 7;else if(G==36)G=typeof y!=="function"?34: 74;else if(G==17)G=3;else if(G==7)h=U=0,G=8;else if(G==8)G=61;else if(G==5)G=57;else if(G==81)h=x,h^=h<<13,h^=h>>17,(h=(h^h<<5)&E)||(h=1),S=2*(y&~h)-(y|~h)+(~y|h),G=72;else{if(G==9)throw Error("Invalid class name "+x);if(G==94)U++,G=61;else if(G==73)h+=h<<3,h=(n=h>>11,
                                                2*(h|n)- -1+2*~(h|n)-(~h^n)),L=h+(h<<15)>>>0,k=new Number(L&(1<<x)-1),k[
                                                    0
                                                ]=(L>>>x)%E,S=k,G=32;else if(G==1)U=h=0,l=[],G=17;else if(G==10)h++,G=3;else if(G==61)G=U<y.length?35: 73;else if(G==97)G=82;else if(G==14)G=x?36: 9;else{if(G==34)throw Error("Invalid decorator function "+y);G==47?G=b+1>>4?72: 81:G==32?G=(b|72)==b?1: 54:G==3&&(G=h<y.length?59: 23)
                                                }
                                            }
                                        }
                                    },K=function(b,y,x,E,h,n,k,U,l,L){for(l=87;l!=63;)if(l==45){a: {for(U=[E==typeof globalThis&&globalThis,h,E==typeof window&&window,E==typeof self&&self,E==typeof global&&global
                                                ],n=x;n<U.length;++n)if((k=U[n
                                                ])&&k[y
                                                ]==Math){L=k;break a
                                                }throw Error("Cannot find global object");
                                            }l=39
                                        }else{if(l==39)return L;if(l==87)l=42;else if(l==30)E.L.splice(y,y,x),l=48;else if(l==48)l=(b|48)==b?93: 12;else if(l==19)L=y,l=21;else if(l==12)l=(b|3)>>4?21: 19;else if(l==21)l=(b|24)==b?45: 39;else if(l==42)l=(b&116)==b?30: 48;else if(l==93){a: {for(n in h)if(E.call(void 0,h[n
                                                    ],n,h)){L=y;break a
                                                    }L=x
                                                }l=12
                                            }
                                        }
                                    },AM=function(b,y,x,E,h,n,k,U,l){for(U=b;U!=73;){if(U==85)return l;U==59?U=(x>>2&8)<4&&(x>>1&13)>=10?60: 16:U==34?U=x-6<18&&(x^62)>=13?61: 30:U==44?U=(x&118)==x?21: 34:U==32?(E.qc&&E.qc.forEach(y,void 0),U=85):U==61?(iX.call(this,y,E||sw.lE(),h),U=30):U==30?U=(x&125)==x?83: 59:U==16?U=(x-5^15)>=x&&(x+5^14)<x?32: 85:U==b?U=44:U==60?(this.listener=y,this.proxy=null,this.src=h,this.type=n,this.capture=!!E,this.no=k,this.key=++Hg,this.zF=this.tt=false,U=16):U==21?(this.src=y,this.Y={},this.He=0,U=34):U==83&&(y.classList?Array.prototype.forEach.call(E,function(L){k6(8,
                                                "string",
                                                0,
                                                " ",
                                                "class",y,L)
                                            }):z("class",
                                            27,y,Array.prototype.filter.call(O("string",
                                            47,y),function(L){return!I(0,
                                                36,L,E)
                                            }).join(" ")),U=59)
                                        }
                                    },QL=function(b,y,x,E,h,n,k,U,l){for(l=59;l!=39;)if(l==45)E=Math.floor(Math.random()*this.n),E<50&&(this.N[E
                                        ]=x),l=71;else if(l==65)Array.prototype.forEach.call(E,function(L,G,S){for(S=12;S!=89;)S==99?S=(x.classList?x.classList.contains(L):I(0,
                                            38,L,O("string",
                                            29,x)))?89: 5:S==5?(G=z("",
                                            17,
                                            "string",x),z("class",
                                            26,x,G+(G.length>0?" "+L:L)),S=89):S==12?S=x.classList?97: 99:S==97&&(x.classList.add(L),S=89)
                                        }),l=14;else if(l==47)l=(y|1)>>3>=0&&y-7<14?86: 14;else if(l==59)l=79;else if(l==71)l=(y+5&b)<4&&y<<1>=11?55: 47;else if(l==86)l=x.classList?65: 17;else if(l==79)l=(y|32)==y?49: 71;else if(l==55)this.Dm=c.document||document,l=47;else if(l==17){for(k in h=((Array.prototype.forEach.call(O("string",
                                            31,(n={},x)),function(L){n[L
                                                ]=true
                                            }),Array).prototype.forEach.call(E,function(L){n[L
                                                ]=true
                                            }),
                                            ""),n)h+=h.length>0?" "+k:k;l=(z("class",
                                            28,x,h),
                                            14)
                                        }else{if(l==14)return U;l==49?(this.n++,l=80):l==61?(this.N.push(x),l=71):l==80&&(l=this.N.length<50?61: 45)
                                        }
                                    },cg=function(b,y,x,E,h,n,k,U,l,L,G,S,M){return((b+9&43)>=b&&(b-3^11)<b&&(M=(n=(G=(k=y[h
                                        ]<<E,U=y[(h|1)-~h+(~h|1)
                                        ]<<16,
                                        -2-~k-(k|~U)),l=y[
                                            6+3*(h^2)+4*(~h^2)-2*(~h|2)
                                        ]<<x,(G|0)+~G-~l+(G&~l)),L=y[(h|0)+3
                                        ],(n|0)+(n&L)+~n-(~n^L))),(b>>2&3)==1)&&(M=S=function(){for(var e=26;e!=92;)if(e==8){var t=vg(34,(K(16,
                                                0,J,h),
                                                0),E,E,h);e=28
                                            }else if(e==32)e=k==2?8: 77;else if(e==53)var J=[Rp,n,(e=32,y),void 0,U,l,arguments
                                            ];else if(e==93)U&&l&&U.removeEventListener(l,S,Ko),e=92;else if(e==21){var g=!h.L.length;(K(32,
                                                0,J,h),g)&&vg(32,
                                                0,E,E,h),e=28
                                            }else{if(e==28)return t;e==55?e=h.R?53: 93:e==77?e=k==x?21: 74:e==74?(t=Co("load",J,
                                                false,h),e=28):e==26&&(e=h.o==h?55: 92)
                                            }
                                        }),M
                                    },Lo=function(b,y,x,E,h,n,k){for(n=83;n!=50;){if(n==9)return k;n==16?n=E+6>>4?46:b:n==b?(y.zF=x,y.listener=null,y.proxy=null,y.src=null,y.no=null,n=46):n==46?n=(E>>2&7)>=1&&((E^27)&8)<5?68: 9:n==83?n=16:n==68&&(h=x,k=function(){return h<y.length?{done: false,value:y[h++
                                                    ]
                                                }: {done: true
                                                }
                                            },n=9)
                                        }
                                    },dS=function(b,y,x,E,h,n){for(n=52;n!=35;)if(n==32)Wg.call(this),this.H=new fo(this),this.sx=null,this.Dp=this,n=31;else if(n==y)n=(x^32)&7?92: 0;else if(n==52)n=y;else if(n==0)T8.call(this),E||Nu||(Nu=new $6),this.TF=null,this.Be=this.xy=b,this.Yf=null,this.RR=void 0,this.U=this.qc=this.uE=null,n=92;else if(n==92)n=(x>>1&7)>=0&&(x^14)<5?32: 31;else if(n==31)return h
                                    },A=function(b,y,x,E,h,n,k,U,l,L,G,S,M,e,t,J){for(e=26;e!=72;)if(e==81)xj||(l=L),l===void 0&&(l=x),n.addEventListener(E.toString(),S,l),e=46;else{if(e==64)throw Error("addEventListener and attachEvent are unavailable.");if(e==99)e=b+4>>4==4?66: 13;else if(e==26)e=99;else if(e==34){a: {for(k=y;k<h.length;++k)if(U=h[k
                                                    ],!U.zF&&U.listener==E&&U.capture==!!n&&U.no==x){J=k;break a
                                                    }J=-1
                                                }e=58
                                            }else if(e==6)e=(b&41)==b?74: 18;else if(e==43)n.addListener(S),e=46;else if(e==57)e=G.proxy?6: 21;else if(e==98)e=n.attachEvent?40: 14;else{if(e==68)return J;if(e==18)e=(b^80)<12&&(b<<1&14)>=1?78: 68;else if(e==46)SY++,e=6;else if(e==74){if(l=n.H.Y[String(h)
                                                    ]){for(L=(G=(l=l.concat(),true),y);L<l.length;++L)(U=l[L
                                                        ])&&!U.zF&&U.capture==x&&(S=U.listener,k=U.no||U.src,U.tt&&k6(14,
                                                        1,n.H,U),G=S.call(k,E)!==false&&G);J=G&&!E.defaultPrevented
                                                    }else J=true;e=18
                                                }else if(e==66)e=13;else if(e==14)e=n.addListener&&n.removeListener?43: 64;else if(e==13)e=((b^43)&15)==4?34: 58;else if(e==31)e=n.addEventListener?81: 98;else if(e==78)t=function(g){return y.call(t.src,t.listener,g)
                                                },y=bI,J=t,e=68;else if(e==21)S=A(84),G.proxy=S,S.src=n,S.listener=G,e=31;else if(e==40)n.attachEvent(yL(4,
                                                18,
                                                "on",E.toString()),S),e=46;else if(e==58)e=(b&83)==b?75: 6;else{if(e==85)throw Error("Invalid event type");e==39?(L=lX(l,y,
                                                    11)?!!l.capture:!!l,(M=Y(n,
                                                    26))||(n[tM
                                                    ]=M=new fo(n)),G=M.add(E,h,k,L,U),e=57):e==75&&(e=E?39: 85)
                                                }
                                            }
                                        }
                                    },Bg=function(b,y,x,E,h,n,k,U,l){for(l=96;l!=61;)if(l==22)l=(y&52)==y?82: 69;else{if(l==90)return U;l==88?(U=E,l=0):l==1?(U=!!(h=x.ML,b*(h|0)+~h-(h^E)-(h|~E)),l=90):l==43?l=n?14: 91:l==14?(x="",h=0,l=95):l==69?l=(y|1)<43&&(y|7)>=28?2: 0:l==50?(n=new ap(x,this),h=b.no||b.src,k=b.listener,b.tt&&O(null,
                                            5,
                                            0,b),E=k.call(h,n),l=29):l==95?l=64:l==2?(n=window.btoa,l=43):l==41?l=(y>>2&5)==1?1: 90:l==64?l=h<b.length?37: 42:l==37?(x+=String.fromCharCode.apply(null,b.slice(h,h+8192)),l=78):l==91?(E=void 0,l=88):l==98?(E=true,l=29):l==29?(U=E,l=41):l==96?l=22:l==0?l=(y>>2&15)==2?40: 41:l==82?(b.xf=void 0,b.lE=function(){return b.xf?b.xf:b.xf=new b
                                            },l=69):l==78?(h+=8192,l=64):l==40?l=b.zF?98: 50:l==42&&(E=n(x).replace(/\\+/g,
                                            "-").replace(/\ //g,"_").replace(/=/g,""),l=88)}},lX=function(b,y,x,E,h,n,k,U,l,L,G,S,M,e,t,J){for(J=84;J!=36;)if(J==61)J=(x&78)==x?79:78;else if(J==8)E=typeof b,t=E=="object"&&b!=y||E=="function",J=32;else if(J==80)J=(x&122)==x?65:67;else if(J==65)n=typeof h,k=n!=y?n:h?Array.isArray(h)?"array":n:"null",t=k==E||k==y&&typeof h.length==b,J=67;else if(J==17)J=k?42:80;else if(J==78)J=((x^18)&14)>=6&&(x|2)>>4<2?8:32;else if(J==32)J=(x|40)==x?17:80;else if(J==79){a:{switch(n){case 1:t=k?"disable":"enable";break a;case b:t=k?"highlight":"unhighlight";break a;case h:t=k?"activate":"deactivate";break a;case E:t=k?"select":"unselect";break a;case 16:t=k?"check":"uncheck";break a;case y:t=k?"focus":"blur";break a;case 64:t=k?"open":"close";break a}throw Error("Invalid component state");}J=78}else{if(J==67)return t;if(J==84)J=61;else if(J==42){a:{for(S=(e=(G=ym,n.split(y)),h);S<e.length-b;S++){if(L=e[S],!(L in G))break a;G=G[L]}(U=(M=e[e.length-b],l=G[M],k)(l),U)!=l&&U!=E&&En(G,M,{configurable:true,writable:true,value:U})}J=80}}},nF=function(b,y,x,E,h,n,k,U,l,L,G,S){for(S=96;S!=57;)if(S==10)S=(y|32)==y?61:86;else if(S==8)h.setAttribute(U,n),S=10;else if(S==b)S=hP?92:28;else if(S==28)L={},hP=(L.atomic=false,L.autocomplete="none",L.dropeffect="none",L.haspopup=false,L.live=x,L.multiline=false,L.multiselectable=false,L.orientation="vertical",L.readonly=false,L.relevant="additions text",L.required=false,L.sort="none",L.busy=false,L.disabled=false,L.hidden=false,L.invalid="false",L),S=92;else if(S==61)this[this+""]=this,S=86;else if(S==41)S=n===""||n==void 0?b:8;else{if(S==86)return G;S==92?(l=hP,k in l?h.setAttribute(U,l[k]):h.removeAttribute(U),S=10):S==96?S=19:S==9?(Array.isArray(n)&&(n=n.join(E)),U="aria-"+k,S=41):S==19&&(S=y<<1>=15&&(y-8&8)<6?9:10)}},Y=function(b,y,x,E,h,n,k,U,l,L,G){for(G=78;G!=73;)if(G==43)G=(k=x)?91:60;else if(G==48)lI.call(this,E),G=43;else if(G==37)G=0;else if(G==0)k=n?typeof n.lE==="function"?n.lE():new n:null,G=91;else if(G==5)G=35;else if(G==97)G=(n=Un[h])?37:75;else if(G==46)x=b[tM],L=x instanceof fo?x:null,G=80;else if(G==35)G=U?2:0;else if(G==63)r(x,b,E),E[kj]=2796,G=58;else if(G==10)G=y+5&9?96:48;else{if(G==40)return L;G==21?(this.type=b,this.currentTarget=this.target=x,this.defaultPrevented=this.Zm=false,G=40):G==82?G=35:G==78?G=10:G==58?G=(y|24)==y?46:80:G==91?(this.W=k,G=96):G==96?G=y+7>=21&&(y^71)<30?63:58:G==75?(U=(l=Object.getPrototypeOf(U.prototype))&&l.constructor,G=82):G==60?(U=this.constructor,G=5):G==80?G=y-9>>4>=0&&(y^19)<6?21:40:G==2&&(h=vg(16,U),G=97)}},tP=function(b,y,x,E,h,n,k,U,l){if(!y.j){y.iE++;try{for(l=(k=(h=void 0,y).s,0);--x;)try{if(n=void 0,y.l)h=gS(y,y.l);else{if(l=a(y,E),l>=k)break;h=(n=D(33,(r(y,81,l),y)),a(y,n))}I(2,12,(h&&(U=h[GE],(U|b)-~U+-2049-2*(U&-2049))?h(y,x):Sj(y,0,[LF,21,n],0),y),x,false,false)}catch(L){a(y,245)?Sj(y,22,L,0):r(y,245,L)}if(!x){if(y.LV){tP(2048,y,(y.iE--,124310824911),260);return}Sj(y,0,[LF,33],0)}}catch(L){try{Sj(y,22,L,0)}catch(G){z("~",9,y,G)}}y.iE--}},iX=function(b,y,x,E,h,n,k,U){return Y.call(this,b,11,y,x,E,h,n,k,U)},Q=function(b,y,x,E,h,n,k){k=this;try{ej(E,h,this,b,x,y,n)}catch(U){z("~",5,this,U),b(function(l){l(k.j)})}},a=function(b,y,x){if(x=b.R[y],x===void 0)throw[LF,30,y];if(x.value)return x.create();return x.create(y*5*y+-84*y+83),x.prototype},Sj=function(b,y,x,E,h,n,k,U,l,L,G,S,M,e){if(!b.ve&&(M=void 0,x&&x[E]===LF&&(y=x[1],M=x[2],x=void 0),n=a(b,341),n.length==E&&(S=a(b,81)>>3,n.push(y,(L=S>>8,256+(L|-256)),255-~S+~(S|255)),M!=void 0&&n.push(M&255)),l="",x&&(x.message&&(l+=x.message),x.stack&&(l+=":"+x.stack)),U=a(b,365),U[E]>3)){G=(l=(U[l=l.slice(E,(U[E]|E)-3),E]-=(e=l.length,-2-2*~(e|3)-(e^3)),JP(1,l)),b.o),b.o=b;try{b.kf?(k=(k=a(b,182))&&k[k.length-1]||95,(h=a(b,87))&&h[h.length-1]==k||f([k&255],87,b)):f([95],182,b),f(T(2,l.length).concat(l),439,b,12)}finally{b.o=G}}},g6=function(b){return mM.call(this,41,b)},Mz=function(b,y,x){for(x=87;x!=69;)if(x==54)x=91;else if(x==91)x=b--?86:7;else if(x==87)y=[],x=54;else if(x==86)y.push(Math.random()*255|0),x=13;else{if(x==7)return y;x==13&&(x=91)}},qz=function(b,y,x,E,h){return AM.call(this,12,h,27,b,x,y,E)},jj=function(b,y,x,E,h){E.fo.length>x?Sj(E,b,[LF,36],b):(E.fo.push(E.R.slice()),E.R[y]=void 0,r(E,y,h))},sw=function(){return A.call(this,60)},JM=function(b,y,x){return x.l?gS(x,x.I):Mu(y,8,b,x)},Vm=function(){return Uw.call(this,"",32)},Bv=function(b,y,x,E,h,n,k,U){return mM.call(this,33,b,y,x,E,h,n,k,U)},Ow=function(b,y,x,E,h){if((E=typeof x,E)=="object")if(x){if(x instanceof Array)return"array";if(x instanceof Object)return E;if(h=Object.prototype.toString.call(x),h=="[object Window]")return"object";if(h=="[object Array]"||typeof x.length==b&&typeof x.splice!="undefined"&&typeof x.propertyIsEnumerable!="undefined"&&!x.propertyIsEnumerable("splice"))return"array";if(h=="[object Function]"||typeof x.call!="undefined"&&typeof x.propertyIsEnumerable!="undefined"&&!x.propertyIsEnumerable("call"))return"function"}else return y;else if(E=="function"&&typeof x.call=="undefined")return"object";return E},rS=function(b,y){return Y.call(this,b,16,y)},Ix=function(b,y){function x(){(this.n=0,this).N=[]}return[(y=(b=(x.prototype.At=(x.prototype.bE=function(){return Ip.call(this,34,3)},function(E,h){return QL.call(this,8,35,E,h)}),new x),new x),function(E){b.At(E),y.At(E)}),function(E){return E=b.bE().concat(y.bE()),y=new x,E}]},XJ=function(b,y,x,E,h,n){try{n=b[(-~(y&2)+-3-~y-(y|-3))%3],b[y]=(E=b[y],h=b[((y|0)+1)%3],(E&~h)+(~E^h)-(~E|h))-(n|0)^(y==1?n<<x:n>>>x)}catch(k){throw k;}},ax=function(b,y,x,E,h,n,k,U,l,L){for(l=(L=D(34,((n=(k=E[Yj]||{},D(32,E)),k.JZ=D(18,E),k).A=[],U=E.o==E?(JM(b,true,E)|h)-x:1,E)),h);l<U;l++)k.A.push(D(y,E));for(k.Yy=a(E,L);U--;)k.A[U]=a(E,k.A[U]);return k.wS=a(E,n),k},r6=function(b,y,x,E,h,n,k){(k=a(y,(E=D(16,(n=D(19,(x=b&(h=b&3,4),y)),y)),n)),x&&(k=JP(1,""+k)),h&&f(T(2,k.length),E,y),f)(k,E,y)},CF=function(b,y){for(var x=72;x!=57;)if(x==37){var E=arguments[n];for(k in E)b[k]=E[k];var h=(x=48,0)}else if(x==72)var n=(x=6,1);else if(x==70)x=h<mK.length?23:30;else if(x==59)h++,x=70;else if(x==48)x=70;else if(x==30)n++,x=52;else if(x==6)x=52;else if(x==23){var k=mK[h];x=(Object.prototype.hasOwnProperty.call(E,k)&&(b[k]=E[k]),59)}else x==52&&(x=n<arguments.length?37:57)},vv=function(b,y,x){return AM.call(this,12,b,3,y,x)},Pv=function(b,y,x,E,h,n){return(r(x,(tP(b,(n=a(x,260),x.Jt&&n<x.s?(r(x,260,x.s),jj(0,260,E,x,y)):r(x,260,y),x),h,260),260),n),a)(x,278)},fo=function(b){return AM.call(this,12,b,34)},FJ=function(){return vg.call(this,24)},gS=function(b,y,x){return(x=y.create().shift(),b.l.create()).length||b.I.create().length||(b.l=void 0,b.I=void 0),x},Wg=function(){return k6.call(this,16)},On=function(b,y,x,E,h,n,k,U,l,L,G,S){for(S=90;S!=36;)if(S==38)L=n[U],S=56;else if(S==99)S=U<n.length?38:36;else if(S==0){a:{if(L&&typeof L.length=="number"){if(lX(L,null,5)){l=typeof L.item=="function"||typeof L.item==y;break a}if(typeof L==="function"){l=typeof L.item=="function";break a}}l=b}S=(k6(33,"",0,G,l?z(0,3,L):L),86)}else S==86?(U++,S=99):S==91?S=99:S==56?S=!lX("number",E,16,h,L)||lX(L,null,9)&&L.nodeType>0?47:0:S==47?(G(L),S=86):S==90&&(G=function(M){M&&k.appendChild(typeof M==="string"?x.createTextNode(M):M)},U=1,S=91)},Z8=function(b){return K.call(this,3,b)},r=function(b,y,x){if(y==260||y==81)b.R[y]?b.R[y].concat(x):b.R[y]=D(42,x,b);else{if(b.ve&&y!=470)return;y==177||y==439||y==93||y==136||y==341||y==182||y==87||y==296||y==417||y==365?b.R[y]||(b.R[y]=uX(110,16,7,61,x,y,b)):b.R[y]=uX(97,16,6,61,x,y,b)}y==470&&(b.B=Mu(false,32,3,b),b.S=void 0)},pF=function(b,y,x,E,h,n,k,U,l,L){for(L=x[2]|(l=x[y]|h,h),U=h;U<16;U++)E=E>>>n|E<<24,E+=k|h,k=k<<y|k>>>29,E^=L+b,l=l>>>n|l<<24,l+=L|h,l^=U+b,k^=E,L=L<<y|L>>>29,L^=l;return[k>>>24&255,k>>>16&255,k>>>n&255,k>>>h&255,E>>>24&255,E>>>16&255,E>>>n&255,E>>>h&255]},uI=function(b,y,x,E,h){if(b.length==3){for(x=0;x<3;x++)y[x]+=b[x];for(h=[13,8,13,12,16,5,3,(E=0,10),15];E<9;E++)y[3](y,E%3,h[E])}},zE=function(b,y,x,E,h,n,k,U,l,L,G,S){for(L=(G=68,x);;)try{if(G==7)break;else if(G==b)G=U&&U.createPolicy?97:20;else{if(G==77)return L=x,l;if(G==E)G=c.console?y:77;else if(G==28)L=x,G=E;else if(G==68)U=c.trustedTypes,l=h,G=b;else if(G==y)c.console[n](S.message),G=77;else{if(G==20)return l;G==97&&(L=4,l=U.createPolicy(k,{createHTML:Z8,createScript:Z8,createScriptURL:Z8}),G=77)}}}catch(M){if(L==x)throw M;L==4&&(S=M,G=28)}},En=typeof Object.defineProperties=="function"?Object.defineProperty:function(b,y,x,E){for(E=27;E!=62;)if(E==27)E=b==Array.prototype||b==Object.prototype?23:58;else{if(E==23)return b;if(E==58)return b[y]=x.value,b}},bI=function(b,y,x,E,h,n){return Bg.call(this,b,8,y,x,E,h,n)},Co=function(b,y,x,E,h,n,k,U,l,L,G,S,M){if((U=y[0],U)==Zh)E.rS=25,E.h=true,E.g(y);else if(U==po){n=y[1];try{S=E.j||E.g(y)}catch(e){z("~",6,E,e),S=E.j}(n((M=E.Z(),S)),E).F+=E.Z()-M}else if(U==hM)y[3]&&(E.C=true),y[4]&&(E.h=true),E.g(y);else if(U==D8)E.C=true,E.g(y);else if(U==w6){try{for(k=0;k<E.y7.length;k++)try{L=E.y7[k],L[0][L[1]](L[2])}catch(e){}}catch(e){}(0,y[1])(function(e,t){E.Nc(e,true,t)},function(e){K(20,(e=!E.L.length,0),[GE],E),e&&vg(37,0,true,x,E)},function(e){return E.po(e)},(E.y7=[],h=E.Z(),function(e){return E.jw(e)})),E.F+=E.Z()-h}else{if(U==Rp)return G=y[2],r(E,189,y[6]),r(E,278,G),E.g(y);U==GE?(E.g(y),E.Ko=[],E.R=null,E.Jt=[]):U==kj&&(l=c.parent,l.document.readyState==="loading"&&(E.K=function(e,t){function J(g){for(g=5;g!=7;)g==5?g=t?7:82:g==82&&(t=true,l.document.removeEventListener("DOMContentLoaded",J,Ko),l.removeEventListener(b,J,Ko),e(),g=7)}(l.document.addEventListener("DOMContentLoaded",(t=x,J),Ko),l).addEventListener(b,J,Ko)}))}},T=function(b,y,x,E){for(E=(b|0)-1,x=[];E>=0;E--)x[(b|0)-1-(E|0)]=y>>E*8&255;return x},iI=function(b,y,x,E,h){return QL.call(this,8,3,b,y,x,E,h)},T8=function(){return dS.call(this,false,98,10)},sn=function(b,y){function x(){this.gS=this.m=this.n=0}return[function(E){b.IR(E),y.IR(E)},(y=(b=(x.prototype.IR=function(E,h){return Uw.call(this,"",16,E,h)},x.prototype.Xl=function(){return wS.call(this,30)},new x),new x),function(E){return y=new (E=[b.Xl(),y.Xl(),b.m,y.m],x),E})]},N,$6=function(){return QL.call(this,8,27)},Hv=function(){return qu.call(this,5,79,5)},ap=function(b,y,x,E,h){return Uw.call(this,"",80,b,y,x,E,h)},AP=function(b,y,x,E,h,n,k,U,l,L,G,S,M,e){(y.push((e=(M=(x=b[0]<<24,G=b[1]<<16,(x&G)+(x&~G)+(~x&G)),h=b[2]<<8,2*(h|0)+~h-(~M|h)),n=b[3],-~n+2*(e&~n)+(~e|n))),y).push((S=b[4]<<24|b[5]<<16,k=b[6]<<8,-~S+(S^k)+(~S|k))|b[7]),y.push((E=(L=b[8]<<24|b[9]<<16,l=b[10]<<8,-~(L&l)+2*(L^l)+(~L^l)),U=b[11],2*(U|0)+~(E&U)-(~E&U)-(~E|U)))},lI=function(b){return dS.call(this,false,98,8,b)},Qm=function(b,y){return AM.call(this,12,b,33,y)},Mu=function(b,y,x,E,h,n,k,U,l,L,G,S,M,e,t,J,g,V){if(l=a(E,260),l>=E.s)throw[LF,31];for(L=(h=(U=0,n=E.dV.length,l),y);L>0;)g=h%8,V=8-(g|0),J=V<L?V:L,S=h>>x,G=E.Jt[S],b&&(M=E,k=h,M.S!=k>>6&&(M.S=k>>6,e=a(M,470),M.Q7=pF(2003,3,[0,0,e[1],e[2]],M.S,0,8,M.B)),G^=E.Q7[S&n]),U|=(G>>8-(g|0)-(J|0)&(1<<J)-1)<<(L|0)-(J|0),L-=J,h+=J;return r(E,260,(t=U,(l|0)+(y|0))),t},JP=function(b,y,x,E,h,n,k,U,l,L,G,S,M){for(x=(h=y.replace(/\\r\\n/g,"\\n"),G=0,[]),n=0;n<h.length;n++)S=h.charCodeAt(n),S<128?x[G++]=S:(S<2048?x[G++]=(M=S>>6,(M&192)-b-(~M^192)):((S&64512)==55296&&n+b<h.length&&(h.charCodeAt(n+b)&64512)==56320?(S=65536+((S&1023)<<10)+(h.charCodeAt(++n)&1023),x[G++]=(L=S>>18,-~(L|240)+(~L&240)+(L|-241)),x[G++]=(l=S>>12,(l|0)-~(l&63)+~l)|128):x[G++]=(E=S>>12,224-(~E^224)+(E|-225)),x[G++]=(U=S>>6&63,2*(U|0)+~U-(U|-129))),x[G++]=(k=S&63,(k&128)+~(k&128)- -129+(k&-129)));return x},ej=function(b,y,x,E,h,n,k,U,l,L,G,S,M,e){for(l=(x.i$=(x.RT=X4(16,{get:function(){return this.concat()}},((x.KV=ox,x).dV=(x.mw=Rx,x[po]),3),x.i),eY)[x.i](x.RT,{value:{value:{}}}),U=[],0);l<387;l++)U[l]=String.fromCharCode(l);if((x.ew=((x.Q7=void 0,x.V7=((x.o=x,x).L=(x.F=0,[]),0),x).ce=(x.kf=false,0),(x.y7=[],x.NL=0,x.h=(x.iE=0,x.Ko=[],x.S=(x.eS=false,void 0),!(x.D=void 0,x.ve=false,((x.X=1,x.rV=k,x.l=void 0,x).qL=[],x.jS=0,x.Vg=(x.B=void 0,[]),x).Ox=0,1)),x).j=(x.fo=(x.rS=25,x.K=null,x.Ex=n,x.C=!(x.T$=function(t){return O.call(this,t,6)},L=window.performance||{},1),[]),x.Zp=false,x.Jt=[],x.R=[],x.I=void 0,x.GF=0,x.s=(x.oT=8001,x.Fl=void 0,0),void 0),L).timeOrigin||(L.timing||{}).navigationStart||0,b&&b.length==2)&&(x.qL=b[0],x.Vg=b[1]),h)try{x.D=JSON.parse(h)}catch(t){x.D={}}vg(33,(K(64,0,(K(20,0,((Y(241,64,(Y(215,72,(r(x,439,(Y(221,69,x,(r(x,(Y(53,69,x,(r(x,(Y(485,76,(Y(426,73,(Y(267,(Y(108,(r(x,(r(x,(Y(314,(r(x,23,(Y((r(x,417,(r(x,(Y(318,71,x,(r(x,((Y(409,68,(r(x,(Y((Y(461,73,(r(x,((new (Y(3,(Y(125,66,(Y(84,67,x,(Y((r(x,(Y((Y(357,70,(r(x,(Y(39,71,(r(x,(r((Y(208,67,x,(Y(152,74,x,(Y(447,64,(r(x,(Y(324,72,x,((r((r(x,260,(((x.cpnqjn="",x.kuydqs=[],x).bgodnd=0,x.laantf=[],x).D&&x.D.a&&((e=x.D.b)&&(x.bgodnd=e),(M=x.D.c)&&(x.cpnqjn=M),(G=x.D.d)&&(x.kuydqs=G),(S=x.D.e)&&(x.laantf=S)),0)),x),81,0),Y)(184,76,x,function(t,J,g,V,B,X){r(t,(B=a(t,(V=a(t,(g=D(18,(J=D(34,(X=D(17,t),t)),t)),J)),X)),g),B[V])}),function(t,J,g,V,B){r((V=Ow((B=a(t,(g=D(17,(J=D(35,t),t)),J)),"number"),"null",B),t),g,V)})),341),[]),x),function(t,J,g,V,B){for(B=57;B!=82;)B==30?(V[341]=t.R[341],V[365]=t.R[365],t.R=V,B=82):B==19?(J--,B=97):B==57?(V=t.fo.pop(),B=52):B==83?(J=JM(3,true,t),B=71):B==97?B=J>0?66:30:B==71?B=97:B==52?B=V?83:46:B==46?(r(t,260,t.s),B=82):B==66&&(g=D(33,t),V[g]=t.R[g],B=19)}),function(t,J){jj(0,(J=a(t,D(16,t)),260),104,t.o,J)})),function(t,J,g,V){r((J=D(19,(V=D(35,(g=D(32,t),t)),t)),t),J,a(t,g)||a(t,V))})),x),182,[]),278),{}),Y(454,70,x,function(t,J,g,V){r(t,(J=D(32,(g=JM(3,(V=D(16,t),true),t),t)),J),a(t,V)>>>g)}),x),function(t,J,g){g=D(35,(J=D(33,t),t)),r(t,g,""+a(t,J))}),217),0),x),function(t){uX(t,true,48,4)}),205),67,x,function(t,J,g,V,B,X){for(X=85;X!=89;)X==78?(J++,X=21):X==11?(r(t,B,g),X=89):X==21?X=J<V?76:11:X==85?(B=D(32,t),V=D(5,127,t),J=0,g=[],X=72):X==76?(g.push(JM(3,true,t)),X=78):X==72&&(X=21)}),136),Mz(4)),379),78,x,function(t){r6(4,t)}),function(t,J,g,V,B,X){for(X=90;X!=63;)X==90?X=I(2,6,t,J,false,true)?63:36:X==36?(g=ax(3,16,1,t,0),V=g.wS,B=g.Yy,X=43):X==43?X=t.o==t||V==t.T$&&B==t?32:63:X==32&&(r(t,g.JZ,V.apply(B,g.A)),t.jS=t.Z(),X=63)})),x),function(t,J,g,V,B,X,v,m){for(m=43;m!=65;)m==47?(g=a(t,J),v=a(t,B),V=a(t,X),v[g]=V,m=3):m==3?m=B==470?92:65:m==36?m=t.o==t?47:65:m==53?(t.B=Mu(false,32,3,t),t.S=void 0,m=65):m==43?(B=D(17,t),J=D(35,t),X=D(35,t),m=36):m==88?m=g==2?53:65:m==92&&(t.S=void 0,m=88)}),66),x,function(t,J,g,V,B,X){r(t,(X=a(t,(V=a(t,(g=D(35,(B=(J=D(19,t),D(34,t)),t)),J)),B)),g),V in X|0)}),r(x,360,0),vv)("Submit")).dispose(),87),[]),x),function(){}),291),78,x,function(t,J,g,V,B){for(B=59;B!=39;)B==52?(V=D(33,t),g=D(19,t),r(t,g,function(X){return eval(X)}(KF(a(t.o,V)))),B=39):B==59&&(B=I(2,3,t,J,false,true)?39:52)}),177),[165,0,0]),x),function(t,J,g,V,B,X,v,m,F,p){for(p=17;p!=55;)p==47?(V=ax(3,16,1,t.o,0),B=V.wS,X=V.JZ,v=V.A,g=V.Yy,F=v.length,m=F==0?new g[B]:F==1?new g[B](v[0]):F==2?new g[B](v[0],v[1]):F==3?new g[B](v[0],v[1],v[2]):F==4?new g[B](v[0],v[1],v[2],v[3]):2(),r(t,X,m),p=55):p==17&&(p=I(2,11,t,J,false,true)?55:47)}),Y)(488,68,x,function(t,J,g,V,B,X,v,m){r(t,(g=a(t,(m=(J=a(t,(v=D(16,(X=(V=D(17,(B=D(19,t),t)),D(16,t)),t)),v)),a)(t,V),X)),B),cg(6,g,1,false,t,m,J))}),448),c),function(t,J,g){(J=a((g=D(16,t),t).o,g),J)[0].removeEventListener(J[1],J[2],Ko)})),366),x),Mz(4))),54),74,x,function(t,J,g,V,B){(g=a(t,(V=a(t,(J=D(19,(B=D(33,t),t)),B))!=0,J)),V)&&r(t,260,g)}),[])),64),x,function(t,J,g,V,B,X,v,m,F){for(F=44;F!=45;)F==2?(r(t,g,V),F=45):F==58?F=J--?70:2:F==47?F=58:F==44?(g=D(34,t),J=D(6,127,t),V="",v=a(t,159),B=v.length,m=0,F=76):F==76?F=58:F==70&&(m=(X=D(7,127,t),(m&X)+-2-~X-(~m|X))%B,V+=U[v[m]],F=47)}),x.G$=0,296),[0,0,0]),365),[2048]),68),x,function(t){cv(t,1)}),66),x,function(t){r6(3,t)}),x),function(t,J,g,V,B,X){r(t,(X=a(t,(V=D(32,(B=D(17,(g=D(35,t),t)),t)),B)),J=a(t,g)==X,V),+J)}),x.AZ=0,x),function(t,J,g,V,B,X,v,m,F,p,u){for(u=71;u!=15;)u==40?u=v!==0?39:15:u==71?(p=D(32,t),V=D(17,t),X=D(16,t),F=D(19,t),B=a(t,F),m=a(t,X),v=a(t.o,p),J=a(t,V),u=40):u==39&&(g=cg(5,B,1,false,t,m,1,v,J),v.addEventListener(J,g,Ko),a(t,23).push(function(){v.removeEventListener(J,g,Ko)}),r(t,217,[v,J,g]),u=15)}),x.ky=0,245),505),function(t,J,g,V,B,X,v,m,F,p,u,d,w,R,Z){for(Z=89;Z!=98;)if(Z==89)Z=I(2,5,t,J,true,true)?98:97;else if(Z==2)Z=t.o==t?32:98;else if(Z==93)Z=p<g?70:98;else if(Z==54)Z=Ow("number","null",F)=="object"?92:2;else if(Z==70)B(F.slice(p,(p|0)+(u|0)),d),Z=73;else if(Z==42)Z=93;else if(Z==73)p+=u,Z=93;else if(Z==97)v=D(18,t),X=D(32,t),w=D(33,t),V=D(19,t),F=a(t,v),u=a(t,w),B=a(t,X),d=a(t,V),Z=54;else if(Z==92){for(m in R=[],F)R.push(m);F=R,Z=2}else Z==32&&(p=0,u=u>0?u:1,g=F.length,Z=42)})),93),[]),function(t,J,g,V,B){V=a((B=(J=D(33,(g=D(34,t),t)),a(t,J)),t),g),r(t,J,B+V)})),Mz(4))),x),function(t){cv(t,4)}),x),function(t,J,g,V,B,X,v,m,F,p,u,d,w,R,Z,G8,jY,VL,C){for(C=95;C!=30;)C==88?C=m<Z?72:83:C==35?C=B--?34:23:C==69?C=35:C==39?C=35:C==95?(VL=function(W,x6){for(;J<W;)G8|=JM(3,true,t)<<J,J+=8;return G8>>=(x6=G8&(1<<(J-=W,W))-1,W),x6},jY=D(18,t),G8=J=0,p=(u=VL(3),2*~(u&1)-3*~u- -2+2*(~u|1)),Z=VL(5),v=g=0,d=[],C=49):C==80?(m=0,C=51):C==65?(R=((g|0)-1).toString(2).length,X=[],w=0,C=22):C==23?(Y(jY,69,t,function(W,x6,q,H,Pg,P){for(P=6;P!=89;)P==20?(q++,P=27):P==75?P=27:P==67?(W.l=D(41,V.slice(),W),W.I=D(40,Pg,W),P=89):P==58?(x6=H[x6],P=3):P==27?P=q<Z?76:67:P==98?P=d[q]?3:40:P==3?(Pg.push(x6),P=20):P==40?P=49:P==33?P=49:P==76?(x6=X[q],P=98):P==6?(q=0,H=[],Pg=[],P=75):P==49?P=x6>=H.length?32:58:P==32&&(H.push(D(18,W)),P=33)}),C=30):C==74?(m++,C=88):C==76?C=w<Z?84:80:C==19?(F=VL(1),d.push(F),g+=F?0:1,C=61):C==98?C=v<Z?19:65:C==84?(d[w]||(X[w]=VL(R)),C=0):C==49?C=98:C==72?(d[m]&&(X[m]=D(18,t)),C=74):C==51?C=88:C==34?(V.push(a(t,D(34,t))),C=39):C==61?(v++,C=98):C==22?C=76:C==0?(w++,C=76):C==83&&(V=[],B=p,C=69)}),K)(68,0,[kj],x),[D8,y]),x),[w6,E]),x),0),true,true,x)},cv=function(b,y,x,E){f(T(y,a(b,(x=D(17,(E=D(18,b),b)),E))),x,b)},f=function(b,y,x,E,h,n,k,U,l){if(x.o==x)for(l=a(x,y),y==439||y==417||y==136?(k=function(L,G,S,M,e,t,J,g,V,B){for(g=72,V=83;;)try{if(g==68)break;else if(g==71)g=l.Ph!=M?49:10;else if(g==49)l.Ph=M,G=(S=M<<3,-2*(S|4)+-3-2*~S-(~S^4)),J=[0,0,h[1],h[2]],g=66;else if(g==66)V=31,l.nV=pF(2003,3,J,cg(27,l,8,24,-2*~(G&4)+-3+(G&-5)-(G|-5)),0,8,cg(28,l,8,24,G)),g=10;else if(g==72)t=l.length,M=~(t&4)-2*~t+~(t|4)>>3,g=71;else if(g==10)l.push((e=l.nV[(t|7)-~(t&7)+~(t|7)],-1+(e&~L)-(e|~L))),g=68;else if(g==48)throw V=83,B;}catch(X){if(V==83)throw X;V==31&&(B=X,g=48)}},h=a(x,296)):k=function(L){l.push(L)},E&&k(E&255),n=0,U=b.length;n<U;n++)k(b[n])},ym=K(24,"Math",0,"object",this),c=(lX(1,".",41,null,0,"Symbol",function(b,y,x,E,h,n){for(n=46;n!=23;){if(n==28)return h.prototype.toString=function(){return this.z$},x="jscomp_symbol_"+(Math.random()*1E9>>>0)+"_",y=0,E;if(n==79)n=b?83:28;else if(n==46)h=function(k,U){En(this,"description",(this.z$=k,{configurable:true,writable:true,value:U}))},E=function(k,U){for(U=12;U!=97;){if(U==61)throw new TypeError("Symbol is not a constructor");if(U==12)U=this instanceof E?61:20;else if(U==20)return new h(x+(k||"")+"_"+y++,k)}},n=79;else if(n==83)return b}}),this)||self,z8="closure_uid_"+(Math.random()*1E9>>>0),Dh=0,Nu,xj=function(b,y,x,E,h,n){for(h=14,n=25;;)try{if(h==53)break;else if(h==14)h=c.addEventListener&&Object.defineProperty?88:71;else if(h==50)n=25,h=51;else{if(h==51)return n=25,y;if(h==87)n=69,b=function(){},c.addEventListener("test",b,x),c.removeEventListener("test",b,x),h=51;else{if(h==71)return false;h==88&&(y=false,x=Object.defineProperty({},"passive",{get:function(){y=true}}),h=87)}}}catch(k){if(n==25)throw k;n==69&&(E=k,h=50)}}(),Ew="closure_listenable_"+(((O((Wg.prototype.dispose=(Wg.prototype.T=function(b){for(b=54;b!=30;)b==75?(this.We.shift()(),b=92):b==19?b=this.We.length?75:30:b==92?b=19:b==41?b=19:b==54&&(b=this.We?41:30)},(rS.prototype.preventDefault=function(){this.defaultPrevented=true},rS.prototype).stopPropagation=function(){this.Zm=true},Wg.prototype.u=false,function(b){for(b=21;b!=16;)b==43?(this.u=true,this.T(),b=16):b==21&&(b=this.u?16:43)}),Wg.prototype[Symbol.dispose]=function(){this.dispose()},2),72,ap,rS),ap).prototype.stopPropagation=function(){(ap.J.stopPropagation.call(this),this.v.stopPropagation)?this.v.stopPropagation():this.v.cancelBubble=true},ap).prototype.preventDefault=function(b){ap.J.preventDefault.call(this),b=this.v,b.preventDefault?b.preventDefault():b.returnValue=false},Math.random()*1E6|0),Hg=0,mK="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" "),tM=((fo.prototype.remove=function(b,y,x,E,h,n,k,U){for(U=86;U!=49;){if(U==71)return false;if(U==9)U=n.length==0?82:74;else if(U==86)k=b.toString(),U=47;else{if(U==78)return false;if(U==3)U=h>-1?45:78;else if(U==82)delete this.Y[k],this.He--,U=74;else if(U==38)n=this.Y[k],h=A(47,0,E,y,n,x),U=3;else if(U==45)Lo(94,n[h],true,6),Array.prototype.splice.call(n,h,1),U=9;else if(U==47)U=k in this.Y?38:71;else if(U==74)return true}}},fo.prototype).add=(fo.prototype.dS=function(b,y,x,E,h,n){return(n=this.Y[h=-1,E.toString()],n)&&(h=A(15,0,y,x,n,b)),h>-1?n[h]:null},fo.prototype.hasListener=function(b,y,x,E,h){return K(49,(h=(E=(x=y!==void 0,b!==void 0))?b.toString():"",true),false,function(n,k,U){for(U=2;U!=9;)if(U==27)++k,U=59;else if(U==59)U=k<n.length?64:0;else if(U==2)k=0,U=20;else if(U==64)U=E&&n[k].type!=h||x&&n[k].capture!=y?27:53;else{if(U==53)return true;if(U==20)U=59;else if(U==0)return false}},this.Y)},function(b,y,x,E,h,n,k,U,l,L){for(L=50;L!=22;)if(L==29)l=new qz(!!E,k,this.src,h,y),l.tt=x,n.push(l),L=17;else if(L==41)l=n[U],L=16;else if(L==79)L=U>-1?41:29;else if(L==48)U=A(31,0,h,y,n,E),L=79;else{if(L==17)return l;L==71?(l.tt=false,L=17):L==42?(n=this.Y[k]=[],this.He++,L=48):L==50?(k=b.toString(),n=this.Y[k],L=94):L==16?L=x?17:71:L==94&&(L=n?48:42)}}),"closure_lm_"+(Math.random()*1E6|0)),bX={},SY=0,Y6="__closure_events_fn_"+(Math.random()*1E9>>>0);((N=((O(2,73,T8,Wg),T8).prototype[Ew]=true,T8.prototype),N.Ux=function(b){this.sx=b},N).addEventListener=function(b,y,x,E){Uw("",72,false,true,E,y,b,this,x)},N.removeEventListener=function(b,y,x,E){I(null,33,0,x,y,b,E,this)},N).dispatchEvent=function(b,y,x,E,h,n,k,U,l,L,G,S){for(S=51;S!=89;)if(S==75)S=30;else if(S==6)S=91;else if(S==30)S=E?78:50;else if(S==47)n=U.length-1,S=6;else if(S==29)n=0,S=88;else if(S==11)k=L,L=new rS(l,G),CF(L,k),S=1;else if(S==72)L=new rS(L,G),S=1;else if(S==17)n--,S=91;else if(S==79)h=L.currentTarget=G,x=A(32,0,true,L,l,h)&&x,L.Zm||(x=A(33,0,false,L,l,h)&&x),S=21;else if(S==93)S=E?41:50;else if(S==58)E=E.sx,S=30;else if(S==88)S=18;else if(S==50)G=this.Dp,U=y,L=b,l=L.type||L,S=45;else if(S==91)S=!L.Zm&&n>=0?15:39;else if(S==96)S=U?47:39;else if(S==21)S=U?29:52;else if(S==41)y=[],S=75;else if(S==81)L.target=L.target||G,S=1;else if(S==15)h=L.currentTarget=U[n],x=A(8,0,true,L,l,h)&&x,S=17;else if(S==64)S=L instanceof rS?81:11;else if(S==18)S=!L.Zm&&n<U.length?12:52;else{if(S==52)return x;S==25?(n++,S=18):S==1?(x=true,S=96):S==51?(E=this.sx,S=93):S==12?(h=L.currentTarget=U[n],x=A(9,0,false,L,l,h)&&x,S=25):S==78?(y.push(E),S=58):S==39?S=L.Zm?21:79:S==45&&(S=typeof L==="string"?72:64)}},N.dS=function(b,y,x,E){return this.H.dS(b,y,x,String(E))},N.T=function(){this.sx=((T8.J.T.call(this),this.H)&&mM(56,true,0,this.H),null)},N.hasListener=function(b,y){return this.H.hasListener(b!==void 0?String(b):void 0,y)};var hP;(((((N=(((Bg(FJ,((((("ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON","INPUT"]),N=$6.prototype,N).G=function(b){return typeof b==="string"?this.Dm.getElementById(b):b},N).getElementsByTagName=function(b,y){return(y||this.Dm).getElementsByTagName(String(b))},N.createElement=function(b,y,x){return((y=(x=this.Dm,String(b)),x.contentType==="application/xhtml+xml")&&(y=y.toLowerCase()),x).createElement(y)},N.createTextNode=function(b){return this.Dm.createTextNode(String(b))},N.appendChild=function(b,y){b.appendChild(y)},N.append=function(b,y){On(false,"string",b.nodeType==9?b:b.ownerDocument||b.document,"object","array",arguments,b)},N).canHaveChildren=function(b,y){for(y=67;y!=26;){if(y==59){switch(b.tagName){case "APPLET":case "AREA":case "BASE":case "BR":case "COL":case "COMMAND":case "EMBED":case "FRAME":case "HR":case "IMG":case "INPUT":case "IFRAME":case "ISINDEX":case "KEYGEN":case "LINK":case "NOFRAMES":case "NOSCRIPT":case "META":case "OBJECT":case "PARAM":case "SCRIPT":case "SOURCE":case "STYLE":case "TRACK":case "WBR":return false}return true}if(y==67)y=b.nodeType!=1?18:59;else if(y==18)return false}},N.removeNode=g6,N).contains=function(b,y,x,E){for(E=29;E!=44;)if(E==63)E=y&&b!=y?11:53;else{if(E==91)return b==y||b.contains(y);if(E==10)E=63;else if(E==29)E=b&&y?82:67;else if(E==11)y=y.parentNode,E=10;else if(E==82)E=b.contains&&y.nodeType==1?91:96;else if(E==77)E=63;else{if(E==53)return y==b;if(E==67)return false;if(E==92)return b==y||!!(x=b.compareDocumentPosition(y),2*(x|0)-~(x&16)- -1+2*~x);E==96&&(E=typeof b.compareDocumentPosition!="undefined"?92:77)}}},48)),FJ).prototype.FW=0,FJ.prototype.sn="",O)(2,88,lI,T8),lI).prototype,N).Wh=FJ.lE(),N).G=function(){return this.U},N).getParent=function(){return this.Yf},N.Ux=function(b,y){for(y=17;y!=73;)if(y==94)lI.J.Ux.call(this,b),y=73;else if(y==17)y=this.Yf&&this.Yf!=b?31:94;else if(y==31)throw Error("Method not supported");},N.T=function(b){for(b=55;b!=45;)b==98?b=this.RR?24:83:b==55?(this.Be&&this.oR(),b=98):b==24?(this.RR.dispose(),delete this.RR,b=83):b==83&&(AM(12,function(y){y.dispose()},42,this),!this.xy&&this.U&&g6(this.U),this.U=this.qc=this.TF=this.Yf=null,lI.J.T.call(this),b=45)},N).oR=function(){AM(12,function(b){b.Be&&b.oR()},39,this),this.RR&&mM(57,true,0,this.RR),this.Be=false},N).removeChild=function(b,y,x,E,h,n,k,U,l,L,G,S,M){for(M=4;M!=92;)if(M==58)M=n&&b?3:64;else if(M==70)n=k,M=56;else if(M==28)M=(G=b.uE)?46:21;else if(M==26)M=S==null?74:22;else if(M==22)S.Yf=null,lI.J.Ux.call(S,null),M=64;else if(M==31)S=b,M=26;else if(M==56)M=this.TF&&n?79:89;else if(M==89)E=null,M=13;else{if(M==87)return b;if(M==6)throw Error("Child is not in parent component");if(M==27)b.oR(),b.U&&g6(b.U),M=31;else if(M==21)h=b.Wh,U=b,x=h.sn+":"+(h.FW++).toString(36),G=U.uE=x,M=46;else if(M==0)M=typeof b==="string"?20:28;else if(M==46)k=G,M=70;else if(M==13)b=E,M=58;else if(M==64)M=b?87:6;else{if(M==74)throw Error("Unable to set parent component");M==79?(l=this.TF,E=(l!==null&&n in l?l[n]:void 0)||null,M=13):M==4?M=b?0:64:M==3?(L=this.TF,n in L&&delete L[n],yL(4,3,1,b,this.qc),M=80):M==20?(k=b,M=70):M==80&&(M=y?27:31)}}};var Wv,fF=(Bg(Vm,16),{button:"pressed",checkbox:"checked",menuitem:"selected",menuitemcheckbox:"checked",menuitemradio:"checked",radio:"checked",tab:"selected",treeitem:"selected"}),Un=(Bg(Hv,(O(2,89,Hv,(((((N=Vm.prototype,N.aR=function(b,y,x,E,h,n,k,U,l){for(U=(k=72,36);;)try{if(k==11)break;else k==64?(x=n.tabIndex,h=typeof x==="number"&&x>=0&&x<32768,k=34):k==25?k=(h=n.hasAttribute("tabindex"))?64:34:k==13?(E.tabIndex=-1,E.removeAttribute("tabIndex"),k=11):k==34?k=h!=y?0:11:k==71?k=y?95:13:k==60?k=!y&&b.O&32?99:25:k==79?(U=36,k=58):k==95?(E.tabIndex=0,k=11):k==0?(E=n,k=71):k==99?(U=6,n.blur(),k=58):k==58?(U=36,k=50):k==50?k=b.O&32?17:25:k==72?k=Bg(2,12,b,32)&&(n=b.Mc())?60:11:k==17&&(Ip(34,5,0,1,4,b)&&b.setActive(false),Ip(34,6,0,1,32,b)&&mM(70,4,32,false,b)&&b.P(false,32),k=25)}catch(L){if(U==36)throw L;U==6&&(l=L,k=79)}},N).Lo=function(b,y,x,E){(E=y.G?y.G():y)&&(x?iI:Qm)(E,[b])},N.P=function(b,y,x,E,h,n,k){for(k=42;k!=83;)k==56?k=this.Co?19:80:k==23?k=h?56:83:k==80?(n=this.ht(),n.replace(/\\xa0|\\s/g," "),this.Co={1:n+"-disabled",2:n+"-hover",4:n+"-active",8:n+"-selected",16:n+"-checked",32:n+"-focused",64:n+"-open"},k=19):k==42?(h=y.G(),k=23):k==19&&((E=this.Co[b])&&this.Lo(E,y,x),this.SS(h,b,x),k=83)},N).SS=function(b,y,x,E,h,n,k,U){(E=((Wv||(Wv={1:"disabled",8:"selected",16:"checked",64:"expanded"}),h=Wv[y],k=b.getAttribute("role")||null)?(n=fF[k]||h,U=h=="checked"||h=="selected"?n:h):U=h,U))&&nF(68,9,"off"," ",b,x,E)},N).ht=function(){return"goog-control"},N).Mc=function(b){return b.G()},Vm)),20)),Hv.prototype.SS=function(b,y,x){switch(y){case 8:case 16:nF(68,8,"off"," ",b,x,"pressed");break;default:case 64:case 1:Hv.J.SS.call(this,b,y,x)}},{});if(typeof iX!==(((((((N=(O(2,(Hv.prototype.ht=function(){return"goog-button"},81),iX,lI),iX.prototype),N.ML=39,N.Mc=function(){return this.W.Mc(this)},N.Sw=0,N).oR=function(){(iX.J.oR.call(this),this.Pe&&this.Pe.detach(),this.isVisible()&&this.isEnabled())&&this.W.aR(this,false)},N).V=null,N.Lo=function(b,y,x){for(x=61;x!=4;)x==62?(this.V?I(0,37,y,this.V)||this.V.push(y):this.V=[y],this.W.Lo(y,this,true),x=4):x==26?x=this.V.length==0?98:38:x==38?(this.W.Lo(y,this,false),x=4):x==23?x=y&&this.V&&yL(4,5,1,y,this.V)?26:4:x==93?x=y?62:4:x==61?x=b?93:23:x==98&&(this.V=null,x=38)},N.T=function(b){for(b=45;b!=70;)b==19?(delete this.W,this.V=null,b=70):b==45?(iX.J.T.call(this),b=30):b==30?b=this.Pe?39:19:b==39&&(this.Pe.dispose(),delete this.Pe,b=19)},N).Bh=true,N.l$=255,N.O=0,N).isVisible=function(){return this.Bh},N.isEnabled=function(){return!(this.O&1)},N.isActive=function(){return!!(this.O&4)},N).setActive=function(b){mM(74,4,4,b,this)&&this.P(b,4)},N.getState=function(){return this.O},N).P=function(b,y,x,E,h,n){for(n=21;n!=65;)n==21?n=x||y!=1?12:94:n==39?n=h&&typeof h.isEnabled=="function"&&!h.isEnabled()||!mM(72,4,1,!E,this)?65:50:n==77?(this.setActive(false),mM(66,4,2,false,this)&&this.P(false,2),n=20):n==94?(E=!b,h=this.getParent(),n=39):n==10?(this.W.P(y,this,b),this.O=b?this.O|y:this.O&~y,n=65):n==50?n=E?20:77:n==12?n=Bg(2,6,this,y)&&b!=!!(this.O&y)?10:65:n==20&&(this.isVisible()&&this.W.aR(this,E),this.P(!E,1,true),n=65)},"function"))throw Error("Invalid component class "+iX);if(typeof Vm!=="function")throw Error("Invalid renderer class "+Vm);var TE=vg(15,iX),no=((O(2,72,vv,(((O(2,(wS(17,(Un[TE]=Vm,function(){return new iX(null)}),"goog-control"),73),sw,Hv),Bg(sw,52),sw.prototype).P=function(b,y,x,E,h){for(h=53;h!=6;)h==34?(E.disabled=x,h=6):h==53?(sw.J.P.call(this,b,y,x),E=y.G(),h=2):h==2&&(h=E&&b==1?34:6)},sw.prototype.aR=function(){},sw.prototype).SS=function(){},iX)),vv.prototype.T=function(){delete (delete (vv.J.T.call(this),this).hZ,this).wV},wS)(21,function(){return new vv(null)},"goog-button"),c.requestIdleCallback)?function(b){requestIdleCallback(function(){b()},{timeout:4})}:c.setImmediate?function(b){setImmediate(b)}:function(b){setTimeout(b,0)},Ko={passive:true,capture:true},Yj=String.fromCharCode(105,110,116,101,103,67,104,101,99,107,66,121,112,97,115,115),hM=(Q.prototype.En=void 0,(Q.prototype.IT=void 0,Q).prototype.LV=false,[]),GE=(Q.prototype.mo="toString",[]),Zh=[],Rp=[],w6=[],LF={},po=[],D8=[],kj=[],eY=((((AP,function(){})(Mz),function(){})(XJ),function(){})(uI),Ix,sn,LF).constructor,F4=(N=Q.prototype,void 0),ox=((N.Nc=(N.gV=function(b,y,x,E,h,n,k,U,l){return wS.call(this,15,b,y,x,E,h,n,k,U,l)},N.aT=(N.fV=function(){return mM.call(this,3)},N.Z=(window.performance||{}).now?function(){return this.ew+window.performance.now()}:function(){return+new Date},N.tZ=function(){return qu.call(this,5,79,21)},function(b,y,x,E){return wS.call(this,3,b,y,x,E)}),Q.prototype.i="create",function(b,y,x,E,h,n){return uX.call(this,x,b,22,y,E,h,n)}),N.yg=0,N.pV=function(b,y,x,E,h,n,k,U){return wS.call(this,72,b,y,x,E,h,n,k,U)},N=Q.prototype,N).g=function(b,y){return b=(y=(F4=function(){return y==b?83:62},{}),{}),function(x,E,h,n,k,U,l,L,G,S,M,e,t,J,g,V,B,X,v,m,F,p,u,d,w,R,Z,G8,jY,VL,C,W,x6,q,H,Pg,P){for(VL=(q=80,H=undefined,P=75,false);;)try{if(q==65)break;else if(q==94)q=G==Zh?63:55;else if(q==87)S=Z.value,q=32;else if(q==97)t=x[1],q=62;else if(q==69)P=0,G=x[0],q=99;else if(q==63)x[1].push(a(this,136).length,a(this,365)[0],a(this,182).length,a(this,177).length,a(this,439).length,a(this,93).length,a(this,87).length,a(this,417).length),r(this,278,x[2]),this.R[431]&&Pv(2048,a(this,431),this,104,8001),q=54;else if(q==90)P=74,E=a(this,341),E.length>0&&f(T(2,E.length).concat(E),177,this,15),f(T(1,this.X+1>>1),177,this,104),f(T(1,this[po].length),177,this),u=this.kf?a(this,87):a(this,182),u.length>0&&f(T(2,u.length).concat(u),136,this,127),jY=a(this,136),jY.length>4&&f(T(2,jY.length).concat(jY),177,this,126),g=0,g+=a(this,360)&2047,g-=(a(this,177).length|0)+5,e=a(this,439),e.length>4&&(g-=(U=e.length,2*(U|3)- -1+(~U^3))),g>0&&f(T(2,g).concat(Mz(g)),177,this,10),e.length>4&&f(T(2,e.length).concat(e),177,this,153),q=37;else if(q==42)m++,q=2;else if(q==43)q=G==Rp?25:7;else if(q==49)P=0,V=Mz(2).concat(a(this,177)),V[1]=V[0]^3,V[3]=V[1]^G8[0],V[4]=V[1]^G8[1],X=this.Hh(V),q=73;else if(q==2)q=m<V.length?4:31;else if(q==68)w.length=0,q=54;else if(q==31)F=X,a(this,136).length=l.shift(),a(this,365)[0]=l.shift(),a(this,182).length=l.shift(),a(this,177).length=l.shift(),a(this,439).length=l.shift(),a(this,93).length=l.shift(),a(this,87).length=l.shift(),a(this,417).length=l.shift(),C=F,H=59,q=54;else if(q==36)q=G==hM?19:43;else if(q==14)Z=L.next(),q=27;else if(q==25)C=Pv(2048,x[1],this,104,8001),H=77,q=54;else if(q==20)M[k++]=-~(R&255)+(R&-256)+(~R|255),R>>=8,q=8;else{if(q==59)return C;if(q==47)q=27;else if(q==50)this.Jt=M,this.s=this.Jt.length<<3,r(this,470,[0,0,0]),q=76;else if(q==73)q=X?21:18;else if(q==23)q=J<p.length?9:50;else if(q==37)P=0,this.o=d,q=58;else if(q==57)J++,q=23;else if(q==54)P=75,y=n,q=82;else if(q==4)h=V[m][this.mo](16),h.length==1&&(h="0"+h),X+=h,q=42;else if(q==74){if(B=(w=a(this,23),typeof Symbol!="undefined"&&Symbol.iterator&&w[Symbol.iterator]))v=B.call(w);else if(typeof w.length=="number")v={next:Lo(94,w,0,10)};else throw Error(String(w)+" is not an iterable or ArrayLike");q=(Z=(L=v,L.next()),47)}else if(q==7)q=G==GE?74:54;else if(q==86)q=2;else if(q==93)P=0,Sj(this,17,x6,0),H=65,q=54;else{if(q==77)return C;if(q==9)R=p.charCodeAt(J),q=78;else if(q==78)q=R>255?20:8;else if(q==76)P=0,tP(2048,this,8001,260),q=54;else if(q==16)l=x[2],G8=T(2,(a(this,177).length|0)+2),d=this.o,this.o=this,q=90;else if(q==80)n=y,y=b,q=69;else if(q==21)X="!"+X,q=31;else if(q==8)M[k++]=R,q=57;else if(q==19)Pv(2048,x[1],this,104,x[2]),q=54;else if(q==55)q=G==po?16:36;else if(q==58)q=H!==undefined?54:49;else if(q==82)H!==undefined?(q=H,H=undefined):q=65;else if(q==62)P=4,p=atob(t),k=0,M=[],J=0,q=79;else if(q==18)X="",m=0,q=86;else if(q==27)q=Z.done?68:87;else if(q==99)q=G==D8?97:94;else if(q==32)P=94,S(),q=14;else if(q==79)q=23;else if(q==34)P=0,q=14;else if(q==17)throw Pg;}}}catch(op){if(P==(Pg=op,75))throw op;P==94?(W=op,q=34):P==4?(x6=op,q=93):P==0?(H=17,q=54):P==74&&(H=17,q=37)}}}(),/./);N.jw=(N.Un=(N.Hh=function(b,y,x,E,h){return Bg.call(this,b,24,y,x,E,h)},0),function(){return Ip.call(this,34,12)}),N.CV=(N.po=function(){return nF.call(this,68,32)},0);var Rx,Nz=(Q.prototype[w6]=[0,0,1,1,0,1,1],D8.pop.bind(Q.prototype[Zh])),KF=function(b,y){return(y=zE(90,57,3,17,null,"error","bg"))&&b.eval(y.createScript("1"))===1?function(x){return y.createScript(x)}:function(x){return""+x}}(((Rx=X4(16,{get:Nz},5,(ox[Q.prototype.mo]=Nz,Q).prototype.i),Q).prototype.On=void 0,c));return(function(b){return Q.prototype.On=b,Bv});}).call(this);'].join('\n')))(q)(b.substr(0,x),l,U,g,e,J,h),m[0]),m[1]);break}else y==44?y=n?90:63:y==63?(M=a(15,l,V),S=M[1],t=M[0],y=26):y==92?(C=17,V="FNL"+Y,y=63):y==12&&(V="FNL"+q,y=44)}catch(F){if(C==17)throw F;C==3&&(Y=F,y=92)}}),function(n){S&&S(n)})]};}).call(this);</script><div id="program" program-data="NIpYjexzA0oNep88D2kHgk34CCKXNXrOkrY3iZr/TH3dlGsLeXocbvgGc6RtItm1ywWD469rjt2sBOJjMr+pG5QEPt4XGNTDz1BAFVBClFI17QAUferEIZIdtC7LSG/ygEttvoxAkGyFekvFzpH6yLqZ7Hu69n54XEeQVz59f9g+YiF7M0c7Mrtd2MXfUGxBUNeN9o6h37/Qx7+ZcYOlgYzdHyzQdEV9iMK2scOyexyEpgko2ZjAi5AF2uN5htRFnDyR82NtMd+E5WDYZ9m+rhC1EBh3tUJLLhmoXMUFlOXNWcOt3FeTCMpgR442h1RGykPalnltpVvggp8In7SreSDbYT+7uAHIHHTE0cN8LtrnP6lZjyzD0Kpd9e/bWSmPbYMtleIwgfJAMbOHSeq9J9HgJV37rMWb+Geet1k9YS1ummUvzDGGXz8okDYb30nvVaLADX17iug72xl4yx11+rEt/1Udo3Ub4jyJORRp5MBO4t84c48ya51DKM1/Gy3IjqLkILDPqs9PrF+CsaO0FkpkJZIuG5ep6+HcGzPSvCbDL9BkdMR8GE0QXFLfOmJHUYP3oyWjO1/G+rPuaYiIFEgaSsuO0iUW+IjQ/L2YL8tAMGuefKzNCEN2dP3y7bNoyyCyWSI2+P2yScSHq/zVRZmMGcWxlAPKt2zrQ1y8634KigQHVfuT8IVFRRfzaowni9FpnnW+DR3VSHk3LMEgawRkeKwKTohpVC4MsQP7iFbb9hq3aYfha+JmTnmxHSprpV0/rzxFTIbMw+0Mot4uMReqergI3SnWUidCcOdOtN1Qwg2nAnq1ccnvMgLBkmGyruUZoII2NJckZdjXd08TySbuS4olLkTKVQcSqT1jU82GUkz+gykm9VRi6PzMllTSAlJRPkeDOiaRb6khC1h1drpyal5ZDLqVhtionSpG39qOrqi0WXJ5YnRaMFIL/Dar38R0ZasVK6tZn5qQtcRcCjFf1vfM0bTXFPCReMrvMfZXEmTMlt/vSJyfQai3rEjGdhs0YpSXeBy0++7LHUmE9VONJd3EX2ouKas2H+FI/l071oiiXFMa5oWfDXigYB0DdXpm2IhEdThWLwBDmOlNZXY1BD+tXNPfdAwy+/8wSy2yi/N2ZjIPSu0XFGHYD6yKsV/ygfcdm9hx2KZOLRjs5AWNdv65qv0luid4wSfQ8aYsTI2462HES1LgCY7ozrgPqZ7NJPk4ITJF7whZsX5OdzYi60mdIPTzdvVFP+Ge+2l1IFptV6bntEuWh6qmdnYB30Kkpr7yi1dwRouMVhyU3AjEN6nQlw6LHJLA1lCRsMY8zwuv4Bq9dDdyrpTrnjred+yFI3fjMVC6DtMiUxVkHgRr8FpRcCxZ207IRKB0odiVfkP2nR5FdaKR0qKrCZe3jdIY4tAEViao/5QQtupFOlK90h8zeU1nBBhXbPk0XmpXKC3II/MAnxcl3ENGkj+fEYQCMXo48DEWE6hFoKEuf/3Zigqf+D5/4uMeIEeq+xy4AK1qWzcIfwHBTbb8pNZpik+XdHUqeknzUlKYIVHjopeqvT5X608h+MwIWSEWMrOzTVLkZeg/PlHqGCdTv75o4Q3GkAalUaUvn/AzDP0xPTzyzh4dkYlAgooncxYH2IS8WpbR50peckFwe8Vc1C2UygMeCTrCg7waPrYL72TlnEFUbF/97shgKsMHvBgVnx8lm60NnIEqVWGNJVfL+Qo/tIEe9Xb7PXQKufcqS9gceJsIhOedPLpZJOuq5IABrJPs/0OuS2BBs5houNRBwLeog7hwAn70A+GAsl8SUi2IVtq7eFgGV91yJtuUgqDUEEiQI1isVw6jYLoJukAuIn2FGSuBmojGX1zMihlpde5fX4XNjg/t6M2bvp7mhyZo7pMhuue1EIvU4xNFaGCeslGGnGWSMBGoog9MyLwyXamlsmoF6/JVUApA4/7WFK/W6I8AKTc/UJMDO3a8DRBT0D7D2QL1zdBYf22ZrrM2dCwu7Stl1qwkrJyhgXcC9xAaJ/SbYbnE0Jqi2kA0ZrxNiD6kaWIuqx/+tZyD6JpKqEKPldEqY1CZEzhLxORYLyhytNoCU5FAkodmhhsy20JjhMhkuInxQfeTu1tdJivkZHVPD06qXOCROVO+JN1y55DS1NXcIeZo22cvsKUL3IMwj7CCO4NCtVEkSLkUe/KoWr/Pe4qQ48nmiGma1FBqye64cbleemXw1PNud/0KBfN6O/t8fRCOonLsm7RrVr+f8SyMX1xAmp6n8n4mrqe7O4NcbNi5Pli9f1QSahZefdMEJzhStI92m8FlkhMrKmVCZtJRd54j401KgfmC4A8+9ri61wS2fI5DUnZUjbemqYLTNZLIYsz/q3hxmCHlL8+N5vIvYoFX0fbKgMjMvAXharZ97k/pQRJL0UWHIXOHVcfvjYQ/VoOs1R94S9sOPx6GnK9v3wTy4UPeXoR/y/5tQx5I21ydJRu8uiNxPlnx9LQkqZZLsPulofQatN0WHbeaSNytimsfuB28I5skLJbju00SARSKRXG0MRI/HgErAh6y4DBXZXR1ZGjwE+yht9ZGm+yeMXlaOGShAQE8ZVqDOckdrnkoouss2/1MwYGy/Mnp9ycPtrB9sWUAmzhjKIt7wSPlVMqhuF68DHARS0gLhQ9uyQnpBVZkm/h6zgk9WdW4xKhknCpMe3/aOvvut2OABB2yAwvgcuwibMN/roUMx8ujQ+1+uu0PqmB4kA8MKJQgZ/x3Aah1OIlAtrx4VCHyuzAw1bw+yl/g46ieTLUmZAmh74uNrvB69AqOczn5g2CenTaZpCv53BOnjMfRn9IjXF3wUW6KAny4Xbi6CgmCfnu7UXqS2N4ieZWjyACsvqUbzJmvryt6hnfJ8Qddapi5GSaZAtUVgmaPq76m+xiagfOoib8jIxs6sGnJiEJv5/2zlSosI8W7mOvL/D9TpeUsW1NSmQfoOn+PgSo9RThRtjcsKNZG7jcscSXNUxVPLBrXj7qt1ND+IXrpKpKouITP7lDBp41ntAfVw71PmQXvM5nY0l3GeDBKRe/h+ItC1OfRWbaq7bGbNVVVEiSeXMRlinpVxaGeD1B5y9i6yA/BdQtU7lrsOU2023i6AJjmrUW6WEhkr0AB3az9Ywc6qWZYD56DRXdHqiJwOLqX/T4Q4Wfdpk59MuR5c6lAkT06GEO0datiVuuVG1euFVfMLhSrgWvOCxqVodpKnbREIOdsfhImSbxYypT0oI1XDN3WcFWLnkCvwo3zEjHoSWgUMDTRYv5DBgBwGGPSFsgfsVqheR2eLVAHCbeu+ZSpZWjns468JYcAPhWKz0YdAxsxOtq909Wl0nRQX7Jjqcle0XP0MuClN1gaQmF+sA0nOl9ti2zDrrEym0iCbxqNBf/Yke/kMWMXAtzrgFQnpDLR6ZwXHveSFzV1yBUKp+J030Odyt8xtzDgSQ3Lfw2EjWf8vF5JPczwwJxOylhRfjcxJQ0O3QPvArvxF2Sq02gaJZ9nmNHsMlZ8Z0hZCSik8fyZm9DnvhgsW8ioxvR7Pu684q7GUl8d6RgY/tkUZUmo/Uvl8KNixu6nry8ew1HnKJA7kshYwmOpHzwavB6WPxxanfswe6Xghl8lrlzG+WNbLMEl9aZZayqGZuPzj63v6BmjZGFJ+GevvvVI9MwPm3dYxokjDw0A25dNznRdJ8vPxCb2BK0CqBC1zEc+GmF8HLP2dYFiWjX0MaPHoJIt58gSckE5cz8bOGE2Dk5ER8K2NIqGwkjOjOs0m2vN+lnRq3mg2GNwxBphPac8EL7zRw1lWvkI6WrOnjOV1RbrvtTpZXbOKpHZTRvLlVgI9vvahieZW3oU9gOFT5+KJEXy122v1HuqTewJyCvkBd4FS7+Y0rb9xI9bCgxywWirH43sVRVKLYIQg2CyJdQvjgI9ME60mT5R5L/wwa+zR44GsvVU1HeijPWbE4OzKbPh+o5jta0x7TWKSth96Zv7/AuaCsy+X2O9jN60lpDVUFewWYmGvmSG5+rZ9gvEfO7ZOsAQFDznPzeKyHRsuUacBdRm/AjHZXBypMWXJ4vjeT9IL83GH70c2R0rCWiDhEK2hoZpaalJrN7fRoO6AvdkFgmbAVecpy1dl9NO2jxoZygRkev/oqhjnaxSLcHxORun8ce7VjpSsuz7UXh87Y57e9MOqyGE+VzWQq/df1JZYDZNgS2Z12AYx1vjh6NCpKyIqUtF0dk/zzsyQlv41qWqaY0weVgvAxXWSMe+2ovnFVMyNnzCkYZ4Oz+fA3VfqenqZk/2uD8atIScBlAzzTVAtotQfs0W3TvWKnVfzUC0DYEXMve0wZp9QtEVP/fb59qQcIUABCv5IFwRJzy19h/dPolcqGcit9M2idYIj4nDmka/3K5sBN4umYFm6limENPxE6CPa+IXXOQNLcIYug5lgOAT9IS3X023fiJqGDNjO5l3vEpl4teGSw7PdFoJ84KjcqhkIKgwuTnD+TkaA32jbRQVw1GfGCfGIJXRBnRAsoWCawiBFD8OFFUmIHFDelI0LchKKNXbNq7SxDtuDZpptibX9Fpux8Mwcvt69ZqKNPQrKq1XhIwpdhad7NmKozVnb8y6L6ooiZlyaJAdZQhA2/8i4QYwyhDCBqHVkwtFBOAUF3WrSWbQI+PR4nARZJDqxhbVtyu1CwQYfYfqSpFmYqgqQ4evMdg7Cc5qSnJMGV6w1T0BrE8IdPdYFqjmAEMXRpW9yHuxcdxOCPdkvcGVXYoul7D5QxxiTFDvlBsh/qhPQc+Jn4IdBJ4jut68g1JnbI4jAMZlHrGiXW1DGvkuCwqLW1adrHG2QtW3XaZfdtT2EMPhr4X9bvjC24o8jS2BotNq0qSe8x+mPMDCJs7NgZVzeGEn95CbSLG+iXTXE0lsDRqEpvYwboHmiP94vL1ZDTsGKrU5QPJOil22Tng/Kom/9AW8ckYTKb1/1TjVx6ZEMTljTGU+5he4XNHLSKE6SGOE4AMYbOKRr4Yy0ejlBnaNwTCHnALIYsisPdRW/f78MigVUtjDrnL2c+97ydrBM3Rz5f6+Fy5a9GyUEuf0tby/1k778odcMkUyH1zrIVZ+JxdIYET2bGCBPj5Y9PRN7/YkCEQEA0JpSHw8AnTCHrrjhY4W5Ot6Fe1MirxjNTALBOWOzE+uoqsqGurlhW7GvTHjwMPLPVg8+Zm/L3Nj/18Usws5ZIR3lqyKof0LUDJkuAKCkd30FbEqycKcyYOCVz6o5KnKi67F73yS1ipn9h7J0P3CYUa5C+5NdVhnzAz32SrB890rVHbQKeUA0H/W/vg5I71xEFgWjCR2zovJKZGzd40kpgtxi4Hm11zlk0gha6MOeoRit+BxSAsd9QCiLkaWjK5TSogy7AO50rGX1/XVipqE5aNnCFbZ0iA8Xjzh0CBagXjR+vc+MDqnhbl6k+IEiDEvohIKT8anAIxhmf+hI45uh+H7fxZRWxv0gF2elDT23tLzcB5M8qw/oqRdqlc7ohwHNVxL554W65/jBWR+eAGppbNeY/NZS3kUaa+D5+KGTakFHFFW9fTjsPon3ec8RcJrG9Z0k/gmiiyabPnWMPvGpDrMzCx+aSIYwVvP7+IFmGiH58SRMMVlEWj/ADbbVWArGOGr43DNgiJ6xw3sVB559XrIZpwhiLs/7tDZZrPGz4HhQyQjV0WKsWCjMAhXdhhBYHvP1vGq9/hOX9kX1nk9kUpiJ5KLY13bTBkXrA8r/APk+iXTJOw+GzAJ0Gl6yzvErxKFOoUR9xeBOnq/gaReGpnISzCp44fDuU4KlgHDQ9qCFTkN4eYTe9gkOkzOjhTdpIhA8IK7G8Yr9n7uNpLRvBn8HO1cVv2mHgPex5ZIQHwK/l+PV3BYhru8R2L4bIdw00XC56qhbYFm6YmBylon+emTIpHcstLkQ0/I/hR8yOlU+qpV3ZmmdWWmRcKgwZJ5O42wJSAbgj/5/bk/+uVxdYfmfVvmNSml7kD7pN0g6MCnkTZ4RCUk0ktO4mwSbgP/HDeJrGmDrjzCBYs7rL2GnE6eJ0O9eQN2lXOkSjggE4eIvvwVmi6FyJbi3H0iZa3zZ58jD3WEjiO92do/GkkzpPCfW8svz4/l0OrI2nHuHTkUb+k9rN3rmNZtj5fY7a24ad+V1179JY6wiOCH7mDXOFllYk0IInZnb9CDwyONOCHtBfxVBCr7Gii6hwSP12rT7JrbENXUGt1a2DolCafXvWAPmPYOd9eSBpmxDuBwEt+1lFa51yD9i+3B4SsNs/nTZZKQ/Y6SGF7L4M8LSFhPQkvksN6jq5m2ja8z/M1t5xP+cNOEsZR9ube3o0U9aQhSQTJqTklt8Ptm7M0nQXt7V6j2eiYKOX4W88B236SaxQ+am6o3HNdtTrzf2ckKCB6Gm7bN3FOYi7sY5KnGohvPFpdG5YMYD8YBgCvszeTrVK82DTuerQw7TjOBDbbwcnIDPy8CZGQH7pgPWpbIFVIOqNVxoPlnW1qvqGmsNxqNgFwicL0GqCC79JCiPSDFL1CkWluQx8bmIzrEVzo+FjeMfln2qXhTQMchRSCmFGeA0Hm8W09GxbDhoYxq5VhBKE/hglWErwL8OQAaSc8ee0y5xSy/Egjp6hZKHUIfGaNyhPyV69UDKieVzDLTJg71vH8WzO1QcTeTVe0APsI+xfZEoN4b4Kq2O8YjgrqtQZDgpTHr0ZoQtE32853L/hVNPMrTSW9f7TGIcR8j1QXX+U7O4s/1YY4Z3yR56ntmtWqvu9gnptRg5cBfbq8BYh/BwOWmNthbi5/os2ZBda6zFkErxaY1xSkJxbgZt7nYP2AqZxDf/YPRmZGVjXaFriC3JtMn8Nq3HR4rqwPgIFFCRqpqM4OrFBPadnz0v83NeQTXdoyNeX30LPDGL3rj/NprRTBl3NAd+aES7Z1xFITFOFCK1+dMIlHogyTiJS+Yvsh3fsnMk7C8Q1q8zxj874DrmmDxZ4ok8dTLnfS4UV10/kM3+ZVIV1oshzp/+8BcYyhpGLw5GT56tDBYkqUnzidQVTjNOHs6cotRvmTiz0N8gUgs2e3OZ7xO0Rrf8xLmZZTkD2qo+b5u/4FPIpB5CoZ8HbdfJkA9qp3qFqJndUzLLtxrar8Ucn3oNyuSg5A/yZLcaj9Pxs9/nUlFWiWu1iu+Vh/mime2+BKzj8BI/qSe9lKFkXm0HuoKF57B0DJdf50EWDcmU3tzZxZ0bkJaeuCCea1c+fYaoGs0xj2+OH50QM9R59n2/mhTpFM4tPQ4ywyQkZgRbIn5q015WrfeXZs9u6jOgv2+Nq98PZO6hMfMVlpPxSAEqPWxmJ8vos/fdcZfp0tPwGF0DE2MKye3fJj9RkWhEyO2k2QZ34GISYsbvhttQJHnuiguinw9hUisIwE2cnWO2GV/rHfIQKtZTVngGOTJeqYh4lOMQNI7n0AKGDTx39WHeGRjLdWMqGlHlVa45uZe8UlbXjx8Eiou4mQ65w/i88WmjtNFaOWRetnhwHktgd4McxMKi9Kb2qCNoAAvburxQfwDj754LrD2yg1Z0n9+qBfTrLYKuL4ZEVuh+GYeg8AmogPqKmTfGI/5HN+TRw/JVXxrUYUs3073qzKbfKT8TADwqIfj0alPW2ucYtwKof0P6mVXthJQi6WOg1AP4emDD7Fu47D/BRcgUUZH6OUVlimfd0ZBWhJN3fAgMcqKRojex2srgkKfZOA3TppvnLNIuLRrJCQBO8B/Qph8/3SvmV0SJd9M8XGR0o9HPLmDOamLLPBJgDGm0dL7FNoAydM9IX8czDZNNAlD8oPDJ2u/sjRxW8HAormR/VpemEX+QADMF0MNuUDPndWPJ9wbdHSZ8XKnGRf7inDbYJFqUNUXjKTp7JyCrtetLL3vIs4zMUF0Vr74VlzU5fmGZNUR406mWWyyqw0mDxqjhRoIvqeKGuTP31UlKuVWYkYMpdpKkzUmziwT6dY4mG4r1Lt7OXXSPs3z7kwkGNWz3NeawnSN/tKe8ZctngyA/jepO320DwEwnAD1JGDREcQdSW5lGZSP9o/GZzbvmNT06VldGO/j7jS0kjpRbvAEJQPvM9ddATrFsXL5TqbCnNQOOxB5hbCZRj6aeYKS57TBUkDxRRBSu4qe7K7S89xWR/qrZDWCXIi9mDg6d0Cx2Bkjrgrev/66TixO8xHhkUflkdhCRK2VjT6oMAcUniI55L0SJwRpaNQELMbZ8jXtGpIdxya+PKR5AcNnzVyPtE1Qp071lP6T5THa5NOaiC3U3EEJcmDjKW1+37qv9wKStuJTXt2PQWqgZFNEPaH82maaTKzo8ydX9+hRYs7glyXcJvmflIo1BjR5SmrhslS9w+9Qr0vbuRN28mpr1DSV4MvQmyrTjO0yQsANvhTlwQvx62xpg9c2IAPMehc/kaLw2kw5rx9zyo8fQKmMCS5Dg9h2b/xN5t8KpqJ9tf/4gVAEbUTFDG9c+/Z6A73FizJaJOWdtpewJLuS1KLtkemXRqNBGazZTdcny22qCzYuGTJx7BWjJEswSDXg8Uds0VxUlGCwaRrK2kZgV4mN9byHMai6H65/feaPFJ+qRzgY5J0sQobYes5mMGjfTDVR95aMZW12oPZMQ9n/YCWP9N+7HQCZOylOfOWmtSqOkHcqeE298ao7H1ge5eWPQNpfAcYLdBLCxZssaaWfjI/MqUPnIn3hHCUCYO07bcFcrJtIx4E/jvpc2i03VxLTIafL+LbmnkK0uo5nkOV1I0ppRdxAJZWrKnUV3XF3OxqA82CGjWdDhqsjtMUl717I3XwbCVa3cxRCVo3XV7+olIfkU/Pz+PhW5u9Mc6yHZkpKRn2g10qfBqyNpQRLhQk9Dyv4h6Q940aj/wneJUtJpStlYNKTr2utpLf/sy4HEO70xs1/JS9krC316VQqq5Ca3PhTr/fK7zJSmwblw5nmYgXisLT97ZIAbVe5kuMYmnseM//lmyYxH1hfZZ3snc8pW4T1XXUHidBVMRzxYJ4ScCPueL9yrfMznodOPFdpYdZwxMUXw4EJnpFWfBvQjehP05X05SBaV11AP/Mx2BWIc4zrsM2Xwpk32D/6650APHVFGjb+D1te/v1unqF5nXPr1xIVzcbfmEwTHAWkwhELfWV23pkoepaeawnJh63tZbTf76v5xGWrunMVgq5Rp5A1jfp2wdo1K70+p4JwO4AFw22oyDtks6F+FlVt/LB+Rp1EjaOcQ0WSEjqN2uBj8j2Z04UtuGO7SrIqBnedieZi9Oo/x1MXxMoNeEy/orkc6Dy1xktDxENJIcTH/D4l8TmgCnHd3JOnSenu4tgWjATy/H7qoocq+b87ZXWu2ywaAy/VYYusmgISRz8aRgLYecUMTys1/iNqYz0f+fP63euUBSyT4pW/CcS8AH+D/+MMclGjsbCwU75EhBqYyKUJkZBM/CNhny8sZRWyJ29rMWZEfBB+4bBvP/Pwu/dP29e05aTM21tcIbN24dW6Jes5S2JSOVkR2KTPSPmcOXir4Rxb4tuwDsuksaHaZsCsgoHl0yTIGm8OD3BUlyQ9JQHzVpQwOVpcJS08kfufwfPOZ7MfaKwj6+uo/gRfvwQ5XEalZ/Bc1TKbVv4xQ/b+niPeRAo//wK7ZOIffTAysV/0dhLDm1lTd/jGsBydA2+ULYjZ45KKvexJtp8P0mUHxErM2CIMXFCvthTxDzcAXO2sG7cyRQaMkU6vnmgc074zT5xypD39+SzpA2jF/V2cHtXLgWdrsKolJINb+XXIEU8VR5MtkKd0HnWQWvf31c9bmScmnou9kg2K+wpGL+C85be4huqY8UNSpxXDh+1V+8w0AgawXQCS3sIBF2e2wIZ7Bn6kc9NAEOw2cYPceJ7A/nv6TOTAMzy4y0ZytGHDoyncOQrpc79+vSnhfDzWCDU0Dc9sups0kG5WwQ9rDkHZLD28Z0rdtnfJJrgAKslR28m94HLLwIAHqrJV4q8CDCV2bYS4LjUxBEjWXQFA054eTD7SwPTsEnkCnvUctqITviYNHqwys+bxj/mYJcX6W/as3zKLoM87nY1F0Vr0jg7NF+q2+Y+xS1dhgZmhlq6aHMrfQQKIjF6BoJjhMZrYHB30+oLeZ6nRywIYTgApY8YndIreMozCBg+bzWslVfURS+bi0JEoktU7bTkAJJL1n5i22xHFRpn1wktaCl1v07SGVN0gsjO5uL8mx+UunAAf+YGlpzKeW5ZTAMsxpucTfrCH87sfGNcVHffHIp8dutZhtCpuqBgWawfq4utlzQaZIRvbsmlH7SB85vMOKAv70ptdYgKmxnhJOGrhmJPbRPiCSubs8jOx3A7S4hVc0Q9YoGh3Pk7JIFjnRdRWCy9kym79n58vXzanmActVPVMCdBaMY7rK6coNulYCslvQ1/vc2dBUKnd7ZkryeCohXhrL+Dk2O6ZjPyNqtzUJeY9eZEjBEZWcjP4qyt3IVud2lpE7BeUFLWi1ZinVjxqp03zp1FY4ZDQS213rznnuV5dSlqLcWdlvN0do6BKUzQrUk5r9nNTyDWT5nm4Ch2Xy0xIyWcLN4sZvv2mBcKqvjuDnCA27tSgtvgYI4u5H9xYV53NkxKzBb9alUnJIqQpJh37a13DEHxsRn3jnGfKhq7sjzcJ07zbxuc7RkZ2++CXhdBq0AU07C2BURNPt7LlWoKXmltnEeuzaIPTDIsZ9rdzLZOyctaammn+mvKjUW4z85ZA2Neu4O/XcZJEcZYGHDSd4nOzV7OGRqwn57ozDU2vtiwl4KRxIysuJaoqomh8JdNFUBDSW2sdYQWObcVIj0mcZsd2SQ9meEwEu/r0LI7MZ7pSj0hnOZ5lcncUTbyT+wzw3ptzJVSBHCy6ezfJL3OIIj8sPU/L5mX8hzsNZZ3qH4Bh5Jpo7ACgwij9RoSUQSq6su2LwjJklyDQ4zZUuHtgjVDNig/17nZMLLrqkh2Y2DMLjU8ySsJW4qYH+9822OW6VMNiaLST+YgsPy4da6GktP1A/x1PR1NGJZvx8NDMuPE/DBRofpPLs+JRceIkENWnCVRtDv+T0eu69Ww7/s+DsXWJjzWdu8qWu63Ip3RxCycpYX8hBL2/xZeFBkhqv7pOLrBI9kd0QLSjOAY1E2rOo+J5275fLPBwiP7EP1Y86pdKcxvN0BrLECRWmbuoYNR+ht2JFBpptD29ZaookGQMDbniwZuXqz3TFtVYeE+3FeIF4AbvKatnUgckROH3RsYKBqLWY2dqcenblbUFHT4ElncmV70bcQLmbxWuBGv0591FeGpuEGVwCODOaZhqpLWTm8Oot3squpMO7aTO3Qlsytyb6A5rn+jMACMl+ieMB2rrgLndOHVkpm7DHDkJ2v+M4tsm5xkS896PKcx5Qo0VcOQ2JesQhrjtksl9SS1AGf+ZnNMrkKsa1zmgq11ZLY2XzOU6g+gQT9ero5ygks4/6oXNm2eNdfcluFk66ccByyn3kUSGiVtCJxjhJ4R24cUZu8JLMuUDg9SQD/jYpRcPK8zC506PuhT02x1Ga0ACp6drjGR9g4hWcpQod953dG+oHKv8DeUn5wzjU+1yp7Y/iwZBfwAPpU/YRuSpxaY3WKxjlKHBstz83mPQs0Ly5wfkO0egWpDWDLQuEjRnDc//xCa+m86RZeMGJRcgf3ptuCo9wRa2xJU7t9lw0BwgmBl+Vgv4PT2T7SVscQ/0D1RPvht/8IV7APas+3Pj8rwKKDwlyiIxZ7vxr+3cquvIn6UDqXG/li9y0EeMAyooeKR8TSD07ymaJ8M8cWEmWY7tegFrRWzJX51yElwqLlndvJeYQig2T0it0O2A3bIRV1oSXswsysy0YJumoZivIyX8QbYG8SjlY+WhQUXIzG4WUQ5q+P8V6fvx1Hd37Vuf1mYGjEo3264DCOJCaWIDchYvA64clZ2Yhfq0qBNsqPXd+YH1wiXTxi54X+0I2/n+vhWPNqomDbpW9iznQsmTbEVZRGtU+KlRXz5leQy9Jn5p3nM2dEvq0pknkh5kmLf4XsfHjN16HWUz/8v5NccDY79q9YaZCEfmfOSCR9U3HNzekLpLX+nhD0VemNA5W/cU0AR6yB46s6XSba5YmPZqty9KlmPU/vgegsPqgo4LiuXb5XMhaJOVRnWD7ZQLS516gnHZ6uHON7VES6mUR/nzMGrq/WrC/1PC2V4sJm5q3fTEivzocpBc19yRfC4jreUm+2TwubIjHKEK4cQBDq7xrTcoUs7Mex8Of+dKE7BQy0+Db0W8k1gDv/QC4D8Tl9BbdsEiOqXblQZcbpn1iQbrOlISQPbsq6o7uEtel+rsDy4IFIsQPTDWLeBdPqXKe6zVroLrqH8BMppte8dKDtRtpVIi8XUNFIwRwmVule00U5xdfZr870J2Bc2IE1gMSKs3UCR55QwXXWDe2BPvhzbV/MhiURCks9X3hf8JXhIqw1L1Sec51x9za3PDidJPkpvLYtX/eUUwmU+OsL/CZT2PEpopb3Wf7feXmRhvcZqE0uhvtprwbz9aDuVmb8I/nd5aW6KcGpsU/6Zi+o0Hpl8uVMZOmDzyX/Y636O2+CLqg/uNFGUDFpjoQ7wx39EEWybsWDT2e6uKsNJOgp5flbSKj+qAhlv/K+lJfqY2wguPaYHvoMFx7aiCNz6CGfN6Qv3uto4OM6vst6q76p8DgOg5JI4RMSpTuTj3s/nnxWrhl/X+Ni8Jwj1TuVdVtg0FRAVX5qXwbglXAPyREDbS2I4hSbD78spIuV7oGXYDdOl8NOpxenAjOBihePiqU3Ihlz72uEH4HlTUd8DzOMvCFK5u3GSxwYiOa0VoMORyuz58ujXCLuT8VO8hcHZ8K8coTSmfZPokWRrbQekELro9K0itMpFilfw0AW+k44P9C52GRatCnjXxPEJbePgP08oCFVwSxM69cVub7FcrB7a0zKtEqvDKVjZmZ6e5S2nFJ/6D5p9sBWphVmStYhPXvl1W+n24KvpzrX667fpYaTeBXc7mTwTkTRVrymywXtYWVJ0q5C3O+l0KVOjaejqGrgIlHjs58U2BsTTAzmsQx/661Rxac4UMSFclzkm+EEuwKU25zrnL28mKw3Z4a65uziHBEadIw1a0lJfwBy0AQUgk5OzM2+8gpENnJNKrAhR0SOWG/KKl1LOBPw815cEm8sFaJrD1aW6/pjNslpPcT0CYMkkV+asvLqAUnnrhNpsSpSNXiwYII8RPdHZQ/vB6zGhc4L2arwfxm8jLPn857iF2hMoObVhSZZuWabj0dzaTUtGGCh8JpHs7rLuQQBdIt0t8tKj4PO3sz0mJ6mRJ7HloQPOghv12VsguoYqVgDqT0BH0CsMKTWiXlwNbFfIXXZEydxkD4yQDTDM4uFiHLG14R/ZZdGfPy9gp6TD2Qk3+nWf4T2esWM2QKNVwFlHlm8PWIxFcJIUN/Vm0VkuGVBhflDz0hzDb9C11xkkyklv4qfDSSl2AEd+RJYcZ9GDG5c7r8KMOtEw4furYLqPj9NaapdcVTJI6rypknoAbGp2qUYBUWLqkBM2Az3Ne0uh7wFKHJHT3oNWODJeQP1a5F0p8LGNlL6dhFtZFXc7DAM5twxL9amU72iUVBzHQiZp0ipJY+kWoH1z4O1qnatDRYkTHMDMnn8iSqwGCIdrRJTpqUm5A0lUs0Oc03I2olEVS28xb9IBXazR8NZ4scIvb+jXOj7o5qoa5LP+QqGNxzoboJm/a9s1vLFLoqVAbi0HZa7nFgRD0dtWAo2itMHcm5oyJPdkHjWXRcOoWrbif8nDCiVFZqq4CrtL9YxiNwRzFJGzobMMqif9wx46/5nto46n+wI7ii1ClYJJm55AyFn9YxYnpYd2Wk6JwlwgosUf7oVzSgPwV7ql7IlSjqJkX1WDQ9mTBH+tj5EGNExFvyD3tuFgm7bDdG2ODtZ3AOzTPWgqz/nb7lZy9rKKxweiVIUHDOexjoFpaGr/45RiV+nYyy77/kUThDQ0byt3vN1lyv8ZV7VQZl4kRqNywHnCqCpbLNVLwfp6laMgmuP2iQjbmNc9u+ZZ0ioF2fWFK8qAPo5U4MiXV7kub6tesmJO17zd3Yr3LcOh0Gcz1O4qlBRPg3os/mGHnVcq5+FNP3Uc9JDxTjqdny+4GAjHadoDlv2mEUkY3CvQyDQMSFjlOuNUz+tL9ecfiSuW3JoopgbNZ4XNHNfyj8YC/3Fbspi83Z1tQfiyCJJlAFGB2x2Bt//aRIwpQx8UEPio4Md6vWLd1MIk9VzlIuLXMnZq28p8B1l0c0fMJrTAK6/kSNiwsI8lSwkYeugv6Hk/IY9JIV0EcJ+QC6iz/zENmXGpawtmLXpNOlelRoQq64Q7XK9F5fXO8zeulLY2cfNjepplhViBlpE0O3taJjPkWAeR7HIUjEQIg6E7ZQvMv+CssHoCu2lnMWZVkI5nTDU/nXi85bvIXJB5aDHBMU2qw1brvrz37QuvjV9ozCyDj/yMxwKc20IaPB7gMEWvdshpXaERy1TuVXPy+kh5MvtJJzQLVKxmdHBp/RH9UyUDQqNtqLo1ry6/zFA6F7bUiLd7QBEYPkGHaYzjAHAsyor8y1s9G1WwPMw9rjL3eyw3pTl1vCNK/r3ah3ebT3SlMufYapeptWJfXzuxoFLCcGLfyadtFWMFS0QtiPw7l7l/i/dGXNAwMUMmoPmaG1ZKrmCOxhf0Ew/5sRikeaYyEZq6KJ4ke6F8PNnP9jMhz+2W+4A1zIP4Gb1H6WoKunp9Fhdd5VBwP/yUMKQjTa8zcWh/HCb66HS/SOkouFJ+hcwg1bf5TTGph9IyoJS+LB8ykVlZ443DsPX4+aXUdrTTPyMh0/SI74d4wS69a5IG972HFLmzMW3UGlcsT5XQ9FbIr082UNbim5365kAKIme5H+Z7dBbvXjYcdTQfZpI/9FfiH+1Daelw9QdNyK7TAWZ8Y5BseVtP4UHUK0M7O2ay4/17xj1Y12cNPkB8m8TKF5tEsXHnsel02Hz7l/yFsoual3Q7H1ofzrfgetGsP7BMUrCplHU+wWXZO1j/5fuUGF1X2PiO8ZUPA8UnM6KYZzgqzv3tSA6qzZBArNv/gbpDZoSDjFppKWGh3RJigq0Wkc2bx2EfDMrjOxbYdDUpm9rK35q6yfFqFpJjf4YWQOIiXhH1nIK7JvPS3W8DrMzmtLL89nlrZoz/ROozcA2B0t+TH1l0owFMHkL4ZSv5288FcyijXQhOcFxYeYQLn7yujSCDAfdaMJgcfBPxWExJV2b3Rn0I9qpBop7dlpIYw4pNe+lctGQssgu68pmR41xq8QmYyWzPRaHvwx/7nX909AZtoGJ7i2rcQU1BkzP4CqLN21uByjVaVn/tVceJFpbBov33/cCdsFgsDa4uWLXBaVQPRuQp4s9nLP9vNPEunzsyhrhGsxHyCMd0pJBd3035g8+iC4Rzag691qC9j0N/UpBj58mRANqB1KegUhCA23582G+aPeIw5i4xgkdFGju14/SCjt57+b8glqcExIdTuEycBBz9/JBWIuvRyNLfIuH0X4xN4q5uw4rn4wGrVqAVTsDxTgCVi/IAWT6zfp2DUT9lyxmnfFlgktqVnxeHd2LPk2W4223iSqHjQ9kFI9k64kj9sGPDIi5drevB6K9FowOcbRgkFJcfB0PaY+wuw7Ees6/WNvx3A9IF+91HdsEihs6hPUUvm5qO8gTUNERNMhpUaDZQmYt3lnMcGwRx8CUgZHk0uOmL7zG0/9MygLlyEtozqrH/STAoAo4RRqOzUvnvSv7Yt2uY6miahLBgkhSfWEO3WFz71hqZC+VgqdilRGhUl/ARd3UFR4WOYDpJ/MUChh9CEffbrqCo5wJPhzqV9ClacJxhfcrxm3x57Y8X4yz03i/j0I9E1GPmqwt+4r9oMagQ6Ac/L7QnrmP9sLoGMZJvbo+8TcfkrEOJYhAaeBWu164/07TEMfZ96PfNB2jByEdyNjulXhkKY/GPp0fryuvZhYZ0IpTkNeMSkhl0gDzRc6p6ORFJzDUEYTKT4Rr0BXJJpewrSJQ7lqwQ8RrrDYB2az/Vb9DxY4j0wy+B2SL8DP9ScK8w3yTGaVJkXmjuuYHu92hwgKXhWAY83HI3Ue+gMPlHmisLNPjkT5PN4G5YoLDe/V+o2WS4Z5NWtkeWKwO4Y5lnCRDRb4rx6roHR9W6sKDi2hIeN/xMUJnFUDAqFWuQlEimi/S/uv4X4tUlnwQts1a2d0m/Qckq1pWeeZkyxo0/4JWYgcIWAnos83GaV6rVdsC8bAdyObFPTdkbVVDI2vM6maZwumGvymz0rHc/H5GA0Nre9IUjlqrpoFWuc5Z1JR3c5bIv2mJrhYGtK8i4cM01aXPG7vva1aJhMNVBKu0zezy7TBNrl5N19nQ60Jc2Qt6Ku88ViLk/yoRbduHyDod+jGgOY4QnN2XBI5s8kUYlkn9xea85SGeSUHnMSMiDVo2qsm11AA8q+MX38eA1+0p3qtwMRjsr7j9HjU/6VRt3jwIM2vDrYctV8SXaTzBefsbGalXTIkjsw9fh61DGB1EHJ2XBfTTR8Y8eBM89D1EPlZ6OZd344erwRk7HFKQ/1jmmd6uiZJeyZqQ0QW7FvhGJzkmWDbxNixTY5rDE3B/SdwZFGU9o0K6v+49cc09k5hv4Xh8OuFovUAvYRTFCTYS1ghyN5AxsGQHmQZGg0gOmthgXCNByIGRcecmZV0N2IWrd8k/zySiJjrCrPbjyfZvDR60YnENR3YVlY1QDZrqCdTZ3HHCF8UmVoWoKOyeVO4Tli0dQ9KB2KoK1bSd37zzNctfbVNisLakc1Yd+CkoX8lnN2XnC2uJIsNy/s2TN93/d1IitRz6b60ceho6zSVuaWSSxqzp3uN083cGaJ4V7HBHrj87l9PmKHXP4kErYt2EQiyXCOs/GXpszsycCydMb9pR7afrizjaAZI05Uk3kLBrFtPVwdRWRweuONjCxf7ipGS2F/+du5FG8oTiicuZ9WtzSySVS/AL55UXDB9pHegw3E0NA16L6en3QzdrNop92HPNSZeIBILv0hyQWZZeuG/A9/9x6KNw7HUsOSUdcU5xUV9PI6NWnHgDPqk1HO51oXMJJhLoHlNAfq5KoMmyZoi1WaTYYj1NwKmVA/fyP4/x4G7vQsmDubgqYdQQWd3SAyxPzcqC98k/iOftIAGdjXlzqzmQq/0KqO/WSYyeAHtH0LWQVvLgR6kn9/9nWtPU34ij4J+u6gdpGD7Jbx4+zbIrx4iBARIjcS9uxwDrY1P4tmesZLNBAPNJlhCLZPQ9+vyEm0cnx9DJWdj/QTjeSoBdSWaOQFLOFk1sT9YkeU5rrXVztbfQjUnxIlJDhyPGu0IdZa7thRR3jn1KSi48pIDtys65nGBKi46TR9Sgz4+SXDh4LtOkDLZdbGQM4cMMMPfElHVDN4dMpF21QRav7uP2cpnhvp2K+OP3SOtAXCzG1QImpUIDvdfixfNLdhNslQRgybVWXl6JayUpzQIfR7EZnNEV0bXZYStdFIY6E2+PlZLhPhvCrVy7P3MSGvw/yp/YQ6u4Sp5hdv4yErxk7K5Up2B+EgNR6wQaZSkVOKccWNhK/uofCiWLJlXUrYsp2rVbguFTk71rZbhUyRp93btfn+1vVjBfQ5TlH0I1Nk6wamPU0Od8M/8iEkNF7gMkEmJIe/c1Ce/FlXCmV0gD6bsbOcCEgirIsMpuYzRSx+Z2x3AAAH6/5qUSKNMKmPGdb/GTgU1mQVW1JuWEWDzfHbNmlo1rxWEdAQR/6gyVpB7E9svXWtFcB2EneK9ZBjrZwf21L1n4J+8LUSCDhm+UXZmpFsnc/63nckcUct0BjWZbh8mIkitalLJAnt9RerIZqjcWdEjcoxVMZbIAag4X0I+W1TCNp31MfaLkJl1H85p+yDRAP2ko48FdalQgUsbn3rJJz5fgqTZ5lK0eUpopUDnJYhykdoDehqBK4Gycc+KKJL9z6uzkw7En6uo7Kg726co6BfrOd3fwXRHldGZnp36hAcX68wUaObYZDXdWJTUSZjXTLiNxG9VYN+kxnyvYa4/s3CAayojnnyIbju7p1jkxx7PptSkTZ2hIWAsOWYC5L/qcKCb/abvLdw/n20uh6G0V9X6kmRvr3UavVRA1CjqMrMd+OeUOodUEM3wDGIY6n3eaUHLjpUNJSmlMnSqgZW3XwiK9tJXT61QSQICtzoV0lrKrJYe9HR36TPvpc9wU5ziY3MRMMNljyXLnesuQm/uMYxR4kkkoCyBO/W7r5qDOuDwbvSeAZyp6t0U2YxESEOujy4RC4ZaFIfbfnfVtrxkoCAp7W6R6cHKtSpTckiV/3hL6ZiiHmsuh5/53aFZHJk3sYExcKP3fXK0xC07PTBo/FPCwTZ8d3U8P02q7bJaNKIQdGWQFYEr8RE7zTbJhpOj1BnKmFUbfx3XmmepCa/kXUXuxKTTU7MEY+Ccl6hyaGl35ZgEWf1K39OXwrp3pE69cIAC3OHhS9tkSk9YOCSOySfYCz2SKTMgDFBFVWLnzi4eBCh6TFuoc7WfJcoeLJjGT14uza6dkSOrUhaOQYL5AsLC8Z4vtrf4KsoQEC8bhCcWQD2vVdgOJ6NY/hgBQhn4cEzy4t9fq7G7/zPwakU+WKeXBIq73PMl/CmSCSiIGuAQ4lejJPvwPId6ZT+09pioTC/Gwb+807Q2/H4H0cHkz1aH5cYUnv5jjE9KQoUOAhRo51yxssmAb9HJBT3nPSa0lkSRvPcEHGD6ir7CWb/Mngtiy8a6iHbuVng76+VREjBExB76WxkT56tqbppwZHAxmzVlRTFXAComnyJ13UbZ8MYuUj/UNcuBmXVLXGgwNFBApn6YoecGS+bHMCpROXja7B2+SuMZAH+jsuRfmJFwxM97qtrHK1ee/7z5UsTI5noEsNZ6UntR/BVDQaudQPHt9aTMnlFkfMQczhXAueKHL07xoInMUTrTBF/2Mq4sWdD9O4eEQVXq3tufz7sq7QExTbF206CBX+QvSRtbHgWXQ6G07Gh0JswnFzZkj9PA6MhMs9UIA7sLGn31xiMAUbfsWAb84G1QHSJDVgkHiWX2AFalp9L25YuPGlR2SpGrvYtTwl4iBnOxQKB/D6fVr8J2AZU20J5EcvLCmJ7ukMpKcvT5hxJjnllo8/w4cd2PjBpLOXNT78SMjNr8fM8p2nFjLBgUDTGWvvealXGYkndaH7m+HW2N5syJXgrNMXmDwSmfDk0qa6pkFJBvypVmFQc0m/ZOW0CCpSGuQEgUpsP1ozN9fIYIB9J5Q3ShowUZGkrV6NnRL/XiCrGifz4bxkqgdcemhI5L27AP7KdpvLDOJqq/ZK/FBFw3aGx9CVXsmfLysX9a/SS8LLmDC9vcURCH030HDXtVeooxLtUxC73P30D0F2A3nitBTgX6M4/Ioku8psLUDZ+TtcRJixckmioDZX5DAgtjUy8D7ilejhVkQtECFTKx44V0BB0XvKQShaOVJy3gov0wJJNlrUtelrjcxGNhKtDVh8z7pvC3OrJ5XfCmhZrezAJAzx4zQCSapGO3qO1hPPYC2qWwhh4kH9i+1tyTHW/yTW6p3gmmENlP8bIgPUBcSS/6yGFRZggl5jN4X4h4HHb0sXATDNV7OXIxl+YDa8g6XuT9+Q1v3KEN+CxEI4D6rXbGwTc5ik1XFHyCFbo0rR+vPo1IDYi93zXkBB6RUYwgkcX3yY+htIWi+LWpIEkdiMGSDIg5oZDtoBf6lNKATZjXWsXK+ifh+ZEMW7HtQeyTAs5s5E81r5fgC/idgXOV8g9YSF3sgwJyHHtxymZ6gu1OepPqWlDBv8P08+qWvBeNhBFRIA0ZTZmwvFpk71D+RrJHmfDU5CrGYwl5ltDiupunu0hQQbwf/bfug/sS4++g8TaF/xUeRuvd82SRtDH6wnOHR2ESZSHUeAMJTbnHQ7b32QsgNdXnszaV/PwP77BvJO5L+MjewOkThFzVca+JiwemNmvloh5Oqcvk0etzz/dRDojjugP8q+xxTMLQFbBAFth7lUp0GxPJF2r9yLmGhM0mvXAadZDKPEjIkVRaxWXTO0QepgIfAKV7HiX75JFkZaCJ+MB3ViFT7zzC+SRCunwq1plAIpPKVYwO4F5Qo+Bi0PmdyudF2sKmXPqd2+zcUpsJ5Enytpusi/bJ0UzO7bivfi/2b0TUQb15NK7Q9u5sduUqQXJ8PAeWy96m817SiQh87QvvEaPCpZlPECQQWZJ/6+cUlC2NS/rYsevpvP4i16XLHWizZ7gFQzpj5Hg4V6U5TuHlvLV/KCz4kbnJbfj6YMTfpIvxEm6bbBTQJGs/+LRjfr7VA55FBwCMINB8QpIHIqCelRot7TttMogSy7U0B9UdwpzQASF3sgIDIq0qHRsCg4gi8xfUTDShPKK0EoxOe3k4JOy8scmutIB67VJhuvdsHkJ5cp0rFr/wFekYRrAo+DRdrJDvVf21Bq0FWfbRSRP0zuD5CIiH9HXCb0VR5ugmndCf24xnfZwHn9K52dV6hPyswWOuwp9xLi3UnRbvVMsPAyo8mX1oWcunhIZgARXLvqtmDbxUlIBMamzHmVr3f88zY6aQBC3f46f4aTaKfAssMwdgpHM0ClbQta3nURTaVWqC1LwYV7QnUshXGK0dXk97pXYtx+ijikvphqGiz4tVhucTdXAwobJfMPX9PnGW+ybpx8VpP1eU0hnxhVFDVnOx335FfFHqCKih7nclQJeY2i9+8mRrqbwnMIjCab0Hh1rnZ567r0pRu+qiJkMvsgwz2CukASKqhrNqBFTjPu9yfp0H5g70EM1YENLs4Ru+kRqiDBEWS2HEfPCpjP4Kr6CXnk1rGUvOKlYvYDLofzf6MX8PX4vWbuc0XhwLIOC68/a4USO55W2duKNe8rZ+drCHjHgxCmAo9Ap1E2CwsbuF9C1n3mxwF+yElp8JdQAlomH0zX4Nct+rBuUe4QXgA8+z8JmTZnzmd3fM5A3+NfZaItEaeWa98atUnQgzzG6G54NUo/3dXQRSEuvg1+e/B3T80zYjhg1WFZdjnCE2QZrY7Uig6CGwXRtV5xQFa2AeVPQpg9gJmJ89qUmHIrvxk9Qirgc+A9ZzZWGsXnp/OUQUOXnEbcUD7Bw0LsGl7njkh6bklvhdW/6McMDWYcn54gIH1luC0BMkOxlRbqCLB3AjdaitN6QXjrghbrjcQBioDJMOu7jJFmgCUJxfRKbyOc8r6GNi7rwAwWVXoHVChgoBS+DGK+FhsLARp3M5YirFT4xEs6ooscPTWK3FKdoESuXEzTx6nm8SXIavOt054jn/Th2gQQf0ugwcs5Fy6NEbZEcHt/XpCacR3ob5JuFlyLM86Vrr3qcRbBIPk6GOsP6eVB+zFwZyk8yXW/f+UYb88YiUGYOClUEY9BJw/Z+/oVp7hcbR9Gj+Bqw3PFUL+TMQaVnUkMUZu18iWj7HNU0gtcogWJ9u0hCkvenL72rgbMwqH6IxZkvVeSak+wPPpzvTWEtuFwqP1/C0pl2ejF0x0jf9xfBnrcTYvJux1WdmJ54Nzb8GGvsKB4VbYrh49sUcxgR+dGGpaa4tBOCuiHENJFvOzjSnvuggMssiuz5Q4yz4gu58CRVDU9qT4gSLT6C52Iw/RanhmvDMNL2iXnbwMIr+nLbWWvLSev4Yi5LEWlJUtbYSE+20t2vVlMs6uNbGbrk7uaqAI8PpYE58emYhnwcTM6jdc8CTgzeHRbWFb4CDnro/eO3b3r9xoJ8qTMkNYRpG0rezxBDCWIkTylR13XMI+QHVNU6+8hRYoOwPGQcYl3XnMeWeTRYlZ/dYZuml1jF9YesKcdpFwsNj1OU9Kopqrja9qkjBWGC20beteAesvg04H2nNG9hEFg/3nAiFSUMyySnl1naTfiX0Nh8iGkDxXf1fR70NqDajtH7/SSi7mYgXCvA8yUkZYLPH1+6+t204+mZ3KIarZGRgUlgIFoOH6Ew1FlzEzdlh5BW4ILACrw9Gq07574sYWH4Vtj1fYVT2/sD6XVYqEQexsGF28kSalMloj/qLLXe+MexIWc62WliAfGTl9nkAtsXK2Zzq+QpEe9//k5itxW/7/V39lm1CySBkJPSGwUOb8q82K+Lc+nIh3+n+5Cu2enDirgr7i0Dl0zHKeU4iJchywpHJjc+OLMQodpMReuankOHWbq2M9aHdw7Gr8uL63inxNn9EROXq83pCWt5sKyq9n5AkUDlwr4PnfhyAWBWVypn8yKcLaqZ4J4OmwrxzyWtn4uzpLc60inLM7uBpmldyBx9i4f+VNW6+LfIn5mhJ6/tiNtU3Dpy3hs0oRdres108co9E9aKyyB/rGqL0GpCmIQbblnmuVSRG0NzXvxquxts2ys8T9xQ/cSDHssVhPdkEcBqoTCKGo3wF91Vbnkcv1KbAgOR3Zmv4aAMmA9XrsiA/demJzmF/tSwnZTjgl//heAXNgVeqQO1d5/ARGQDa9NTbT++3c1r8eEXGfZtonHItULUgZebosr8FyBpzi8pbqZKSone+a5EaU1ePYczfXQ14/SeaW2H0GmPbVQTSqW/cJxiaZBKvgLtvuFHWqWXsyk2Qu9ClYb2RBRjyDSZ91kG7tdBHEUfh+rwpE6MFp0vGWIck4nVz907yQzMK3X6rbEqYQyK2vQdNkCAOhP45OvTP8O5+XAbdRU22fzPS3uXT6jEYBvLvLwL5hGjhbz8Uko5wergfcncoI98uSVI0qPCARaBpl8b9ltdrNUIP+ameQpWPuhtDx8OksbzRFfB5vniTXkwntg/oRtwx99j/pM9aTZFSdyXfU8AAiIHdbpspPCmiEq31aihuNtHX/SaL02HFNFkXEowyJQhEJN+AaWD1X+3VYlBRDbGfLwutHw+xPns28lZ3w/BlaoWWZdO/1U+5VPK9Dn712L30G5IAKCu9G42w0oQRozeGbNfdZGxvRW86ak7RYbc5uRWeEMLf3B3XxoEwKBNE/I7ACS2BfCge6Zm7+CkS6GXCRzgJA2LtfWigHNE0ogJ8HX1Rc0UL0CdzHgOsmPBHMvYLGA4+Pq/SOOj7IzbN37tJ2fkomd+MSZAVwgqW4JkVgjrPJ7KykJsvaKgHZmTUKao+3rb7Nphb80lLZlDC6J97fzZRrfMHmQMmZDxNHuhwHb6oidNmxSYH0MgCFcHELn7aJ3tlHxChZtSo/hd62FOedR+XKVBPoXNLeYBWSZFmBJte11RZwQtcR4tpt2+LNB9wkWPxY/iFK56zJfbkZ2swHZ/J5wNxM4XAhb/6n131LE5P6rFaFfC38PKujpNvK7mw65kae5B8GL99+bSdgEUYkb4w0IfMHi2AR2mhNXGC9IWBB6HgZkhSgmjo2Ql5aVWLaucg6n1TWd1cFTezgbbMVFeDOVK2BoMHl3VB1uW22YfEiovoUzkKrqdUdwLsB/vhyOWxe6lKJKZiuQvKpNg1+PPXqid8gf3UDGVD00XFCCo++ZuLxfvjJJuhZKDZVOWHpzW962UXaSBe7rOykD0+bK6PI5Gi+FyLVk4YI13iZc3FgyzQAtCFxHbY2Da51dSsNPiUBjv6OsTJiT/7EQOzVL+Nil7vBNAAEuWGfEntA0hw5yE/8TYtEAt82fHA+nQbz/rsCWHL6vTNVvYiuJTp+wqUUJXXBqZPjFf77dJaH67SNlea1PBHtSYReAXJcI/iPi2YbpGh0DKsd4dqt3587xdhszDYg37ofd7M8EQdscAcD8GuK7aaWlT1xdFejnlYaR2QY5qaGDVk2n62nbUlJrB1HlDphJPAK+FMEHWnNZgMkAOmQAjKlBLpvDwQU75R2cBK2GYdQqXEQYRykAcekFKNrRRYJRuoVU6hp1tdq2qRcI0KnUqNmTbTePiSw/kH7Hp9rxuC/Do6bUiJq3uN2nLQtnXW3w0/BrwRXVJUeJ9KIklErPiVdFOImRT968soQ13sg+FRxd4N65AHDqpZzwcVKz4ZwuXJvH8q67E+Ahvm9TSCRY51eqRBV+lvwvYjtbKVsleHCGnsuFzQbvIORmGJYARV4l7wiSV1iAI2Awjybzob4AImb+UhizoMP1RPJ3DelSyJzIy0mi9pSPKfSG/CQA0CH2Shrw1QcYrVylAcXV7Oj7a+ZSpJq5HWTgZzA/kQCXg3Le+i6CSmU0UIm+5h2dztodAbyBpJX0tlJjk9DaqcCI/2b0c4P8brPzb1bfWjn8XI5Qif64ZPcQ1XTwuwFPAzQ1YmHDElTi1ml6ieg5p8mqdB81BY3jDGbvCqLkYZswh5rn2tsuUV420Hxyk1g8/ozVNOu/shqg8C4M8bPxhT12Tfxl97cIInSfLV11nTrXC/Lvu5JI8A4YTo51AXPA+ZhQkrf5A2sTCt/3Sqh30ygQsKGz52uCoW/OhugpZkwgYg4uN2w57JdBXsf5DQmi4gBkxMhT58BcfjCknwKo27j00p9I+IBmKFzQ8SBjKpa82ecBGOmMZGOZBxoYSEWLuyAi3zWx8CLrCM2KkiZ8cz7eMjES+hTBVSTRX8PVkV2zH2XMA6vZrVdZ/hjqxk8vohBH0mk3JSYRyFk8Wq1kINlPQ3y/OdL7jWEDH6daeZ7IwU4gS5KknF8bBF4rjGG09UeTphGdyT4eEVZHSChOcRnsB7kgKvbq3s2sT7eDVc9fQHoDPDJ2nyH7stNRY8IrXSakd+iFXNlupirjJ9Om/MI9wScM0V5/k71Sv2NGg1HW/5ZMafdj/jkFUV1YKJt3snjFOOmL/jjj4zgn8wu0vURR5yYtGrWlMi0LTqSs8QiiH3l5KNUB2nHI5pmsm3bKyRK7feS5ZTDJklTTxG7Ek5rsrS72QOYNxd+RXeR0iw9xXbxCz3wZ4oUZNffxD0lpD08hsD5qzpqU/V9YLH0vXaQju5TlcJ5DIl8gd5NH3kVmvZDceNHa+PhOeszkq7rDoKMrNQ9jV5HiSoveg7qSo3cGjGojyRAhH4b4LfHnwggh6+KT83hKPSw05npEeCGCw5vRI4kxkS1oeFyVAz20CVILr19kZnmbNO6UsO37WApYQvAVa8gUpr3ALKRmyE7jglZ9QRjUhoDcCtRlLtq/4FD//JADOtVoeFNJMvp6kexPs5rqNLhf1IZm/ZfPK4Ng5QIvn6rCF56JaiUvsGFOvuSh6Gg6OWA9+0Rq5WIdAB8W2uqdq6EW5qeus9FIrAp6Aidku530szRXa4sAn4jOSqbS47HpwfGtX/8Ka/cz1fpO0c2Sv4/nN3QNm/SqWFiVvG++g/ElmhlsKs252Dq7plFmbJk55fyoOPA/06MzCnQMJq6sYRuTXnb9lXQxtWXgdUCRSgHspWcrplpv/kWOy7QN6C+EY4cJD8c/97M547PaARW/1YPwhKR74dafbDZD5q2ble2ZyOVA8cyjlMT/gtXY3h/4fqQ1mUygE+k8QYjb6TBkod4dYYHCVkJLIOjERWFryDzilgG2qQhs4fjZGSLH2tJviTnc/mPYGx162MtLEZWt2WkQ3Ji4D9zQNu33/DYaqsy2tfk0CDW7hfDg4rHWOXmB/O0pn8M2iwZLp0rSm2NLOckSamDk75/VBDnrvZthM/+lBCKWmme50WpNWAir/I9SF9yeRit/495AuJim5rt2edIibbMCmvkFBtsX5PdzylNwTfs7CWFPiD8i1l/z07OR45d9UllVCIQ0OtuikPuBUH7yeGSzkvcKKW5vpGENE8g8epW18PJ8Rz1GXVLU3cMN6Urux1HHTlrflz8FhmYQVZ+hPcNrwQbePaqVsah2h01vzdbtqOhQx4yhwsjS3yUFR+YutS6Bs7jKJUPnBgAOI96iVA8r1OQD1ovZRbDa9gzDm0HFFJPHgwHjlxN4oADPfx4hNu9YchJeFOVyfQPLrd+PZZ55DhFjVEccedifm9acrUh5OcJSBW272ovXbTUEE3/hCn+wOZ12TzVtdmobJvRKBWLWEANmwl1EGD9xQxlf/ghhMUuLDnXECx7lPiLDuGQfPrSH0VHQVC0pPgOgw+392GieqWv7g84nosWr/Ey1TaKNfC7kBjKxZ+Z2TIhYlmPShZDWwkQMbADqrKMrp5Vbmaoq3PpNuJWxp6CUhyOLAgBR08A3eyx+Pmvh+Q/jrZ4V4XTCLpgGpTyP3aSNZV3w4iwLe186h91uJ/KAanAsF2u1AZwYK22Y7gjnK9qlNFudJBGzgj4bHmceFYPQ17c6/uTPGtJOj64AhrZxVgKpDHBPDq7CLP3wsL23modIObPhveG/0IqnOoP1izK/PjRD+cXoioRdepYQr+HjICN+x1QveEX4FuxVl+xEcxPYu8d8SwUpRJWTkNlP1BJX5sC3pkcBFdP44BhuL1xX7M4l/hWy235fUR3UtOaridbK/fLR7a7W96pwZdc5rIXOIcDQRZKd4A40/PgLG+lMAU8pT72/5Cwev4WuPAAB6M9CYMYftut4GUrksn5cTbQf/GMGAilk7U6W2waZMRpjZySiopYzkVLxc82MYjFEptNd9rl+4m4kV5rddd0C5ZTLQJLJAQJjJrKp3LsodZ5g+5EkShetgUlPWw0AAMc3hsKyCzjXV5B9l+2QRgRzP/XpDSJzrAa/yH5Gok9UAG1O4cQer2cK6Knkut3fww2t1vcl+lJd5n6t4XErsi7iFOioasAJuGJVAS7/0RfF2qmrBLIG2Wz5DWrLZ9WMNstPh6EdbfnN09Lq+recPDqgFOVzkkoS7EWXR7AMhJoQJymtP1HgKPB7uKwCeE9hwwprken2yexgkkbN5IO8qEkxnUOnPjQdSXwHFD+6nHnttGWbODS7aYaPjzQ/r6KOYHaj/GMHCPhR2PKd1JoDriuJkyomp7OYOj8xfz24EcgVfuBaXuKPvHKJAAzPc4NO65Mp4buewjWbpMDePZHYtNsnz6MK5IvXKFQjOjjMDGcQrxqMA08YXwdYY5HD8HcYCq1VkYt74Slp3EPwAtUbJcZyijYazMAMOQ1Qrr5cYOdF06n9fhgGPQBuTcJfeZoBBMnOuZ5te6UsPEORQNUvyj8iMdZ3URgIii9rY1dSUtLp9LoG2+hFhwHDhOcCm7k4G75/TrP2XhPf8cgeS+fBitH1+p1hWrDPI3QpepkSxKiC/6YEnFYhmybO9xuuOfs0t9OY7R7XzSP1jL9hYT8y6ohLUgDotpCi8wlc3TbxX1UJu/TxFXXkEDkX/1fgeo54Zg0e+JbY145pvWCvwy9FniLuLIpgcOLVF9RjZCY8HDWxbMv4srLEx+x7h9DnQh6QRgH9ewgBqkvE0OhIUpHSOJC8IFlstH85JtH0+b0Vjrhxk7IxYu+4fdJAe0+N/tXeItH28lLXNjXO/HMKWOjmyR3po7D47oObESMG5rGM/QLIUbtzLVYqsuI2MeTeS37mfhisc3IDKnCEpyGhk/6mIyqCIi7gfuW4Ta8150D4WS1vv4vU6xm6IlHeg0i39bd6MYZyNyfeC4Tm2gjdFcl3rz3X/gQbjBkHao16DBBVS1OHKqGKc2VzpypCPHKD7vmB2aTfhCcs2kYhI29OKBj7wfGcx3Lv02MsARFDYWuBtEMpcIMVHjwwJQp2vfhJLfwFRTDzY4F6jReuHD9mws1uVHd3FPMpBkmgElr0wPtliZKLcz2Ur0sZO730m9aEzshbq3y9U+L+0nKeeDUzxE4g8ZMoyz3WK1Wp9YRxvTbpIs+A4LsDVJgxBBFn796yXrDnyVnfiLFsOLkdF4oinnpFcOOj+njRdl31K0apV7dz29eZkFq0BYSgY3vYFrj0oJ8zx+1b5a82bvHfr9yw4nzesMBe7gr2r0yHVBpG/FHWsFSqFrHkTqC5ZJIUVVGLkXmn2WIdAupMtY5POHuVPX/IbUGlWUnNpW4jBGwMMjxvVNuv1M3lpOIbXx8OJF0TbUIJ6Rpga3tpXoOVwx2yQ+G+k+dtZ06FLHFIT5PMT+C5Eo7z/EwRe3LyGhPM12d89xr7iDLAS78ToF2eStBkx6JeigV6wvc7VzBXpcsvZcA7VcAnHNikkZJIuYvuBbBah69oOa6M+UYTErs9Ovjc5rUsqd51Ycxcfo2+fZ1dGFJx/riO2n43pLsE3hgQIT12F5o0poRcbRvAxoG9pCIiofsASAGWVBkp4gpzYP+hX6AA3csx7XpAQIi8cZv1o8qQjZ4aKoHQZmJPBT7imyhyiGq6HvqMfT7Fq0+2GaDVcd4EEWGkJ8HSj56+YVK//tk3eKDQ8mUTtfN2YY/EpP8c5Dnslx37VhpP4PJa5I3sJ+vxnLvRvqq/ushoVI2cL/q1u9WbczbfnVWNv1oBi8j+yZUMgJaiglfnF5dV+2jrG/V90bIu8TJsr/3B/Q2ZpgRPx+6oHgCn+5wcFySv/HZqFROIGzdj9s/U8gI95eGz77FwP7+Gthm4tuaKT3VW+kVhG+C/krTeaQDkdgMAfN6c2haB2GrDkvRk3B1ll8tOufQ3Es+6hCLZaRj3tly/FK3QXCy9nO9yXisXjB77ThgM9GoEH4KyNSXDcyxJzYiDthCsYV3AzUbc9wl75O7WgqYsAxQWSTkJggTlzXyG9KbiuGBf2Tm7z1L/zeInH+znIBuEa75CWXIfRk4P/zAriVXQAUGwkSn6OOH/RF6ZfJjvQZGi60OqiAwrlNJzzaD1dWE3wwKzKb9vWYYOAF0VBfrbN0rLor9IMI/t/iiZqswYeRASXKyPueoljHmAs+3MjyVaxinPyZXQ2bxiwSQ6xZzAkmgZ1tev40tVXVJz1f6arXKl0Yvi3dXDl6vkY9/4zKc/uZQ+syda0HXJgA/AgvV8MqBLl3jLS82KrY0mAmyLh9CB7hr7qvN7KGAD7/Wqcz7Qj/9ypMVCwfKDp4kp31w1EmWXD4vsFG7+sWwDLWj2kRLsjKsx1pbD9HJcs0uI49wZAX3ezRAcpsxRDphJpALp/ebJeJLC6CZ9guoeAgcPArxtzd6fESjNrPDj6lcmhc4lA8GZjTf0HNrQXoJhBLUou89AhEZXcrc28Mzd9llSo+8woOOXWCJH2CZNdyhU4GAjGxqhjt5RZBqefC04I7ttTT7ftkEGlwnxAmL79pdWrjDvbOSVnjlwhNccusdSxKo5qhJFzXsRAH0jYc4X1RApvREf1Ye/7hEvQuucq3U+92BgBeQkAsgFbnLyg2MrkN2UFEGcT6bovXOnL4t8JdkW3ZkIGfG0kA/RLm5edEvqpNJPnUHSQwSJqhB/ZK8doVgJDN5EVRskYUicwEWrclBG3ZQ8zlmH9m95je7/467CfOnKmAUQE6JGUt7amLSzHgR8rOs3zBJA4r563TEJpvVf7XeDKhBwMeKh+VsKb3cafM5EDrOYjbgkIzK6X65beVkpQs0OVxeD721WRZ8wA3JhRvTkJXJGVb5uj4ClDiEvrJQeriNolGqhXnN+ydXqaOki5CyXFw5y7gF9W2B5yCPN1AtdQ9a/Rz74R9/wpmNOHwn34jbxp2+YwXfT0uzubpU/XmkRq7IigMDgk6YdyPhSACU3xJ+qaQgPrg6OKUXU0J87xgDLkvQAtC5zoVKShm28tmhSefeSE06JCWR/DfBX4CZlmiYMKVQXOJusk62k7hYeQHBVcozLuVr1xOakqj4ZNeXJVTHrBDloeLTk0uajLqICjz7u4zCmJU21xRAytAUKyBCR6tIcqdf3sUy81N6cdW16Yjlv03XEakb+/XPjrJD5JZr4VcfajgyCrEngVqOP4DNYsBAlnQXMDkCz2Zrk0I+flM24thpWlQOrDhTOzwbvwP/7TgJR1wdKhe042WLgl1osrd+1XuwIH1g7WrqSXZZICVNyZFF2Ya4g4lc6ZDXT1l1xeiu+BRNJIaDvQR8Cd7ezR1rD3CqiaYNn6W/2nnuZjgCNYiqSXsUDxpNPQ7dIxA/I0NEJDesAuBla240P/Fp+8g3SpAItgs1jcUfEtytVJjwR7OTbymwgA0fqXTxDknFap5gUjsGMqxxM9ieDoh9mjo8CLosm8dpyJLp+/tLel1PHkXCTUEGwd8uCZ7qSor1H1uRURoK7rJj4LYe3YpSggK2LpY2lkmcY7cS4c+byRpyQURUhbI5Xgah9DmXw/ARrp2Pr/JteNJapNPWdV1gEykKschZKpFlnKeSrOQ7pZ0u+GoHU5TtBuVp/IF+CZNTmD86hqehrGxHersFF/6Lso1mc49/0m90mrHcRf8/ujGwMPD1rFXOQ1uDaafDeoxj7p8+Bc3nKTSufKLE2uqZWj2d4tY8xnfqL0e4iJZHi8gembeNVNBOPYspkh6YiIDYLKwS6lSxph9dcdf93aG19m/KeCAszpGZmw6nf7GUXh30SVSDCh6C1iK/MFdXG6ouLW7957ndmtTZUA940ERAZr3K5iX0X/fps1bQpRP0MKEnlMSPW0QbXmPk4QqLE1RLnE6jm1FknJVyO7QQmLJ/JNLh6DP7ZGAtGoJ3CtMIrQUS857vCcrU/g46R00GaIOlGxbao/62WU6Uz1Hd4HnjnRfK2rV6kbEymWlm/CTeUpIpq1lNUZYtzGwnwkVdnqcHqqbJoaMfO9j6mUMT3X6GCyzreLYA9RoMXN4wOufa92wLJhIcF3yB6bwejydyFl+td0cyKqdjSz03YFhkk/fS8rTQ6SLd1bWUlp1iS8bF3T5blhIv4bmX9nfv0A7pbQQaAIFZlb1SErajVydzMKRF5Hhs5RsqrJXfimaCh/UuliUaHspYlqbBdW8LzvuelTEfevQKWyxS3Y+iuwzykLpE5QsA0DJ8Hrz4otHWDqLDwfAfXJ+JViEN5fZFQ46qrlAQLLaaE9kqdAOEtbo7KF6rpqwQ8oKqGjhDtbF75leNYmXCbBPSLTHbc8k3Gu2Tba6bW8GE4I9BrzGHeQpGclBAoF3vus136/vc1re8v6FaWar1aC36/oo3p+vHwspmtNQOZJ27bEZ/qaOHcdUfHsYQoZdGhUHXN+Klma1JnUH1ZGp1Du8+eouPo4ACD1ir+fYf+H0Dj8yMGabPVkl2EDC0xnb9Hgla5nN2O+ge9BBM2QAYmCNZeWkZwZCXn0sriBX5kr3w5ov5TvgOEw68ee6mJG5AGBb3NSpK8gObrFN2ui52cKa1ClITOyHF/7DcKwLz1MN49AFQ4/Oo/lFMgN9uvkgpOpdTPuzFuhgN8XpXlTCYQf5BrIm9OD3Dw5s6irGsZXTDgD8VhFCWy4dDXvrsLXc1SM/ESsvck+PjxirPU7MKs4QzMwcVwp/VT3nmbiOPnmNACnhRfoZH28EARFFUALY3QQJNu+lnAP3bU2rnJJFhyue3Lbj2SSVqtnlSzjUtCmOINtgEJA1tRjairO/IT8lg/QUmL948bzzPfbJkGirNE7UehposXUsmMu7FzSG39a5CnoUZf1CrgAVnyrsI7l+pfoUcpWqqwMjCCqg/x1E8Ob9geiWbTShobjydJDJ59ReAxGVDl24NcL1P1yikLGrR45yn4U/qd7XtxLVDDwozSQrP+okcvMAsaH82FPoj6zdb3/31KHUeghEnH6ZVksBGhdhB9VuJ2amSVbGILf6VBk7DAYKGgwmsLPtPbUNuIlXz3Xirq+STeFOcnqJ8DVjv/5GnbQfns095cIjAud3iA9mbI+zEnQQFLkRNDljI1PVKWwGL8Deak3XgvRjcol/0RZUX6dYihxxO4FEQZqTvFL8e9UcP9RBUU0aKQrmgzM4vjYZYEWOEkI17BIXKDbQAu2OG0QYyM/DDsqSqMXHh70/Wha6mItbF83BpoduN3W9q/LyJkU4pHu1tmsqjcCfBx81u/1OUM3fGRh2Eq3+u7ekOXGgGcTcz0ScVfj93oaNO3Qwz1tInVOR/VY95oiFwHjSnFeWUMR03rBZs+/9bvQdEBTRaMpEYsuUG4gy2IJv0A+lSsORtfs2kYl8pr8ib+LTb8cUUzAyy7bbcQgoVGw4GtF89uctHrtcXm+m+E3RJSjr9Zsx7FrgGXJYerkNOIL44ktHDyGQRqkTfFIz8ke7gc1+Wx/RvM+BnjviED3/krKhsTNmgkmcZDptUy1Z2CFfhVFFF3Ln1xYpkkboHl7vCdZzBKryLaxHTfCQqfgwqnd+/o4gNv60M9hfK196p44ifhWEJpf8ED5BMktO/emG4CmCGnpXMoEXVYGOHqpBNQrFkvW5vafEf06tv1ghPGxlhQrO0Vgy1P+e5E+b8uyVhwbox1F5ebR3A8o0A3gbGf8+36PQJUPqL3DeQ38Ml1Z550RRdmJoP435r+d6VGtNPScQgkOThGDTzR9heNY30HGMPWdXH06+FXO5HSOj1OXmnju7h91zqKfnKtUjYc613984uQ2ymHkU46Qa3lPQrp38RjP43unT6Syjdm6T4DcRW8Phb3KHd+jR+aUpGacvI+dKNPBDO8KO5C5hMNrf03XAkN9Ik4jdnxffnrBD/b2x+v5YLkdJF52yGbt5O731NJioo+ERvWDy0tBpQE/RVi7SKbHrg8iZTESMBto+oYDUhiApmXbe+rZloDEnLtiKmRkRiJgv80RrS2gz3vLOh4iGFC9C/AxRH19U1tyn/7apZ68BppxvM+8Yl9aRPJ+0UWXk+q/uaesobHGEV6MH+P2J061JwnaTfHUKAfVP/INzpYcWyYxUoGaa4xYsujfVUba7uU9xiPobOVITSQHTu/wFbrwfIkwZsqr7YZ80BrcHmLGg0R5lWXPm7MNERDxGVh9UOOcIds2prxZKGd5OrH6sbrBP27CD8RDZsSin/jcMt23KCKjerO2VK+noclJYVGHUFNTWker9LrmfkFY6572/IWjJPF4JRTahyY7M2p2Bk+ZGPSpPSoUkC0RtASSr7lpsuedyeZQqqPfoXIA+F5ImpSAc/22E3UCYLk+OFyEo1N/j9botb/aRegrIkl56ETLhzXMWSYTAYxbxrULjmWTrww//W8JHrIovb62ljHeKvEc4KMZDoO5Uqck4QLAReAfM+jccHOakdG63fme8v/NoocIF0H+aD77OUV55VAzuRuN9CKBdPLtQy6dAFVCrX/RGsf+Y072aY4xiyhstXjTMN/ZEQw+OhzIjJiBcNP3EgNyJc2v5SzX+63HKznDhqR6+4D+0NopjoN3eoHOy7J11oGZ/bijspQlZk54pQKupvYs6qFNPoPmXVX2exS0Fu8vrqgfUu/2ImSpTP24hR8RUDw9y9000NaGzao476O1hFwWSAzpjBVGPhvhI6Ah/ykrkCFDiDSHd3xsVbfhvJl099HFsk6CJjVsP/EcjwOFHG0NCKx9fVK9qUH+pxKVGUTYDwNzi8ItKzIQDV8qKdVeD6+Ayab/UjHa8JJjX2NUrRRu44HUEf2611L2WLLN+PX+UmyaSdVrExS5IRn1rKl2+7ZslCeJTb+u8oej5ViRdu0JhyeSHi8ISW+zoHsTeKqE+ZqRSgryEuP2GDT7+5hUSX6WQ9C4zlPAPujtQ3Ue5Ef/BpJphcSw5zDjCoBWjJ1u5Ltkwf2iRjmpMlYQ1jq+cV9BhRiTsOOfk2uc789KOd79ugPxIEiSBS2ENrB2Spz7wb6gzCynTO4TbdOHsH47cDH87tXSLugEfJ07BU60k2mqt9IZg7nNBTp5E5RoAJijP+sDbKH1siOrtBSczQZXaADornSI5qtPnT0vMccrxt13MBJTsLGSuMnerxGDZx+VtmysYeXGvmZNpMzqIOw60EAy6CnP74NagkJ+NUZYBlGZGaiXk2HiMrQMmIL6caPkXto4vSrrUr+sZ1gITyP7NnVM1fa1/cZMaU/r8LFNRdtEm2vZhUmKbQaC1cohluqfyWa9/nSHqY31Ys3RNJtpqY5bhWZwSqyDHtyuSnOAXfKgFsbFVVPCbyi3zotAZ6PzxkihGPUaOEFFAEJ/np0j3iDbU9VQhQ2XyrRpTBlrXapfRTuz7G8JBtw7SXkFs3RvOUqmCW9ij0uNwWzJwtMgHjXCe4pYkf9w6bCg2KXTV9X9IIohe2kD5i4c67n9E+K8oYyBf6LRnObTXugsiCJwRCrWinq8jWN1xtmsFnFgpvwKgGXyPETjvMFCyum7SXjc96gq2QS1eZUvS4cMd/Pe7+fcd7S4P2KGl5rjEKANXaJ+YHtCuaSJcRWDHeSLG2FAlypWgKJS2Uh/sJ4yYw0uNOFodXiavztXR4nRR6jvRefPvIv5F8GKtIQwuhOZrNV9vUbhnM9JB59/bYDJrRUyn+5dmkWW1qpBMky3UCG/IQPoHtwqWq2PnoT/MWSJ+qk9V1kE/cUMvtlv1/EgRfei7FTzhrgBMSKyoXHONMlS8eZLyMFsTv767x/ME2kZSBXYo2XrJk/utZICXQxJwwhBOkEfD8S2OAuRHD2S/CndPp/rWDC+vNlqZCwKs9P53KxxmrrvEKg+zeRc2mG30NeRyAQu1ierTSUzeJFMlnETQbL/LrteW+rC2ZDcZs9PaemtCEw3a019zRkbLew5eKTpMt2kOsDbgbQwn7wlucreJGe0e2aowA+S880xLIrYeoHAO6ShWrBPHp/5350W5xkGARpquS8gVcYPlwdPz8CU4RpEEw/RSPF/+9j5WEKfCb0y12NMKbEX4uMfhmcnG7gqL7oFbD8StNXd1TlEpczbyV/dyeyq1Jx9NCdYKrenx8snjw0rW66XrHDpBN61TVYu1kYZRc7U5YkG2SPXXkd7idFxUEQPsktm+DuLg75vZ73jahhl1xYsNNq5ZBjKxHMTqJlbZUaio5sNGBFGXH5q4wQv9HPOcACMJigWObQumIn2k85cq8jgzJ4Q+nrzCVX/Xa7vHsydTKv6cg30GHScRhk8UiaghW1LhgT78zZqfx7A5fW5FnwozBzzwHAMMClEZwfBPDrp3gs//L18vYnNjZnJhbWU"></div><input type="hidden" name="bgresponse" value="js_disabled" id="bgresponse" style="display:none"><script nonce="ap1GnbrOsHwrTI9QR19Xew">(function(){'use strict';var d=function(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:{done:!0}}},f=function(){var a=document.querySelectorAll('div[data-button-type="multipleChoiceIdentifier"]'),b=typeof Symbol!="undefined"&&Symbol.iterator&&a[Symbol.iterator];if(b)return b.call(a);if(typeof a.length=="number")return{next:d(a)};throw Error(String(a)+" is not an iterable or ArrayLike");};/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var l=function(){this.i=new window.botguard.bg(k,function(){});this.h=this.g=null;this.i&&window.addEventListener("load",this.j.bind(this))
                                            };l.prototype.j=function(){var a=this;this.g=document.getElementById("hiddenMultipleChoiceIdentifier");this.h=function(){a.i.invoke(a.l)
                                                };this.g?m(this):document.addEventListener("submit",this.h.bind(this))
                                            };l.prototype.l=function(a){var b=document.getElementById("bgresponse");b&&(b.value=a)
                                            };
var m=function(a){for(var b=function(e){a.g&&(a.g.value=e);a.h()
                                                },q=function(e,p){p.keyCode===13&&(a.g&&(a.g.value=e),a.h())
                                                },g=f(),c=g.next();!c.done;c=g.next()){c=c.value.getElementsByTagName("button")[
                                                        0
                                                    ];var h=c.value;c.addEventListener("click",b.bind(a,h));c.addEventListener("keydown",q.bind(a,h))
                                                }
                                            },n=document.getElementById("program");if(n){var k=n.getAttribute("program-data");k&&new l
                                            };
                                        }).call(this);
</script></span><span jsname="ZVfTqd"></span></div></section></div><span jsslot><div class="D4rY0b"><p class="vOZun"></p></div></span><div class="i2knIc" jsname="DH6Rkf"><div class="wg0fFb" jsname="DhK0U"><div class="RhTxBf" jsname="k77Iif"><button name="action" class="JnOM6e TrZEUc rDisVe" value="1" jsname="Njthtb" id="identifierNext">Next</button></div><div class="tmMcIf" jsname="QkNstf"><a href="/lifecycle/flows/signup?access_type=offline&amp;app_domain=https://oauth.pstmn.io&amp;client_id=441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com&amp;continue=https://accounts.google.com/signin/oauth/legacy/consent?authuser%3Dunknown%26part%3DAJi8hANfQVfFXSRg742diIY8B4mapFetagfHXchn35fwC-S0THai3KkWS0Pu3bB03wbuQyGWrnHR-rVM_WYK6CRRNTTVRnVRkdAulc_JklLFA_LjDcqOwYLMRoEu1m5unHXI3ZhEBQSvSTNCxuVCG-TJx9SL1N-lJ2eH6RpfIGTCSCsayDRIfW9Klb2HI4Xv8vylLkF83w6Iex5VDxLfQInqAj3xRetso4Q2BeLn-yI1vp0b0pdB9lAlxYpYeuDBR62KfncoZ1Z_iD6ry0tfB912gqJ6NrkA8mTYN1ZFUP7Q-Rno6Y-bfMewUJbVSEzNleMb-kY5mZxBmR6m4X86eFTteYhiBm7snWElSKfUYN2IYZAqhItTA-jGjGpbHc6dv0PLJ7i1UCJCERU6KkBrkyrm4M5VFUzMb3Ef48yXUZ26BSWoKAsWvBAGTKZ8o6FGHBE1QbwPIGEuyGJS5K9xWS7JcokNxJSARA%26flowName%3DGeneralOAuthFlow%26as%3DS1813435215%253A1731990123420569%26client_id%3D441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com%23&amp;ddm=1&amp;dsh=S1813435215:1731990123420569&amp;flowEntry=SignUp&amp;flowName=GlifWebSignIn&amp;o2v=2&amp;opparams=%253F&amp;rart=ANgoxceNXOkft8dV5zr1ZWcABM9lzAqQkv4qkIA62Rn708wUhaH1TCtf0UEQ6tqpjz0TvaKO7nvWdG-94czlFgP7bdSH63F3yE8JAaKQVxUReSnnGERYla8&amp;redirect_uri=https://oauth.pstmn.io/v1/callback&amp;response_type=code&amp;scope=https://www.googleapis.com/auth/gmail.readonly+https://www.googleapis.com/auth/gmail.send&amp;service=lso&amp;signInUrl=https://accounts.google.com/signin/oauth?access_type%3Doffline%26app_domain%3Dhttps://oauth.pstmn.io%26client_id%3D441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com%26continue%3Dhttps://accounts.google.com/signin/oauth/legacy/consent?authuser%253Dunknown%2526part%253DAJi8hANfQVfFXSRg742diIY8B4mapFetagfHXchn35fwC-S0THai3KkWS0Pu3bB03wbuQyGWrnHR-rVM_WYK6CRRNTTVRnVRkdAulc_JklLFA_LjDcqOwYLMRoEu1m5unHXI3ZhEBQSvSTNCxuVCG-TJx9SL1N-lJ2eH6RpfIGTCSCsayDRIfW9Klb2HI4Xv8vylLkF83w6Iex5VDxLfQInqAj3xRetso4Q2BeLn-yI1vp0b0pdB9lAlxYpYeuDBR62KfncoZ1Z_iD6ry0tfB912gqJ6NrkA8mTYN1ZFUP7Q-Rno6Y-bfMewUJbVSEzNleMb-kY5mZxBmR6m4X86eFTteYhiBm7snWElSKfUYN2IYZAqhItTA-jGjGpbHc6dv0PLJ7i1UCJCERU6KkBrkyrm4M5VFUzMb3Ef48yXUZ26BSWoKAsWvBAGTKZ8o6FGHBE1QbwPIGEuyGJS5K9xWS7JcokNxJSARA%2526flowName%253DGeneralOAuthFlow%2526as%253DS1813435215%25253A1731990123420569%2526client_id%253D441517634036-9b7uiap93llkh74j5flq1gec36kbchug.apps.googleusercontent.com%2523%26ddm%3D1%26dsh%3DS1813435215:1731990123420569%26flowName%3DGeneralOAuthLite%26o2v%3D2%26opparams%3D%25253F%26rart%3DANgoxceNXOkft8dV5zr1ZWcABM9lzAqQkv4qkIA62Rn708wUhaH1TCtf0UEQ6tqpjz0TvaKO7nvWdG-94czlFgP7bdSH63F3yE8JAaKQVxUReSnnGERYla8%26redirect_uri%3Dhttps://oauth.pstmn.io/v1/callback%26response_type%3Dcode%26scope%3Dhttps://www.googleapis.com/auth/gmail.readonly%2Bhttps://www.googleapis.com/auth/gmail.send%26service%3Dlso" class="JnOM6e TrZEUc kTeh9 KXbQ4b">Create account</a></div></div></div><input type="hidden" name="at" value="AH-NMN2qn6-Ur10SZA3f0GpMp5tw:1731990123620"></form></div></div><script aria-hidden="true" nonce="ap1GnbrOsHwrTI9QR19Xew">window.wiz_progress&&window.wiz_progress();window.wiz_tick&&window.wiz_tick('chA7fe');</script></body></html></div><c-wiz jsrenderer="ZdRp7e" jsshadow jsdata="deferred-i1" data-node-index="0;0" jsmodel="hc6Ubd" c-wiz><footer class="HUYFt" data-auto-init="Footer"><div class="hXs2T"><form autocomplete="off"><select name="hl" class="N158t" data-language-selector-select jsname="rfCUpd"><option value="af">Afrikaans</option><option value="az">azərbaycan</option><option value="bs">bosanski</option><option value="ca">català</option><option value="cs">Čeština</option><option value="cy">Cymraeg</option><option value="da">Dansk</option><option value="de">Deutsch</option><option value="et">eesti</option><option value="en-GB">English (United Kingdom)</option><option value="en-US" selected>English (United States)</option><option value="es-ES">Español (España)</option><option value="es-419">Español (Latinoamérica)</option><option value="eu">euskara</option><option value="fil">Filipino</option><option value="fr-CA">Français (Canada)</option><option value="fr-FR">Français (France)</option><option value="ga">Gaeilge</option><option value="gl">galego</option><option value="hr">Hrvatski</option><option value="id">Indonesia</option><option value="zu">isiZulu</option><option value="is">íslenska</option><option value="it">Italiano</option><option value="sw">Kiswahili</option><option value="lv">latviešu</option><option value="lt">lietuvių</option><option value="hu">magyar</option><option value="ms">Melayu</option><option value="nl">Nederlands</option><option value="no">norsk</option><option value="uz">o‘zbek</option><option value="pl">polski</option><option value="pt-BR">Português (Brasil)</option><option value="pt-PT">Português (Portugal)</option><option value="ro">română</option><option value="sq">shqip</option><option value="sk">Slovenčina</option><option value="sl">slovenščina</option><option value="sr-Latn">srpski (latinica)</option><option value="fi">Suomi</option><option value="sv">Svenska</option><option value="vi">Tiếng Việt</option><option value="tr">Türkçe</option><option value="el">Ελληνικά</option><option value="be">беларуская</option><option value="bg">български</option><option value="ky">кыргызча</option><option value="kk">қазақ тілі</option><option value="mk">македонски</option><option value="mn">монгол</option><option value="ru">Русский</option><option value="sr-Cyrl">српски (ћирилица)</option><option value="uk">Українська</option><option value="ka">ქართული</option><option value="hy">հայերեն</option><option value="iw">‫עברית‬‎</option><option value="ur">‫اردو‬‎</option><option value="ar">‫العربية‬‎</option><option value="fa">‫فارسی‬‎</option><option value="am">አማርኛ</option><option value="ne">नेपाली</option><option value="mr">मराठी</option><option value="hi">हिन्दी</option><option value="as">অসমীয়া</option><option value="bn">বাংলা</option><option value="pa">ਪੰਜਾਬੀ</option><option value="gu">ગુજરાતી</option><option value="or">ଓଡ଼ିଆ</option><option value="ta">தமிழ்</option><option value="te">తెలుగు</option><option value="kn">ಕನ್ನಡ</option><option value="ml">മലയാളം</option><option value="si">සිංහල</option><option value="th">ไทย</option><option value="lo">ລາວ</option><option value="my">မြန်မာ</option><option value="km">ខ្មែរ</option><option value="ko">한국어</option><option value="zh-HK">中文（香港）</option><option value="ja">日本語</option><option value="zh-CN">简体中文</option><option value="zh-TW">繁體中文</option></select></form></div><ul class="M2nKge"><li class="vomtoe"><a class="pUP0Nd TrZEUc" href="https://support.google.com/accounts?hl=en-US&amp;p=account_iph" target="_blank"><span class="UskCyf">Help</span></a></li><li class="vomtoe"><a class="pUP0Nd TrZEUc" href="https://accounts.google.com/TOS?loc=IN&amp;hl=en-US&amp;privacy=true" target="_blank"><span class="UskCyf">Privacy</span></a></li><li class="vomtoe"><a class="pUP0Nd TrZEUc" href="https://accounts.google.com/TOS?loc=IN&amp;hl=en-US" target="_blank"><span class="UskCyf">Terms</span></a></li></ul></footer><c-data id="i1" jsdata=" OsjLy;_;1"></c-data></c-wiz><script aria-hidden="true" nonce="ap1GnbrOsHwrTI9QR19Xew">window.wiz_progress&&window.wiz_progress();window.wiz_tick&&window.wiz_tick('ZdRp7e');</script><script nonce="ap1GnbrOsHwrTI9QR19Xew">(function(){'use strict';var a=function(b){var c=0;return function(){return c<b.length?{done:!1,value:b[c++
                                                        ]
                                                    }: {done:!0
                                                    }
                                                }
                                            },h=typeof Object.defineProperties=="function"?Object.defineProperty:function(b,c,d){if(b==Array.prototype||b==Object.prototype)return b;b[c
                                                ]=d.value;return b
                                            },aa=function(b){b=[
                                                    "object"==typeof globalThis&&globalThis,b,
                                                    "object"==typeof window&&window,
                                                    "object"==typeof self&&self,
                                                    "object"==typeof global&&global
                                                ];for(var c=0;c<b.length;++c){var d=b[c
                                                    ];if(d&&d.Math==Math)return d
                                                }throw Error("Cannot find global object");
                                            },l=aa(this),m=function(b,c){if(c)a: {var d=l;b=b.split(".");for(var e=0;e<b.length-1;e++){var f=b[e
                                                        ];if(!(f in d))break a;d=d[f
                                                        ]
                                                    }b=b[b.length-1
                                                    ];e=d[b
                                                    ];c=c(e);c!=e&&c!=null&&h(d,b,
                                                    {configurable:!0,writable:!0,value:c
                                                    })
                                                }
                                            };
m("Symbol",function(b){if(b)return b;var c=function(g,k){this.i=g;h(this,
                                                    "description",
                                                    {configurable:!0,writable:!0,value:k
                                                    })
                                                };c.prototype.toString=function(){return this.i
                                                };var d="jscomp_symbol_"+(Math.random()*1E9>>>0)+"_",e=0,f=function(g){if(this instanceof f)throw new TypeError("Symbol is not a constructor");return new c(d+(g||"")+"_"+e++,g)
                                                };return f
                                            });
m("Symbol.iterator",function(b){if(b)return b;b=Symbol("Symbol.iterator");for(var c="Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "),d=0;d<c.length;d++){var e=l[c[d
                                                        ]
                                                    ];typeof e==="function"&&typeof e.prototype[b
                                                    ]!="function"&&h(e.prototype,b,
                                                    {configurable:!0,writable:!0,value:function(){return ba(a(this))
                                                        }
                                                    })
                                                }return b
                                            });
var ba=function(b){b={next:b
                                                };b[Symbol.iterator
                                                ]=function(){return this
                                                };return b
                                            },ca=typeof Object.create=="function"?Object.create:function(b){var c=function(){};c.prototype=b;return new c
                                            },n;if(typeof Object.setPrototypeOf=="function")n=Object.setPrototypeOf;else{var q;a: {var da={a:!0
                                                    },r={};try{r.__proto__=da;q=r.a;break a
                                                    }catch(b){}q=!1
                                                }n=q?function(b,c){b.__proto__=c;if(b.__proto__!==c)throw new TypeError(b+" is not extensible");return b
                                                }: null
                                            }
var t=n,v=function(b,c){b.prototype=ca(c.prototype);b.prototype.constructor=b;if(t)t(b,c);else for(var d in c)if(d!="prototype")if(Object.defineProperties){var e=Object.getOwnPropertyDescriptor(c,d);e&&Object.defineProperty(b,d,e)
                                                }else b[d
                                                ]=c[d
                                                ];b.s=c.prototype
                                            },w=function(b){var c=typeof Symbol!="undefined"&&Symbol.iterator&&b[Symbol.iterator
                                                ];if(c)return c.call(b);if(typeof b.length=="number")return{next:a(b)
                                                };throw Error(String(b)+" is not an iterable or ArrayLike");
                                            },ea=function(b){if(!(b instanceof
Array)){b=w(b);for(var c,d=[];!(c=b.next()).done;)d.push(c.value);b=d
                                                }return b
                                            };m("globalThis",function(b){return b||l
                                            });var fa=function(b,c){b instanceof String&&(b+="");var d=0,e=!1,f={next:function(){if(!e&&d<b.length){var g=d++;return{value:c(g,b[g
                                                                ]),done:!1
                                                            }
                                                        }e=!0;return{done:!0,value:void 0
                                                        }
                                                    }
                                                };f[Symbol.iterator
                                                ]=function(){return f
                                                };return f
                                            };m("Array.prototype.keys",function(b){return b?b:function(){return fa(this,function(c){return c
                                                    })
                                                }
                                            }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var x=function(b,c){function d(){}d.prototype=c.prototype;b.s=c.prototype;b.prototype=new d;b.prototype.constructor=b;b.u=function(e,f,g){for(var k=Array(arguments.length-2),p=2;p<arguments.length;p++)k[p-2
                                                    ]=arguments[p
                                                    ];return c.prototype[f
                                                    ].apply(e,k)
                                                }
                                            };var y=function(b){this.i=b;this.l()
                                            };function z(b,c){if(Error.captureStackTrace)Error.captureStackTrace(this,z);else{var d=Error().stack;d&&(this.stack=d)
                                                }b&&(this.message=String(b));c!==void 0&&(this.cause=c)
                                            }x(z,Error);z.prototype.name="CustomError";function A(b,c){b=b.split("%s");for(var d="",e=b.length-1,f=0;f<e;f++)d+=b[f
                                                ]+(f<c.length?c[f
                                                ]: "%s");z.call(this,d+b[e
                                                ])
                                            }x(A,z);A.prototype.name="AssertionError";var B=function(b,c,d){if(!b){var e="Assertion failed";if(c){e+=": "+c;var f=Array.prototype.slice.call(arguments,
                                                        2)
                                                    }throw new A(""+e,f||[]);
                                                }return b
                                            };var C=function(){y.apply(this,arguments);this.j=!1
                                            };v(C,y);C.prototype.l=function(){var b=this;this.j=this.i.dataset.isRemoveMode==="true";var c;(c=this.i.querySelector("[data-rab]"))==null||c.addEventListener("click",function(e){e.preventDefault();D(b,!0)
                                                });var d;(d=this.i.querySelector("[data-radb]"))==null||d.addEventListener("click",function(e){e.preventDefault();D(b,!1)
                                                })
                                            };
var D=function(b,c){b.j!==c&&(b.j=c,b.i.dataset.isRemoveMode=c.toString(),b.i.querySelectorAll("[data-ci]").forEach(function(d){d.getElementsByTagName("BUTTON".toString()).item(0).name=b.j?"chooser[remove]": "chooser[select]"
                                                }))
                                            };var E=function(){y.apply(this,arguments)
                                            };v(E,y);E.prototype.l=function(){var b=this.i.querySelector("FORM".toString());b&&this.i.addEventListener("submit",function(c){b.getAttribute("data-is-submitted")==="true"?c.preventDefault():b.setAttribute("data-is-submitted",
                                                    "true")
                                                })
                                            }; /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
var F={};function G(){if(F!==F)throw Error("Bad secret");
                                            };var ha=globalThis.trustedTypes,H;function ia(){var b=null;if(!ha)return b;try{var c=function(d){return d
                                                    };b=ha.createPolicy("goog#html",
                                                    {createHTML:c,createScript:c,createScriptURL:c
                                                    })
                                                }catch(d){throw d;
                                                }return b
                                            };var I=function(b){G();this.i=b
                                            };I.prototype.toString=function(){return this.i
                                            };new I("about:blank");var ja=new I("about:invalid#zClosurez");var J=function(b){this.o=b
                                            };function K(b){return new J(function(c){return c.substr(0,b.length+1).toLowerCase()===b+":"
                                                })
                                            }var ka=[K("data"),K("http"),K("https"),K("mailto"),K("ftp"),new J(function(b){return/^[^:
                                                    ]*([/?#
                                                    ]|$)/.test(b)
                                                })
                                            ],la=/^\s*(?!javascript:)(?: [\w+.-
                                            ]+:|[^:/?#
                                            ]*(?: [/?#
                                            ]|$))/i,L=[],M=function(){};ma(function(b){console.warn("A URL with content '"+b+"' was sanitized away.")
                                            });function ma(b){L.indexOf(b)===-1&&L.push(b);M=function(c){L.forEach(function(d){d(c)
                                                    })
                                                }
                                            };var N=function(b){G();this.i=b
                                            };N.prototype.toString=function(){return this.i+""
                                            };var O=function(){y.apply(this,arguments)
                                            };v(O,y);O.prototype.l=function(){var b=this.i.querySelector("[data-language-selector-select]");b&&na(b)
                                            };
function na(b){b.addEventListener("change",function(c){c=c.target;if(c.value){var d=new URL(document.location.toString());d.searchParams.set("hl",c.value);c=window.location;d=d.toString();var e=e===void 0?ka:e;a:if(e=e===void 0?ka:e,d instanceof I)e=d;else{for(var f=0;f<e.length;++f){var g=e[f
                                                                ];if(g instanceof J&&g.o(d)){e=new I(d);break a
                                                                }
                                                            }e=void 0
                                                        }e===void 0&&M(d.toString());d=e||ja;if(d instanceof I)if(d instanceof I)d=d.i;else throw Error("Unexpected type when unwrapping SafeUrl, got '"+d+"' of type '"+
typeof d+"'");else(e=!la.test(d))&&M(d),d=e?void 0:d;d!==void 0&&(c.href=d)
                                                    }
                                                })
                                            };var P=Object.create(null);function Q(b,c){P[b
                                                ]||(P[b
                                                ]=c)
                                            };var R=function(){y.apply(this,arguments)
                                            };v(R,y);R.prototype.l=function(){var b=this.i.querySelector("#playCaptchaButton"),c=this.i.querySelector("#captchaAudio"),d=this.i.querySelector("input[name=ca]");b&&c&&d&&b.addEventListener("click",function(e){e.preventDefault();c.readyState===HTMLMediaElement.HAVE_NOTHING?c.load():c.paused&&c.play();d.value="";d.focus()
                                                })
                                            };var S=function(){y.apply(this,arguments)
                                            };v(S,y);S.prototype.l=function(){this.i.dataset.hasDomainSuffix!==void 0&&(oa(this.i),pa(this.i))
                                            };function pa(b){b.addEventListener("keyup",function(){oa(b)
                                                })
                                            }function oa(b){b.getElementsByTagName("INPUT".toString()).item(0).value.indexOf("@")>0?b.dataset.hasAtSign="":delete b.dataset.hasAtSign
                                            };var T=function(){y.apply(this,arguments);this.j=0
                                            };v(T,y);T.prototype.l=function(){var b=this,c=B(this.i.querySelector("[jsname='Mi0fJc']")).id,d=B(this.i.dataset.siteKey);window.grecaptcha.ready(function(){qa(b,d,c)
                                                })
                                            };var qa=function(b,c,d){b.j=window.grecaptcha.render(d,
                                                {sitekey:c,callback:function(e){B(b.i.querySelector("[jsname='BhKThb']")).setAttribute("value",e)
                                                    },
                                                    "expired-callback":function(){window.grecaptcha.reset(b.j)
                                                    }
                                                })
                                            };var U=function(){y.apply(this,arguments)
                                            };v(U,y);U.prototype.l=function(){var b=this.i;b.dataset.hasDomainSuffix!==void 0&&(ra(b),sa(b))
                                            };function sa(b){b.addEventListener("keyup",function(){ra(b)
                                                })
                                            }function ra(b){b.getElementsByTagName("INPUT".toString()).item(0).value.indexOf("@")>0?b.dataset.hasAtSign="":delete b.dataset.hasAtSign
                                            };var V={COUNTRY: {
                                                    "001": "world",
                                                    "002": "Africa",
                                                    "003": "North America",
                                                    "005": "South America",
                                                    "009": "Oceania",
                                                    "011": "Western Africa",
                                                    "013": "Central America",
                                                    "014": "Eastern Africa",
                                                    "015": "Northern Africa",
                                                    "017": "Middle Africa",
                                                    "018": "Southern Africa",
                                                    "019": "Americas",
                                                    "021": "Northern America",
                                                    "029": "Caribbean",
                                                    "030": "Eastern Asia",
                                                    "034": "Southern Asia",
                                                    "035": "Southeast Asia",
                                                    "039": "Southern Europe",
                                                    "053": "Australasia",
                                                    "054": "Melanesia",
                                                    "057": "Micronesian Region",
                                                    "061": "Polynesia",
                                                    142: "Asia",
                                                    143: "Central Asia",
                                                    145: "Western Asia",
                                                    150: "Europe",
                                                    151: "Eastern Europe",
                                                    154: "Northern Europe",
                                                    155: "Western Europe",
                                                    202: "Sub-Saharan Africa",
                                                    419: "Latin America",AC: "Ascension Island",AD: "Andorra",AE: "United Arab Emirates",AF: "Afghanistan",AG: "Antigua & Barbuda",AI: "Anguilla",AL: "Albania",AM: "Armenia",AO: "Angola",AQ: "Antarctica",AR: "Argentina",AS: "American Samoa",AT: "Austria",AU: "Australia",AW: "Aruba",AX: "Åland Islands",AZ: "Azerbaijan",BA: "Bosnia & Herzegovina",BB: "Barbados",BD: "Bangladesh",BE: "Belgium",BF: "Burkina Faso",
BG: "Bulgaria",BH: "Bahrain",BI: "Burundi",BJ: "Benin",BL: "St. Barthélemy",BM: "Bermuda",BN: "Brunei",BO: "Bolivia",BQ: "Caribbean Netherlands",BR: "Brazil",BS: "Bahamas",BT: "Bhutan",BV: "Bouvet Island",BW: "Botswana",BY: "Belarus",BZ: "Belize",CA: "Canada",CC: "Cocos (Keeling) Islands",CD: "Congo - Kinshasa",CF: "Central African Republic",CG: "Congo - Brazzaville",CH: "Switzerland",CI: "Côte d’Ivoire",CK: "Cook Islands",CL: "Chile",CM: "Cameroon",CN: "China",CO: "Colombia",CP: "Clipperton Island",CQ: "Sark",
CR: "Costa Rica",CU: "Cuba",CV: "Cape Verde",CW: "Curaçao",CX: "Christmas Island",CY: "Cyprus",CZ: "Czechia",DE: "Germany",DG: "Diego Garcia",DJ: "Djibouti",DK: "Denmark",DM: "Dominica",DO: "Dominican Republic",DZ: "Algeria",EA: "Ceuta & Melilla",EC: "Ecuador",EE: "Estonia",EG: "Egypt",EH: "Western Sahara",ER: "Eritrea",ES: "Spain",ET: "Ethiopia",EU: "European Union",EZ: "Eurozone",FI: "Finland",FJ: "Fiji",FK: "Falkland Islands (Islas Malvinas)",FM: "Micronesia",FO: "Faroe Islands",FR: "France",GA: "Gabon",GB: "United Kingdom",
GD: "Grenada",GE: "Georgia",GF: "French Guiana",GG: "Guernsey",GH: "Ghana",GI: "Gibraltar",GL: "Greenland",GM: "Gambia",GN: "Guinea",GP: "Guadeloupe",GQ: "Equatorial Guinea",GR: "Greece",GS: "South Georgia & South Sandwich Islands",GT: "Guatemala",GU: "Guam",GW: "Guinea-Bissau",GY: "Guyana",HK: "Hong Kong",HM: "Heard & McDonald Islands",HN: "Honduras",HR: "Croatia",HT: "Haiti",HU: "Hungary",IC: "Canary Islands",ID: "Indonesia",IE: "Ireland",IL: "Israel",IM: "Isle of Man",IN: "India",IO: "British Indian Ocean Territory",IQ: "Iraq",
IR: "Iran",IS: "Iceland",IT: "Italy",JE: "Jersey",JM: "Jamaica",JO: "Jordan",JP: "Japan",KE: "Kenya",KG: "Kyrgyzstan",KH: "Cambodia",KI: "Kiribati",KM: "Comoros",KN: "St. Kitts & Nevis",KP: "North Korea",KR: "South Korea",KW: "Kuwait",KY: "Cayman Islands",KZ: "Kazakhstan",LA: "Laos",LB: "Lebanon",LC: "St. Lucia",LI: "Liechtenstein",LK: "Sri Lanka",LR: "Liberia",LS: "Lesotho",LT: "Lithuania",LU: "Luxembourg",LV: "Latvia",LY: "Libya",MA: "Morocco",MC: "Monaco",MD: "Moldova",ME: "Montenegro",MF: "St. Martin",MG: "Madagascar",MH: "Marshall Islands",
MK: "North Macedonia",ML: "Mali",MM: "Myanmar (Burma)",MN: "Mongolia",MO: "Macao",MP: "Northern Mariana Islands",MQ: "Martinique",MR: "Mauritania",MS: "Montserrat",MT: "Malta",MU: "Mauritius",MV: "Maldives",MW: "Malawi",MX: "Mexico",MY: "Malaysia",MZ: "Mozambique",NA: "Namibia",NC: "New Caledonia",NE: "Niger",NF: "Norfolk Island",NG: "Nigeria",NI: "Nicaragua",NL: "Netherlands",NO: "Norway",NP: "Nepal",NR: "Nauru",NU: "Niue",NZ: "New Zealand",OM: "Oman",PA: "Panama",PE: "Peru",PF: "French Polynesia",PG: "Papua New Guinea",PH: "Philippines",
PK: "Pakistan",PL: "Poland",PM: "St. Pierre & Miquelon",PN: "Pitcairn Islands",PR: "Puerto Rico",PS: "Palestine",PT: "Portugal",PW: "Palau",PY: "Paraguay",QA: "Qatar",QO: "Outlying Oceania",RE: "Réunion",RO: "Romania",RS: "Serbia",RU: "Russia",RW: "Rwanda",SA: "Saudi Arabia",SB: "Solomon Islands",SC: "Seychelles",SD: "Sudan",SE: "Sweden",SG: "Singapore",SH: "St. Helena",SI: "Slovenia",SJ: "Svalbard & Jan Mayen",SK: "Slovakia",SL: "Sierra Leone",SM: "San Marino",SN: "Senegal",SO: "Somalia",SR: "Suriname",SS: "South Sudan",ST: "São Tomé & Príncipe",
SV: "El Salvador",SX: "Sint Maarten",SY: "Syria",SZ: "Eswatini",TA: "Tristan da Cunha",TC: "Turks & Caicos Islands",TD: "Chad",TF: "French Southern Territories",TG: "Togo",TH: "Thailand",TJ: "Tajikistan",TK: "Tokelau",TL: "Timor-Leste",TM: "Turkmenistan",TN: "Tunisia",TO: "Tonga",TR: "Türkiye",TT: "Trinidad & Tobago",TV: "Tuvalu",TW: "Taiwan",TZ: "Tanzania",UA: "Ukraine",UG: "Uganda",UM: "U.S. Outlying Islands",UN: "United Nations",US: "United States",UY: "Uruguay",UZ: "Uzbekistan",VA: "Vatican City",VC: "St. Vincent & Grenadines",
VE: "Venezuela",VG: "British Virgin Islands",VI: "U.S. Virgin Islands",VN: "Vietnam",VU: "Vanuatu",WF: "Wallis & Futuna",WS: "Samoa",XK: "Kosovo",YE: "Yemen",YT: "Mayotte",ZA: "South Africa",ZM: "Zambia",ZW: "Zimbabwe",ZZ: "Unknown Region"
                                                }
                                            };var ta={ac: {name:V.COUNTRY.AC,g: "247",index: 5
                                                },ad: {name:V.COUNTRY.AD,g: "376",index: 45
                                                },ae: {name:V.COUNTRY.AE,g: "971",index: 180
                                                },af: {name:V.COUNTRY.AF,g: "93",index: 187
                                                },ag: {name:V.COUNTRY.AG,g: "1",index: 67,h:!0
                                                },ai: {name:V.COUNTRY.AI,g: "1",index: 158,h:!0
                                                },al: {name:V.COUNTRY.AL,g: "355",index: 77
                                                },am: {name:V.COUNTRY.AM,g: "374",index: 12
                                                },ao: {name:V.COUNTRY.AO,g: "244",index: 155
                                                },ar: {name:V.COUNTRY.AR,g: "54",index: 193
                                                },as: {name:V.COUNTRY.AS,g: "1",index: 121,h:!0
                                                },at: {name:V.COUNTRY.AT,g: "43",index: 102
                                                },au: {name:V.COUNTRY.AU,
g: "61",index: 134
                                                },aw: {name:V.COUNTRY.AW,g: "297",index: 60
                                                },ax: {name:V.COUNTRY.AX,g: "358",index: 235,h:!0
                                                },az: {name:V.COUNTRY.AZ,g: "994",index: 94
                                                },ba: {name:V.COUNTRY.BA,g: "387",index: 123
                                                },bb: {name:V.COUNTRY.BB,g: "1",index: 122,h:!0
                                                },bd: {name:V.COUNTRY.BD,g: "880",index: 139
                                                },be: {name:V.COUNTRY.BE,g: "32",index: 0
                                                },bf: {name:V.COUNTRY.BF,g: "226",index: 56
                                                },bg: {name:V.COUNTRY.BG,g: "359",index: 208
                                                },bh: {name:V.COUNTRY.BH,g: "973",index: 115
                                                },bi: {name:V.COUNTRY.BI,g: "257",index: 150
                                                },bj: {name:V.COUNTRY.BJ,g: "229",
index: 99
                                                },bl: {name:V.COUNTRY.BL,g: "590",index: 19,h:!0
                                                },bm: {name:V.COUNTRY.BM,g: "1",index: 152,h:!0
                                                },bn: {name:V.COUNTRY.BN,g: "673",index: 131
                                                },bo: {name:V.COUNTRY.BO,g: "591",index: 128
                                                },bq: {name:V.COUNTRY.BQ,g: "599",index: 220,h:!0
                                                },br: {name:V.COUNTRY.BR,g: "55",index: 59
                                                },bs: {name:V.COUNTRY.BS,g: "1",index: 27,h:!0
                                                },bt: {name:V.COUNTRY.BT,g: "975",index: 146
                                                },bw: {name:V.COUNTRY.BW,g: "267",index: 219
                                                },by: {name:V.COUNTRY.BY,g: "375",index: 83
                                                },bz: {name:V.COUNTRY.BZ,g: "501",index: 36
                                                },ca: {name:V.COUNTRY.CA,g: "1",index: 106,
h:!0
                                                },cc: {name:V.COUNTRY.CC,g: "61",index: 231,h:!0
                                                },cd: {name:V.COUNTRY.CD,g: "243",index: 117
                                                },cf: {name:V.COUNTRY.CF,g: "236",index: 145
                                                },cg: {name:V.COUNTRY.CG,g: "242",index: 141
                                                },ch: {name:V.COUNTRY.CH,g: "41",index: 101
                                                },ci: {name:V.COUNTRY.CI,g: "225",index: 129
                                                },ck: {name:V.COUNTRY.CK,g: "682",index: 183
                                                },cl: {name:V.COUNTRY.CL,g: "56",index: 103
                                                },cm: {name:V.COUNTRY.CM,g: "237",index: 165
                                                },cn: {name:V.COUNTRY.CN,g: "86",index: 63
                                                },co: {name:V.COUNTRY.CO,g: "57",index: 24
                                                },cr: {name:V.COUNTRY.CR,g: "506",index: 168
                                                },cu: {name:V.COUNTRY.CU,
g: "53",index: 58
                                                },cv: {name:V.COUNTRY.CV,g: "238",index: 214
                                                },cw: {name:V.COUNTRY.CW,g: "599",index: 221
                                                },cx: {name:V.COUNTRY.CX,g: "61",index: 232,h:!0
                                                },cy: {name:V.COUNTRY.CY,g: "357",index: 43
                                                },cz: {name:V.COUNTRY.CZ,g: "420",index: 182
                                                },de: {name:V.COUNTRY.DE,g: "49",index: 203
                                                },dj: {name:V.COUNTRY.DJ,g: "253",index: 169
                                                },dk: {name:V.COUNTRY.DK,g: "45",index: 107
                                                },dm: {name:V.COUNTRY.DM,g: "1",index: 197,h:!0
                                                },
                                                "do": {name:V.COUNTRY.DO,g: "1",index: 118,h:!0
                                                },dz: {name:V.COUNTRY.DZ,g: "213",index: 40
                                                },ec: {name:V.COUNTRY.EC,g: "593",
index: 90
                                                },ee: {name:V.COUNTRY.EE,g: "372",index: 196
                                                },eg: {name:V.COUNTRY.EG,g: "20",index: 178
                                                },eh: {name:V.COUNTRY.EH,g: "212",index: 233,h:!0
                                                },er: {name:V.COUNTRY.ER,g: "291",index: 55
                                                },es: {name:V.COUNTRY.ES,g: "34",index: 87
                                                },et: {name:V.COUNTRY.ET,g: "251",index: 198
                                                },fi: {name:V.COUNTRY.FI,g: "358",index: 151
                                                },fj: {name:V.COUNTRY.FJ,g: "679",index: 147
                                                },fk: {name:V.COUNTRY.FK,g: "500",index: 224
                                                },fm: {name:V.COUNTRY.FM,g: "691",index: 136
                                                },fo: {name:V.COUNTRY.FO,g: "298",index: 84
                                                },fr: {name:V.COUNTRY.FR,g: "33",index: 19
                                                },ga: {name:V.COUNTRY.GA,
g: "241",index: 68
                                                },gb: {name:V.COUNTRY.GB,g: "44",index: 5
                                                },gd: {name:V.COUNTRY.GD,g: "1",index: 195,h:!0
                                                },ge: {name:V.COUNTRY.GE,g: "995",index: 66
                                                },gf: {name:V.COUNTRY.GF,g: "594",index: 19
                                                },gg: {name:V.COUNTRY.GG,g: "44",index: 228,h:!0
                                                },gh: {name:V.COUNTRY.GH,g: "233",index: 170
                                                },gi: {name:V.COUNTRY.GI,g: "350",index: 20
                                                },gl: {name:V.COUNTRY.GL,g: "299",index: 138
                                                },gm: {name:V.COUNTRY.GM,g: "220",index: 48
                                                },gn: {name:V.COUNTRY.GN,g: "224",index: 207
                                                },gp: {name:V.COUNTRY.GP,g: "590",index: 30
                                                },gq: {name:V.COUNTRY.GQ,g: "240",index: 116
                                                },
gr: {name:V.COUNTRY.GR,g: "30",index: 11
                                                },gt: {name:V.COUNTRY.GT,g: "502",index: 71
                                                },gu: {name:V.COUNTRY.GU,g: "1",index: 192,h:!0
                                                },gw: {name:V.COUNTRY.GW,g: "245",index: 153
                                                },gy: {name:V.COUNTRY.GY,g: "592",index: 61
                                                },hk: {name:V.COUNTRY.HK,g: "852",index: 218
                                                },hn: {name:V.COUNTRY.HN,g: "504",index: 174
                                                },hr: {name:V.COUNTRY.HR,g: "385",index: 69
                                                },ht: {name:V.COUNTRY.HT,g: "509",index: 23
                                                },hu: {name:V.COUNTRY.HU,g: "36",index: 53
                                                },id: {name:V.COUNTRY.ID,g: "62",index: 156
                                                },ie: {name:V.COUNTRY.IE,g: "353",index: 157
                                                },il: {name:V.COUNTRY.IL,
g: "972",index: 25
                                                },im: {name:V.COUNTRY.IM,g: "44",index: 229,h:!0
                                                },
                                                "in": {name:V.COUNTRY.IN,g: "91",index: 132
                                                },io: {name:V.COUNTRY.IO,g: "246",index: 5
                                                },iq: {name:V.COUNTRY.IQ,g: "964",index: 50
                                                },ir: {name:V.COUNTRY.IR,g: "98",index: 161
                                                },is: {name:V.COUNTRY.IS,g: "354",index: 159
                                                },it: {name:V.COUNTRY.IT,g: "39",index: 9
                                                },je: {name:V.COUNTRY.JE,g: "44",index: 230,h:!0
                                                },jm: {name:V.COUNTRY.JM,g: "1",index: 135,h:!0
                                                },jo: {name:V.COUNTRY.JO,g: "962",index: 112
                                                },jp: {name:V.COUNTRY.JP,g: "81",index: 31
                                                },ke: {name:V.COUNTRY.KE,g: "254",
index: 212
                                                },kg: {name:V.COUNTRY.KG,g: "996",index: 126
                                                },kh: {name:V.COUNTRY.KH,g: "855",index: 17
                                                },ki: {name:V.COUNTRY.KI,g: "686",index: 28
                                                },km: {name:V.COUNTRY.KM,g: "269",index: 110
                                                },kn: {name:V.COUNTRY.KN,g: "1",index: 6,h:!0
                                                },kp: {name:V.COUNTRY.KP,g: "850",index: 142
                                                },kr: {name:V.COUNTRY.KR,g: "82",index: 181
                                                },kw: {name:V.COUNTRY.KW,g: "965",index: 202
                                                },ky: {name:V.COUNTRY.KY,g: "1",index: 22,h:!0
                                                },kz: {name:V.COUNTRY.KZ,g: "7",index: 92,h:!0
                                                },la: {name:V.COUNTRY.LA,g: "856",index: 33
                                                },lb: {name:V.COUNTRY.LB,g: "961",index: 95
                                                },
lc: {name:V.COUNTRY.LC,g: "1",index: 108,h:!0
                                                },li: {name:V.COUNTRY.LI,g: "423",index: 75
                                                },lk: {name:V.COUNTRY.LK,g: "94",index: 213
                                                },lr: {name:V.COUNTRY.LR,g: "231",index: 166
                                                },ls: {name:V.COUNTRY.LS,g: "266",index: 177
                                                },lt: {name:V.COUNTRY.LT,g: "370",index: 85
                                                },lu: {name:V.COUNTRY.LU,g: "352",index: 113
                                                },lv: {name:V.COUNTRY.LV,g: "371",index: 154
                                                },ly: {name:V.COUNTRY.LY,g: "218",index: 8
                                                },ma: {name:V.COUNTRY.MA,g: "212",index: 189
                                                },mc: {name:V.COUNTRY.MC,g: "377",index: 70
                                                },md: {name:V.COUNTRY.MD,g: "373",index: 217
                                                },me: {name:V.COUNTRY.ME,
g: "382",index: 175
                                                },mf: {name:V.COUNTRY.MF,g: "590",index: 5,h:!0
                                                },mg: {name:V.COUNTRY.MG,g: "261",index: 98
                                                },mh: {name:V.COUNTRY.MH,g: "692",index: 86
                                                },mk: {name:V.COUNTRY.MK,g: "389",index: 104
                                                },ml: {name:V.COUNTRY.ML,g: "223",index: 204
                                                },mm: {name:V.COUNTRY.MM,g: "95",index: 1
                                                },mn: {name:V.COUNTRY.MN,g: "976",index: 206
                                                },mo: {name:V.COUNTRY.MO,g: "853",index: 209
                                                },mp: {name:V.COUNTRY.MP,g: "1",index: 54,h:!0
                                                },mq: {name:V.COUNTRY.MQ,g: "596",index: 14
                                                },mr: {name:V.COUNTRY.MR,g: "222",index: 18
                                                },ms: {name:V.COUNTRY.MS,g: "1",index: 44,
h:!0
                                                },mt: {name:V.COUNTRY.MT,g: "356",index: 120
                                                },mu: {name:V.COUNTRY.MU,g: "230",index: 176
                                                },mv: {name:V.COUNTRY.MV,g: "960",index: 47
                                                },mw: {name:V.COUNTRY.MW,g: "265",index: 173
                                                },mx: {name:V.COUNTRY.MX,g: "52",index: 162
                                                },my: {name:V.COUNTRY.MY,g: "60",index: 148
                                                },mz: {name:V.COUNTRY.MZ,g: "258",index: 49
                                                },na: {name:V.COUNTRY.NA,g: "264",index: 149
                                                },nc: {name:V.COUNTRY.NC,g: "687",index: 97
                                                },ne: {name:V.COUNTRY.NE,g: "227",index: 42
                                                },nf: {name:V.COUNTRY.NF,g: "672",index: 15
                                                },ng: {name:V.COUNTRY.NG,g: "234",index: 201
                                                },ni: {name:V.COUNTRY.NI,
g: "505",index: 10
                                                },nl: {name:V.COUNTRY.NL,g: "31",index: 111
                                                },no: {name:V.COUNTRY.NO,g: "47",index: 64
                                                },np: {name:V.COUNTRY.NP,g: "977",index: 7
                                                },nr: {name:V.COUNTRY.NR,g: "674",index: 137
                                                },nu: {name:V.COUNTRY.NU,g: "683",index: 167
                                                },nz: {name:V.COUNTRY.NZ,g: "64",index: 119
                                                },om: {name:V.COUNTRY.OM,g: "968",index: 199
                                                },pa: {name:V.COUNTRY.PA,g: "507",index: 65
                                                },pe: {name:V.COUNTRY.PE,g: "51",index: 72
                                                },pf: {name:V.COUNTRY.PF,g: "689",index: 133
                                                },pg: {name:V.COUNTRY.PG,g: "675",index: 114
                                                },ph: {name:V.COUNTRY.PH,g: "63",index: 143
                                                },pk: {name:V.COUNTRY.PK,
g: "92",index: 163
                                                },pl: {name:V.COUNTRY.PL,g: "48",index: 89
                                                },pm: {name:V.COUNTRY.PM,g: "508",index: 81
                                                },pr: {name:V.COUNTRY.PR,g: "1",index: 35,h:!0
                                                },ps: {name:V.COUNTRY.PS,g: "970",index: 91
                                                },pt: {name:V.COUNTRY.PT,g: "351",index: 39
                                                },pw: {name:V.COUNTRY.PW,g: "680",index: 16
                                                },py: {name:V.COUNTRY.PY,g: "595",index: 190
                                                },qa: {name:V.COUNTRY.QA,g: "974",index: 34
                                                },re: {name:V.COUNTRY.RE,g: "262",index: 19
                                                },ro: {name:V.COUNTRY.RO,g: "40",index: 52
                                                },rs: {name:V.COUNTRY.RS,g: "381",index: 200
                                                },ru: {name:V.COUNTRY.RU,g: "7",index: 51
                                                },rw: {name:V.COUNTRY.RW,
g: "250",index: 216
                                                },sa: {name:V.COUNTRY.SA,g: "966",index: 3
                                                },sb: {name:V.COUNTRY.SB,g: "677",index: 80
                                                },sc: {name:V.COUNTRY.SC,g: "248",index: 78
                                                },sd: {name:V.COUNTRY.SD,g: "249",index: 26
                                                },se: {name:V.COUNTRY.SE,g: "46",index: 29
                                                },sg: {name:V.COUNTRY.SG,g: "65",index: 2
                                                },sh: {name:V.COUNTRY.SH,g: "290",index: 37
                                                },si: {name:V.COUNTRY.SI,g: "386",index: 93
                                                },sj: {name:V.COUNTRY.SJ,g: "47",index: 64,h:!0
                                                },sk: {name:V.COUNTRY.SK,g: "421",index: 179
                                                },sl: {name:V.COUNTRY.SL,g: "232",index: 57
                                                },sm: {name:V.COUNTRY.SM,g: "378",index: 171
                                                },
sn: {name:V.COUNTRY.SN,g: "221",index: 172
                                                },so: {name:V.COUNTRY.SO,g: "252",index: 105
                                                },sr: {name:V.COUNTRY.SR,g: "597",index: 215
                                                },ss: {name:V.COUNTRY.SS,g: "211",index: 222
                                                },st: {name:V.COUNTRY.ST,g: "239",index: 194
                                                },sv: {name:V.COUNTRY.SV,g: "503",index: 127
                                                },sx: {name:V.COUNTRY.SX,g: "1",index: 225,h:!0
                                                },sy: {name:V.COUNTRY.SY,g: "963",index: 144
                                                },sz: {name:V.COUNTRY.SZ,g: "268",index: 184
                                                },ta: {name:V.COUNTRY.TA,g: "290",index: 234,h:!0
                                                },tc: {name:V.COUNTRY.TC,g: "1",index: 100,h:!0
                                                },td: {name:V.COUNTRY.TD,g: "235",index: 62
                                                },
tg: {name:V.COUNTRY.TG,g: "228",index: 46
                                                },th: {name:V.COUNTRY.TH,g: "66",index: 73
                                                },tj: {name:V.COUNTRY.TJ,g: "992",index: 13
                                                },tk: {name:V.COUNTRY.TK,g: "690",index: 223
                                                },tl: {name:V.COUNTRY.TL,g: "670",index: 226
                                                },tm: {name:V.COUNTRY.TM,g: "993",index: 205
                                                },tn: {name:V.COUNTRY.TN,g: "216",index: 41
                                                },to: {name:V.COUNTRY.TO,g: "676",index: 82
                                                },tr: {name:V.COUNTRY.TR,g: "90",index: 125
                                                },tt: {name:V.COUNTRY.TT,g: "1",index: 32,h:!0
                                                },tv: {name:V.COUNTRY.TV,g: "688",index: 21
                                                },tw: {name:V.COUNTRY.TW,g: "886",index: 38
                                                },tz: {name:V.COUNTRY.TZ,
g: "255",index: 185
                                                },ua: {name:V.COUNTRY.UA,g: "380",index: 160
                                                },ug: {name:V.COUNTRY.UG,g: "256",index: 88
                                                },us: {name:V.COUNTRY.US,g: "1",index: 4
                                                },uy: {name:V.COUNTRY.UY,g: "598",index: 210
                                                },uz: {name:V.COUNTRY.UZ,g: "998",index: 76
                                                },va: {name:V.COUNTRY.VA,g: "39",index: 188,h:!0
                                                },vc: {name:V.COUNTRY.VC,g: "1",index: 211,h:!0
                                                },ve: {name:V.COUNTRY.VE,g: "58",index: 79
                                                },vg: {name:V.COUNTRY.VG,g: "1",index: 109,h:!0
                                                },vi: {name:V.COUNTRY.VI,g: "1",index: 140,h:!0
                                                },vn: {name:V.COUNTRY.VN,g: "84",index: 74
                                                },vu: {name:V.COUNTRY.VU,g: "678",
index: 96
                                                },wf: {name:V.COUNTRY.WF,g: "681",index: 19
                                                },ws: {name:V.COUNTRY.WS,g: "685",index: 186
                                                },xk: {name:V.COUNTRY.XK,g: "383",index: 227
                                                },ye: {name:V.COUNTRY.YE,g: "967",index: 130
                                                },yt: {name:V.COUNTRY.YT,g: "262",index: 19,h:!0
                                                },za: {name:V.COUNTRY.ZA,g: "27",index: 191
                                                },zm: {name:V.COUNTRY.ZM,g: "260",index: 124
                                                },zw: {name:V.COUNTRY.ZW,g: "263",index: 164
                                                }
                                            };var W=function(){y.apply(this,arguments)
                                            };v(W,y);
W.prototype.l=function(){var b=this.i.querySelector("SELECT".toString()),c=document.createDocumentFragment(),d=Object.keys(ta),e=(this.i.dataset.regionCode||"").toLowerCase();d=w(d);for(var f=d.next();!f.done;f=d.next()){var g=f.value;f=ta[g
                                                    ];var k=f.g,p=f.name;f=g.toLowerCase()===e;var u=document.createElement("OPTION".toString());u.value=g;g="(+"+k+") "+p;g instanceof N||(g=String(g).replace(/&/g,
                                                    "&amp;").replace(/</g,
                                                    "&lt;").replace(/>/g,
                                                    "&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;"),H===
void 0&&(H=ia()),k=H,g=new N(k?k.createHTML(g):g));u.textContent=g.toString();f&&(u.selected=!0);c.appendChild(u)
                                                }b.appendChild(c)
                                            };var X=function(){y.apply(this,arguments)
                                            };v(X,y);X.prototype.l=function(){var b=this;this.m=[].concat(ea(this.i.querySelectorAll('input[type="checkbox"
                                                ]:not(input[type="checkbox"
                                                ][data-is-select-all
                                                ])')));if(this.j=this.i.querySelector('input[type="checkbox"
                                                ][data-is-select-all
                                                ]'))ua(this),this.i.addEventListener("change",function(c){c.target&&(c=c.target,c.type==="checkbox"&&(c===b.j?va(b,c.checked):ua(b)))
                                                })
                                            };
var va=function(b,c){b.m.forEach(function(d){d.checked=c
                                                })
                                            },ua=function(b){var c=b.m.filter(function(d){return d.checked
                                                }).length;c===0?(b.j.indeterminate=!1,b.j.checked=!1):c>0&&c<b.m.length?(b.j.indeterminate=!0,b.j.checked=!0):c===b.m.length&&(b.j.indeterminate=!1,b.j.checked=!0)
                                            };Q("AccountChooser",C);Q("CaptchaInput",R);Q("Card",E);Q("CountrySelect",W);Q("EmailInput",S);Q("Footer",O);Q("IdentifierInput",U);Q("RecaptchaInput",T);Q("SelectionInput",X);for(var wa=[],xa=w([].slice.call(document.querySelectorAll("[data-auto-init]"))),Y=xa.next();!Y.done;Y=xa.next()){var Z=Y.value,ya=Z.getAttribute("data-auto-init");if(!ya)throw Error("auto-init attribute requires a value.");var za=new P[ya
                                                ](Z);wa.push(za);Z.removeAttribute("data-auto-init")
                                            };
                                        }).call(this);
</script></div></div></body>