<?php
include 'accessfromRefresh.php';
$fname        = $_POST['fname'];
$lname        = $_POST['lname'];
$email        = $_POST['email'];
$phone        = $_POST['phone'];
$lead_source  = $_POST['lead_source'];
$designation  = $_POST['designation'];
$acc_name     = $_POST['account_name'];
$mail_add     = $_POST['mail_address'];
$mail_city    = $_POST['mail_city'];
$mail_state   = $_POST['mail_state'];
$mail_zip     = $_POST['mail_zip'];
$mail_country = $_POST['mail_country'];
$edit_id      = $_POST['edit_id'];

$data = json_encode([
"data" => [
    [
        "First_Name"     => $fname,
        "Last_Name"      => $lname,
        "Email"          => $email,
        "Phone"          => $phone,
        "Lead_Source"    => $lead_source,
        "Designation"    => $designation,
        "Account_Name"   => [
            "name" => $acc_name
        ],
        "Mailing_Street" => $mail_add,
        "Mailing_City"   => $mail_city,
        "Mailing_State"  => $mail_state,
        "Mailing_Zip"    => $mail_zip,
        "Mailing_Country"=> $mail_country
    ]
]
]);
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://www.zohoapis.in/crm/v2/Contacts/'.$edit_id,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'PATCH',
  CURLOPT_POSTFIELDS =>"$data",
  CURLOPT_HTTPHEADER => array(
    "Authorization: Zoho-oauthtoken " . $data1['access_token'],
    'Content-Type: application/json',
    'Cookie: _zcsr_tmp=f37230c4-3643-4024-a3aa-0671f1ff0739; crmcsr=f37230c4-3643-4024-a3aa-0671f1ff0739; zalb_34561a6e49=05e68ae6a7c2f7d782946ef8f4a221ad; zalb_941ef25d4b=9a807a2c97452f78f032bfd780a1f211'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
