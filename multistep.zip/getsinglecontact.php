<?php
include 'accessfromRefresh.php';
$edit_id =$_GET['Id'];
$curl = curl_init();
$edit_id;
$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => "https://www.zohoapis.in/crm/v2/contacts/".$edit_id."?fields=Full_Name%2CEmail%2CPhone%2Cid%2CMailing_State%2CMailing_Country%2CMailing_City%2CMailing_Street%2CMailing_Zip%2CLead_Source%2CDesignation%2CAccount_Name",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    "Authorization: Zoho-oauthtoken " . $data1['access_token'],
    'Content-Type: application/json',
    'Cookie: _zcsr_tmp=f37230c4-3643-4024-a3aa-0671f1ff0739; crmcsr=f37230c4-3643-4024-a3aa-0671f1ff0739; zalb_34561a6e49=05e68ae6a7c2f7d782946ef8f4a221ad; zalb_941ef25d4b=9a807a2c97452f78f032bfd780a1f211'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
