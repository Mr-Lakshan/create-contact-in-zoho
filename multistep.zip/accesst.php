<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://accounts.zoho.in/oauth/v2/token',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'grant_type=authorization_code&client_id=1000.VXGLDRHL8UNEI430WEUAXOUJEXSRID&client_secret=03e20015f8f02acc541c7545b00d0eefc437a38c61&redirect_uri=https%3A%2F%2Fmdev.topscripts.in%2Fauth%2Fzoho.php&code=1000.5b913cab20a204cc6ab124a62089b3df.018d3f9f4d0e1397bb9b69c5d27fe580',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded',
    'Cookie: _zcsr_tmp=2fa05361-895b-4f3a-b012-1d840ca1f8c7; iamcsr=2fa05361-895b-4f3a-b012-1d840ca1f8c7; zalb_6e73717622=cc36c6f8a6790832246efd66c032e512'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
?>