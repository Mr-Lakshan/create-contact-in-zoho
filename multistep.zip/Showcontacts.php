<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Contacts</title>
    <style>
body {
    font-family: 'Arial', sans-serif;
    background-color: #FFFFFF;
    color: #333333;
}

table {
    width: 100%;
    border-collapse: collapse;
    background-color: #F7F7F7;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    overflow: hidden;
    /* table-layout: fixed;  Ensures even column width distribution */
    box-sizing: border-box;  /* Prevents overflow due to padding or borders */
}

thead {
    background-color: #3479e2;
    color: white;
}

th {
    padding: 8px;
    text-align: center;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 12px;
    overflow: hidden;
}

td {
    padding: 5px 8px;
    border-bottom: 1px solid #B2DFDB;
    text-align: center;
    /* overflow: hidden; */
    /* white-space: nowrap; */
}

tbody tr:hover {
    background-color: #E1F5FE;
    transition: background-color 0.2s ease;
}

tbody tr:last-child td {
    border-bottom: none;
}

/* Container for action buttons (edit & delete) */
.action-buttons {
    display: flex;
    justify-content: center;
    gap: 10px;
    align-items: center; /* Align buttons vertically in the center */
}

.edit-btn-2, .delete-btn-2 {
    padding: 2px 5px;
    background: transparent;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 12px;
}

.edit-btn-2 {
    color: black;
    border: 2px solid #3156cf;
}

.delete-btn-2 {
    color: #d1172f;
    border: 2px solid #FFB74D;
}

.edit-btn-2:hover {
    background: #2f2cd8;
    color: white;
}

.delete-btn-2:hover {
    background: #FFB74D;
    color: black;
}

@media screen and (max-width: 768px) {
    table {
        display: block;
        overflow-x: auto;
        white-space: nowrap;
    }
}

tbody tr:nth-child(even) {
    background-color: #F7F7F7;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.button-container {
    display: flex;
    justify-content: flex-start;
    gap: 20px;
    margin: 20px 0;
}

button {
    padding: 5px 8px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    border-radius: 6px;
    cursor: pointer;
    outline: none;
    transition: all 0.3s ease-in-out;
    border: none;
    align-items: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: auto;
}

button:focus {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.new-contact {
    background-color: #FF8A65;
    color: white;
    transition: background-color 0.3s, transform 0.2s ease-in-out;
}

.new-contact:hover {
    background-color: #FF7043;
    transform: scale(1.05);
}

.new-contact:active {
    background-color: #FF5722;
}

.export {
    background-color: #355ddf;
    color: white;
    transition: background-color 0.3s, transform 0.2s ease-in-out;
}

.export:hover {
    background-color: #3d5af1;
    transform: scale(1.05);
}

.export:active {
    background-color: #2d48c1;
}

#csvUpload {
    padding: 5px 5px;
    font-size: 14px;
    font-weight: 600;
    border-radius: 6px;
    cursor: pointer;
    background-color: #28a745;
    color: white;
    border: none;
    display: inline-block;
    transition: background-color 0.3s, transform 0.2s ease-in-out;
    margin-right: 5%;
}

#csvUpload:hover {
    background-color: #218838;
    transform: scale(1.05);
}

#csvUpload:active {
    background-color: #1e7e34;
}

.button-container2 {
    display: inline-flex;
    float: inline-end;
    gap: 1em;
    margin: 1%;
}

#importBtn {
    background-color: #2d48c1;
    color: #FFFFFF;
}

.last-td {
    background-color: black;
}

    </style>
</head>
<body>
    <div class="button-container2"> 
        <button type="button" class="new-contact">Add New</a></button>
        <button type="button" class="export" id="export-btn">Export csv</a></button>
        <input type="file" id="csvUpload" accept=".csv">
        <button id="importBtn">Import CSV</button>
    </div>
        <div class="container">
            <table id="contactTable">
            <thead >
                <tr>
                    <th>Id</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Street</th>
                    <th>State</th>
                    <th>Country</th>
                    <th>Zip</th>
                    <th colspan="2">Actions</th>
                </tr>
            </thead>
            <tbody id="tabledata">
            </tbody>
        </table>
    </div>

    <script>
        $.ajax({
            url:"getcontacts.php",
            method:"GET",
            success:function (response) {
                console.log(response);
                let data = JSON.parse(response);
                
                data.data.forEach(function(contact) {
                    let row = '<tr>';
                    row += '<td>' + contact.id + '</td>';
                    row += '<td>' + contact.Full_Name + '</td>';
                    row += '<td>' + contact.Email + '</td>';
                    row += '<td>' + contact.Phone + '</td>';
                    row += '<td>' + contact.Mailing_Street + '</td>';
                    row += '<td>' + contact.Mailing_State + '</td>';
                    row += '<td>' + contact.Mailing_Country + '</td>';
                    row += '<td>' + contact.Mailing_Zip + '</td>';
                    
                    row += '<td class="action-buttons"> <button class="edit-btn-2" value="' + contact.id + '">Edit</button>  </td>';
                    row += '<td class="action"> <button class="delete-btn-2" value="' + contact.id + '">Delete</button> </td>';
                    row += '</tr>';
                    $('#tabledata').append(row);
                });
            }
        });
        
        $(document).on('click','.edit-btn-2',function () {
           
            let editId = $(this).val();
            
            $.ajax({
                url:    'editForm.php',
                method: 'POST',
                data:   editId,
                success:function (response) {
                    sessionStorage.setItem("Id", editId);
                    window.location.href = "http://localhost/lakshan/editform.php";
                }
            })

        })
        $(document).on('click','.new-contact',function () {
            localStorage.clear();
            window.location.href='newform.php';
        })
        $(document).on('click', '.delete-btn-2', function () {
    let delId = $(this).val();
    let delItem = $(this).closest('tr'); 
    Swal.fire({
  title: 'Are you sure?',
  text: 'You won\'t be able to revert this!',
  icon: 'warning',
  showCancelButton: true,  
  confirmButtonText: 'Yes, delete it!',  
  cancelButtonText: 'No, keep it'  
}).then((result) => {
  if (result.isConfirmed) {
    $.ajax({
        url: 'deletesingle.php',
        method: 'POST',
        data: { id: delId }, 
        success: function (response) {
            console.log(response);
            let parsedResponse = JSON.parse(response);

           
            if (parsedResponse.data && parsedResponse.data[0].status === 'success') {
                delItem.fadeOut('fast');
             } else {
                Swal.fire('Error: Could not delete the contact');
            }
        },
        error: function () {
            Swal.fire('Error: Something went wrong with the request.');
        }
    });
    
  } else if (result.isDismissed) {
    
    console.log('Action canceled');
  }
});

    
});

$(document).on('click', '#export-btn', function() {
  var tableData = [];

  // Extract table headers
//   var headers = [];
//   $('#contactTable thead th').each(function() {
//     headers.push($(this).text().trim());
//   });

//   tableData.push(headers.join(','));

  // Extract table rows
  $('#contactTable tbody tr').each(function() {
    var row = [];
    $(this).find('td').each(function() {
      row.push($(this).text().trim());
    });
    tableData.push(row.join(','));
  });

  
  var csvString = tableData.join('\n');


  var blob = new Blob([csvString], { type: 'text/csv' });

 
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = 'table_data.csv';
  a.click();

 
  URL.revokeObjectURL(url);
});


$('#importBtn').on('click', function () {
    var fileInput = $('#csvUpload')[0];


    if (fileInput.files.length === 0) {
        Swal.fire('Please select a CSV file.');
        return;
    }

    var file = fileInput.files[0];
    var reader = new FileReader();
    reader.onload = function (e) {
        var csvContent = e.target.result;
        var data = parseCSV(csvContent);
        populateTable(data);
    };

    reader.readAsText(file);
});

function parseCSV(csvContent) {
    var rows = csvContent.split('\n');
    var data = [];

    rows.forEach(function (row, index) {
        var cells = row.split(',');

        
        cells = cells.map(cell => cell.trim());

        //var cellss = cells.pop();
        data.push(cells);
    });

    return data;
}
function populateTable(data) {
    var tableBody = $('#contactTable tbody');
    $(tableBody).empty();  // Clear existing table data

    for (var i = 0; i < data.length; i++) {
        var row = '<tr>';
        let id = data[i][0];
        console.log(id);
        data[i].forEach(function(column, index) {
            var tdContent = column; 
           
            if (i==0) {
                tdContent = column;
                
            }
      
            else{

                
                
                if (index === data[i].length - 1) {
                    
                    tdContent = `<button class="delete-btn-2" value = "${id}">Delete</button>`;
                }
                
                
                else if (index === data[i].length - 2) {
                    if(i==0){
                        tdContent = column;
                    }
                    tdContent = `<button class="edit-btn-2" value = "${id}">Edit</button>`;
                }
            }

           
            row += `<td>${tdContent}</td>`;
        });

        row += '</tr>';
        tableBody.append(row); 
    }
}




    </script>
</body>
</html>
