<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://accounts.zoho.in/oauth/v2/token',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('grant_type' => 'refresh_token','client_id' => '1000.VXGLDRHL8UNEI430WEUAXOUJEXSRID','client_secret' => '03e20015f8f02acc541c7545b00d0eefc437a38c61','refresh_token' => '1000.bb4e95a1d6f2812305a2c6bb2ff6ec85.399e553ae25b615430d1529e24d28f0d','redirect_uri' => 'https://mdev.topscripts.in/auth/zoho.php'),
  CURLOPT_HTTPHEADER => array(
    'Cookie: _zcsr_tmp=2fa05361-895b-4f3a-b012-1d840ca1f8c7; iamcsr=2fa05361-895b-4f3a-b012-1d840ca1f8c7; zalb_6e73717622=cc36c6f8a6790832246efd66c032e512'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
// echo var_dump($response);

$data1=json_decode($response,true);
//  print_r($data1);  

?>
